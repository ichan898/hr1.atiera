<?php
// File: profile_dropdown.php
// Profile dropdown component
?>
<div class="relative">
  <button id="profile-menu" class="flex items-center space-x-2 p-2 hover:bg-gray-100 rounded-lg">
    <div class="w-10 h-10 bg-gray-700 rounded-lg flex items-center justify-center overflow-hidden">
      <img 
        src="assets/logo2.png" 
        alt="HR1 Logo"
        class="w-8 h-8 object-contain"
      >
    </div>
    <div class="text-left">
      <p class="text-sm font-medium"><?php echo htmlspecialchars($_SESSION['user_name'] ?? 'HR User'); ?></p>
      <p class="text-xs text-gray-500"><?php echo htmlspecialchars($_SESSION['user_role'] ?? 'HR Officer'); ?></p>
    </div>
    <i data-lucide="chevron-down" class="w-4 h-4 text-gray-500"></i>
  </button>
  <div id="profile-dropdown" class="hidden absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border z-50">
    <!-- <a href="profile.php" class="block px-4 py-3 hover:bg-gray-50">
      <div class="flex items-center space-x-2">
        <i data-lucide="user" class="w-4 h-4"></i>
        <span>My Profile</span>
      </div>
    </a> -->
    <!-- <a href="settings.php" class="block px-4 py-3 hover:bg-gray-50">
      <div class="flex items-center space-x-2">
        <i data-lucide="settings" class="w-4 h-4"></i>
        <span>Settings</span>
      </div>
    </a> -->
    <div class="border-t"></div>
    <a href="logout.php" class="block px-4 py-3 text-red-600 hover:bg-red-50">
      <div class="flex items-center space-x-2">
        <i data-lucide="log-out" class="w-4 h-4"></i>
        <span>Logout</span>
      </div>
    </a>
  </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
  // Profile dropdown toggle
  const profileMenu = document.getElementById('profile-menu');
  const profileDropdown = document.getElementById('profile-dropdown');
  
  if (profileMenu) {
    profileMenu.addEventListener('click', function(e) {
      e.stopPropagation();
      profileDropdown.classList.toggle('hidden');
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', function(event) {
      if (!profileMenu.contains(event.target) && !profileDropdown.contains(event.target)) {
        profileDropdown.classList.add('hidden');
      }
    });
  }
});
</script>