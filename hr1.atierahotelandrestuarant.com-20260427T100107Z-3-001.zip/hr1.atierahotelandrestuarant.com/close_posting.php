<?php
// File: close_posting.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

$id = $_GET['id'] ?? null;
if (!$id) {
    header('Location: job_postings.php');
    exit();
}

// Update status to closed
$stmt = $connections->prepare("UPDATE job_postings SET status = 'closed', updated_at = NOW() WHERE id = ?");
$stmt->execute([$id]);

header('Location: job_postings.php?success=closed');
exit();
?>