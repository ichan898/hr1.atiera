<?php
// File: new_job_posting.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

// Fetch departments from database for dropdown
$departments = [];
try {
    $stmt = $pdo->query("SELECT id, name FROM departments WHERE is_active = 1 ORDER BY name");
    $departments = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error fetching departments: " . $e->getMessage());
    $error = "Unable to load department list.";
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        // Calculate salary range from min/max if provided
        $salary_range = null;
        $salary_min = null;
        $salary_max = null;
        
        if (!empty($_POST['salary_min']) && !empty($_POST['salary_max'])) {
            $salary_min = floatval($_POST['salary_min']);
            $salary_max = floatval($_POST['salary_max']);
            $salary_range = "₱" . number_format($salary_min, 2) . " - ₱" . number_format($salary_max, 2);
        }
        
        // Get department name from department_id
        $department_name = '';
        if (!empty($_POST['department_id'])) {
            $stmt = $pdo->prepare("SELECT name FROM departments WHERE id = ?");
            $stmt->execute([$_POST['department_id']]);
            $dept = $stmt->fetch(PDO::FETCH_ASSOC);
            $department_name = $dept['name'] ?? '';
        }
        
        $data = [
            'job_title' => $_POST['job_title'] ?? '',
            'job_code' => $_POST['job_code'] ?? '',
            'department' => $department_name,
            'department_id' => $_POST['department_id'] ?? null,
            'location' => $_POST['location'] ?? '',
            'employment_type' => $_POST['employment_type'] ?? 'full_time',
            'salary_range' => $salary_range,
            'salary_min' => $salary_min,
            'salary_max' => $salary_max,
            'experience_level' => $_POST['experience_level'] ?? 'mid',
            'description' => $_POST['description'] ?? '',
            'requirements' => $_POST['requirements'] ?? '',
            'responsibilities' => $_POST['responsibilities'] ?? '',
            'benefits' => $_POST['benefits'] ?? '',
            'status' => $_POST['status'] ?? 'draft',
            'vacancies' => $_POST['vacancies'] ?? 1,
            'published_date' => !empty($_POST['published_date']) ? $_POST['published_date'] : date('Y-m-d'),
            'closing_date' => $_POST['closing_date'] ?? null,
            'posting_date' => date('Y-m-d'),
            'created_by' => $_SESSION['user_id']
        ];
        
        // Remove null values for optional fields
        foreach ($data as $key => $value) {
            if (is_null($value)) {
                unset($data[$key]);
            }
        }
        
        if (createJobPosting($data, $_SESSION['user_id'])) {
            header('Location: job_postings.php?success=created');
            exit();
        } else {
            $error = "Failed to create job posting. Please try again.";
        }
    } catch (Exception $e) {
        error_log("Error creating job posting: " . $e->getMessage());
        $error = "An error occurred while creating the job posting.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>HR1 - New Job Posting</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
</head>

<body class="h-screen bg-gray-100 font-sans">
<div class="flex h-full">
  <?php include 'sidebar.php'; ?>
  
  <div class="flex-1 flex flex-col overflow-y-auto">
    <main class="p-6">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-gray-300 pb-4 mb-6">
        <div>
          <h2 class="text-2xl font-bold text-gray-800">Create New Job Posting</h2>
          <p class="text-sm text-gray-600">Fill in the details for the new job opening</p>
        </div>
        <div class="flex items-center space-x-4">
          <?php include 'profile_dropdown.php'; ?>
        </div>
      </div>

      <?php if (isset($error)): ?>
      <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
        <?php echo htmlspecialchars($error); ?>
      </div>
      <?php endif; ?>

      <form method="POST" class="bg-white rounded-lg shadow p-6">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          <!-- Basic Information -->
          <div class="space-y-4">
            <h3 class="text-lg font-semibold text-gray-800">Basic Information</h3>
            
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">Job Title *</label>
              <input type="text" name="job_title" required
                     class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
            
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">Job Code *</label>
              <input type="text" name="job_code" required
                     class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                     placeholder="e.g., FDO-001">
            </div>
            
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">Department *</label>
              <select name="department_id" required
                      class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="">Select Department</option>
                <?php foreach ($departments as $dept): ?>
                <option value="<?php echo htmlspecialchars($dept['id']); ?>">
                  <?php echo htmlspecialchars($dept['name']); ?>
                </option>
                <?php endforeach; ?>
              </select>
            </div>
            
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">Location</label>
              <input type="text" name="location"
                     class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                     placeholder="e.g., Main Office, Remote">
            </div>
            
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">Number of Vacancies</label>
              <input type="number" name="vacancies" min="1" value="1"
                     class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
          </div>

          <!-- Job Details -->
          <div class="space-y-4">
            <h3 class="text-lg font-semibold text-gray-800">Job Details</h3>
            
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">Employment Type</label>
              <select name="employment_type"
                      class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="full_time">Full Time</option>
                <option value="part_time">Part Time</option>
                <option value="contract">Contract</option>
                <option value="temporary">Temporary</option>
                <option value="internship">Internship</option>
              </select>
            </div>
            
            <div class="grid grid-cols-2 gap-4">
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Salary Min (₱)</label>
                <input type="number" name="salary_min" step="0.01" min="0"
                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                       placeholder="e.g., 25000">
              </div>
              
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Salary Max (₱)</label>
                <input type="number" name="salary_max" step="0.01" min="0"
                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                       placeholder="e.g., 35000">
              </div>
            </div>
            
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">Experience Level</label>
              <select name="experience_level"
                      class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="entry">Entry Level</option>
                <option value="mid" selected>Mid Level</option>
                <option value="senior">Senior Level</option>
                <option value="executive">Executive</option>
              </select>
            </div>
            
            <div class="grid grid-cols-2 gap-4">
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Published Date</label>
                <input type="date" name="published_date"
                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                       value="<?php echo date('Y-m-d'); ?>">
              </div>
              
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Closing Date</label>
                <input type="date" name="closing_date"
                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
              </div>
            </div>
            
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">Status</label>
              <select name="status"
                      class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="draft">Draft</option>
                <option value="active">Active</option>
                <option value="closed">Closed</option>
                <option value="archived">Archived</option>
              </select>
            </div>
          </div>
        </div>

        <!-- Rich Text Editors -->
        <div class="mt-8 space-y-6">
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Job Description</label>
            <div id="description-editor" style="height: 200px;"></div>
            <textarea name="description" id="description" class="hidden"></textarea>
          </div>
          
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Requirements</label>
            <div id="requirements-editor" style="height: 150px;"></div>
            <textarea name="requirements" id="requirements" class="hidden"></textarea>
          </div>
          
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Responsibilities</label>
            <div id="responsibilities-editor" style="height: 150px;"></div>
            <textarea name="responsibilities" id="responsibilities" class="hidden"></textarea>
          </div>
          
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Benefits</label>
            <div id="benefits-editor" style="height: 150px;"></div>
            <textarea name="benefits" id="benefits" class="hidden"></textarea>
          </div>
        </div>

        <!-- Form Actions -->
        <div class="flex justify-end space-x-4 mt-8 pt-6 border-t">
          <a href="job_postings.php"
             class="px-6 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 transition-colors">
            Cancel
          </a>
          <button type="submit"
                  class="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors">
            Create Job Posting
          </button>
        </div>
      </form>
    </main>
  </div>
</div>

<script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>
<script>
document.addEventListener("DOMContentLoaded", () => {
  lucide.createIcons();
  
  // Initialize Quill editors
  const editors = {};
  const fields = ['description', 'requirements', 'responsibilities', 'benefits'];
  
  fields.forEach(field => {
    editors[field] = new Quill(`#${field}-editor`, {
      theme: 'snow',
      modules: {
        toolbar: [
          [{ 'header': [1, 2, 3, false] }],
          ['bold', 'italic', 'underline', 'strike'],
          [{ 'list': 'ordered'}, { 'list': 'bullet' }],
          ['link', 'clean']
        ]
      },
      placeholder: `Enter job ${field}...`
    });
    
    // Set initial content to empty
    editors[field].setContents([]);
    
    // Update hidden textarea on content change
    editors[field].on('text-change', () => {
      document.getElementById(field).value = editors[field].root.innerHTML;
    });
    
    // Initialize with empty value
    document.getElementById(field).value = '';
  });
  
  // Form submission validation
  document.querySelector('form').addEventListener('submit', (e) => {
    // Update all textareas with Quill content
    fields.forEach(field => {
      document.getElementById(field).value = editors[field].root.innerHTML;
    });
    
    // Validate required fields
    const jobTitle = document.querySelector('input[name="job_title"]').value.trim();
    const jobCode = document.querySelector('input[name="job_code"]').value.trim();
    const department = document.querySelector('select[name="department_id"]').value;
    
    if (!jobTitle || !jobCode || !department) {
      e.preventDefault();
      alert('Please fill in all required fields marked with *');
      return false;
    }
    
    return true;
  });
  
  // Set min date for closing date to today
  const closingDateInput = document.querySelector('input[name="closing_date"]');
  if (closingDateInput) {
    const today = new Date().toISOString().split('T')[0];
    closingDateInput.min = today;
  }
});
</script>
</body>
</html>