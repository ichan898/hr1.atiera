<?php
// export_report.php
// Generates a CSV export of the HR report data.

session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

// ==================== FUNCTION DEFINITIONS (only if not already defined) ====================

if (!function_exists('getEmployeeDashboardStats')) {
    function getEmployeeDashboardStats($connections) {
        $query = "
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'Active' THEN 1 ELSE 0 END) as active_count,
                SUM(CASE WHEN status = 'Inactive' THEN 1 ELSE 0 END) as inactive_count,
                SUM(CASE WHEN status = 'On Leave' THEN 1 ELSE 0 END) as on_leave_count,
                SUM(CASE WHEN status = 'Terminated' THEN 1 ELSE 0 END) as terminated_count
            FROM employees
        ";
        try {
            $stmt = $connections->prepare($query);
            $stmt->execute();
            $result = $stmt->fetch();
            return $result ?: ['total' => 0, 'active_count' => 0, 'inactive_count' => 0, 'on_leave_count' => 0, 'terminated_count' => 0];
        } catch (Exception $e) {
            error_log("Error in getEmployeeDashboardStats: " . $e->getMessage());
            return ['total' => 0, 'active_count' => 0, 'inactive_count' => 0, 'on_leave_count' => 0, 'terminated_count' => 0];
        }
    }
}

if (!function_exists('getRecruitmentDashboardStats')) {
    function getRecruitmentDashboardStats($connections, $start_date, $end_date) {
        $query = "
            SELECT 
                COUNT(*) as total_applicants,
                SUM(CASE WHEN application_status = 'new' THEN 1 ELSE 0 END) as new_applicants,
                SUM(CASE WHEN application_status = 'hired' THEN 1 ELSE 0 END) as hired,
                SUM(CASE WHEN application_status = 'rejected' THEN 1 ELSE 0 END) as rejected,
                SUM(CASE WHEN application_status = 'shortlisted' THEN 1 ELSE 0 END) as shortlisted
            FROM applicants
            WHERE DATE(applied_at) BETWEEN ? AND ? 
            AND is_active = 1
        ";
        try {
            $stmt = $connections->prepare($query);
            $stmt->execute([$start_date, $end_date]);
            $result = $stmt->fetch();
            return $result ?: ['total_applicants' => 0, 'new_applicants' => 0, 'hired' => 0, 'rejected' => 0, 'shortlisted' => 0];
        } catch (Exception $e) {
            error_log("Error in getRecruitmentDashboardStats: " . $e->getMessage());
            return ['total_applicants' => 0, 'new_applicants' => 0, 'hired' => 0, 'rejected' => 0, 'shortlisted' => 0];
        }
    }
}

if (!function_exists('getDepartmentBreakdownDashboard')) {
    function getDepartmentBreakdownDashboard($connections) {
        $query = "
            SELECT 
                d.name as department,
                COUNT(e.id) as employee_count,
                SUM(CASE WHEN e.status = 'Active' THEN 1 ELSE 0 END) as active,
                COALESCE(AVG(ed.basic_salary), 0) as avg_salary
            FROM departments d
            LEFT JOIN employees e ON d.id = e.department_id
            LEFT JOIN employment_details ed ON e.id = ed.employee_id
            GROUP BY d.id, d.name
            ORDER BY employee_count DESC
        ";
        try {
            $stmt = $connections->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error in getDepartmentBreakdownDashboard: " . $e->getMessage());
            return [];
        }
    }
}

if (!function_exists('getOnboardingDashboardStats')) {
    function getOnboardingDashboardStats($connections) {
        $query = "
            SELECT 
                status,
                COUNT(*) as count,
                CASE status
                    WHEN 'pending' THEN 'bg-yellow-100 text-yellow-800'
                    WHEN 'onboarding' THEN 'bg-blue-100 text-blue-800'
                    WHEN 'completed' THEN 'bg-green-100 text-green-800'
                    WHEN 'cancelled' THEN 'bg-red-100 text-red-800'
                    ELSE 'bg-gray-100 text-gray-800'
                END as badge_class
            FROM onboarding
            WHERE status IS NOT NULL
            GROUP BY status
            ORDER BY FIELD(status, 'onboarding', 'pending', 'completed', 'cancelled')
        ";
        try {
            $stmt = $connections->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error in getOnboardingDashboardStats: " . $e->getMessage());
            return [];
        }
    }
}

if (!function_exists('getMonthlyHiresDashboard')) {
    function getMonthlyHiresDashboard($connections) {
        $query = "
            SELECT 
                DATE_FORMAT(hire_date, '%Y-%m') as month,
                COUNT(*) as hire_count
            FROM employees
            WHERE hire_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
            AND status IN ('Active', 'On Leave')
            GROUP BY DATE_FORMAT(hire_date, '%Y-%m')
            ORDER BY month
        ";
        try {
            $stmt = $connections->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error in getMonthlyHiresDashboard: " . $e->getMessage());
            return [];
        }
    }
}

if (!function_exists('getJobPostingDashboardStats')) {
    function getJobPostingDashboardStats($connections) {
        $query = "
            SELECT 
                status,
                COUNT(*) as count,
                SUM(vacancies) as total_vacancies,
                SUM(filled_positions) as filled_positions,
                SUM(applications_count) as total_applications
            FROM job_postings
            WHERE status IN ('active', 'draft', 'closed')
            GROUP BY status
        ";
        try {
            $stmt = $connections->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error in getJobPostingDashboardStats: " . $e->getMessage());
            return [];
        }
    }
}

if (!function_exists('getRecentActivityDashboard')) {
    function getRecentActivityDashboard($connections) {
        $query = "
            SELECT 
                al.description,
                al.action,
                al.created_at,
                u.full_name
            FROM activity_logs al
            LEFT JOIN users u ON al.user_id = u.id
            WHERE al.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
            ORDER BY al.created_at DESC
            LIMIT 10
        ";
        try {
            $stmt = $connections->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error in getRecentActivityDashboard: " . $e->getMessage());
            return [];
        }
    }
}

if (!function_exists('getTurnoverDashboardStats')) {
    function getTurnoverDashboardStats($connections, $start_date, $end_date) {
        $query = "
            SELECT 
                (SELECT COUNT(*) FROM employees WHERE status = 'Terminated' AND DATE(updated_at) BETWEEN ? AND ?) as terminated_count,
                (SELECT COUNT(*) FROM employees WHERE status = 'Active') as active_count,
                (SELECT COUNT(*) FROM employees WHERE hire_date BETWEEN ? AND ?) as hired_count
        ";
        try {
            $stmt = $connections->prepare($query);
            $stmt->execute([$start_date, $end_date, $start_date, $end_date]);
            $result = $stmt->fetch();
            return $result ?: ['terminated_count' => 0, 'active_count' => 0, 'hired_count' => 0];
        } catch (Exception $e) {
            error_log("Error in getTurnoverDashboardStats: " . $e->getMessage());
            return ['terminated_count' => 0, 'active_count' => 0, 'hired_count' => 0];
        }
    }
}

if (!function_exists('getEmployeeStatusDistribution')) {
    function getEmployeeStatusDistribution($connections) {
        $query = "
            SELECT 
                status,
                COUNT(*) as count
            FROM employees
            WHERE status IN ('Active', 'Inactive', 'On Leave', 'Terminated')
            GROUP BY status
        ";
        try {
            $stmt = $connections->prepare($query);
            $stmt->execute();
            $result = $stmt->fetchAll();
            
            $data = ['labels' => [], 'data' => [], 'colors' => []];
            foreach ($result as $row) {
                $data['labels'][] = $row['status'];
                $data['data'][] = $row['count'];
                switch ($row['status']) {
                    case 'Active':    $data['colors'][] = '#10b981'; break;
                    case 'On Leave':  $data['colors'][] = '#3b82f6'; break;
                    case 'Inactive':  $data['colors'][] = '#f59e0b'; break;
                    case 'Terminated':$data['colors'][] = '#ef4444'; break;
                    default:          $data['colors'][] = '#6b7280';
                }
            }
            return $data;
        } catch (Exception $e) {
            error_log("Error in getEmployeeStatusDistribution: " . $e->getMessage());
            return ['labels' => [], 'data' => [], 'colors' => []];
        }
    }
}

if (!function_exists('getRecentHires')) {
    function getRecentHires($connections) {
        $query = "
            SELECT 
                e.employee_id,
                CONCAT(e.first_name, ' ', e.last_name) as full_name,
                d.name as department,
                ed.job_title,
                e.hire_date
            FROM employees e
            LEFT JOIN departments d ON e.department_id = d.id
            LEFT JOIN employment_details ed ON e.id = ed.employee_id
            WHERE e.hire_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
            AND e.status = 'Active'
            ORDER BY e.hire_date DESC
            LIMIT 10
        ";
        try {
            $stmt = $connections->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error in getRecentHires: " . $e->getMessage());
            return [];
        }
    }
}

if (!function_exists('getEmploymentTypeStats')) {
    function getEmploymentTypeStats($connections) {
        $query = "
            SELECT 
                ed.employment_type,
                COUNT(*) as count
            FROM employees e
            INNER JOIN employment_details ed ON e.id = ed.employee_id
            WHERE e.status = 'Active'
            GROUP BY ed.employment_type
        ";
        try {
            $stmt = $connections->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error in getEmploymentTypeStats: " . $e->getMessage());
            return [];
        }
    }
}

if (!function_exists('getGenderDistribution')) {
    function getGenderDistribution($connections) {
        $query = "
            SELECT 
                gender,
                COUNT(*) as count
            FROM employees
            WHERE status = 'Active'
            GROUP BY gender
        ";
        try {
            $stmt = $connections->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error in getGenderDistribution: " . $e->getMessage());
            return [];
        }
    }
}

if (!function_exists('getJobRequestStats')) {
    function getJobRequestStats($status, $connections) {
        $query = "
            SELECT 
                overall_status as status,
                COUNT(*) as count
            FROM job_requests
            WHERE overall_status IN ('approved', 'pending', 'rejected')
            GROUP BY overall_status
        ";
        try {
            $stmt = $connections->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error in getJobRequestStats: " . $e->getMessage());
            return [];
        }
    }
}

if (!function_exists('getUpcomingBirthdays')) {
    function getUpcomingBirthdays($connections, $limit = 10) {
        $query = "
            SELECT 
                CONCAT(e.first_name, ' ', e.last_name) as full_name,
                e.date_of_birth,
                d.name as department
            FROM employees e
            LEFT JOIN departments d ON e.department_id = d.id
            WHERE e.status = 'Active'
            AND DAYOFYEAR(e.date_of_birth) >= DAYOFYEAR(CURDATE())
            AND DAYOFYEAR(e.date_of_birth) <= DAYOFYEAR(DATE_ADD(CURDATE(), INTERVAL 30 DAY))
            ORDER BY DAYOFYEAR(e.date_of_birth)
            LIMIT ?
        ";
        try {
            $stmt = $connections->prepare($query);
            $stmt->execute([$limit]);
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error in getUpcomingBirthdays: " . $e->getMessage());
            return [];
        }
    }
}

// ==================== END OF FUNCTION DEFINITIONS ====================

// Get filter values from POST (submitted by the export button)
$start_date = $_POST['start_date'] ?? date('Y-m-01');
$end_date   = $_POST['end_date'] ?? date('Y-m-d');
$report_type = $_POST['report_type'] ?? 'overview';

// Fetch all required statistics
$employee_stats       = getEmployeeDashboardStats($connections);
$recruitment_stats    = getRecruitmentDashboardStats($connections, $start_date, $end_date);
$department_breakdown = getDepartmentBreakdownDashboard($connections);
$onboarding_stats     = getOnboardingDashboardStats($connections);
$monthly_hires        = getMonthlyHiresDashboard($connections);
$job_posting_stats    = getJobPostingDashboardStats($connections);
$recent_activity      = getRecentActivityDashboard($connections);
$turnover_stats       = getTurnoverDashboardStats($connections, $start_date, $end_date);
$employee_status_dist = getEmployeeStatusDistribution($connections);
$gender_dist          = getGenderDistribution($connections);
$job_request_stats    = getJobRequestStats(null, $connections);
$recent_hires         = getRecentHires($connections);
$upcoming_birthdays   = getUpcomingBirthdays($connections, 10);
$employment_type_stats = getEmploymentTypeStats($connections);

// Helper to calculate turnover rate
$turnover_rate = 0;
if (!empty($turnover_stats['active_count']) && $turnover_stats['active_count'] > 0) {
    $turnover_rate = ($turnover_stats['terminated_count'] / $turnover_stats['active_count']) * 100;
}

// Set headers for CSV download
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="HR_Report_' . $start_date . '_to_' . $end_date . '.csv"');

// Open output stream
$output = fopen('php://output', 'w');

// Add UTF-8 BOM for Excel compatibility
fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));

// ----------------------------------------------------------------------
// Helper function to write a section title
function writeSection($fp, $title) {
    fputcsv($fp, [strtoupper($title)]);
    fputcsv($fp, []); // blank line
}

// Helper function to write a key-value pair
function writePair($fp, $key, $value) {
    fputcsv($fp, [$key, $value]);
}

// ----------------------------------------------------------------------
// 1. Report Header
// ----------------------------------------------------------------------
fputcsv($output, ['HR ANALYTICS REPORT']);
fputcsv($output, ["Period: $start_date to $end_date"]);
fputcsv($output, ['Generated: ' . date('Y-m-d H:i:s')]);
fputcsv($output, ['Generated By: ' . ($_SESSION['user_name'] ?? 'System')]);
fputcsv($output, []); // blank line

// ----------------------------------------------------------------------
// 2. Data Sections (depending on report type)
// ----------------------------------------------------------------------

// ---------- OVERVIEW or EMPLOYEE sections ----------
if ($report_type === 'overview' || $report_type === 'employee') {
    // Employee Statistics
    writeSection($output, 'EMPLOYEE STATISTICS');
    writePair($output, 'Total Employees', $employee_stats['total'] ?? 0);
    writePair($output, 'Active', $employee_stats['active_count'] ?? 0);
    writePair($output, 'On Leave', $employee_stats['on_leave_count'] ?? 0);
    writePair($output, 'Inactive', $employee_stats['inactive_count'] ?? 0);
    writePair($output, 'Terminated', $employee_stats['terminated_count'] ?? 0);
    fputcsv($output, []);

    // Turnover Rate
    writePair($output, 'Turnover Rate', number_format($turnover_rate, 1) . '%');
    writePair($output, 'Terminated (selected period)', $turnover_stats['terminated_count'] ?? 0);
    fputcsv($output, []);

    // Department Breakdown
    writeSection($output, 'DEPARTMENT BREAKDOWN');
    fputcsv($output, ['Department', 'Total Employees', 'Active', 'On Leave', 'Avg Salary']);
    if (!empty($department_breakdown)) {
        foreach ($department_breakdown as $dept) {
            // Get on‑leave count for this department (if needed – you can add a function)
            $on_leave = 0; // Replace with actual data if you have it
            fputcsv($output, [
                $dept['department'] ?? 'N/A',
                $dept['employee_count'] ?? 0,
                $dept['active'] ?? 0,
                $on_leave,
                '₱' . number_format($dept['avg_salary'] ?? 0, 2)
            ]);
        }
    } else {
        fputcsv($output, ['No department data available']);
    }
    fputcsv($output, []);

    // Gender Distribution
    writeSection($output, 'GENDER DISTRIBUTION (ACTIVE)');
    fputcsv($output, ['Gender', 'Count']);
    if (!empty($gender_dist)) {
        foreach ($gender_dist as $g) {
            fputcsv($output, [$g['gender'] ?? 'Unknown', $g['count'] ?? 0]);
        }
    } else {
        fputcsv($output, ['No gender data']);
    }
    fputcsv($output, []);

    // Employment Type Distribution
    writeSection($output, 'EMPLOYMENT TYPE DISTRIBUTION');
    fputcsv($output, ['Employment Type', 'Count']);
    if (!empty($employment_type_stats)) {
        foreach ($employment_type_stats as $et) {
            fputcsv($output, [$et['employment_type'] ?? 'Unknown', $et['count'] ?? 0]);
        }
    } else {
        fputcsv($output, ['No employment type data']);
    }
    fputcsv($output, []);

    // Recent Hires
    writeSection($output, 'RECENT HIRES (LAST 30 DAYS)');
    fputcsv($output, ['Name', 'Job Title', 'Department', 'Hire Date']);
    if (!empty($recent_hires)) {
        foreach ($recent_hires as $hire) {
            fputcsv($output, [
                $hire['full_name'] ?? '',
                $hire['job_title'] ?? '',
                $hire['department'] ?? '',
                isset($hire['hire_date']) ? date('Y-m-d', strtotime($hire['hire_date'])) : ''
            ]);
        }
    } else {
        fputcsv($output, ['No recent hires']);
    }
    fputcsv($output, []);

    // Upcoming Birthdays
    writeSection($output, 'UPCOMING BIRTHDAYS (NEXT 30 DAYS)');
    fputcsv($output, ['Name', 'Department', 'Birth Date', 'Days Until']);
    if (!empty($upcoming_birthdays)) {
        $today = new DateTime();
        foreach ($upcoming_birthdays as $bday) {
            if (!empty($bday['date_of_birth'])) {
                $birthday = new DateTime($bday['date_of_birth']);
                $next = clone $birthday;
                $next->setDate($today->format('Y'), $birthday->format('m'), $birthday->format('d'));
                if ($next < $today) {
                    $next->modify('+1 year');
                }
                $days = $today->diff($next)->days;
            } else {
                $days = '';
            }
            fputcsv($output, [
                $bday['full_name'] ?? '',
                $bday['department'] ?? '',
                isset($bday['date_of_birth']) ? date('Y-m-d', strtotime($bday['date_of_birth'])) : '',
                $days
            ]);
        }
    } else {
        fputcsv($output, ['No upcoming birthdays']);
    }
    fputcsv($output, []);

    // Recent Activity
    writeSection($output, 'RECENT ACTIVITY (LAST 7 DAYS)');
    fputcsv($output, ['Description', 'User', 'Date']);
    if (!empty($recent_activity)) {
        foreach ($recent_activity as $act) {
            fputcsv($output, [
                $act['description'] ?? '',
                $act['full_name'] ?? 'System',
                isset($act['created_at']) ? date('Y-m-d H:i', strtotime($act['created_at'])) : ''
            ]);
        }
    } else {
        fputcsv($output, ['No recent activity']);
    }
    fputcsv($output, []);
}

// ---------- OVERVIEW or RECRUITMENT sections ----------
if ($report_type === 'overview' || $report_type === 'recruitment') {
    // Recruitment Statistics
    writeSection($output, 'RECRUITMENT STATISTICS');
    writePair($output, 'Total Applicants', $recruitment_stats['total_applicants'] ?? 0);
    writePair($output, 'New Applicants', $recruitment_stats['new_applicants'] ?? 0);
    writePair($output, 'Hired', $recruitment_stats['hired'] ?? 0);
    writePair($output, 'Rejected', $recruitment_stats['rejected'] ?? 0);
    writePair($output, 'Shortlisted', $recruitment_stats['shortlisted'] ?? 0);
    fputcsv($output, []);

    // Job Posting Stats
    writeSection($output, 'JOB POSTING STATUS');
    fputcsv($output, ['Status', 'Postings', 'Total Vacancies', 'Filled', 'Applications']);
    if (!empty($job_posting_stats)) {
        foreach ($job_posting_stats as $job) {
            fputcsv($output, [
                ucfirst($job['status'] ?? ''),
                $job['count'] ?? 0,
                $job['total_vacancies'] ?? 0,
                $job['filled_positions'] ?? 0,
                $job['total_applications'] ?? 0
            ]);
        }
    } else {
        fputcsv($output, ['No job posting data']);
    }
    fputcsv($output, []);

    // Job Request Stats
    writeSection($output, 'JOB REQUEST STATUS');
    fputcsv($output, ['Status', 'Count']);
    if (!empty($job_request_stats)) {
        foreach ($job_request_stats as $req) {
            fputcsv($output, [ucfirst($req['status'] ?? ''), $req['count'] ?? 0]);
        }
    } else {
        fputcsv($output, ['No job request data']);
    }
    fputcsv($output, []);
}

// ---------- OVERVIEW only (extra charts) ----------
if ($report_type === 'overview') {
    // Monthly Hires (Last 6 Months)
    writeSection($output, 'MONTHLY HIRES (LAST 6 MONTHS)');
    fputcsv($output, ['Month', 'Hires']);
    if (!empty($monthly_hires)) {
        foreach ($monthly_hires as $mh) {
            $month = $mh['month'] ?? '';
            if (!empty($month)) {
                $date = DateTime::createFromFormat('Y-m', $month);
                $month = $date ? $date->format('M Y') : $month;
            }
            fputcsv($output, [$month, $mh['hire_count'] ?? 0]);
        }
    } else {
        fputcsv($output, ['No monthly hires data']);
    }
    fputcsv($output, []);
}

// ---------- ONBOARDING sections ----------
if ($report_type === 'onboarding' || $report_type === 'overview') {
    // Onboarding Summary
    writeSection($output, 'ONBOARDING SUMMARY');
    if (!empty($onboarding_stats)) {
        fputcsv($output, ['Status', 'Count']);
        foreach ($onboarding_stats as $os) {
            fputcsv($output, [ucfirst($os['status'] ?? ''), $os['count'] ?? 0]);
        }
    } else {
        fputcsv($output, ['No onboarding data']);
    }
    fputcsv($output, []);

    // Onboarding List (detailed)
    writeSection($output, 'ONBOARDING DETAILS');
    try {
        $onboarding_list = $connections->query("
            SELECT 
                o.employee_id,
                o.first_name,
                o.last_name,
                o.job_position,
                o.hire_date,
                o.status,
                o.contract_status
            FROM onboarding o
            WHERE o.status IS NOT NULL
            ORDER BY o.created_at DESC 
            LIMIT 50
        ")->fetchAll();

        if (!empty($onboarding_list)) {
            fputcsv($output, ['Employee ID', 'Name', 'Position', 'Hire Date', 'Status', 'Contract Status']);
            foreach ($onboarding_list as $onb) {
                fputcsv($output, [
                    $onb['employee_id'] ?? '',
                    trim(($onb['first_name'] ?? '') . ' ' . ($onb['last_name'] ?? '')),
                    $onb['job_position'] ?? '',
                    isset($onb['hire_date']) ? date('Y-m-d', strtotime($onb['hire_date'])) : '',
                    $onb['status'] ?? '',
                    $onb['contract_status'] ?? ''
                ]);
            }
        } else {
            fputcsv($output, ['No onboarding records found']);
        }
    } catch (Exception $e) {
        fputcsv($output, ['Error loading onboarding data']);
    }
    fputcsv($output, []);

    // Contract Status Distribution
    writeSection($output, 'CONTRACT STATUS DISTRIBUTION');
    try {
        $contract_statuses = $connections->prepare("
            SELECT 
                contract_status,
                COUNT(*) as count
            FROM onboarding
            WHERE contract_status IS NOT NULL
            GROUP BY contract_status
        ");
        $contract_statuses->execute();
        $contracts = $contract_statuses->fetchAll();
        if (!empty($contracts)) {
            fputcsv($output, ['Contract Status', 'Count']);
            foreach ($contracts as $c) {
                fputcsv($output, [$c['contract_status'] ?? 'Unknown', $c['count'] ?? 0]);
            }
        } else {
            fputcsv($output, ['No contract status data']);
        }
    } catch (Exception $e) {
        fputcsv($output, ['Error loading contract status']);
    }
    fputcsv($output, []);
}

// ----------------------------------------------------------------------
// Footer
fputcsv($output, ['*** END OF REPORT ***']);

// Close the output stream
fclose($output);
exit;