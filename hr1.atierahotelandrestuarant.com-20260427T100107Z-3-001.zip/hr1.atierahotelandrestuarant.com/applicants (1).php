<?php
// File: applicants.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

// Get applicants with filters
$status = $_GET['status'] ?? '';
$job_id = $_GET['job_id'] ?? '';
$qualification_filter = $_GET['qualification'] ?? ''; // New filter for qualification status

// Build query based on your actual table structure
$query = "SELECT a.*, j.job_title, j.department FROM applicants a 
          LEFT JOIN job_postings j ON a.job_id = j.id WHERE 1=1";
$params = [];

if ($status) {
    $query .= " AND a.application_status = ?";
    $params[] = $status;
}

if ($job_id) {
    $query .= " AND a.job_id = ?";
    $params[] = $job_id;
}

// Add qualification filter
if ($qualification_filter !== '') {
    if ($qualification_filter === 'qualified') {
        $query .= " AND a.is_qualified = 1";
    } elseif ($qualification_filter === 'not_qualified') {
        $query .= " AND a.is_qualified = 0";
    }
    // If 'all' or empty, no filter
}

// Use applied_at instead of created_at (based on your table structure)
$query .= " ORDER BY a.qualification_score DESC, a.applied_at DESC";

try {
    $stmt = $connections->prepare($query);
    $stmt->execute($params);
    $applicants = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}

// Get jobs for filter
try {
    $jobs_stmt = $connections->prepare("SELECT id, job_title FROM job_postings WHERE status = 'active'");
    $jobs_stmt->execute();
    $jobs = $jobs_stmt->fetchAll();
} catch (PDOException $e) {
    $jobs = [];
}

// Get stats - FIXED based on your actual application_status enum values
try {
    $stats_stmt = $connections->prepare("
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN application_status = 'new' THEN 1 ELSE 0 END) as new,
            SUM(CASE WHEN application_status = 'reviewed' THEN 1 ELSE 0 END) as reviewed,
            SUM(CASE WHEN application_status = 'shortlisted' THEN 1 ELSE 0 END) as shortlisted,
            SUM(CASE WHEN application_status = 'interviewed' THEN 1 ELSE 0 END) as interviewed,
            SUM(CASE WHEN application_status = 'hired' THEN 1 ELSE 0 END) as hired,
            SUM(CASE WHEN application_status = 'rejected' THEN 1 ELSE 0 END) as rejected,
            SUM(CASE WHEN is_qualified = 1 THEN 1 ELSE 0 END) as qualified,
            SUM(CASE WHEN is_qualified = 0 AND qualification_score > 0 THEN 1 ELSE 0 END) as not_qualified,
            SUM(CASE WHEN qualification_score = 0 OR qualification_score IS NULL THEN 1 ELSE 0 END) as not_scored
        FROM applicants
    ");
    $stats_stmt->execute();
    $stats = $stats_stmt->fetch();
} catch (PDOException $e) {
    // Initialize empty stats if query fails
    $stats = [
        'total' => 0, 'new' => 0, 'reviewed' => 0, 'shortlisted' => 0,
        'interviewed' => 0, 'hired' => 0, 'rejected' => 0,
        'qualified' => 0, 'not_qualified' => 0, 'not_scored' => 0
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>HR1 - Applicants</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<style>
    .score-badge {
        transition: all 0.3s ease;
    }
    .score-badge:hover {
        transform: scale(1.05);
    }
</style>
</head>

<body class="h-screen bg-gray-100 font-sans">
<div class="flex h-full">
  
  <!-- Sidebar -->
  <?php include 'sidebar.php'; ?>
  
  <!-- Main Content -->
  <div class="flex-1 flex flex-col overflow-y-auto">
    <main class="p-6 space-y-6">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-gray-300 pb-4">
        <div>
          <h2 class="text-2xl font-bold text-gray-800">Applicants</h2>
          <p class="text-sm text-gray-600">Manage job applicants and screening process</p>
        </div>
        <div class="flex items-center space-x-4">
          <!--<a href="import_applicants.php" class="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">-->
          <!--  <i data-lucide="upload" class="w-4 h-4"></i>-->
          <!--  <span>Import Applicants</span>-->
          <!--</a>-->
          <?php include 'profile_dropdown.php'; ?>
        </div>
      </div>

      <!-- Stats - UPDATED to match your application_status values -->
      <div class="grid grid-cols-1 md:grid-cols-10 gap-3">
        <div class="bg-white p-3 rounded-lg shadow border">
          <p class="text-xs text-gray-600">Total</p>
          <p class="text-lg font-bold text-gray-800"><?php echo $stats['total']; ?></p>
        </div>
        <div class="bg-white p-3 rounded-lg shadow border border-l-4 border-l-blue-500">
          <p class="text-xs text-gray-600">New</p>
          <p class="text-lg font-bold text-gray-800"><?php echo $stats['new']; ?></p>
        </div>
        <div class="bg-white p-3 rounded-lg shadow border border-l-4 border-l-yellow-500">
          <p class="text-xs text-gray-600">Reviewed</p>
          <p class="text-lg font-bold text-gray-800"><?php echo $stats['reviewed']; ?></p>
        </div>
        <div class="bg-white p-3 rounded-lg shadow border border-l-4 border-l-green-500">
          <p class="text-xs text-gray-600">Qualified</p>
          <p class="text-lg font-bold text-green-700"><?php echo $stats['qualified']; ?></p>
        </div>
        <div class="bg-white p-3 rounded-lg shadow border border-l-4 border-l-purple-500">
          <p class="text-xs text-gray-600">Shortlisted</p>
          <p class="text-lg font-bold text-gray-800"><?php echo $stats['shortlisted']; ?></p>
        </div>
        <div class="bg-white p-3 rounded-lg shadow border border-l-4 border-l-indigo-500">
          <p class="text-xs text-gray-600">Interviewed</p>
          <p class="text-lg font-bold text-gray-800"><?php echo $stats['interviewed']; ?></p>
        </div>
        <div class="bg-white p-3 rounded-lg shadow border border-l-4 border-l-green-600">
          <p class="text-xs text-gray-600">Hired</p>
          <p class="text-lg font-bold text-gray-800"><?php echo $stats['hired']; ?></p>
        </div>
        <div class="bg-white p-3 rounded-lg shadow border border-l-4 border-l-red-500">
          <p class="text-xs text-gray-600">Rejected</p>
          <p class="text-lg font-bold text-gray-800"><?php echo $stats['rejected']; ?></p>
        </div>
        <div class="bg-white p-3 rounded-lg shadow border border-l-4 border-l-red-400">
          <p class="text-xs text-gray-600">Not Qualified</p>
          <p class="text-lg font-bold text-red-600"><?php echo $stats['not_qualified']; ?></p>
        </div>
        <div class="bg-white p-3 rounded-lg shadow border border-l-4 border-l-gray-400">
          <p class="text-xs text-gray-600">Not Scored</p>
          <p class="text-lg font-bold text-gray-600"><?php echo $stats['not_scored']; ?></p>
        </div>
      </div>

      <!-- Filters and Tabs -->
      <div class="bg-white rounded-lg shadow">
        <div class="p-4 border-b">
          <div class="flex flex-col md:flex-row md:items-center space-y-3 md:space-y-0 md:space-x-4">
            <div class="flex-1">
              <input type="text" id="searchInput" placeholder="Search applicants..." class="w-full px-4 py-2 border rounded-lg">
            </div>
            <select id="statusFilter" class="px-4 py-2 border rounded-lg">
              <option value="">All Status</option>
              <option value="new" <?php echo $status == 'new' ? 'selected' : ''; ?>>New</option>
              <option value="reviewed" <?php echo $status == 'reviewed' ? 'selected' : ''; ?>>Reviewed</option>
              <option value="shortlisted" <?php echo $status == 'shortlisted' ? 'selected' : ''; ?>>Shortlisted</option>
              <option value="interviewed" <?php echo $status == 'interviewed' ? 'selected' : ''; ?>>Interviewed</option>
              <option value="hired" <?php echo $status == 'hired' ? 'selected' : ''; ?>>Hired</option>
              <option value="rejected" <?php echo $status == 'rejected' ? 'selected' : ''; ?>>Rejected</option>
            </select>
            <!-- New Qualification Filter -->
            <select id="qualificationFilter" class="px-4 py-2 border rounded-lg">
              <option value="">All Qualifications</option>
              <option value="qualified" <?php echo $qualification_filter == 'qualified' ? 'selected' : ''; ?>>Qualified</option>
              <option value="not_qualified" <?php echo $qualification_filter == 'not_qualified' ? 'selected' : ''; ?>>Not Qualified</option>
              <option value="not_scored" <?php echo $qualification_filter == 'not_scored' ? 'selected' : ''; ?>>Not Scored</option>
            </select>
            <select id="jobFilter" class="px-4 py-2 border rounded-lg">
              <option value="">All Jobs</option>
              <?php foreach($jobs as $job): ?>
                <option value="<?php echo $job['id']; ?>" <?php echo $job_id == $job['id'] ? 'selected' : ''; ?>>
                  <?php echo htmlspecialchars($job['job_title']); ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>

        <!-- Applicants Table -->
        <div class="overflow-x-auto">
          <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
              <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Applicant</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Applied For</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Department</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Applied Date</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Qualification Status</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Score</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
              <?php foreach($applicants as $applicant): 
                // Determine qualification status
                $qualification_score = $applicant['qualification_score'] ?? 0;
                $is_qualified = $applicant['is_qualified'] ?? 0;
                
                if ($qualification_score === null || $qualification_score == 0) {
                    $qual_status = 'not_scored';
                    $qual_color = 'bg-gray-100 text-gray-800';
                    $qual_text = 'Not Scored';
                    $score_color = 'text-gray-500';
                } elseif ($is_qualified == 1) {
                    $qual_status = 'qualified';
                    $qual_color = 'bg-green-100 text-green-800';
                    $qual_text = 'Qualified';
                    $score_color = $qualification_score >= 80 ? 'text-green-600' : ($qualification_score >= 70 ? 'text-green-500' : 'text-green-400');
                } else {
                    $qual_status = 'not_qualified';
                    $qual_color = 'bg-red-100 text-red-800';
                    $qual_text = 'Not Qualified';
                    $score_color = $qualification_score >= 60 ? 'text-yellow-600' : ($qualification_score >= 50 ? 'text-orange-500' : 'text-red-500');
                }
                
                // Get score display
                $score_display = $qualification_score !== null ? $qualification_score : 'N/A';
              ?>
              <tr class="hover:bg-gray-50 applicant-row">
                <td class="px-6 py-4">
                  <div class="flex items-center">
                    <div class="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center mr-3">
                      <i data-lucide="user" class="w-5 h-5 text-gray-600"></i>
                    </div>
                    <div>
                      <div class="text-sm font-medium text-gray-900">
                        <?php echo htmlspecialchars($applicant['first_name'] . ' ' . $applicant['last_name']); ?>
                      </div>
                      <div class="text-sm text-gray-500"><?php echo htmlspecialchars($applicant['email']); ?></div>
                    </div>
                  </div>
                </td>
                <td class="px-6 py-4 text-sm text-gray-900"><?php echo htmlspecialchars($applicant['job_title'] ?? 'Not specified'); ?></td>
                <td class="px-6 py-4 text-sm text-gray-900"><?php echo htmlspecialchars($applicant['department'] ?? 'Not specified'); ?></td>
                <td class="px-6 py-4 text-sm text-gray-500">
                  <?php 
                  // Use applied_at if it exists, otherwise use created_at
                  $date = !empty($applicant['applied_at']) ? $applicant['applied_at'] : $applicant['created_at'];
                  echo date('M d, Y', strtotime($date)); 
                  ?>
                </td>
                <td class="px-6 py-4">
                  <span class="px-3 py-1 text-xs rounded-full <?php echo $qual_color; ?>">
                    <?php echo $qual_text; ?>
                  </span>
                </td>
                <td class="px-6 py-4">
                  <?php if ($qualification_score !== null && $qualification_score > 0): ?>
                    <div class="flex items-center space-x-2">
                      <div class="w-16 bg-gray-200 rounded-full h-2">
                        <div class="bg-blue-600 h-2 rounded-full" style="width: <?php echo min($qualification_score, 100); ?>%"></div>
                      </div>
                      <span class="text-sm font-bold <?php echo $score_color; ?> score-badge" title="Qualification Score: <?php echo $qualification_score; ?>/100">
                        <?php echo $qualification_score; ?>
                      </span>
                    </div>
                  <?php else: ?>
                    <span class="text-sm text-gray-400">N/A</span>
                  <?php endif; ?>
                </td>
                <td class="px-6 py-4">
                  <?php 
                  $statusClass = [
                    'new' => 'bg-blue-100 text-blue-800',
                    'reviewed' => 'bg-yellow-100 text-yellow-800',
                    'shortlisted' => 'bg-green-100 text-green-800',
                    'interviewed' => 'bg-purple-100 text-purple-800',
                    'hired' => 'bg-green-100 text-green-800',
                    'rejected' => 'bg-red-100 text-red-800'
                  ];
                  $currentStatus = $applicant['application_status'] ?? 'new';
                  $class = $statusClass[$currentStatus] ?? 'bg-gray-100 text-gray-800';
                  ?>
                  <span class="px-3 py-1 text-xs rounded-full <?php echo $class; ?>">
                    <?php echo ucfirst($currentStatus); ?>
                  </span>
                </td>
                <td class="px-6 py-4">
                  <div class="flex space-x-2">
                    <a href="view_applicant.php?id=<?php echo $applicant['id']; ?>" 
                       class="px-3 py-1 text-sm bg-gray-100 rounded hover:bg-gray-200" title="View">
                      <i data-lucide="eye" class="w-4 h-4"></i>
                    </a>
                    <a href="screen_applicant.php?id=<?php echo $applicant['id']; ?>" 
                       class="px-3 py-1 text-sm bg-blue-100 text-blue-700 rounded hover:bg-blue-200" title="Screen">
                      <i data-lucide="search" class="w-4 h-4"></i>
                    </a>
                    <?php if ($is_qualified == 1): ?>
                    <a href="schedule_interview.php?id=<?php echo $applicant['id']; ?>" 
                       class="px-3 py-1 text-sm bg-green-100 text-green-700 rounded hover:bg-green-200" title="Schedule Interview">
                      <i data-lucide="calendar" class="w-4 h-4"></i>
                    </a>
                    <?php else: ?>
                    <a href="screen_applicant.php?id=<?php echo $applicant['id']; ?>" 
                       class="px-3 py-1 text-sm bg-yellow-100 text-yellow-700 rounded hover:bg-yellow-200" title="Qualify Applicant">
                      <i data-lucide="check-circle" class="w-4 h-4"></i>
                    </a>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
          
          <?php if(empty($applicants)): ?>
          <div class="text-center py-12">
            <i data-lucide="users" class="w-12 h-12 text-gray-400 mx-auto mb-4"></i>
            <p class="text-gray-500">No applicants found</p>
            <a href="import_applicants.php" class="mt-2 inline-block text-blue-600 hover:underline">
              Import applicants or wait for applications
            </a>
          </div>
          <?php endif; ?>
        </div>
      </div>
    </main>
  </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
  lucide.createIcons();
  
  // Filter functionality
  const statusFilter = document.getElementById('statusFilter');
  const jobFilter = document.getElementById('jobFilter');
  const qualificationFilter = document.getElementById('qualificationFilter');
  const searchInput = document.getElementById('searchInput');
  const applicantRows = document.querySelectorAll('.applicant-row');
  
  // Function to update URL with filters
  function updateFilters() {
    const status = statusFilter.value;
    const jobId = jobFilter.value;
    const qualification = qualificationFilter.value;
    const search = searchInput.value;
    
    let url = 'applicants.php';
    const params = [];
    
    if (status) params.push(`status=${status}`);
    if (jobId) params.push(`job_id=${jobId}`);
    if (qualification) params.push(`qualification=${qualification}`);
    if (search) params.push(`search=${encodeURIComponent(search)}`);
    
    if (params.length > 0) {
      url += '?' + params.join('&');
    }
    
    window.location.href = url;
  }
  
  // Add event listeners
  statusFilter.addEventListener('change', updateFilters);
  jobFilter.addEventListener('change', updateFilters);
  qualificationFilter.addEventListener('change', updateFilters);
  
  // Search functionality (debounced)
  let searchTimeout;
  searchInput.addEventListener('input', function() {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(updateFilters, 500);
  });
  
  // Enter key in search
  searchInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
      updateFilters();
    }
  });
});
</script>
</body>
</html>