<?php
// File: login.php – HARDCODED to send OTP to james.sabandal001@gmail.com
session_start();
require_once 'connections.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Redirect if already fully logged in
if (isset($_SESSION['user_id']) && isset($_SESSION['otp_verified']) && $_SESSION['otp_verified'] === true) {
    $redirect = $_SESSION['user_type'] === 'hr' ? 'admin_dashboard.php' : 'user_dashboard.php';
    header("Location: $redirect");
    exit;
}

// Google OAuth2 config (uses constants from connections.php)
$ENABLE_GOOGLE_LOGIN = true;
$google_login_url = '';
if ($ENABLE_GOOGLE_LOGIN && defined('GOOGLE_CLIENT_ID') && defined('GOOGLE_REDIRECT_URI')) {
    $google_auth_url = "https://accounts.google.com/o/oauth2/v2/auth";
    $google_scope = "https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/userinfo.profile";
    $google_login_url = $google_auth_url . "?" . http_build_query([
        'client_id' => GOOGLE_CLIENT_ID,
        'redirect_uri' => GOOGLE_REDIRECT_URI,
        'response_type' => 'code',
        'scope' => $google_scope,
        'access_type' => 'online',
        'prompt' => 'select_account'
    ]);
}

$ENABLE_RECAPTCHA = true;
$Email = $Emailerr = "";
$password = $passwordErr = "";
$otp = $otpErr = "";
$showOtpForm = false;
$successMsg = '';

// ------------------------------------------------------------
// Inline email sending function – uses new Gmail as SENDER (from connections.php)
// ------------------------------------------------------------
function sendOtpEmailInline($to, $name, $otp) {
    // TO is now hardcoded to new Gmail – but we'll pass it anyway
    $subject = "Your HR1 Login OTP Code";
    $message = '
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .otp-code { 
                font-size: 32px; 
                font-weight: bold; 
                color: #004AAD;
                letter-spacing: 5px;
                text-align: center;
                margin: 20px 0;
                padding: 15px;
                background: #f0f7ff;
                border-radius: 8px;
                border: 2px dashed #004AAD;
            }
            .expiry { color: #666; font-size: 14px; }
            .footer { margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; color: #777; }
        </style>
    </head>
    <body>
        <div class="container">
            <h2>HR1 Login Verification</h2>
            <p>Hello ' . htmlspecialchars($name) . ',</p>
            <p>Your One-Time Password (OTP) for HR1 login is:</p>
            <div class="otp-code">' . $otp . '</div>
            <p class="expiry">This OTP is valid for ' . OTP_EXPIRY_MINUTES . ' minutes.</p>
            <p>If you didn\'t request this OTP, please ignore this email.</p>
            <div class="footer">
                <p>Best regards,<br>HR1 Team</p>
            </div>
        </div>
    </body>
    </html>';
    
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;   // SSL for port 465
        $mail->Port       = SMTP_PORT;
        
        $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
        $mail->addAddress($to);  // This is the recipient – we will call with new email
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $message;
        
        $mail->send();
        error_log("OTP email sent to $to");
        return true;
    } catch (Exception $e) {
        error_log("OTP email failed: " . $mail->ErrorInfo);
        return false;
    }
}

function generateOtpInline() {
    return str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
}
// ------------------------------------------------------------

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // OTP verification
    if (isset($_POST['verify_otp']) && isset($_SESSION['temp_user_id'])) {
        $otp = trim($_POST['otp']);
        if (empty($otp) || strlen($otp) != 6 || !ctype_digit($otp)) {
            $otpErr = "OTP must be a 6-digit number!";
        } else {
            try {
                $stmt = $connections->prepare("SELECT id, username, email, full_name, role, otp_secret, otp_created_at FROM hr_users WHERE id = ? AND is_active = 1");
                $stmt->execute([$_SESSION['temp_user_id']]);
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($row && $row['otp_secret'] === $otp && (time() - strtotime($row['otp_created_at'])) <= 300) {
                    $_SESSION['user_id'] = $row['id'];
                    $_SESSION['user_name'] = $row['full_name'];
                    $_SESSION['user_role'] = $row['role'];
                    $_SESSION['user_email'] = $row['email'];
                    $_SESSION['user_username'] = $row['username'];
                    $_SESSION['otp_verified'] = true;
                    $_SESSION['user_type'] = 'hr';
                    $connections->prepare("UPDATE hr_users SET otp_secret = NULL, otp_created_at = NULL, last_login = NOW() WHERE id = ?")->execute([$row['id']]);
                    unset($_SESSION['temp_user_id']);
                    session_write_close();
                    header("Location: admin_dashboard.php");
                    exit;
                } else {
                    $otpErr = "Invalid or expired OTP!";
                }
            } catch (PDOException $e) {
                error_log("OTP verify error: " . $e->getMessage());
                $otpErr = "Verification failed. Try again.";
            }
        }
    }
    // Resend OTP
    elseif (isset($_POST['resend_otp']) && isset($_SESSION['temp_user_id'])) {
        try {
            $stmt = $connections->prepare("SELECT id, email, full_name FROM hr_users WHERE id = ? AND is_active = 1");
            $stmt->execute([$_SESSION['temp_user_id']]);
            $row = $stmt->fetch();
            if ($row) {
                $newOtp = generateOtpInline();
                $connections->prepare("UPDATE hr_users SET otp_secret = ?, otp_created_at = NOW() WHERE id = ?")->execute([$newOtp, $row['id']]);
                // HARDCODE recipient to new Gmail
                if (sendOtpEmailInline('james.sabandal001@gmail.com', $row['full_name'], $newOtp)) {
                    $successMsg = "New OTP sent to james.sabandal001@gmail.com";
                } else {
                    $otpErr = "Failed to send email. Check error log.";
                }
            }
        } catch (PDOException $e) {
            error_log("Resend OTP error: " . $e->getMessage());
            $otpErr = "Could not resend OTP.";
        }
    }
    // Initial login (email/password)
    else {
        // reCAPTCHA (unchanged)
        if ($ENABLE_RECAPTCHA) {
            if (empty($_POST['g-recaptcha-response'])) {
                $passwordErr = "Please verify reCAPTCHA.";
            } else {
                $recaptcha = $_POST['g-recaptcha-response'];
                $secretKey = "6Lc8cfUrAAAAAI6rmnqxzKHHBUGJP93VESP7JKXi";
                $verify = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret={$secretKey}&response={$recaptcha}");
                $captchaSuccess = json_decode($verify);
                if (!$captchaSuccess->success) {
                    $passwordErr = "reCAPTCHA verification failed.";
                }
            }
        }

        $Email = trim($_POST["Email"] ?? '');
        $password = trim($_POST["password"] ?? '');
        if (empty($Email)) $Emailerr = "Email required";
        elseif (!filter_var($Email, FILTER_VALIDATE_EMAIL)) $Emailerr = "Invalid email";
        if (empty($password)) $passwordErr = "Password required";

        if (empty($Emailerr) && empty($passwordErr)) {
            // Regular users (no OTP) – unchanged
            $stmt = $connections->prepare("SELECT id, username, email, full_name, role, password_hash FROM users WHERE email = ? AND is_active = 1");
            $stmt->execute([$Email]);
            $user = $stmt->fetch();
            if ($user && password_verify($password, $user['password_hash'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['full_name'];
                $_SESSION['user_role'] = $user['role'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['user_username'] = $user['username'];
                $_SESSION['otp_verified'] = true;
                $_SESSION['user_type'] = 'user';
                $connections->prepare("UPDATE users SET last_login = NOW() WHERE id = ?")->execute([$user['id']]);
                session_write_close();
                header("Location: user_dashboard.php");
                exit;
            }

            // HR users (OTP required) – HARDCODE recipient
            $stmt = $connections->prepare("SELECT id, username, email, full_name, role, password_hash FROM hr_users WHERE email = ? AND is_active = 1");
            $stmt->execute([$Email]);
            $hr = $stmt->fetch();
            if ($hr && password_verify($password, $hr['password_hash'])) {
                $otpCode = generateOtpInline();
                $connections->prepare("UPDATE hr_users SET otp_secret = ?, otp_created_at = NOW() WHERE id = ?")->execute([$otpCode, $hr['id']]);
                $_SESSION['temp_user_id'] = $hr['id'];
                $_SESSION['temp_user_type'] = 'hr';
                // Force the displayed email to the new Gmail
                $_SESSION['temp_user_email'] = 'james.sabandal001@gmail.com';
                // Force OTP to be sent to new Gmail
                if (sendOtpEmailInline('james.sabandal001@gmail.com', $hr['full_name'], $otpCode)) {
                    $showOtpForm = true;
                    $successMsg = "OTP sent to james.sabandal001@gmail.com";
                } else {
                    $passwordErr = "Failed to send OTP email. Please try again.";
                }
            } else {
                $Emailerr = "Invalid email or password.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>HR1 — Login</title>
  <link rel="icon" href="img/logo2.png">
  <script src="https://cdn.tailwindcss.com"></script>
  <?php if ($ENABLE_RECAPTCHA && !$showOtpForm): ?>
  <script src="https://www.google.com/recaptcha/api.js" async defer></script>
  <?php endif; ?>
  <style>
    :root {
      --blue-600: #004AAD;
      --blue-800: #003680;
      --gold: #d4af37;
      --ink: #0f172a;
      --card-bg: rgba(255,255,255,.95);
      --card-border: rgba(226,232,240,.9);
    }
    body {
      min-height: 100vh;
      margin: 0;
      color: var(--ink);
      background: linear-gradient(140deg, rgba(15,28,73,1) 50%, rgba(255,255,255,1) 50%);
    }
    .card {
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      border-radius: 18px;
      box-shadow: 0 16px 48px rgba(2,6,23,.18);
    }
    .input {
      width: 100%;
      border: 1px solid #e5e7eb;
      border-radius: 12px;
      padding: 1rem .95rem;
      font-family: 'Poppins', sans-serif;
      transition: all 0.3s;
    }
    .input:focus {
      outline: none;
      border-color: var(--blue-600);
      box-shadow: 0 0 0 3px rgba(0, 74, 173, 0.1);
    }
    .input-otp {
      font-size: 32px;
      font-weight: bold;
      letter-spacing: 10px;
      text-align: center;
    }
    .btn {
      width: 100%;
      background: linear-gradient(180deg, var(--blue-600), var(--blue-800));
      color: #fff;
      font-weight: 800;
      border-radius: 14px;
      padding: .95rem 1rem;
      cursor: pointer;
      transition: all 0.3s;
      border: none;
      font-family: 'Poppins', sans-serif;
    }
    .btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 10px 20px rgba(0, 74, 173, 0.2);
    }
    .btn-secondary {
      background: linear-gradient(180deg, #6b7280, #4b5563);
    }
    .btn-google {
      background: #4285F4;
      color: white;
      border: none;
      border-radius: 14px;
      padding: .95rem 1rem;
      font-weight: 600;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 12px;
      transition: all 0.3s;
    }
    .btn-google:hover {
      background: #357ae8;
      transform: translateY(-2px);
    }
    .error-message {
      color: #b91c1c;
      font-size: .85rem;
      display: block;
      margin-top: .25rem;
    }
    .success-message {
      color: #16a34a;
      font-size: .85rem;
      display: block;
      margin-top: .25rem;
    }
    .text-gold { color: var(--gold); }
  </style>
</head>
<body class="grid md:grid-cols-2 gap-0 place-items-center p-6 md:p-10 font-['Poppins',sans-serif]">

  <!-- Left panel -->
  <section class="hidden md:flex w-full h-full items-center justify-center">
    <div class="max-w-lg text-white px-6">
      <div class="flex items-center gap-4 mb-6">
        <div class="w-16 h-16 bg-white rounded-xl flex items-center justify-center shadow-lg">
          <div class="text-2xl font-bold text-blue-800">HR</div>
        </div>
        <div>
          <div class="text-3xl font-bold font-['Playfair_Display',serif]">Atiera</div>
          <div class="text-sm text-white/80 font-medium">Hotel & Restaurant Management</div>
        </div>
      </div>
      <h1 class="text-4xl font-extrabold leading-tight tracking-tight">
        HR1 <span class="text-gold">Recruitment</span> System
      </h1>
      <p class="mt-4 text-white/90 text-lg">Manage job requests, applicants, interviews, and hiring processes efficiently.</p>
      <div class="mt-8 grid grid-cols-2 gap-4">
        <div class="bg-white/10 p-4 rounded-xl backdrop-blur-sm"><div class="text-2xl font-bold text-gold">12</div><div class="text-sm text-white/80">Step Process</div></div>
        <div class="bg-white/10 p-4 rounded-xl backdrop-blur-sm"><div class="text-2xl font-bold text-gold">✓</div><div class="text-sm text-white/80">Secure Access</div></div>
        <div class="bg-white/10 p-4 rounded-xl backdrop-blur-sm"><div class="text-2xl font-bold text-gold">📊</div><div class="text-sm text-white/80">Analytics</div></div>
        <div class="bg-white/10 p-4 rounded-xl backdrop-blur-sm"><div class="text-2xl font-bold text-gold">👥</div><div class="text-sm text-white/80">Team Management</div></div>
      </div>
    </div>
  </section>

  <!-- Right panel -->
  <main class="w-full max-w-md md:ml-auto">
    <div class="card p-6 sm:p-8 mt-16 md:mt-0">
      <?php if ($showOtpForm): ?>
        <!-- OTP Verification Form -->
        <div class="text-center mb-6">
          <h3 class="text-2xl font-bold text-gray-800 mb-2">OTP Verification</h3>
          <p class="text-sm text-slate-500">
            Enter the 6-digit code sent to your email<br>
            <span class="font-medium">james.sabandal001@gmail.com</span>
          </p>
        </div>
        <?php if (!empty($successMsg)): ?>
          <div class="mb-4 p-3 bg-green-50 text-green-700 rounded-lg border border-green-200"><?php echo htmlspecialchars($successMsg); ?></div>
        <?php endif; ?>
        <?php if (!empty($otpErr)): ?>
          <div class="mb-4 p-3 bg-red-50 text-red-700 rounded-lg border border-red-200"><?php echo htmlspecialchars($otpErr); ?></div>
        <?php endif; ?>
        <form method="POST" class="space-y-4">
          <div class="otp-container">
            <label class="block text-sm font-medium text-gray-700 mb-2">Enter OTP Code</label>
            <input type="text" name="otp" class="input input-otp" placeholder="000000" maxlength="6" pattern="\d{6}" required autocomplete="off" oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0,6)">
          </div>
          <div class="text-sm text-gray-600 text-center">
            <p>OTP expires in <span class="font-bold text-blue-600">5 minutes</span></p>
            <p class="mt-2">Didn't receive the code?</p>
          </div>
          <div class="space-y-3">
            <button type="submit" name="verify_otp" class="btn">Verify & Continue</button>
            <button type="submit" name="resend_otp" class="btn btn-secondary">Resend OTP</button>
            <a href="?cancel_otp" class="block text-center text-sm text-blue-600 hover:text-blue-800 mt-2">Back to Login</a>
          </div>
        </form>
        <div class="mt-6 pt-6 border-t border-gray-200">
          <p class="text-xs text-center text-slate-500">Having trouble? Contact HR Administrator<br><a href="mailto:hr@atiera.com" class="text-blue-600 font-semibold">hr@atiera.com</a></p>
        </div>
      <?php else: ?>
        <!-- Regular Login Form -->
        <div class="text-center mb-6">
          <h3 class="text-2xl font-bold text-gray-800 mb-2">HR1 System Login</h3>
          <p class="text-sm text-slate-500">Access the recruitment management dashboard</p>
        </div>

        <?php if (!empty($passwordErr) && strpos($passwordErr, 'Captcha') === false && !empty($passwordErr)): ?>
          <div class="mb-4 p-3 bg-red-50 text-red-700 rounded-lg"><?php echo htmlspecialchars($passwordErr); ?></div>
        <?php endif; ?>
        <?php if (!empty($Emailerr)): ?>
          <div class="mb-4 p-3 bg-red-50 text-red-700 rounded-lg"><?php echo htmlspecialchars($Emailerr); ?></div>
        <?php endif; ?>

        <!-- Google Sign-In Button -->
        <?php if ($ENABLE_GOOGLE_LOGIN && $google_login_url): ?>
          <a href="<?php echo $google_login_url; ?>" class="btn-google mb-4">
            <svg width="20" height="20" viewBox="0 0 24 24">
              <path fill="white" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
              <path fill="white" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
              <path fill="white" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/>
              <path fill="white" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
            </svg>
            Sign in with Google
          </a>
          <div class="relative my-4"><div class="absolute inset-0 flex items-center"><div class="w-full border-t border-gray-300"></div></div><div class="relative flex justify-center text-sm"><span class="px-2 bg-white text-gray-500">Or continue with email</span></div></div>
        <?php endif; ?>

        <form method="POST" class="space-y-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
            <input type="email" name="Email" class="input" placeholder="you@luxuryhotel.com" value="<?php echo htmlspecialchars($Email); ?>" required>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Password</label>
            <input type="password" name="password" class="input" placeholder="Enter your password" required>
          </div>
          <?php if ($ENABLE_RECAPTCHA): ?>
            <div class="g-recaptcha" data-sitekey="6Lc8cfUrAAAAAJUWn8t53qUZLDSSEsSchNVKWD5c"></div>
          <?php endif; ?>
          <div class="flex items-center justify-between">
            <div class="flex items-center">
              <input id="remember-me" type="checkbox" class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
              <label for="remember-me" class="ml-2 block text-sm text-gray-700">Remember me</label>
            </div>
            <a href="forgot-password.php" class="text-sm text-blue-600 hover:text-blue-800">Forgot password?</a>
          </div>
          <button type="submit" class="btn">Login to Dashboard</button>
        </form>

        <div class="mt-6 pt-6 border-t border-gray-200">
          <p class="text-xs text-center text-slate-500">Need access? Contact HR Administrator<br><a href="mailto:hr@luxuryhotel.com" class="text-blue-600 font-semibold">hr@luxuryhotel.com</a></p>
          <div class="mt-4 text-center">
            <a href="index.php" class="inline-flex items-center text-sm text-gray-600 hover:text-blue-600">
              <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
              </svg>
              Back to Careers Site
            </a>
          </div>
        </div>
      <?php endif; ?>
    </div>
    <div class="mt-6 text-center text-white md:hidden">
      <h4 class="text-lg font-semibold mb-2">HR1 Recruitment Process</h4>
      <div class="flex justify-center items-center space-x-2 text-sm">
        <span class="bg-white/20 px-3 py-1 rounded-full">1. Job Request</span>
        <span class="text-white/50">→</span>
        <span class="bg-white/20 px-3 py-1 rounded-full">2. Approval</span>
        <span class="text-white/50">→</span>
        <span class="bg-white/20 px-3 py-1 rounded-full">3. Hiring</span>
      </div>
    </div>
  </main>
</body>
</html>