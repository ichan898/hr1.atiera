<?php
// File: sign_contract.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

// Check if ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: onboarding.php');
    exit();
}

$id = $_GET['id'];

// Fetch onboarding details
$query = "SELECT * FROM onboarding WHERE id = ?";
$stmt = $connections->prepare($query);
$stmt->execute([$id]);
$onboarding = $stmt->fetch();

if (!$onboarding) {
    header('Location: onboarding.php');
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_contract'])) {
    // Fetch current contract_file directly from DB to avoid undefined key warnings
    $stmt_file = $connections->prepare("SELECT contract_file FROM onboarding WHERE id = ?");
    $stmt_file->execute([$id]);
    $current_file_row = $stmt_file->fetch();
    $existing_contract_file = $current_file_row ? $current_file_row['contract_file'] : null;

    $contract_status = $_POST['contract_status'] ?? '';
    $contract_signed = isset($_POST['contract_signed']) ? 1 : 0;
    $signature = $_POST['signature'] ?? '';
    $notes = $_POST['notes'] ?? '';

    // Handle file upload
    $contract_file = $existing_contract_file; // keep existing by default
    if (isset($_FILES['contract_file']) && $_FILES['contract_file']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = 'uploads/contracts/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        // Sanitize file name
        $fileName = time() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '', basename($_FILES['contract_file']['name']));
        $targetFile = $uploadDir . $fileName;

        if (move_uploaded_file($_FILES['contract_file']['tmp_name'], $targetFile)) {
            $contract_file = $targetFile;
        }
    }

    $update_query = "UPDATE onboarding SET 
        contract_status = ?,
        contract_signed = ?,
        contract_file = ?,
        contract_signature = ?,
        contract_signed_date = ?,
        notes = CONCAT(COALESCE(notes, ''), ?),
        updated_at = NOW()
        WHERE id = ?";

    $contract_signed_date = $contract_signed ? date('Y-m-d') : null;
    $update_notes = "\n\nContract updated on " . date('Y-m-d H:i:s') . ": " . $notes;

    $update_stmt = $connections->prepare($update_query);
    $update_stmt->execute([
        $contract_status,
        $contract_signed,
        $contract_file,
        $signature,
        $contract_signed_date,
        $update_notes,
        $id
    ]);

    $_SESSION['success'] = "Contract details updated successfully!";
    header("Location: view_onboarding.php?id=$id");
    exit();
}

// Get HR users for dropdown
$hr_users_query = "SELECT id, full_name FROM users WHERE role IN ('admin', 'hr_manager', 'hr_officer')";
$hr_users = $connections->query($hr_users_query)->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HR1 - Sign Employment Contract</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="bg-gray-50 min-h-screen">
    <div class="flex">
        <?php include 'sidebar.php'; ?>
        
        <div class="flex-1 p-6">
            <!-- Header -->
            <div class="flex justify-between items-center mb-6">
                <div>
                    <h1 class="text-2xl font-bold text-gray-800">Employment Contract Management</h1>
                    <p class="text-gray-600">
                        <?php echo htmlspecialchars($onboarding['first_name'] . ' ' . $onboarding['last_name']); ?> - 
                        <?php echo htmlspecialchars($onboarding['job_position']); ?>
                    </p>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="view_onboarding.php?id=<?php echo $id; ?>" 
                       class="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 flex items-center">
                        <i data-lucide="arrow-left" class="w-4 h-4 mr-2"></i>
                        Back to Onboarding
                    </a>
                    <?php include 'profile_dropdown.php'; ?>
                </div>
            </div>

            <?php if (isset($_SESSION['success'])): ?>
            <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-6">
                <div class="flex items-center">
                    <i data-lucide="check-circle" class="w-5 h-5 mr-2"></i>
                    <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                </div>
            </div>
            <?php endif; ?>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <!-- Contract Details -->
                <div class="lg:col-span-2">
                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
                        <h2 class="text-xl font-bold text-gray-800 mb-4">Contract Information</h2>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <p class="text-sm text-gray-500">Employee Name</p>
                                <p class="font-medium"><?php echo htmlspecialchars($onboarding['first_name'] . ' ' . $onboarding['last_name']); ?></p>
                            </div>
                            <div>
                                <p class="text-sm text-gray-500">Position</p>
                                <p class="font-medium"><?php echo htmlspecialchars($onboarding['job_position']); ?></p>
                            </div>
                            <div>
                                <p class="text-sm text-gray-500">Department</p>
                                <p class="font-medium"><?php echo htmlspecialchars($onboarding['department']); ?></p>
                            </div>
                            <div>
                                <p class="text-sm text-gray-500">Employment Type</p>
                                <p class="font-medium"><?php echo ucfirst(htmlspecialchars($onboarding['employment_type'])); ?></p>
                            </div>
                            <?php if (!empty($onboarding['salary'])): ?>
                            <div>
                                <p class="text-sm text-gray-500">Salary</p>
                                <p class="font-medium">₱<?php echo number_format($onboarding['salary'], 2); ?></p>
                            </div>
                            <?php endif; ?>
                            <div>
                                <p class="text-sm text-gray-500">Start Date</p>
                                <p class="font-medium"><?php echo date('M d, Y', strtotime($onboarding['start_date'])); ?></p>
                            </div>
                        </div>
                    </div>

                    <!-- Contract Form -->
                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                        <h3 class="text-lg font-semibold mb-4">Contract Details</h3>
                        <form method="POST" enctype="multipart/form-data">
                            <div class="space-y-6">
                                <!-- Contract Status -->
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Contract Status</label>
                                    <select name="contract_status" class="w-full border border-gray-300 rounded-lg p-2">
                                        <option value="Pending HR" <?php echo ($onboarding['contract_status'] ?? '') == 'Pending HR' ? 'selected' : ''; ?>>Pending HR</option>
                                        <option value="HR Approved" <?php echo ($onboarding['contract_status'] ?? '') == 'HR Approved' ? 'selected' : ''; ?>>HR Approved</option>
                                        <option value="Manager Approved" <?php echo ($onboarding['contract_status'] ?? '') == 'Manager Approved' ? 'selected' : ''; ?>>Manager Approved</option>
                                        <option value="Completed" <?php echo ($onboarding['contract_status'] ?? '') == 'Completed' ? 'selected' : ''; ?>>Completed</option>
                                        <option value="Rejected" <?php echo ($onboarding['contract_status'] ?? '') == 'Rejected' ? 'selected' : ''; ?>>Rejected</option>
                                    </select>
                                </div>

                                <!-- Signed Status -->
                                <div class="flex items-center">
                                    <input type="checkbox" name="contract_signed" id="contract_signed" value="1" 
                                           class="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                                           <?php echo !empty($onboarding['contract_signed']) ? 'checked' : ''; ?>>
                                    <label for="contract_signed" class="ml-2 block text-sm text-gray-700">
                                        Contract Signed by Employee
                                    </label>
                                </div>

                                <!-- Signature -->
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Employee Signature (Digital)</label>
                                    <input type="text" name="signature" 
                                           class="w-full border border-gray-300 rounded-lg p-2"
                                           placeholder="Enter employee's name as digital signature"
                                           value="<?php echo htmlspecialchars($onboarding['contract_signature'] ?? ''); ?>">
                                </div>

                                <!-- Contract File -->
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Contract Document</label>
                                    <div class="mt-1 flex items-center">
                                        <input type="file" name="contract_file" 
                                               class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                                               accept=".pdf,.doc,.docx">
                                    </div>
                                    <?php if (!empty($onboarding['contract_file'])): ?>
                                    <p class="mt-2 text-sm text-gray-500">
                                        Current file: 
                                        <a href="<?php echo htmlspecialchars($onboarding['contract_file']); ?>" 
                                           target="_blank" class="text-blue-600 hover:underline">
                                            View Contract
                                        </a>
                                    </p>
                                    <?php endif; ?>
                                </div>

                                <!-- Notes -->
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Notes</label>
                                    <textarea name="notes" rows="3" 
                                              class="w-full border border-gray-300 rounded-lg p-2"
                                              placeholder="Add any notes about the contract..."></textarea>
                                </div>

                                <button type="submit" name="update_contract"
                                        class="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 font-medium">
                                    <i data-lucide="save" class="w-5 h-5 inline mr-2"></i>
                                    Update Contract Details
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Right Column - Status & Actions -->
                <div class="space-y-6">
                    <!-- Current Status -->
                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                        <h3 class="text-lg font-semibold mb-4">Current Status</h3>
                        <div class="space-y-4">
                            <div class="flex justify-between items-center">
                                <span class="text-gray-600">Contract Status</span>
                                <span class="px-3 py-1 rounded-full text-sm font-medium 
                                    <?php 
                                    $status = $onboarding['contract_status'] ?? 'Pending';
                                    echo $status == 'Completed' ? 'bg-green-100 text-green-800' : 
                                           ($status == 'Rejected' ? 'bg-red-100 text-red-800' : 
                                           'bg-yellow-100 text-yellow-800'); 
                                    ?>">
                                    <?php echo htmlspecialchars($status); ?>
                                </span>
                            </div>
                            
                            <div class="flex justify-between items-center">
                                <span class="text-gray-600">Signed Status</span>
                                <span class="px-3 py-1 rounded-full text-sm font-medium 
                                    <?php echo !empty($onboarding['contract_signed']) ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'; ?>">
                                    <?php echo !empty($onboarding['contract_signed']) ? 'Signed' : 'Not Signed'; ?>
                                </span>
                            </div>
                            
                            <?php if (!empty($onboarding['contract_signed']) && !empty($onboarding['contract_signed_date'])): ?>
                            <div class="border-t pt-4">
                                <p class="text-sm text-gray-500">Signed Date</p>
                                <p class="font-medium"><?php echo date('M d, Y', strtotime($onboarding['contract_signed_date'])); ?></p>
                            </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($onboarding['approved_by_hr'])): ?>
                            <div class="border-t pt-4">
                                <p class="text-sm text-gray-500">Approved by HR</p>
                                <p class="font-medium"><?php echo date('M d, Y', strtotime($onboarding['approved_by_hr'])); ?></p>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Quick Actions -->
                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                        <h3 class="text-lg font-semibold mb-4">Quick Actions</h3>
                        <div class="space-y-3">
                            <?php if (empty($onboarding['contract_signed'])): ?>
                            <button type="button" onclick="markAsSigned()"
                                    class="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700">
                                <i data-lucide="check-circle" class="w-4 h-4 inline mr-2"></i>
                                Mark as Signed
                            </button>
                            <?php endif; ?>
                            
                            <?php if (!empty($onboarding['contract_file'])): ?>
                            <a href="<?php echo htmlspecialchars($onboarding['contract_file']); ?>" 
                               target="_blank"
                               class="block w-full text-center border border-blue-600 text-blue-600 py-2 rounded-lg hover:bg-blue-50">
                                <i data-lucide="file-text" class="w-4 h-4 inline mr-2"></i>
                                View Contract
                            </a>
                            <?php endif; ?>
                            
                            <a href="view_onboarding.php?id=<?php echo $id; ?>"
                               class="block w-full text-center border border-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-50">
                                <i data-lucide="eye" class="w-4 h-4 inline mr-2"></i>
                                View Onboarding
                            </a>
                        </div>
                    </div>

                    <!-- Contract Template -->
                    <div class="bg-blue-50 border border-blue-200 rounded-xl p-6">
                        <h3 class="text-lg font-semibold mb-2 text-blue-800">Contract Template</h3>
                        <p class="text-sm text-blue-700 mb-4">Standard employment contract includes:</p>
                        <ul class="space-y-2 text-blue-700 text-sm">
                            <li class="flex items-start">
                                <i data-lucide="check-circle" class="w-4 h-4 mr-2 mt-0.5 text-blue-600"></i>
                                <span>Job title and description</span>
                            </li>
                            <li class="flex items-start">
                                <i data-lucide="check-circle" class="w-4 h-4 mr-2 mt-0.5 text-blue-600"></i>
                                <span>Salary and compensation</span>
                            </li>
                            <li class="flex items-start">
                                <i data-lucide="check-circle" class="w-4 h-4 mr-2 mt-0.5 text-blue-600"></i>
                                <span>Work schedule and location</span>
                            </li>
                            <li class="flex items-start">
                                <i data-lucide="check-circle" class="w-4 h-4 mr-2 mt-0.5 text-blue-600"></i>
                                <span>Benefits and entitlements</span>
                            </li>
                            <li class="flex items-start">
                                <i data-lucide="check-circle" class="w-4 h-4 mr-2 mt-0.5 text-blue-600"></i>
                                <span>Probation period</span>
                            </li>
                        </ul>
                        <a href="templates/employment_contract.docx" 
                           class="mt-4 inline-flex items-center text-sm text-blue-600 hover:text-blue-800">
                            <i data-lucide="download" class="w-4 h-4 mr-2"></i>
                            Download Template
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener("DOMContentLoaded", () => {
        lucide.createIcons();
    });

    function markAsSigned() {
        if (confirm('Mark this contract as signed by the employee?')) {
            document.querySelector('#contract_signed').checked = true;
            document.querySelector('[name="signature"]').value = "<?php echo htmlspecialchars($onboarding['first_name'] . ' ' . $onboarding['last_name']); ?>";
            document.querySelector('[name="contract_status"]').value = 'HR Approved';
            
            // Submit the form
            document.querySelector('form').submit();
        }
    }
    </script>
</body>
</html>