<?php
require_once 'email_functions.php';
$result = sendOtpEmail('vergarajamesryan47@gmail.com', 'Test User', '123456');
echo $result ? "Email sent (via SMTP or fallback)" : "All methods failed";
?>