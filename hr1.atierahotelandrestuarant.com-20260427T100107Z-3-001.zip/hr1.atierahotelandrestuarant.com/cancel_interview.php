<?php
// File: cancel_interview.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

// Get interview ID
if (!isset($_GET['id'])) {
    header('Location: interviews.php');
    exit();
}

$interview_id = $_GET['id'];

// Fetch interview details
$query = "SELECT * FROM interviews WHERE id = :id";
$stmt = $connections->prepare($query);
$stmt->bindParam(':id', $interview_id, PDO::PARAM_INT);
$stmt->execute();
$interview = $stmt->fetch();

if (!$interview) {
    $_SESSION['error'] = "Interview not found";
    header('Location: interviews.php');
    exit();
}

// Cancel the interview
try {
    $update_query = "UPDATE interviews SET 
                     status = 'cancelled',
                     cancelled_at = NOW(),
                     cancelled_by = :user_id,
                     updated_at = NOW()
                     WHERE id = :id";
    
    $update_stmt = $connections->prepare($update_query);
    $update_stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
    $update_stmt->bindParam(':id', $interview_id, PDO::PARAM_INT);
    $update_stmt->execute();
    
    $_SESSION['success'] = "Interview cancelled successfully!";
    
} catch (PDOException $e) {
    $_SESSION['error'] = "Failed to cancel interview: " . $e->getMessage();
}

header('Location: view_interview.php?id=' . $interview_id);
exit();
?>