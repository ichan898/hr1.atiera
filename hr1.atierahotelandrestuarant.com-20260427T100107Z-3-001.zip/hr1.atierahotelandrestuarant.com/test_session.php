<?php
// test_session.php - Display all session variables
session_start();
echo "<h2>Session Debugger</h2>";
echo "<pre>";
echo "Session ID: " . session_id() . "\n\n";
echo "SESSION CONTENTS:\n";
print_r($_SESSION);
echo "\n\n";
echo "Session save path: " . ini_get('session.save_path') . "\n";
echo "Session cookie params: " . print_r(session_get_cookie_params(), true) . "\n";
echo "</pre>";

// Test if session can be written
$_SESSION['test_write'] = time();
echo "<p>Test write at: " . $_SESSION['test_write'] . "</p>";
echo "<a href='test_session.php'>Refresh to see if session persists</a>";
?>