<?php
// process_onboarding.php – PDO version
// Only runs when this file is executed directly (not when included)

// Check if this script is the main script being executed
if (basename(__FILE__) == basename($_SERVER['SCRIPT_FILENAME'])) {
    // This block runs only when the script is accessed directly
    error_reporting(E_ALL);
    ini_set('display_errors', 1);

    require_once 'connections.php'; // This should define $connections as a PDO object

    if (!$connections) {
        die("Database connection failed.");
    }

    // Get today's date
    $today = date('Y-m-d');

    // Fetch eligible onboarding records
    $sql = "
        SELECT 
            o.*,
            a.gender AS applicant_gender,
            a.birthday AS applicant_birthday,
            d.id AS department_id
        FROM onboarding o
        LEFT JOIN applicants a ON o.applicant_id = a.id
        LEFT JOIN departments d ON o.department = d.name
        WHERE o.start_date <= :today
          AND o.employee_record_id IS NULL
          AND o.status != 'completed'
    ";
    $stmt = $connections->prepare($sql);
    if (!$stmt) {
        $error = $connections->errorInfo();
        die("Prepare failed: " . $error[2]);
    }
    $stmt->execute([':today' => $today]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $processed = 0;
    $errors = [];

    foreach ($rows as $row) {
        // Begin transaction
        $connections->beginTransaction();
        try {
            // Determine gender (use applicant gender or default)
            $gender = $row['applicant_gender'] ?? 'Male';
            if (!in_array($gender, ['Male', 'Female', 'Other'])) {
                $gender = 'Male'; // Ensure valid enum
            }

            // Determine date of birth
            $dob = $row['applicant_birthday'] ?? $row['date_of_birth'] ?? null;
            if (!$dob) {
                throw new Exception("Missing date of birth for onboarding ID {$row['id']}");
            }

            // Insert employee (without employee_id first)
            $insertEmp = "
                INSERT INTO employees (
                    first_name, middle_name, last_name, position, gender,
                    department_id, email, contact_number, address, date_of_birth, hire_date, status
                ) VALUES (
                    :first_name, :middle_name, :last_name, :position, :gender,
                    :department_id, :email, :contact_number, :address, :dob, :hire_date, 'Active'
                )
            ";
            $stmtEmp = $connections->prepare($insertEmp);
            if (!$stmtEmp) {
                $error = $connections->errorInfo();
                throw new Exception("Prepare employee insert failed: " . $error[2]);
            }
            $stmtEmp->execute([
                ':first_name'    => $row['first_name'],
                ':middle_name'   => $row['middle_name'],
                ':last_name'     => $row['last_name'],
                ':position'      => $row['job_position'],
                ':gender'        => $gender,
                ':department_id' => $row['department_id'],
                ':email'         => $row['email'],
                ':contact_number'=> $row['contact_number'],
                ':address'       => $row['address'],
                ':dob'           => $dob,
                ':hire_date'     => $row['hire_date']
            ]);
            $new_employee_id = $connections->lastInsertId();

            // Generate a unique employee_id
            $emp_code = 'EMP' . date('Ymd') . str_pad($new_employee_id, 4, '0', STR_PAD_LEFT);
            $updateEmp = "UPDATE employees SET employee_id = :emp_code WHERE id = :id";
            $stmtUpdEmp = $connections->prepare($updateEmp);
            if (!$stmtUpdEmp) {
                $error = $connections->errorInfo();
                throw new Exception("Prepare employee update failed: " . $error[2]);
            }
            $stmtUpdEmp->execute([
                ':emp_code' => $emp_code,
                ':id'       => $new_employee_id
            ]);

            // Link onboarding to new employee
            $updateOnboard = "
                UPDATE onboarding 
                SET employee_record_id = :emp_id, status = 'completed', updated_at = NOW()
                WHERE id = :onboard_id
            ";
            $stmtUpd = $connections->prepare($updateOnboard);
            if (!$stmtUpd) {
                $error = $connections->errorInfo();
                throw new Exception("Prepare onboarding update failed: " . $error[2]);
            }
            $stmtUpd->execute([
                ':emp_id'      => $new_employee_id,
                ':onboard_id'  => $row['id']
            ]);

            $connections->commit();
            $processed++;
            echo "✅ Processed onboarding ID {$row['id']} → Employee ID $emp_code\n";
        } catch (Exception $e) {
            $connections->rollBack();
            $errors[] = "❌ Error on onboarding ID {$row['id']}: " . $e->getMessage();
        }
    }

    echo "\n--- Summary ---\n";
    echo "Processed: $processed\n";
    if (!empty($errors)) {
        echo "Errors:\n" . implode("\n", $errors);
    } else {
        echo "All good!";
    }
}
// If the file is included, nothing above this line runs.
?>