<?php
// File: update_request_status.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $requestId = $_POST['request_id'] ?? 0;
    $status = $_POST['status'] ?? '';
    $comments = $_POST['comments'] ?? '';
    
    if (empty($requestId) || empty($status)) {
        $_SESSION['flash_message'] = [
            'type' => 'error',
            'message' => 'Invalid request'
        ];
        header("Location: job_requests.php");
        exit();
    }
    
    // Check permission
    if (!in_array($_SESSION['user_role'], ['admin', 'hr_manager', 'hr_officer'])) {
        $_SESSION['flash_message'] = [
            'type' => 'error',
            'message' => 'You do not have permission to update request status'
        ];
        header("Location: view_request.php?id={$requestId}");
        exit();
    }
    
    $result = updateJobRequestStatus($requestId, $status, $comments, $connections);
    
    if ($result['success']) {
        $_SESSION['flash_message'] = [
            'type' => 'success',
            'message' => "Job request status updated to " . ucfirst($status)
        ];
    } else {
        $_SESSION['flash_message'] = [
            'type' => 'error',
            'message' => $result['error']
        ];
    }
    
    header("Location: view_request.php?id={$requestId}");
    exit();
} else {
    header("Location: job_requests.php");
    exit();
}
?>