<?php
session_start();
require_once 'connections.php';
require_once 'email_functions.php';

echo "<h2>Manual OTP Test</h2>";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $otp = $_POST['otp'];
    $temp_id = $_SESSION['temp_user_id'] ?? null;
    
    echo "<p>Temp user ID: $temp_id</p>";
    echo "<p>Entered OTP: $otp</p>";
    
    if ($temp_id) {
        $stmt = $connections->prepare("SELECT otp_secret, otp_created_at FROM hr_users WHERE id = ?");
        $stmt->execute([$temp_id]);
        $row = $stmt->fetch();
        if ($row) {
            echo "<p>Stored OTP: {$row['otp_secret']}</p>";
            echo "<p>Created at: {$row['otp_created_at']}</p>";
            $timeDiff = time() - strtotime($row['otp_created_at']);
            echo "<p>Time difference: $timeDiff seconds</p>";
            if ($row['otp_secret'] === $otp && $timeDiff <= 300) {
                echo "<p style='color:green'>✅ OTP VALID! Setting session...</p>";
                $_SESSION['user_id'] = $temp_id;
                $_SESSION['otp_verified'] = true;
                unset($_SESSION['temp_user_id']);
                echo "<p>Session updated. <a href='test_auth.php'>Check auth</a></p>";
            } else {
                echo "<p style='color:red'>❌ OTP invalid or expired</p>";
            }
        }
    } else {
        echo "<p>No temp user in session. Please login first.</p>";
    }
} else {
    // Show form
    echo '<form method="POST">';
    echo '<label>Enter OTP: </label>';
    echo '<input type="text" name="otp" placeholder="6-digit code">';
    echo '<button type="submit">Verify</button>';
    echo '</form>';
    echo "<p>Current session: <pre>" . print_r($_SESSION, true) . "</pre></p>";
}
?>