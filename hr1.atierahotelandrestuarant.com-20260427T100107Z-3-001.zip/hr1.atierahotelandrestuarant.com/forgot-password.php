<?php
// File: forgot-password.php
session_start();
require_once 'connections.php';

$email = $error = $success = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST["email"]);
    
    if (empty($email)) {
        $error = "Email is required!";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format!";
    } else {
        // Check if email exists in HR users
        $stmt = $connections->prepare("
            SELECT id, full_name 
            FROM hr_users 
            WHERE email = ? AND is_active = TRUE
        ");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        
        if ($user) {
            // Generate reset token
            $token = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
            
            // Store token in database
            $updateStmt = $connections->prepare("
                UPDATE hr_users 
                SET reset_token = ?, reset_expires = ? 
                WHERE id = ?
            ");
            $updateStmt->execute([$token, $expires, $user['id']]);
            
            // Send reset email (in production)
            $reset_link = "http://localhost/atiera/reset-password.php?token=$token";
            
            $success = "Password reset instructions have been sent to your email.";
            
            // For demo, show the link
            $success .= "<br><br><strong>Demo Reset Link:</strong> <a href='$reset_link' class='text-blue-600'>$reset_link</a>";
        } else {
            $error = "Email not found in HR system.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - HR1 System</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        :root {
            --blue-600: #004AAD;
            --blue-800: #003680;
        }
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #004AAD 0%, #003680 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .card {
            background: white;
            border-radius: 18px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>
<body>
    <div class="w-full max-w-md mx-4">
        <div class="card p-8">
            <div class="text-center mb-8">
                <div class="w-16 h-16 bg-blue-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <svg class="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"/>
                    </svg>
                </div>
                <h2 class="text-2xl font-bold text-gray-800">Forgot Password</h2>
                <p class="text-gray-600 mt-2">Enter your email to reset your password</p>
            </div>
            
            <?php if ($error): ?>
                <div class="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-lg mb-4">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="bg-green-50 border border-green-200 text-green-600 px-4 py-3 rounded-lg mb-4">
                    <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" class="space-y-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                    <input type="email" name="email" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" 
                           placeholder="you@atiera.com" value="<?php echo htmlspecialchars($email); ?>" required>
                </div>
                
                <button type="submit" class="w-full bg-blue-600 text-white py-3 px-4 rounded-lg font-semibold hover:bg-blue-700 transition duration-200">
                    Send Reset Instructions
                </button>
            </form>
            
            <div class="mt-6 text-center">
                <a href="login.php" class="text-blue-600 hover:text-blue-800 font-medium">
                    ← Back to Login
                </a>
            </div>
        </div>
        
        <div class="mt-6 text-center text-white">
            <p class="text-sm">Need help? Contact HR support</p>
            <p class="font-medium">hr-support@atiera.com</p>
        </div>
    </div>
</body>
</html>