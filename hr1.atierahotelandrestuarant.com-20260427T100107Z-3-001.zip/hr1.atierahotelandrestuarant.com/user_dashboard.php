<?php
// File: admin_dashboard.php
session_start();
require_once 'connections.php';
require_once 'functions.php'; // Include functions instead
requireAuth(); // This will work now

// Initialize stats array with default values
$stats = [
    'jobs' => ['total_jobs' => 0, 'open_jobs' => 0, 'closed_jobs' => 0],
    'applicants' => ['total_applicants' => 0, 'new_applicants' => 0, 'hired_applicants' => 0],
    'requests' => ['total_requests' => 0, 'approved_requests' => 0, 'pending_requests' => 0],
    'activity' => []
];

try {
    // Job stats
    $stmt = $connections->prepare("
        SELECT 
            COUNT(*) as total_jobs,
            SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as open_jobs,
            SUM(CASE WHEN status = 'closed' THEN 1 ELSE 0 END) as closed_jobs
        FROM job_postings
    ");
    $stmt->execute();
    $jobResult = $stmt->fetch();
    if ($jobResult) {
        $stats['jobs'] = [
            'total_jobs' => (int)$jobResult['total_jobs'],
            'open_jobs' => (int)$jobResult['open_jobs'],
            'closed_jobs' => (int)$jobResult['closed_jobs']
        ];
    }

    // Applicant stats
    $stmt = $connections->prepare("
        SELECT 
            COUNT(*) as total_applicants,
            SUM(CASE WHEN application_status = 'new' THEN 1 ELSE 0 END) as new_applicants,
            SUM(CASE WHEN application_status = 'hired' THEN 1 ELSE 0 END) as hired_applicants
        FROM applicants
    ");
    $stmt->execute();
    $applicantResult = $stmt->fetch();
    if ($applicantResult) {
        $stats['applicants'] = [
            'total_applicants' => (int)$applicantResult['total_applicants'],
            'new_applicants' => (int)$applicantResult['new_applicants'],
            'hired_applicants' => (int)$applicantResult['hired_applicants']
        ];
    }

    // Job request stats
    $stmt = $connections->prepare("
        SELECT 
            COUNT(*) as total_requests,
            SUM(CASE WHEN overall_status = 'approved' THEN 1 ELSE 0 END) as approved_requests,
            SUM(CASE WHEN overall_status = 'pending' THEN 1 ELSE 0 END) as pending_requests
        FROM job_requests
        WHERE is_active = TRUE
    ");
    $stmt->execute();
    $requestResult = $stmt->fetch();
    if ($requestResult) {
        $stats['requests'] = [
            'total_requests' => (int)$requestResult['total_requests'],
            'approved_requests' => (int)$requestResult['approved_requests'],
            'pending_requests' => (int)$requestResult['pending_requests']
        ];
    }

    // Recent activity - Fixed query
    $stmt = $connections->prepare("
        (SELECT 'application' as type, CONCAT('New application from ', first_name, ' ', last_name) as description, 
                created_at as timestamp, CONCAT(first_name, ' ', last_name) as user
         FROM applicants 
         WHERE created_at IS NOT NULL
         ORDER BY created_at DESC LIMIT 5)
        UNION
        (SELECT 'job_request' as type, CONCAT('Job request for ', position_title) as description, 
                created_at as timestamp, requested_by as user
         FROM job_requests 
         WHERE created_at IS NOT NULL
         ORDER BY created_at DESC LIMIT 5)
        ORDER BY timestamp DESC
        LIMIT 10
    ");
    $stmt->execute();
    $stats['activity'] = $stmt->fetchAll();

} catch (PDOException $e) {
    error_log("Stats error: " . $e->getMessage());
    // Keep default values if error occurs
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>HR1 User Dashboard</title>

<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
    /* HR1 Custom Styles */
    .process-step {
        position: relative;
        padding-left: 30px;
        margin-bottom: 15px;
    }
    .process-step:before {
        content: '';
        position: absolute;
        left: 0;
        top: 5px;
        width: 20px;
        height: 20px;
        border-radius: 50%;
        background: #e5e7eb;
        border: 2px solid #9ca3af;
    }
    .process-step.completed:before {
        background: #10b981;
        border-color: #10b981;
    }
    .process-step.active:before {
        background: #3b82f6;
        border-color: #3b82f6;
        animation: pulse 2s infinite;
    }
    @keyframes pulse {
        0% { box-shadow: 0 0 0 0 rgba(59, 130, 246, 0.5); }
        70% { box-shadow: 0 0 0 10px rgba(59, 130, 246, 0); }
        100% { box-shadow: 0 0 0 0 rgba(59, 130, 246, 0); }
    }
    
    .status-badge {
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
        text-transform: uppercase;
    }
    .status-pending { background: #fef3c7; color: #d97706; }
    .status-approved { background: #d1fae5; color: #065f46; }
    .status-rejected { background: #fee2e2; color: #991b1b; }
    .status-new { background: #dbeafe; color: #1e40af; }
    .status-hired { background: #dcfce7; color: #166534; }
    
    .stat-card {
        transition: all 0.3s ease;
        cursor: pointer;
    }
    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0,0,0,0.1);
    }
</style>
</head>

<body class="h-screen bg-gray-100 font-sans">

<div class="flex h-full">

  <!-- Sidebar -->
  <?php include 'user_sidebar.php'; ?>

  <!-- Main Content -->
  <div class="flex-1 flex flex-col overflow-y-auto">
    <main class="p-6 space-y-6">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-gray-300 pb-4">
        <h2 class="text-2xl font-bold text-gray-800">HR1 Recruitment Dashboard</h2>
        <div class="flex items-center space-x-4">
            <!-- ========== WEATHER WIDGET ADDED HERE ========== -->
            <div id="weather-widget" class="flex items-center space-x-3 mr-4 bg-white/80 backdrop-blur-sm rounded-lg px-4 py-2 shadow-sm border border-gray-200">
                <i data-lucide="cloud" class="w-5 h-5 text-gray-600"></i>
                <span class="text-sm font-medium text-gray-700">Loading weather...</span>
            </div>
            <!-- ============================================== -->
            <?php include 'user_profile_dropdown.php'; ?>
        </div>
      </div>

      <!-- Dashboard Cards -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <!-- Job Requests Card -->
        <div onclick="window.location.href='user_job_requests.php'"
             class="cursor-pointer bg-white p-6 rounded-lg shadow-md border border-gray-200 stat-card">
          <div class="flex items-center justify-between mb-4">
            <h3 class="text-lg font-semibold text-gray-700">Job Requests</h3>
            <i data-lucide="file-text" class="w-6 h-6 text-blue-600"></i>
          </div>
          <p id="totalRequests" class="text-3xl font-bold text-gray-900"><?php echo $stats['requests']['total_requests']; ?></p>
          <p class="text-sm text-gray-500">Total Requests</p>
          <div class="mt-4 flex space-x-6 text-sm">
            <span id="approvedRequests" class="text-green-600">Approved: <?php echo $stats['requests']['approved_requests']; ?></span>
            <span id="pendingRequests" class="text-amber-600">Pending: <?php echo $stats['requests']['pending_requests']; ?></span>
          </div>
        </div>

        <!-- Job Postings Card -->
        <div onclick="window.location.href='user_job_postings.php'"
             class="cursor-pointer bg-white p-6 rounded-lg shadow-md border border-gray-200 stat-card">
          <div class="flex items-center justify-between mb-4">
            <h3 class="text-lg font-semibold text-gray-700">Job Postings</h3>
            <i data-lucide="megaphone" class="w-6 h-6 text-green-600"></i>
          </div>
          <p id="totalJobs" class="text-3xl font-bold text-gray-900"><?php echo $stats['jobs']['total_jobs']; ?></p>
          <p class="text-sm text-gray-500">Total Postings</p>
          <div class="mt-4 flex space-x-6 text-sm">
            <span id="openJobs" class="text-green-600">Open: <?php echo $stats['jobs']['open_jobs']; ?></span>
            <span id="closedJobs" class="text-red-600">Closed: <?php echo $stats['jobs']['closed_jobs']; ?></span>
          </div>
        </div>

        <!-- Applicants Card -->
        <div onclick="window.location.href='user_applicants.php'"
             class="cursor-pointer bg-white p-6 rounded-lg shadow-md border border-gray-200 stat-card">
          <div class="flex items-center justify-between mb-4">
            <h3 class="text-lg font-semibold text-gray-700">Applicants</h3>
            <i data-lucide="users" class="w-6 h-6 text-purple-600"></i>
          </div>
          <p id="totalApplicants" class="text-3xl font-bold text-gray-900"><?php echo $stats['applicants']['total_applicants']; ?></p>
          <p class="text-sm text-gray-500">Total Applicants</p>
          <div class="mt-4 flex space-x-6 text-sm">
            <span id="newApplicants" class="text-blue-600">New: <?php echo $stats['applicants']['new_applicants']; ?></span>
            <span id="hiredApplicants" class="text-green-600">Hired: <?php echo $stats['applicants']['hired_applicants']; ?></span>
          </div>
        </div>

        <!-- Quick Actions Card -->
        <div class="bg-white p-6 rounded-lg shadow-md border border-gray-200">
          <h3 class="text-lg font-semibold text-gray-700 mb-4">Quick Actions</h3>
          <div class="space-y-3">
            <a href="user_job_request_form.php" class="flex items-center space-x-3 p-3 rounded-lg bg-blue-50 text-blue-600 hover:bg-blue-100">
              <i data-lucide="plus-circle" class="w-5 h-5"></i>
              <span>Create Job Request</span>
            </a>
            <a href="user_applicants.php?status=new" class="flex items-center space-x-3 p-3 rounded-lg bg-green-50 text-green-600 hover:bg-green-100">
              <i data-lucide="search" class="w-5 h-5"></i>
              <span>Screen Applicants</span>
            </a>
            <a href="user_interviews.php" class="flex items-center space-x-3 p-3 rounded-lg bg-purple-50 text-purple-600 hover:bg-purple-100">
              <i data-lucide="calendar" class="w-5 h-5"></i>
              <span>Schedule Interview</span>
            </a>
          </div>
        </div>
      </div>

      <!-- Recent Activity & Charts -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Recent Activity -->
        <div class="bg-white rounded-lg shadow p-6">
          <h3 class="text-lg font-semibold text-gray-800 mb-4">Recent Activity</h3>
          <div class="space-y-4">
            <?php if (!empty($stats['activity'])): ?>
              <?php foreach ($stats['activity'] as $activity): ?>
                <div class="flex items-start space-x-3">
                  <div class="w-8 h-8 rounded-full flex items-center justify-center 
                    <?php echo $activity['type'] == 'application' ? 'bg-blue-100 text-blue-600' : 'bg-green-100 text-green-600'; ?>">
                    <i data-lucide="<?php echo $activity['type'] == 'application' ? 'user' : 'file-text'; ?>" class="w-4 h-4"></i>
                  </div>
                  <div class="flex-1">
                    <p class="text-sm text-gray-800"><?php echo htmlspecialchars($activity['description']); ?></p>
                    <p class="text-xs text-gray-500">
                      <?php echo date('M j, g:i A', strtotime($activity['timestamp'])); ?> • 
                      <?php echo htmlspecialchars($activity['user']); ?>
                    </p>
                  </div>
                </div>
              <?php endforeach; ?>
            <?php else: ?>
              <p class="text-gray-500 text-center py-4">No recent activity</p>
            <?php endif; ?>
          </div>
        </div>

        <!-- Applications Chart -->
        <div class="bg-white rounded-lg shadow p-6">
          <h3 class="text-lg font-semibold text-gray-800 mb-4">Applications Trend</h3>
          <canvas id="applicationsChart" height="200"></canvas>
        </div>
      </div>
    </main>
  </div>
</div>

<!-- Recruitment Modal -->
<div id="recruitmentModal"
     class="hidden fixed inset-0 flex items-center justify-center
            bg-black bg-opacity-50 z-50">
  <div class="bg-white rounded-lg shadow-lg w-11/12 max-w-lg p-6 relative">
    <button onclick="closeModal()"
            class="absolute top-3 right-3 text-gray-600 hover:text-black">
      <i data-lucide="x" class="w-6 h-6"></i>
    </button>
    <h3 class="text-xl font-bold text-gray-800 mb-4">
      Recruitment Status
    </h3>
    <canvas id="recruitmentChart" width="400" height="400"></canvas>
  </div>
</div>

<script>
let recruitmentChart;
let applicationsChart;

document.addEventListener("DOMContentLoaded", () => {
  lucide.createIcons();
  loadDashboardCharts();
  loadWeather();  // <-- NEW: load weather on page start
  // Auto-refresh weather every 10 minutes (600000 ms)
  setInterval(loadWeather, 600000);
  // Auto-refresh charts every 30 seconds (existing)
  setInterval(loadDashboardCharts, 30000);
});

function loadDashboardCharts() {
  // Load applications chart data
  fetch("ajax/dashboard_stats.php")
    .then(res => res.json())
    .then(data => {
      // Update applications chart
      if (data.applications_trend) {
        updateApplicationsChart(data.applications_trend);
      }
    })
    .catch(() => console.error("Failed to load stats"));
}

function updateApplicationsChart(trendData) {
  const ctx = document.getElementById('applicationsChart').getContext('2d');
  
  if (applicationsChart) {
    applicationsChart.destroy();
  }
  
  // Default data if no real data
  const labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
  const data = [12, 19, 8, 15, 10, 18];
  
  applicationsChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: labels,
      datasets: [{
        label: 'Applications',
        data: data,
        borderColor: '#3b82f6',
        backgroundColor: 'rgba(59, 130, 246, 0.1)',
        borderWidth: 2,
        fill: true,
        tension: 0.4
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: false
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            stepSize: 1
          }
        }
      }
    }
  });
}

// ========== NEW WEATHER FUNCTIONS ==========
function loadWeather() {
    const widget = document.getElementById('weather-widget');
    if (!widget) return;

    // Show loading state
    widget.innerHTML = `<i data-lucide="loader-2" class="w-5 h-5 text-gray-600 animate-spin"></i><span class="text-sm font-medium text-gray-700">Fetching weather...</span>`;
    lucide.createIcons();

    // Try to get user's location
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const lat = position.coords.latitude;
                const lon = position.coords.longitude;
                fetchWeather(`weather.php?lat=${lat}&lon=${lon}`);
            },
            (error) => {
                console.warn('Geolocation error:', error);
                // Fallback to default Philippine city (change if needed)
                fetchWeather('weather.php?city=Manila');
            }
        );
    } else {
        // Geolocation not supported
        fetchWeather('weather.php?city=Manila');
    }
}

function fetchWeather(url) {
    fetch(url)
        .then(response => response.json())
        .then(data => {
            if (data.error) throw new Error(data.error);
            updateWeatherWidget(data);
        })
        .catch(error => {
            console.error('Weather fetch error:', error);
            const widget = document.getElementById('weather-widget');
            if (widget) {
                widget.innerHTML = `<i data-lucide="cloud-off" class="w-5 h-5 text-red-500"></i><span class="text-sm font-medium text-gray-700">Weather unavailable</span>`;
                lucide.createIcons();
            }
        });
}

function updateWeatherWidget(data) {
    const widget = document.getElementById('weather-widget');
    if (!widget) return;

    // Choose a Lucide icon based on weather condition
    let iconName = 'cloud';
    const cond = data.condition.toLowerCase();
    if (cond.includes('clear')) iconName = 'sun';
    else if (cond.includes('rain')) iconName = 'cloud-rain';
    else if (cond.includes('snow')) iconName = 'cloud-snow';
    else if (cond.includes('thunder')) iconName = 'cloud-lightning';
    else if (cond.includes('drizzle')) iconName = 'cloud-drizzle';
    else if (cond.includes('mist') || cond.includes('fog')) iconName = 'cloud-fog';

    widget.innerHTML = `
        <i data-lucide="${iconName}" class="w-5 h-5 text-gray-600"></i>
        <span class="text-sm font-medium text-gray-700">${data.temp}°C, ${data.condition} in ${data.city}</span>
    `;
    lucide.createIcons();  // Re-run to render the new icon
}
// ===========================================

// Your existing modal functions
function openModal() {
  document.getElementById("recruitmentModal").classList.remove("hidden");
  fetchStats(true);
}

function closeModal() {
  document.getElementById("recruitmentModal").classList.add("hidden");
}

function fetchStats(openModalAfter) {
  fetch("ajax/recruitment_stats.php")
    .then(res => res.json())
    .then(data => {
      // Update modal chart if needed
      if (openModalAfter) {
        buildChart(data.open_jobs, data.closed_jobs);
      }
    })
    .catch(() => console.error("Failed to load stats"));
}

function buildChart(openJobs, closedJobs) {
  const ctx = document.getElementById("recruitmentChart").getContext("2d");

  if (recruitmentChart) {
    recruitmentChart.destroy();
  }

  recruitmentChart = new Chart(ctx, {
    type: "pie",
    data: {
      labels: ["Open Jobs", "Closed Jobs"],
      datasets: [{
        data: [openJobs, closedJobs],
        backgroundColor: ["#22c55e", "#ef4444"]
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { position: "bottom" } }
    }
  });
}
</script>

</body>
</html>