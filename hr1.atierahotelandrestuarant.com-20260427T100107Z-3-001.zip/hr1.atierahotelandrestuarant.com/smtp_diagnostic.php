<?php
// smtp_diagnostic.php - Detailed SMTP test
require_once 'connections.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer(true);
$mail->SMTPDebug = 2;          // verbose debug output
$mail->Debugoutput = 'html';   // output in HTML

echo "<h2>SMTP Diagnostic Test</h2>";
echo "<p>Testing connection to " . SMTP_HOST . ":" . SMTP_PORT . " ...</p>";

try {
    $mail->isSMTP();
    $mail->Host       = SMTP_HOST;
    $mail->SMTPAuth   = true;
    $mail->Username   = SMTP_USERNAME;
    $mail->Password   = SMTP_PASSWORD;
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = SMTP_PORT;

    $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
    $mail->addAddress('vergarajamesryan47@gmail.com');
    $mail->Subject = 'SMTP Diagnostic Test';
    $mail->Body    = '<h1>Test</h1><p>If you see this, your SMTP is working.</p>';

    $mail->send();
    echo "<p style='color:green; font-weight:bold;'>✅ Email sent successfully! Your SMTP configuration is correct.</p>";
} catch (Exception $e) {
    echo "<p style='color:red; font-weight:bold;'>❌ Email sending failed.</p>";
    echo "<p>Error: " . $mail->ErrorInfo . "</p>";
    echo "<p>Check your SMTP credentials and hosting firewall.</p>";
}
?>