<?php
// File: add_onboarding.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

$errors = [];
$success = false;

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect and validate data
    $employee_id = $_POST['employee_id'] ?? generateEmployeeId();
    $first_name = trim($_POST['first_name'] ?? '');
    $middle_name = trim($_POST['middle_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $contact_number = trim($_POST['contact_number'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $date_of_birth = $_POST['date_of_birth'] ?? '';
    $job_position = trim($_POST['job_position'] ?? '');
    $department = trim($_POST['department'] ?? '');
    $hire_date = $_POST['hire_date'] ?? date('Y-m-d');
    $employment_type = $_POST['employment_type'] ?? 'probationary';
    $salary = $_POST['salary'] ?? null;
    $supervisor_name = trim($_POST['supervisor_name'] ?? '');
    
    // Validation
    if (empty($first_name)) $errors[] = 'First name is required';
    if (empty($last_name)) $errors[] = 'Last name is required';
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required';
    if (empty($contact_number)) $errors[] = 'Contact number is required';
    if (empty($job_position)) $errors[] = 'Job position is required';
    
    // Handle resume upload
    $resume_path = null;
    if (isset($_FILES['resume']) && $_FILES['resume']['error'] === UPLOAD_ERR_OK) {
        $allowed_types = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
        $max_size = 5 * 1024 * 1024; // 5MB
        
        if ($_FILES['resume']['size'] > $max_size) {
            $errors[] = 'Resume file is too large (max 5MB)';
        } elseif (!in_array($_FILES['resume']['type'], $allowed_types)) {
            $errors[] = 'Only PDF and Word documents are allowed';
        } else {
            $upload_dir = 'uploads/resumes/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $file_extension = pathinfo($_FILES['resume']['name'], PATHINFO_EXTENSION);
            $filename = time() . '_' . preg_replace('/[^a-zA-Z0-9]/', '_', $last_name) . '_Resume.' . $file_extension;
            $target_path = $upload_dir . $filename;
            
            if (move_uploaded_file($_FILES['resume']['tmp_name'], $target_path)) {
                $resume_path = $target_path;
            } else {
                $errors[] = 'Failed to upload resume';
            }
        }
    }
    
    // If no errors, insert into database
    if (empty($errors)) {
        try {
            $query = "INSERT INTO onboarding (
                employee_id, first_name, middle_name, last_name, email, 
                contact_number, address, date_of_birth, job_position, 
                department, hire_date, employment_type, salary, supervisor_name,
                status, contract_status, contract_signed, documents_complete,
                orientation_complete, system_access_setup, equipment_provided,
                resume, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";
            
            $stmt = $connections->prepare($query);
            $stmt->execute([
                $employee_id, $first_name, $middle_name, $last_name, $email,
                $contact_number, $address, $date_of_birth, $job_position,
                $department, $hire_date, $employment_type, $salary, $supervisor_name,
                'onboarding', 'Pending HR', 0, 0, 0, 0, 0, $resume_path
            ]);
            
            $success = true;
            $_SESSION['success_message'] = 'Employee added to onboarding successfully!';
            header('Location: onboarding.php');
            exit();
            
        } catch (PDOException $e) {
            $errors[] = 'Database error: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>HR1 - Add Onboarding</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="h-screen bg-gray-100 font-sans">
<div class="flex h-full">
  
  <!-- Sidebar -->
  <?php include 'sidebar.php'; ?>
  
  <!-- Main Content -->
  <div class="flex-1 flex flex-col overflow-y-auto">
    <main class="p-6">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-gray-300 pb-4 mb-6">
        <div>
          <h2 class="text-2xl font-bold text-gray-800">Add Employee to Onboarding</h2>
          <p class="text-sm text-gray-600">Add new employee to the onboarding process</p>
        </div>
        <div class="flex items-center space-x-4">
          <a href="onboarding.php" class="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
            Cancel
          </a>
          <?php include 'profile_dropdown.php'; ?>
        </div>
      </div>

      <!-- Error Messages -->
      <?php if (!empty($errors)): ?>
      <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
        <h4 class="font-semibold mb-1">Please fix the following errors:</h4>
        <ul class="list-disc list-inside">
          <?php foreach ($errors as $error): ?>
          <li><?php echo htmlspecialchars($error); ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
      <?php endif; ?>

      <!-- Form -->
      <form method="POST" action="" enctype="multipart/form-data" class="bg-white rounded-lg shadow p-6">
        <div class="space-y-8">
          <!-- Personal Information -->
          <div>
            <h3 class="text-lg font-semibold mb-4 pb-2 border-b">
              <i data-lucide="user" class="w-5 h-5 inline mr-2"></i>
              Personal Information
            </h3>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">First Name *</label>
                <input type="text" name="first_name" required
                       value="<?php echo htmlspecialchars($_POST['first_name'] ?? ''); ?>"
                       class="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
              </div>
              
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Middle Name</label>
                <input type="text" name="middle_name"
                       value="<?php echo htmlspecialchars($_POST['middle_name'] ?? ''); ?>"
                       class="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
              </div>
              
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Last Name *</label>
                <input type="text" name="last_name" required
                       value="<?php echo htmlspecialchars($_POST['last_name'] ?? ''); ?>"
                       class="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
              </div>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Email *</label>
                <input type="email" name="email" required
                       value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                       class="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
              </div>
              
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Contact Number *</label>
                <input type="tel" name="contact_number" required
                       value="<?php echo htmlspecialchars($_POST['contact_number'] ?? ''); ?>"
                       class="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
              </div>
            </div>
            
            <div class="mt-4">
              <label class="block text-sm font-medium text-gray-700 mb-1">Address *</label>
              <textarea name="address" rows="2" required
                        class="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"><?php echo htmlspecialchars($_POST['address'] ?? ''); ?></textarea>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Date of Birth *</label>
                <input type="date" name="date_of_birth" required
                       value="<?php echo htmlspecialchars($_POST['date_of_birth'] ?? ''); ?>"
                       class="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
              </div>
              
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Resume (PDF/DOC)</label>
                <input type="file" name="resume"
                       accept=".pdf,.doc,.docx"
                       class="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                <p class="text-xs text-gray-500 mt-1">Max 5MB, PDF or Word documents only</p>
              </div>
            </div>
          </div>

          <!-- Employment Information -->
          <div>
            <h3 class="text-lg font-semibold mb-4 pb-2 border-b">
              <i data-lucide="briefcase" class="w-5 h-5 inline mr-2"></i>
              Employment Information
            </h3>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Job Position *</label>
                <select name="job_position" required
                        class="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                  <option value="">Select Position</option>
                  <option value="Housekeeping Supervisor" <?php echo ($_POST['job_position'] ?? '') == 'Housekeeping Supervisor' ? 'selected' : ''; ?>>Housekeeping Supervisor</option>
                  <option value="Front Desk Agent" <?php echo ($_POST['job_position'] ?? '') == 'Front Desk Agent' ? 'selected' : ''; ?>>Front Desk Agent</option>
                  <option value="Chef" <?php echo ($_POST['job_position'] ?? '') == 'Chef' ? 'selected' : ''; ?>>Chef</option>
                  <option value="Waiter/Waitress" <?php echo ($_POST['job_position'] ?? '') == 'Waiter/Waitress' ? 'selected' : ''; ?>>Waiter/Waitress</option>
                  <option value="Manager" <?php echo ($_POST['job_position'] ?? '') == 'Manager' ? 'selected' : ''; ?>>Manager</option>
                  <option value="Housekeeper" <?php echo ($_POST['job_position'] ?? '') == 'Housekeeper' ? 'selected' : ''; ?>>Housekeeper</option>
                  <option value="Maintenance" <?php echo ($_POST['job_position'] ?? '') == 'Maintenance' ? 'selected' : ''; ?>>Maintenance</option>
                </select>
              </div>
              
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Department *</label>
                <select name="department" required
                        class="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                  <option value="">Select Department</option>
                  <option value="Housekeeping" <?php echo ($_POST['department'] ?? '') == 'Housekeeping' ? 'selected' : ''; ?>>Housekeeping</option>
                  <option value="Front Office" <?php echo ($_POST['department'] ?? '') == 'Front Office' ? 'selected' : ''; ?>>Front Office</option>
                  <option value="Food & Beverage" <?php echo ($_POST['department'] ?? '') == 'Food & Beverage' ? 'selected' : ''; ?>>Food & Beverage</option>
                  <option value="Kitchen" <?php echo ($_POST['department'] ?? '') == 'Kitchen' ? 'selected' : ''; ?>>Kitchen</option>
                  <option value="Management" <?php echo ($_POST['department'] ?? '') == 'Management' ? 'selected' : ''; ?>>Management</option>
                  <option value="Maintenance" <?php echo ($_POST['department'] ?? '') == 'Maintenance' ? 'selected' : ''; ?>>Maintenance</option>
                </select>
              </div>
              
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Hire Date *</label>
                <input type="date" name="hire_date" required
                       value="<?php echo htmlspecialchars($_POST['hire_date'] ?? date('Y-m-d')); ?>"
                       class="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
              </div>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Employment Type *</label>
                <select name="employment_type" required
                        class="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                  <option value="probationary" <?php echo ($_POST['employment_type'] ?? '') == 'probationary' ? 'selected' : ''; ?>>Probationary</option>
                  <option value="regular" <?php echo ($_POST['employment_type'] ?? '') == 'regular' ? 'selected' : ''; ?>>Regular</option>
                  <option value="contractual" <?php echo ($_POST['employment_type'] ?? '') == 'contractual' ? 'selected' : ''; ?>>Contractual</option>
                  <option value="part-time" <?php echo ($_POST['employment_type'] ?? '') == 'part-time' ? 'selected' : ''; ?>>Part-time</option>
                </select>
              </div>
              
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Salary (optional)</label>
                <input type="number" name="salary" step="0.01"
                       value="<?php echo htmlspecialchars($_POST['salary'] ?? ''); ?>"
                       placeholder="0.00"
                       class="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
              </div>
              
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Supervisor (optional)</label>
                <input type="text" name="supervisor_name"
                       value="<?php echo htmlspecialchars($_POST['supervisor_name'] ?? ''); ?>"
                       class="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
              </div>
            </div>
          </div>
        </div>

        <!-- Form Actions -->
        <div class="flex justify-end gap-3 pt-6 mt-6 border-t">
          <a href="onboarding.php" 
             class="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
            Cancel
          </a>
          <button type="submit" 
                  class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            <i data-lucide="user-plus" class="w-4 h-4 inline mr-2"></i>
            Add to Onboarding
          </button>
        </div>
      </form>
    </main>
  </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
    lucide.createIcons();
});
</script>
</body>
</html>