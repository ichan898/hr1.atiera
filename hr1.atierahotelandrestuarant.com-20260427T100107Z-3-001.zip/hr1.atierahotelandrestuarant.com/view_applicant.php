<?php
// File: view_applicant.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

// Check if ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: applicants.php');
    exit();
}

$applicant_id = $_GET['id'];

// Fetch applicant details
$query = "SELECT a.*, j.job_title, j.department, j.requirements 
          FROM applicants a 
          LEFT JOIN job_postings j ON a.job_id = j.id 
          WHERE a.id = ?";
$stmt = $connections->prepare($query);
$stmt->execute([$applicant_id]);
$applicant = $stmt->fetch();

if (!$applicant) {
    header('Location: applicants.php');
    exit();
}

// Fetch interview history if exists (with error handling)
$interviews = [];
try {
    $check_table = $connections->query("SHOW TABLES LIKE 'interviews'");
    if ($check_table->rowCount() > 0) {
        $interview_query = "SELECT * FROM interviews WHERE applicant_id = ? ORDER BY scheduled_date DESC";
        $interview_stmt = $connections->prepare($interview_query);
        $interview_stmt->execute([$applicant_id]);
        $interviews = $interview_stmt->fetchAll();
    }
} catch (PDOException $e) {
    $interviews = [];
}

// Fetch screening notes if exists (with error handling)
$screening_notes = [];
try {
    $check_table = $connections->query("SHOW TABLES LIKE 'screening_notes'");
    if ($check_table->rowCount() > 0) {
        $screening_query = "SELECT sn.*, u.first_name, u.last_name 
                           FROM screening_notes sn 
                           LEFT JOIN users u ON sn.screener_id = u.id 
                           WHERE sn.applicant_id = ? 
                           ORDER BY sn.created_at DESC";
        $screening_stmt = $connections->prepare($screening_query);
        $screening_stmt->execute([$applicant_id]);
        $screening_notes = $screening_stmt->fetchAll();
    }
} catch (PDOException $e) {
    $screening_notes = [];
}

// Extract score breakdown from qualifications JSON
$breakdown = null;
$total_score = $applicant['qualification_score'] ?? 0;
$is_qualified = $applicant['is_qualified'] ?? 0;

if (!empty($applicant['qualifications'])) {
    $qual_data = json_decode($applicant['qualifications'], true);
    if (isset($qual_data['score_breakdown'])) {
        $breakdown = $qual_data['score_breakdown'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>HR1 - View Applicant</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
</head>

<body class="h-screen bg-gray-100 font-sans">
<div class="flex h-full">
  
  <!-- Sidebar -->
  <?php include 'sidebar.php'; ?>
  
  <!-- Main Content -->
  <div class="flex-1 flex flex-col overflow-y-auto">
    <main class="p-6 space-y-6">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-gray-300 pb-4">
        <div class="flex items-center space-x-4">
          <a href="applicants.php" class="text-blue-600 hover:text-blue-800">
            <i data-lucide="arrow-left" class="w-5 h-5"></i>
          </a>
          <div>
            <h2 class="text-2xl font-bold text-gray-800">Applicant Details</h2>
            <p class="text-sm text-gray-600">View and manage applicant information</p>
          </div>
        </div>
        <div class="flex items-center space-x-4">
          <?php include 'profile_dropdown.php'; ?>
        </div>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Left Column: Applicant Info -->
        <div class="lg:col-span-2 space-y-6">
          <!-- Basic Information Card -->
          <div class="bg-white rounded-lg shadow p-6">
            <div class="flex justify-between items-start mb-6">
              <div class="flex items-center space-x-4">
                <div class="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center">
                  <i data-lucide="user" class="w-8 h-8 text-gray-600"></i>
                </div>
                <div>
                  <h3 class="text-xl font-bold text-gray-800">
                    <?php echo htmlspecialchars($applicant['first_name'] . ' ' . $applicant['last_name']); ?>
                  </h3>
                  <p class="text-gray-600"><?php echo htmlspecialchars($applicant['email']); ?></p>
                  <p class="text-gray-600"><?php echo htmlspecialchars($applicant['phone']); ?></p>
                </div>
              </div>
              <div class="text-right">
                <span class="px-3 py-1 text-sm rounded-full 
                  <?php echo $applicant['application_status'] == 'new' ? 'bg-blue-100 text-blue-800' : 
                         ($applicant['application_status'] == 'screened' ? 'bg-yellow-100 text-yellow-800' : 
                         ($applicant['application_status'] == 'interviewed' ? 'bg-purple-100 text-purple-800' : 
                         ($applicant['application_status'] == 'hired' ? 'bg-green-100 text-green-800' : 
                         'bg-red-100 text-red-800'))); ?>">
                  <?php echo ucfirst($applicant['application_status']); ?>
                </span>
              </div>
            </div>

            <div class="grid grid-cols-2 gap-4">
              <div>
                <label class="text-sm text-gray-500">Applied Position</label>
                <p class="font-medium"><?php echo htmlspecialchars($applicant['job_title']); ?></p>
              </div>
              <div>
                <label class="text-sm text-gray-500">Department</label>
                <p class="font-medium"><?php echo htmlspecialchars($applicant['department']); ?></p>
              </div>
              <div>
                <label class="text-sm text-gray-500">Applied Date</label>
                <p class="font-medium"><?php echo date('F j, Y', strtotime($applicant['created_at'])); ?></p>
              </div>
              <div>
                <label class="text-sm text-gray-500">Location</label>
                <p class="font-medium"><?php echo htmlspecialchars($applicant['location'] ?? 'Not specified'); ?></p>
              </div>
              <div class="col-span-2">
                <label class="text-sm text-gray-500">Cover Letter</label>
                <p class="mt-2 text-gray-700"><?php echo nl2br(htmlspecialchars($applicant['cover_letter'] ?? 'No cover letter provided')); ?></p>
              </div>
            </div>

            <!-- Action Buttons -->
            <div class="mt-6 pt-6 border-t border-gray-200 flex space-x-3">
              <a href="screen_applicant.php?id=<?php echo $applicant['id']; ?>" 
                 class="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-center">
                <i data-lucide="search" class="w-4 h-4 inline mr-2"></i> Screen Applicant
              </a>
              <a href="schedule_interview.php?applicant_id=<?php echo $applicant['id']; ?>" 
                 class="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 text-center">
                <i data-lucide="calendar" class="w-4 h-4 inline mr-2"></i> Schedule Interview
              </a>
              <?php if (isset($applicant['resume_path']) && $applicant['resume_path']): ?>
              <a href="<?php echo htmlspecialchars($applicant['resume_path']); ?>" 
                 target="_blank"
                 class="flex-1 px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 text-center">
                <i data-lucide="file-text" class="w-4 h-4 inline mr-2"></i> View Resume
              </a>
              <?php endif; ?>
            </div>
          </div>

          <!-- Interview History -->
          <div class="bg-white rounded-lg shadow">
            <div class="p-6 border-b border-gray-200">
              <h3 class="text-lg font-semibold text-gray-800">Interview History</h3>
            </div>
            <div class="p-6">
              <?php if (!empty($interviews)): ?>
                <div class="space-y-4">
                  <?php foreach($interviews as $interview): ?>
                  <div class="border border-gray-200 rounded-lg p-4">
                    <div class="flex justify-between items-start">
                      <div>
                        <p class="font-medium"><?php echo htmlspecialchars($interview['interview_type'] ?? 'Interview'); ?></p>
                        <p class="text-sm text-gray-600">
                          <?php echo isset($interview['scheduled_date']) ? date('F j, Y, g:i A', strtotime($interview['scheduled_date'])) : 'Date not set'; ?>
                        </p>
                        <p class="text-sm text-gray-600">Status: 
                          <span class="font-medium 
                            <?php echo ($interview['status'] ?? 'scheduled') == 'completed' ? 'text-green-600' : 
                                   (($interview['status'] ?? 'scheduled') == 'scheduled' ? 'text-blue-600' : 
                                   'text-yellow-600'); ?>">
                            <?php echo ucfirst($interview['status'] ?? 'scheduled'); ?>
                          </span>
                        </p>
                      </div>
                      <?php if (isset($interview['interviewers'])): ?>
                      <div class="text-right">
                        <p class="text-sm text-gray-600">Interviewers:</p>
                        <p class="font-medium"><?php echo htmlspecialchars($interview['interviewers']); ?></p>
                      </div>
                      <?php endif; ?>
                    </div>
                    <?php if (isset($interview['notes']) && $interview['notes']): ?>
                    <div class="mt-3 pt-3 border-t border-gray-100">
                      <p class="text-sm text-gray-700"><?php echo nl2br(htmlspecialchars($interview['notes'])); ?></p>
                    </div>
                    <?php endif; ?>
                  </div>
                  <?php endforeach; ?>
                </div>
              <?php else: ?>
                <div class="text-center py-8 text-gray-500">
                  <i data-lucide="calendar-x" class="w-12 h-12 mx-auto mb-4"></i>
                  <p>No interview scheduled yet</p>
                  <a href="schedule_interview.php?applicant_id=<?php echo $applicant_id; ?>" 
                     class="mt-2 inline-block text-blue-600 hover:underline">
                    Schedule an interview
                  </a>
                </div>
              <?php endif; ?>
            </div>
          </div>
        </div>

        <!-- Right Column: Screening Notes & Score Breakdown -->
        <div class="space-y-6">
          <!-- Score Breakdown Card -->
          <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Qualification Score Breakdown</h3>
            
            <?php if ($breakdown && isset($breakdown['education_score'], $breakdown['experience_score'], $breakdown['skills_score'])): ?>
              <div class="space-y-4">
                <!-- Education -->
                <div>
                  <div class="flex justify-between text-sm mb-1">
                    <span>Education Match</span>
                    <span class="font-medium"><?php echo $breakdown['education_score']; ?> / 5</span>
                  </div>
                  <div class="w-full bg-gray-200 rounded-full h-2">
                    <div class="bg-blue-600 h-2 rounded-full" style="width: <?php echo ($breakdown['education_score'] / 5) * 100; ?>%"></div>
                  </div>
                  <?php if (isset($breakdown['education_percent'])): ?>
                    <p class="text-xs text-gray-500 mt-1">Contribution: <?php echo round($breakdown['education_percent']); ?> points</p>
                  <?php endif; ?>
                </div>
                
                <!-- Experience -->
                <div>
                  <div class="flex justify-between text-sm mb-1">
                    <span>Experience Level</span>
                    <span class="font-medium"><?php echo $breakdown['experience_score']; ?> / 5</span>
                  </div>
                  <div class="w-full bg-gray-200 rounded-full h-2">
                    <div class="bg-green-600 h-2 rounded-full" style="width: <?php echo ($breakdown['experience_score'] / 5) * 100; ?>%"></div>
                  </div>
                  <?php if (isset($breakdown['experience_percent'])): ?>
                    <p class="text-xs text-gray-500 mt-1">Contribution: <?php echo round($breakdown['experience_percent']); ?> points</p>
                  <?php endif; ?>
                </div>
                
                <!-- Skills -->
                <div>
                  <div class="flex justify-between text-sm mb-1">
                    <span>Skills Match</span>
                    <span class="font-medium"><?php echo $breakdown['skills_score']; ?> / 5</span>
                  </div>
                  <div class="w-full bg-gray-200 rounded-full h-2">
                    <div class="bg-purple-600 h-2 rounded-full" style="width: <?php echo ($breakdown['skills_score'] / 5) * 100; ?>%"></div>
                  </div>
                  <?php if (isset($breakdown['skills_percent'])): ?>
                    <p class="text-xs text-gray-500 mt-1">Contribution: <?php echo round($breakdown['skills_percent']); ?> points</p>
                  <?php endif; ?>
                </div>
                
                <!-- Total Score -->
                <div class="pt-2 mt-2 border-t border-gray-200">
                  <div class="flex justify-between items-center">
                    <span class="font-semibold">Total Score</span>
                    <span class="text-xl font-bold <?php echo $is_qualified ? 'text-green-600' : 'text-red-600'; ?>">
                      <?php echo $total_score; ?> / 100
                    </span>
                  </div>
                  <div class="mt-1">
                    <span class="px-2 py-1 text-xs rounded-full <?php echo $is_qualified ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                      <?php echo $is_qualified ? 'Qualified' : 'Not Qualified'; ?>
                    </span>
                  </div>
                </div>
              </div>
            <?php elseif ($total_score > 0): ?>
              <div class="text-center py-4 text-gray-500">
                <i data-lucide="bar-chart-2" class="w-12 h-12 mx-auto mb-2"></i>
                <p>Score: <?php echo $total_score; ?>/100</p>
                <p class="text-sm">(Detailed breakdown not available for this applicant)</p>
              </div>
            <?php else: ?>
              <div class="text-center py-8 text-gray-500">
                <i data-lucide="file-question" class="w-12 h-12 mx-auto mb-4"></i>
                <p>No qualification score yet</p>
                <a href="screen_applicant.php?id=<?php echo $applicant_id; ?>" 
                   class="mt-2 inline-block text-blue-600 hover:underline">
                  Screen this applicant
                </a>
              </div>
            <?php endif; ?>
          </div>

          <!-- Screening Notes -->
          <div class="bg-white rounded-lg shadow">
            <div class="p-6 border-b border-gray-200">
              <h3 class="text-lg font-semibold text-gray-800">Screening Notes</h3>
            </div>
            <div class="p-6">
              <?php if (!empty($screening_notes)): ?>
                <div class="space-y-4">
                  <?php foreach($screening_notes as $note): ?>
                  <div class="border border-gray-200 rounded-lg p-4">
                    <div class="flex justify-between items-start mb-2">
                      <span class="px-2 py-1 text-xs rounded 
                        <?php echo ($note['screening_result'] ?? 'pending') == 'passed' ? 'bg-green-100 text-green-800' : 
                               (($note['screening_result'] ?? 'pending') == 'failed' ? 'bg-red-100 text-red-800' : 
                               'bg-yellow-100 text-yellow-800'); ?>">
                        <?php echo ucfirst($note['screening_result'] ?? 'pending'); ?>
                      </span>
                      <span class="text-xs text-gray-500">
                        <?php echo isset($note['created_at']) ? date('M j, Y', strtotime($note['created_at'])) : 'Date not available'; ?>
                      </span>
                    </div>
                    <p class="text-sm text-gray-700"><?php echo nl2br(htmlspecialchars($note['notes'] ?? '')); ?></p>
                    <?php if (isset($note['first_name']) || isset($note['last_name'])): ?>
                    <div class="mt-2 pt-2 border-t border-gray-100 text-xs text-gray-500">
                      Screened by: <?php echo htmlspecialchars(($note['first_name'] ?? '') . ' ' . ($note['last_name'] ?? '')); ?>
                    </div>
                    <?php endif; ?>
                  </div>
                  <?php endforeach; ?>
                </div>
              <?php else: ?>
                <div class="text-center py-8 text-gray-500">
                  <i data-lucide="file-text" class="w-12 h-12 mx-auto mb-4"></i>
                  <p>No screening notes yet</p>
                  <a href="screen_applicant.php?id=<?php echo $applicant_id; ?>" 
                     class="mt-2 inline-block text-blue-600 hover:underline">
                    Add screening notes
                  </a>
                </div>
              <?php endif; ?>
            </div>
          </div>

          <!-- Update Status -->
          <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Update Status</h3>
            <form action="update_status.php" method="POST" class="space-y-4">
              <input type="hidden" name="applicant_id" value="<?php echo $applicant['id']; ?>">
              
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">New Status</label>
                <select name="status" class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                  <option value="new" <?php echo $applicant['application_status'] == 'new' ? 'selected' : ''; ?>>New</option>
                  <option value="screened" <?php echo $applicant['application_status'] == 'screened' ? 'selected' : ''; ?>>Screened</option>
                  <option value="interviewed" <?php echo $applicant['application_status'] == 'interviewed' ? 'selected' : ''; ?>>Interviewed</option>
                  <option value="hired" <?php echo $applicant['application_status'] == 'hired' ? 'selected' : ''; ?>>Hired</option>
                  <option value="rejected" <?php echo $applicant['application_status'] == 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                </select>
              </div>
              
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Notes</label>
                <textarea name="notes" rows="3" class="w-full px-3 py-2 border border-gray-300 rounded-lg" 
                          placeholder="Add notes about status change..."></textarea>
              </div>
              
              <button type="submit" class="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                Update Status
              </button>
            </form>
          </div>
        </div>
      </div>
    </main>
  </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
  lucide.createIcons();
});
</script>
</body>
</html>