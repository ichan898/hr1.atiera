<?php
// File: edit_review.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

$is_manager = checkUserRole($_SESSION['user_id'], ['manager', 'admin'], $connections);
$review_id = $_GET['id'] ?? 0;

if (!$is_manager && !$reviewer_access) {
    header('Location: performance.php');
    exit();
}

// Get review details
$review = null;
try {
    $sql = "SELECT pr.*, CONCAT(e.first_name, ' ', e.last_name) as employee_name
            FROM performance_reviews pr
            JOIN employees e ON pr.employee_id = e.id
            WHERE pr.id = ?";
    $stmt = $connections->prepare($sql);
    $stmt->bind_param("i", $review_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $review = $result->fetch_assoc();
    $stmt->close();
} catch (Exception $e) {
    error_log("Error getting review: " . $e->getMessage());
}

if (!$review) {
    header('Location: performance.php');
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $due_date = $_POST['due_date'] ?? '';
    $summary = $_POST['summary'] ?? '';
    $rating = $_POST['rating'] ?? '';
    $status = $_POST['status'] ?? 'draft';
    $review_date = $status == 'completed' ? date('Y-m-d') : $review['review_date'];

    try {
        $sql = "UPDATE performance_reviews 
                SET due_date = ?, summary = ?, rating = ?, status = ?, review_date = ?, updated_at = NOW()
                WHERE id = ?";
        
        $stmt = $connections->prepare($sql);
        $stmt->bind_param("ssdssi", $due_date, $summary, $rating, $status, $review_date, $review_id);
        
        if ($stmt->execute()) {
            $_SESSION['success_message'] = "Performance review updated successfully!";
            header('Location: performance.php');
            exit();
        } else {
            $error = "Failed to update performance review.";
        }
        
        $stmt->close();
    } catch (Exception $e) {
        $error = "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>HR1 - Edit Performance Review</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
</head>

<body class="h-screen bg-gray-100 font-sans">
<div class="flex h-full">
  <?php include 'sidebar.php'; ?>
  
  <div class="flex-1 flex flex-col overflow-y-auto">
    <main class="p-6">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-gray-300 pb-4 mb-6">
        <div>
          <h2 class="text-2xl font-bold text-gray-800">Edit Performance Review</h2>
          <p class="text-sm text-gray-600">Edit performance review for <?php echo htmlspecialchars($review['employee_name'] ?? ''); ?></p>
        </div>
        <div>
          <a href="performance.php" class="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 flex items-center">
            <i data-lucide="arrow-left" class="w-4 h-4 mr-2"></i>
            Back to Dashboard
          </a>
        </div>
      </div>

      <!-- Form -->
      <div class="max-w-2xl mx-auto bg-white rounded-lg shadow border">
        <div class="p-6">
          <?php if (isset($error)): ?>
            <div class="mb-4 p-3 bg-red-100 text-red-700 rounded-lg">
              <?php echo htmlspecialchars($error); ?>
            </div>
          <?php endif; ?>

          <form method="POST" action="">
            <div class="space-y-6">
              <!-- Employee Info (readonly) -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                  Employee
                </label>
                <input type="text" value="<?php echo htmlspecialchars($review['employee_name'] ?? ''); ?>"
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50" readonly>
              </div>

              <!-- Due Date -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                  Due Date <span class="text-red-500">*</span>
                </label>
                <input type="date" name="due_date" required
                       value="<?php echo htmlspecialchars($review['due_date'] ?? ''); ?>"
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
              </div>

              <!-- Rating -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                  Rating (1-5)
                </label>
                <select name="rating"
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                  <option value="">Select Rating</option>
                  <?php for ($i = 1; $i <= 5; $i += 0.5): ?>
                    <option value="<?php echo $i; ?>" <?php echo ($review['rating'] == $i) ? 'selected' : ''; ?>>
                      <?php echo $i; ?>
                    </option>
                  <?php endfor; ?>
                </select>
              </div>

              <!-- Summary -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                  Summary
                </label>
                <textarea name="summary" rows="4"
                          class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                          placeholder="Enter performance summary..."><?php echo htmlspecialchars($review['summary'] ?? ''); ?></textarea>
              </div>

              <!-- Status -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                  Status
                </label>
                <select name="status"
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                  <option value="draft" <?php echo ($review['status'] == 'draft') ? 'selected' : ''; ?>>Draft</option>
                  <option value="scheduled" <?php echo ($review['status'] == 'scheduled') ? 'selected' : ''; ?>>Scheduled</option>
                  <option value="completed" <?php echo ($review['status'] == 'completed') ? 'selected' : ''; ?>>Completed</option>
                  <option value="cancelled" <?php echo ($review['status'] == 'cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                </select>
              </div>

              <!-- Submit Button -->
              <div class="pt-4">
                <button type="submit"
                        class="w-full px-4 py-3 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500">
                  Update Performance Review
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </main>
  </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
  lucide.createIcons();
});
</script>
</body>
</html>