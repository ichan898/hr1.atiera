<?php
// File: ajax/dashboard_stats.php
require_once '../connections.php';
session_start();
requireAuth();

header('Content-Type: application/json');

try {
    // Get applications trend (last 7 days)
    $stmt = $connections->prepare("
        SELECT DATE(created_at) as date, COUNT(*) as count
        FROM applicants
        WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
        GROUP BY DATE(created_at)
        ORDER BY date
    ");
    $stmt->execute();
    $applications_trend = $stmt->fetchAll();
    
    echo json_encode([
        'status' => 'success',
        'applications_trend' => $applications_trend
    ]);
    
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
