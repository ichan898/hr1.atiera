<?php
// File: view_posting.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

$id = $_GET['id'] ?? null;
if (!$id) {
    header('Location: job_postings.php');
    exit();
}

$posting = getJobPosting($id);
if (!$posting) {
    header('Location: job_postings.php?error=notfound');
    exit();
}

// Get applicants for this job - FIXED: added alias for application_status
$stmt = $connections->prepare("SELECT *, application_status as status FROM applicants WHERE job_id = ? ORDER BY applied_at DESC");
$stmt->execute([$id]);
$applicants = $stmt->fetchAll();

// Get applicant counts by status
$status_counts = [
    'new' => 0,
    'reviewed' => 0,
    'shortlisted' => 0,
    'rejected' => 0,
    'hired' => 0
];

foreach ($applicants as $applicant) {
    $status = $applicant['status'] ?? 'new';
    if (isset($status_counts[$status])) {
        $status_counts[$status]++;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>HR1 - View Job Posting</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
</head>

<body class="h-screen bg-gray-100 font-sans">
<div class="flex h-full">
  <?php include 'user_sidebar.php'; ?>
  
  <div class="flex-1 flex flex-col overflow-y-auto">
    <main class="p-6">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-gray-300 pb-4 mb-6">
        <div>
          <h2 class="text-2xl font-bold text-gray-800"><?php echo htmlspecialchars($posting['job_title'] ?? 'Untitled'); ?></h2>
          <p class="text-sm text-gray-600">Job Code: <?php echo $posting['job_code'] ?? 'N/A'; ?></p>
        </div>
        <div class="flex items-center space-x-4">
          <span class="px-3 py-1 text-xs rounded-full 
            <?php echo getJobPostingStatusColor($posting['status'] ?? 'draft'); ?>">
            <?php echo ucfirst($posting['status'] ?? 'draft'); ?>
          </span>
          <a href="user_edit_posting.php?id=<?php echo $id; ?>" 
             class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center space-x-2">
            <i data-lucide="edit" class="w-4 h-4"></i>
            <span>Edit</span>
          </a>
          <?php include 'user_profile_dropdown.php'; ?>
        </div>
      </div>

      <!-- Two Column Layout -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Left Column - Job Details -->
        <div class="lg:col-span-2 space-y-6">
          <!-- Job Information Card -->
          <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Job Information</h3>
            <div class="grid grid-cols-2 gap-4">
              <div>
                <p class="text-sm text-gray-600">Department</p>
                <p class="font-medium"><?php echo htmlspecialchars($posting['department'] ?? 'Not specified'); ?></p>
              </div>
              <div>
                <p class="text-sm text-gray-600">Location</p>
                <p class="font-medium"><?php echo htmlspecialchars($posting['location'] ?? 'Not specified'); ?></p>
              </div>
              <div>
                <p class="text-sm text-gray-600">Employment Type</p>
                <p class="font-medium">
                  <?php 
                  if (isset($posting['employment_type'])) {
                      echo ucfirst(str_replace('_', ' ', $posting['employment_type']));
                  } else {
                      echo 'Not specified';
                  }
                  ?>
                </p>
              </div>
              <div>
                <p class="text-sm text-gray-600">Experience Level</p>
                <p class="font-medium">
                  <?php 
                  if (isset($posting['experience_level']) && !empty($posting['experience_level'])) {
                      echo ucfirst($posting['experience_level']);
                  } else {
                      echo 'Not specified';
                  }
                  ?>
                </p>
              </div>
              <div>
                <p class="text-sm text-gray-600">Salary Range</p>
                <p class="font-medium"><?php echo htmlspecialchars($posting['salary_range'] ?? 'Not specified'); ?></p>
              </div>
              <div>
                <p class="text-sm text-gray-600">Posted Date</p>
                <p class="font-medium"><?php echo date('M d, Y', strtotime($posting['created_at'])); ?></p>
              </div>
              <?php if (!empty($posting['closing_date'])): ?>
              <div>
                <p class="text-sm text-gray-600">Closing Date</p>
                <p class="font-medium"><?php echo date('M d, Y', strtotime($posting['closing_date'])); ?></p>
              </div>
              <?php endif; ?>
              <?php if (!empty($posting['vacancies'])): ?>
              <div>
                <p class="text-sm text-gray-600">Vacancies</p>
                <p class="font-medium"><?php echo $posting['vacancies']; ?></p>
              </div>
              <?php endif; ?>
            </div>
          </div>

          <!-- Job Description -->
          <?php if (!empty($posting['description'])): ?>
          <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Job Description</h3>
            <div class="prose max-w-none">
              <?php echo $posting['description']; ?>
            </div>
          </div>
          <?php endif; ?>

          <!-- Requirements & Responsibilities -->
          <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <?php if (!empty($posting['requirements'])): ?>
            <div class="bg-white rounded-lg shadow p-6">
              <h3 class="text-lg font-semibold text-gray-800 mb-4">Requirements</h3>
              <div class="prose max-w-none">
                <?php echo $posting['requirements']; ?>
              </div>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($posting['responsibilities'])): ?>
            <div class="bg-white rounded-lg shadow p-6">
              <h3 class="text-lg font-semibold text-gray-800 mb-4">Responsibilities</h3>
              <div class="prose max-w-none">
                <?php echo $posting['responsibilities']; ?>
              </div>
            </div>
            <?php endif; ?>
          </div>

          <!-- Benefits -->
          <?php if (!empty($posting['benefits'])): ?>
          <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Benefits</h3>
            <div class="prose max-w-none">
              <?php echo $posting['benefits']; ?>
            </div>
          </div>
          <?php endif; ?>
        </div>

        <!-- Right Column - Applications & Actions -->
        <div class="space-y-6">
          <!-- Applications Card -->
          <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Applications</h3>
            
            <div class="space-y-4">
              <div class="flex items-center justify-between">
                <div class="flex items-center space-x-2">
                  <div class="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                    <i data-lucide="users" class="w-4 h-4 text-blue-600"></i>
                  </div>
                  <span class="font-medium">Total Applicants</span>
                </div>
                <span class="text-2xl font-bold"><?php echo count($applicants); ?></span>
              </div>
              
              <?php if (count($applicants) > 0): ?>
              <div class="space-y-2">
                <?php foreach ($status_counts as $status => $count): 
                  if ($count > 0): 
                    $colors = [
                      'new' => 'bg-blue-100 text-blue-800',
                      'reviewed' => 'bg-yellow-100 text-yellow-800',
                      'shortlisted' => 'bg-green-100 text-green-800',
                      'rejected' => 'bg-red-100 text-red-800',
                      'hired' => 'bg-purple-100 text-purple-800'
                    ];
                ?>
                <div class="flex items-center justify-between">
                  <span class="text-sm text-gray-600"><?php echo ucfirst($status); ?></span>
                  <span class="px-2 py-1 text-xs rounded-full <?php echo $colors[$status] ?? 'bg-gray-100 text-gray-800'; ?>">
                    <?php echo $count; ?>
                  </span>
                </div>
                <?php endif; endforeach; ?>
              </div>
              <?php endif; ?>
              
              <a href="user_applicants.php?job_id=<?php echo $id; ?>" 
                 class="block w-full text-center px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50">
                View All Applicants
              </a>
            </div>
          </div>

          <!-- Quick Actions -->
          <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Quick Actions</h3>
            
            <div class="space-y-3">
              <?php if (($posting['status'] ?? 'draft') == 'active'): ?>
              <a href="user_close_posting.php?id=<?php echo $id; ?>" 
                 onclick="return confirm('Are you sure you want to close this job posting?')"
                 class="flex items-center space-x-3 p-3 border border-gray-200 rounded-md hover:bg-gray-50">
                <i data-lucide="archive" class="w-5 h-5 text-gray-600"></i>
                <span>Close Job Posting</span>
              </a>
              <?php elseif (($posting['status'] ?? 'draft') == 'draft'): ?>
              <a href="?id=<?php echo $id; ?>&action=publish" 
                 onclick="return confirm('Publish this job posting?')"
                 class="flex items-center space-x-3 p-3 border border-gray-200 rounded-md hover:bg-gray-50">
                <i data-lucide="send" class="w-5 h-5 text-gray-600"></i>
                <span>Publish Job Posting</span>
              </a>
              <?php endif; ?>
              
              <a href="user_duplicate_posting.php?id=<?php echo $id; ?>" 
                 onclick="return confirm('Duplicate this job posting?')"
                 class="flex items-center space-x-3 p-3 border border-gray-200 rounded-md hover:bg-gray-50">
                <i data-lucide="copy" class="w-5 h-5 text-gray-600"></i>
                <span>Duplicate Job Posting</span>
              </a>
              
              <?php if (isset($posting['job_request_id']) && $posting['job_request_id']): ?>
              <a href="user_view_request.php?id=<?php echo $posting['job_request_id']; ?>" 
                 class="flex items-center space-x-3 p-3 border border-gray-200 rounded-md hover:bg-gray-50">
                <i data-lucide="file-text" class="w-5 h-5 text-gray-600"></i>
                <span>View Original Request</span>
              </a>
              <?php endif; ?>
            </div>
          </div>

          <!-- Created Information -->
          <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Created Information</h3>
            
            <div class="space-y-3">
              <div>
                <p class="text-sm text-gray-600">Created By</p>
                <p class="font-medium"><?php echo htmlspecialchars($posting['created_by_name'] ?? 'Unknown'); ?></p>
              </div>
              
              <div>
                <p class="text-sm text-gray-600">Created On</p>
                <p class="font-medium"><?php echo date('M d, Y \a\t h:i A', strtotime($posting['created_at'])); ?></p>
              </div>
              
              <?php if (isset($posting['updated_at']) && $posting['updated_at'] != $posting['created_at']): ?>
              <div>
                <p class="text-sm text-gray-600">Last Updated</p>
                <p class="font-medium"><?php echo date('M d, Y \a\t h:i A', strtotime($posting['updated_at'])); ?></p>
              </div>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </main>
  </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
  lucide.createIcons();
});
</script>
</body>
</html>