<?php
// test_session_write.php
session_start();
$_SESSION['test_key'] = time();
echo "Session test key set to: " . $_SESSION['test_key'] . "<br>";
echo "<a href='test_session_read.php'>Click here to test if session persists</a>";
?>

<?php
// test_session_read.php
session_start();
echo "Session test key value: " . ($_SESSION['test_key'] ?? 'NOT SET - session lost!') . "<br>";
echo "<a href='test_session_write.php'>Go back to write</a>";
?>