<?php
// File: setup_system.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: onboarding.php');
    exit();
}

$id = $_GET['id'];

$query = "SELECT o.*, d.name as department_name 
          FROM onboarding o 
          LEFT JOIN departments d ON o.department = d.id 
          WHERE o.id = ?";
$stmt = $connections->prepare($query);
$stmt->execute([$id]);
$onboarding = $stmt->fetch();

if (!$onboarding) {
    header('Location: onboarding.php');
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_system'])) {
        // Collect form data
        $system_email = $_POST['system_email'] ?? '';
        $system_username = $_POST['system_username'] ?? '';
        $temporary_password = $_POST['temporary_password'] ?? '';
        $access_groups = isset($_POST['access_groups']) ? json_encode($_POST['access_groups']) : null;
        $software_licenses = isset($_POST['software_licenses']) ? json_encode($_POST['software_licenses']) : null;
        $system_access_setup = isset($_POST['system_access_setup']) ? 1 : 0;
        $system_notes = $_POST['system_notes'] ?? '';

        // If temporary password is empty, generate one
        if (empty($temporary_password)) {
            $temporary_password = generateTemporaryPassword();
        }

        // Update onboarding record
        $update_query = "UPDATE onboarding SET 
            system_email = ?,
            system_username = ?,
            system_password = ?,
            system_access_groups = ?,
            system_software_licenses = ?,
            system_access_setup = ?,
            system_notes = ?,
            system_setup_at = NOW(),
            updated_at = NOW()
            WHERE id = ?";
        
        $update_stmt = $connections->prepare($update_query);
        $update_stmt->execute([
            $system_email,
            $system_username,
            password_hash($temporary_password, PASSWORD_DEFAULT),
            $access_groups,
            $software_licenses,
            $system_access_setup,
            $system_notes,
            $id
        ]);

        // Create user account if needed and if user_id not already set
        if ($system_access_setup && empty($onboarding['user_id'] ?? null)) {
            $user_query = "INSERT INTO users (username, email, password_hash, full_name, role, department, employee_id, created_at)
                          VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";
            $user_stmt = $connections->prepare($user_query);
            $user_stmt->execute([
                $system_username,
                $system_email,
                password_hash($temporary_password, PASSWORD_DEFAULT),
                ($onboarding['first_name'] ?? '') . ' ' . ($onboarding['last_name'] ?? ''),
                'employee',
                $onboarding['department'] ?? null,
                $onboarding['employee_record_id'] ?? null
            ]);

            $user_id = $connections->lastInsertId();

            // Update onboarding with user_id
            $update_user_id = "UPDATE onboarding SET user_id = ? WHERE id = ?";
            $update_user_stmt = $connections->prepare($update_user_id);
            $update_user_stmt->execute([$user_id, $id]);
        }

        $_SESSION['success'] = "System access details updated!";
        header("Location: view_onboarding.php?id=$id");
        exit();
    }

    // Handle password reset
    if (isset($_POST['reset_password'])) {
        $new_password = generateTemporaryPassword();

        $reset_query = "UPDATE onboarding SET 
            system_password = ?,
            system_setup_at = NOW(),
            updated_at = NOW()
            WHERE id = ?";

        $reset_stmt = $connections->prepare($reset_query);
        $reset_stmt->execute([
            password_hash($new_password, PASSWORD_DEFAULT),
            $id
        ]);

        // Also update users table if user_id exists
        if (!empty($onboarding['user_id'] ?? null)) {
            $user_reset = "UPDATE users SET password_hash = ? WHERE id = ?";
            $user_reset_stmt = $connections->prepare($user_reset);
            $user_reset_stmt->execute([
                password_hash($new_password, PASSWORD_DEFAULT),
                $onboarding['user_id']
            ]);
        }

        $_SESSION['password_reset'] = $new_password;
        header("Location: setup_system.php?id=$id");
        exit();
    }
}

// Function to generate temporary password
function generateTemporaryPassword($length = 10) {
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*';
    $password = '';
    for ($i = 0; $i < $length; $i++) {
        $password .= $chars[random_int(0, strlen($chars) - 1)];
    }
    return $password;
}

// Decode system data safely
$system_access_groups = !empty($onboarding['system_access_groups'] ?? null) ? json_decode($onboarding['system_access_groups'], true) : [];
$software_licenses = !empty($onboarding['system_software_licenses'] ?? null) ? json_decode($onboarding['system_software_licenses'], true) : [];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HR1 - System Access Setup</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="bg-gray-50 min-h-screen">
    <div class="flex">
        <?php include 'sidebar.php'; ?>

        <div class="flex-1 p-6">
            <!-- Header -->
            <div class="flex justify-between items-center mb-6">
                <div>
                    <h1 class="text-2xl font-bold text-gray-800">System Access Setup</h1>
                    <p class="text-gray-600">
                        <?php echo htmlspecialchars(($onboarding['first_name'] ?? '') . ' ' . ($onboarding['last_name'] ?? '')); ?> - 
                        <?php echo htmlspecialchars($onboarding['job_position'] ?? ''); ?>
                    </p>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="view_onboarding.php?id=<?php echo $id; ?>" 
                       class="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 flex items-center">
                        <i data-lucide="arrow-left" class="w-4 h-4 mr-2"></i>
                        Back to Onboarding
                    </a>
                    <?php include 'profile_dropdown.php'; ?>
                </div>
            </div>

            <?php if (isset($_SESSION['success'])): ?>
            <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-6">
                <div class="flex items-center">
                    <i data-lucide="check-circle" class="w-5 h-5 mr-2"></i>
                    <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['password_reset'])): ?>
            <div class="bg-blue-50 border border-blue-200 text-blue-700 px-4 py-3 rounded-lg mb-6">
                <div class="flex items-center justify-between">
                    <div class="flex items-center">
                        <i data-lucide="key" class="w-5 h-5 mr-2"></i>
                        <div>
                            <p class="font-medium">New Temporary Password Generated</p>
                            <p class="text-sm">Password: <code class="font-mono"><?php echo $_SESSION['password_reset']; ?></code></p>
                        </div>
                    </div>
                    <button onclick="copyToClipboard('<?php echo $_SESSION['password_reset']; ?>')" 
                            class="text-blue-600 hover:text-blue-800">
                        <i data-lucide="copy" class="w-4 h-4"></i>
                    </button>
                </div>
                <?php unset($_SESSION['password_reset']); ?>
            </div>
            <?php endif; ?>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <!-- Main Form -->
                <div class="lg:col-span-2">
                    <form method="POST">
                        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
                            <h2 class="text-xl font-bold text-gray-800 mb-6">Account Credentials</h2>

                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                                    <input type="email" name="system_email" 
                                           class="w-full border border-gray-300 rounded-lg p-2"
                                           value="<?php echo htmlspecialchars($onboarding['system_email'] ?? ''); ?>"
                                           placeholder="employee@luxuryhotel.com">
                                    <p class="text-xs text-gray-500 mt-1">Company email address</p>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Username</label>
                                    <input type="text" name="system_username" 
                                           class="w-full border border-gray-300 rounded-lg p-2"
                                           value="<?php echo htmlspecialchars($onboarding['system_username'] ?? ''); ?>"
                                           placeholder="Username for login">
                                    <p class="text-xs text-gray-500 mt-1">System login username</p>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Temporary Password</label>
                                    <div class="flex">
                                        <input type="text" name="temporary_password" 
                                               class="w-full border border-gray-300 rounded-l-lg p-2"
                                               value="<?php echo htmlspecialchars(!empty($onboarding['system_password'] ?? null) ? '********' : ''); ?>"
                                               placeholder="Leave blank to auto-generate">
                                        <button type="submit" name="reset_password" 
                                                class="bg-gray-100 border border-gray-300 border-l-0 rounded-r-lg px-3 hover:bg-gray-200">
                                            <i data-lucide="refresh-cw" class="w-4 h-4"></i>
                                        </button>
                                    </div>
                                    <p class="text-xs text-gray-500 mt-1">Employee will need to change on first login</p>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">User Role</label>
                                    <select class="w-full border border-gray-300 rounded-lg p-2" disabled>
                                        <option selected>Employee</option>
                                    </select>
                                    <p class="text-xs text-gray-500 mt-1">Default role for new employees</p>
                                </div>
                            </div>
                        </div>

                        <!-- Access Groups -->
                        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
                            <h2 class="text-xl font-bold text-gray-800 mb-6">Access Groups & Permissions</h2>

                            <div class="mb-6">
                                <label class="block text-sm font-medium text-gray-700 mb-2">System Access Groups</label>
                                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                                    <?php 
                                    $access_groups_list = [
                                        'hr_system' => 'HR System',
                                        'payroll_system' => 'Payroll System',
                                        'timekeeping' => 'Timekeeping System',
                                        'email_system' => 'Email System',
                                        'file_server' => 'File Server',
                                        'department_drive' => 'Department Drive',
                                        'pms_system' => 'Property Management System',
                                        'cctv_access' => 'CCTV Access',
                                        'door_access' => 'Door Access Control'
                                    ];

                                    foreach ($access_groups_list as $key => $label):
                                        $checked = in_array($key, $system_access_groups) ? 'checked' : '';
                                    ?>
                                    <div class="flex items-center">
                                        <input type="checkbox" name="access_groups[]" value="<?php echo $key; ?>" 
                                               id="access_<?php echo $key; ?>"
                                               class="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                                               <?php echo $checked; ?>>
                                        <label for="access_<?php echo $key; ?>" class="ml-2 text-sm text-gray-700">
                                            <?php echo $label; ?>
                                        </label>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Software Licenses</label>
                                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                                    <?php 
                                    $software_list = [
                                        'microsoft_office' => 'Microsoft Office 365',
                                        'adobe_creative' => 'Adobe Creative Cloud',
                                        'quickbooks' => 'QuickBooks',
                                        'opera_pms' => 'Opera PMS',
                                        'micros_pos' => 'MICROS POS',
                                        'autocad' => 'AutoCAD',
                                        'slack' => 'Slack',
                                        'zoom' => 'Zoom Pro',
                                        'vpn_access' => 'VPN Access'
                                    ];

                                    foreach ($software_list as $key => $label):
                                        $checked = in_array($key, $software_licenses) ? 'checked' : '';
                                    ?>
                                    <div class="flex items-center">
                                        <input type="checkbox" name="software_licenses[]" value="<?php echo $key; ?>" 
                                               id="software_<?php echo $key; ?>"
                                               class="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                                               <?php echo $checked; ?>>
                                        <label for="software_<?php echo $key; ?>" class="ml-2 text-sm text-gray-700">
                                            <?php echo $label; ?>
                                        </label>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>

                        <!-- Notes and Submit -->
                        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                            <div class="flex items-center mb-4">
                                <input type="checkbox" name="system_access_setup" id="system_access_setup" value="1" 
                                       class="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                                       <?php echo !empty($onboarding['system_access_setup']) ? 'checked' : ''; ?>>
                                <label for="system_access_setup" class="ml-2 block text-sm font-medium text-gray-700">
                                    Mark system access as complete
                                </label>
                            </div>

                            <div class="mb-4">
                                <label class="block text-sm font-medium text-gray-700 mb-2">Setup Notes</label>
                                <textarea name="system_notes" rows="3" 
                                          class="w-full border border-gray-300 rounded-lg p-2"
                                          placeholder="Add any notes about system setup..."><?php echo htmlspecialchars($onboarding['system_notes'] ?? ''); ?></textarea>
                            </div>

                            <button type="submit" name="update_system"
                                    class="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 font-medium">
                                <i data-lucide="save" class="w-5 h-5 inline mr-2"></i>
                                Update System Access
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Right Column -->
                <div class="space-y-6">
                    <!-- Status -->
                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                        <h3 class="text-lg font-semibold mb-4">System Status</h3>
                        <div class="space-y-4">
                            <div class="flex justify-between items-center">
                                <span class="text-gray-600">Setup Status</span>
                                <span class="px-3 py-1 rounded-full text-sm font-medium 
                                    <?php echo !empty($onboarding['system_access_setup']) ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'; ?>">
                                    <?php echo !empty($onboarding['system_access_setup']) ? 'Complete' : 'Pending'; ?>
                                </span>
                            </div>

                            <?php if (!empty($onboarding['system_setup_at'] ?? null)): ?>
                            <div class="border-t pt-4">
                                <p class="text-sm text-gray-500">Setup Date</p>
                                <p class="font-medium"><?php echo date('M d, Y', strtotime($onboarding['system_setup_at'])); ?></p>
                            </div>
                            <?php endif; ?>

                            <?php if (!empty($onboarding['system_email'] ?? null)): ?>
                            <div class="border-t pt-4">
                                <p class="text-sm text-gray-500">Email Address</p>
                                <p class="font-medium"><?php echo htmlspecialchars($onboarding['system_email']); ?></p>
                            </div>
                            <?php endif; ?>

                            <?php if (!empty($onboarding['user_id'] ?? null)): ?>
                            <div class="border-t pt-4">
                                <p class="text-sm text-gray-500">User Account</p>
                                <p class="font-medium">Created (ID: <?php echo $onboarding['user_id']; ?>)</p>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Quick Actions -->
                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                        <h3 class="text-lg font-semibold mb-4">Quick Actions</h3>
                        <div class="space-y-3">
                            <form method="POST" class="mb-3">
                                <button type="submit" name="reset_password"
                                        class="w-full bg-yellow-600 text-white py-2 rounded-lg hover:bg-yellow-700">
                                    <i data-lucide="refresh-cw" class="w-4 h-4 inline mr-2"></i>
                                    Reset Password
                                </button>
                            </form>

                            <?php if (!empty($onboarding['system_email'] ?? null)): ?>
                            <a href="mailto:<?php echo htmlspecialchars($onboarding['system_email']); ?>" 
                               class="block w-full text-center border border-blue-600 text-blue-600 py-2 rounded-lg hover:bg-blue-50">
                                <i data-lucide="mail" class="w-4 h-4 inline mr-2"></i>
                                Send Welcome Email
                            </a>
                            <?php endif; ?>

                            <a href="view_onboarding.php?id=<?php echo $id; ?>"
                               class="block w-full text-center border border-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-50">
                                <i data-lucide="eye" class="w-4 h-4 inline mr-2"></i>
                                View Onboarding
                            </a>
                        </div>
                    </div>

                    <!-- IT Checklist -->
                    <div class="bg-blue-50 border border-blue-200 rounded-xl p-6">
                        <h3 class="text-lg font-semibold mb-2 text-blue-800">IT Setup Checklist</h3>
                        <ul class="space-y-2 text-blue-700 text-sm">
                            <li class="flex items-start">
                                <i data-lucide="check-circle" class="w-4 h-4 mr-2 mt-0.5 text-blue-600"></i>
                                <span>Create email account</span>
                            </li>
                            <li class="flex items-start">
                                <i data-lucide="check-circle" class="w-4 h-4 mr-2 mt-0.5 text-blue-600"></i>
                                <span>Setup HR system access</span>
                            </li>
                            <li class="flex items-start">
                                <i data-lucide="check-circle" class="w-4 h-4 mr-2 mt-0.5 text-blue-600"></i>
                                <span>Configure security groups</span>
                            </li>
                            <li class="flex items-start">
                                <i data-lucide="check-circle" class="w-4 h-4 mr-2 mt-0.5 text-blue-600"></i>
                                <span>Assign software licenses</span>
                            </li>
                            <li class="flex items-start">
                                <i data-lucide="check-circle" class="w-4 h-4 mr-2 mt-0.5 text-blue-600"></i>
                                <span>Setup VPN access if required</span>
                            </li>
                            <li class="flex items-start">
                                <i data-lucide="check-circle" class="w-4 h-4 mr-2 mt-0.5 text-blue-600"></i>
                                <span>Provide login credentials</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener("DOMContentLoaded", () => {
        lucide.createIcons();

        // Auto-generate email and username
        const emailField = document.querySelector('input[name="system_email"]');
        const usernameField = document.querySelector('input[name="system_username"]');
        const setupCheckbox = document.querySelector('#system_access_setup');

        if (setupCheckbox && emailField && usernameField) {
            setupCheckbox.addEventListener('change', function() {
                if (this.checked && !emailField.value) {
                    const firstName = "<?php echo addslashes($onboarding['first_name'] ?? ''); ?>";
                    const lastName = "<?php echo addslashes($onboarding['last_name'] ?? ''); ?>";

                    const email = (firstName.charAt(0) + lastName).toLowerCase().replace(/[^a-z0-9]/g, '') + '@luxuryhotel.com';
                    const username = (firstName.charAt(0) + lastName).toLowerCase().replace(/[^a-z0-9]/g, '');

                    emailField.value = email;
                    usernameField.value = username;
                }
            });
        }
    });

    function copyToClipboard(text) {
        navigator.clipboard.writeText(text).then(() => {
            alert('Password copied to clipboard!');
        });
    }
    </script>
</body>
</html>