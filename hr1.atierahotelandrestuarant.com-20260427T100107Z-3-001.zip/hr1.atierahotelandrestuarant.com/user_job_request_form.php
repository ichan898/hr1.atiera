<?php
// File: job_request_form.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

$departments = getDepartments($connections);
$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data matching your database structure
    $data = [
        'position_title' => $_POST['position_title'] ?? '',
        'department' => $_POST['department'] ?? '',
        'number_needed' => $_POST['number_needed'] ?? 1,
        'reason' => $_POST['reason'] ?? 'new_position',
        'qualifications' => $_POST['qualifications'] ?? '',
        'target_start_date' => $_POST['target_start_date'] ?? '',
        'requested_by' => $_POST['requested_by'] ?? '',
        'requested_by_email' => $_POST['requested_by_email'] ?? '',
        'justification' => $_POST['justification'] ?? '',
        'budget_approved' => isset($_POST['budget_approved']) ? 1 : 0,
        'position_type' => $_POST['position_type'] ?? 'new_position',
        'required_skills' => $_POST['required_skills'] ?? '',
        'experience_level' => $_POST['experience_level'] ?? 'mid',
        'education_level' => $_POST['education_level'] ?? 'bachelor',
        'responsibilities' => $_POST['responsibilities'] ?? '',
        'reporting_to' => $_POST['reporting_to'] ?? '',
        'salary_budget' => $_POST['salary_budget'] ?? 0,
        'urgency_level' => $_POST['urgency_level'] ?? 'medium'
    ];
    
    // Validate using your existing validateJobRequest function
    $validationErrors = validateJobRequest($data);
    
    if (empty($validationErrors)) {
        // Set user information
        $data['requested_by'] = $data['requested_by'] ?: $_SESSION['user_name'] ?? 'Unknown';
        $data['requested_by_email'] = $data['requested_by_email'] ?: $_SESSION['user_email'] ?? '';
        $data['hiring_manager_id'] = $_SESSION['user_id'];
        
        $result = createJobRequest($data, $connections);
        
        if ($result['success']) {
            // Check if saving as draft
            if (isset($_POST['action']) && $_POST['action'] == 'save_draft') {
                updateJobRequestStatus($result['request_id'], 'draft', 'Saved as draft', $connections);
                header("Location: edit_request.php?id={$result['request_id']}&success=1&type=draft");
                exit();
            } else {
                header("Location: view_request.php?id={$result['request_id']}&success=1");
                exit();
            }
        } else {
            $errors[] = $result['error'];
        }
    } else {
        $errors = $validationErrors;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>HR1 - New Job Request</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
</head>

<body class="h-screen bg-gray-100 font-sans">
<div class="flex h-full">
  
  <!-- Sidebar -->
  <?php include 'user_sidebar.php'; ?>
  
  <!-- Main Content -->
  <div class="flex-1 flex flex-col overflow-y-auto">
    <main class="p-6 space-y-6">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-gray-300 pb-4">
        <div>
          <h2 class="text-2xl font-bold text-gray-800">New Job Request</h2>
          <p class="text-sm text-gray-600">Fill out the form to create a new job requisition</p>
        </div>
        <div class="flex items-center space-x-4">
          <a href="user_job_requests.php" class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
            Back to List
          </a>
          <?php include 'user_profile_dropdown.php'; ?>
        </div>
      </div>

      <!-- Error Messages -->
      <?php if (!empty($errors)): ?>
        <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
          <p class="font-bold">Please fix the following errors:</p>
          <ul class="list-disc list-inside mt-2">
            <?php foreach ($errors as $error): ?>
              <li><?php echo htmlspecialchars($error); ?></li>
            <?php endforeach; ?>
          </ul>
        </div>
      <?php endif; ?>

      <!-- Success Message -->
      <?php if ($success): ?>
        <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg">
          <div class="flex items-center">
            <i data-lucide="check-circle" class="w-5 h-5 mr-2"></i>
            <span><?php echo htmlspecialchars($success); ?></span>
          </div>
        </div>
      <?php endif; ?>

      <!-- Job Request Form -->
      <form method="POST" class="space-y-8">
        <!-- Basic Information Card -->
        <div class="bg-white rounded-lg shadow border">
          <div class="border-b px-6 py-4">
            <h3 class="text-lg font-semibold text-gray-800">Basic Information</h3>
          </div>
          <div class="p-6 space-y-6">
            <div class="grid md:grid-cols-2 gap-6">
              <!-- Position Title -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                  Position Title <span class="text-red-500">*</span>
                </label>
                <input type="text" 
                       name="position_title" 
                       required
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
              </div>
              
              <!-- Department -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                  Department <span class="text-red-500">*</span>
                </label>
                <select name="department" 
                        required
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                  <option value="">Select Department</option>
                  <?php foreach ($departments as $dept): ?>
                    <option value="<?php echo htmlspecialchars($dept['name']); ?>">
                      <?php echo htmlspecialchars($dept['name']); ?>
                    </option>
                  <?php endforeach; ?>
                </select>
              </div>
              
              <!-- Number Needed -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Number of Positions Needed</label>
                <input type="number" 
                       name="number_needed" 
                       value="1"
                       min="1"
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
              </div>
              
              <!-- Position Type -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Position Type</label>
                <select name="position_type" 
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                  <option value="new_position">New Position</option>
                  <option value="replacement">Replacement</option>
                  <option value="temporary">Temporary</option>
                  <option value="contract">Contract</option>
                </select>
              </div>
              
              <!-- Reason for Request -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Reason for Request</label>
                <select name="reason" 
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                  <?php foreach (getRequestReasons() as $key => $label): ?>
                    <option value="<?php echo $key; ?>"><?php echo $label; ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              
              <!-- Urgency Level -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Urgency Level</label>
                <select name="urgency_level" 
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                  <?php foreach (getUrgencyLevels() as $key => $label): ?>
                    <option value="<?php echo $key; ?>" <?php echo $key == 'medium' ? 'selected' : ''; ?>>
                      <?php echo $label; ?>
                    </option>
                  <?php endforeach; ?>
                </select>
              </div>
            </div>
            
            <div class="grid md:grid-cols-2 gap-6">
              <!-- Target Start Date -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                  Target Start Date <span class="text-red-500">*</span>
                </label>
                <input type="date" 
                       name="target_start_date" 
                       required
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg">
              </div>
              
              <!-- Salary Budget -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Salary Budget</label>
                <div class="relative">
                  <span class="absolute left-3 top-2 text-gray-500">&#8369;</span>
                  <input type="number" 
                         name="salary_budget" 
                         value="0"
                         step="0.01"
                         min="0"
                         class="w-full px-3 py-2 border border-gray-300 rounded-lg pl-8 focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
              </div>
            </div>
            
            <!-- Reporting To -->
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-2">Reporting To</label>
              <input type="text" 
                     name="reporting_to" 
                     class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
          </div>
        </div>

        <!-- Position Details Card -->
        <div class="bg-white rounded-lg shadow border">
          <div class="border-b px-6 py-4">
            <h3 class="text-lg font-semibold text-gray-800">Position Details</h3>
          </div>
          <div class="p-6 space-y-6">
            <!-- Qualifications -->
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-2">
                Qualifications & Requirements <span class="text-red-500">*</span>
              </label>
              <textarea name="qualifications" 
                        rows="4"
                        required
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"></textarea>
            </div>
            
            <!-- Required Skills -->
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-2">Required Skills</label>
              <textarea name="required_skills" 
                        rows="3"
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"></textarea>
            </div>
            
            <!-- Responsibilities -->
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-2">Responsibilities</label>
              <textarea name="responsibilities" 
                        rows="4"
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"></textarea>
            </div>
            
            <div class="grid md:grid-cols-2 gap-6">
              <!-- Experience Level -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Experience Level</label>
                <select name="experience_level" 
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                  <?php foreach (getExperienceLevels() as $key => $label): ?>
                    <option value="<?php echo $key; ?>" <?php echo $key == 'mid' ? 'selected' : ''; ?>>
                      <?php echo $label; ?>
                    </option>
                  <?php endforeach; ?>
                </select>
              </div>
              
              <!-- Education Level -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Education Level</label>
                <select name="education_level" 
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                  <?php foreach (getEducationLevels() as $key => $label): ?>
                    <option value="<?php echo $key; ?>" <?php echo $key == 'bachelor' ? 'selected' : ''; ?>>
                      <?php echo $label; ?>
                    </option>
                  <?php endforeach; ?>
                </select>
              </div>
            </div>
          </div>
        </div>

        <!-- Requester Information Card -->
        <div class="bg-white rounded-lg shadow border">
          <div class="border-b px-6 py-4">
            <h3 class="text-lg font-semibold text-gray-800">Requester Information</h3>
          </div>
          <div class="p-6 space-y-6">
            <div class="grid md:grid-cols-2 gap-6">
              <!-- Requested By -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                  Requested By <span class="text-red-500">*</span>
                </label>
                <input type="text" 
                       name="requested_by" 
                       value="<?php echo htmlspecialchars($_SESSION['user_name'] ?? ''); ?>"
                       required
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
              </div>
              
              <!-- Requested By Email -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                  Requested By Email <span class="text-red-500">*</span>
                </label>
                <input type="email" 
                       name="requested_by_email" 
                       value="<?php echo htmlspecialchars($_SESSION['user_email'] ?? ''); ?>"
                       required
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
              </div>
            </div>
            
            <!-- Justification -->
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-2">
                Justification / Business Case <span class="text-red-500">*</span>
              </label>
              <textarea name="justification" 
                        rows="4"
                        required
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"></textarea>
            </div>
            
            <!-- Budget Approval -->
            <div class="flex items-center space-x-3">
              <input type="checkbox" 
                     name="budget_approved" 
                     id="budget_approved"
                     value="1"
                     class="w-4 h-4 text-blue-600 border-gray-300 rounded">
              <label for="budget_approved" class="text-sm text-gray-700">
                Budget has been approved
              </label>
            </div>
          </div>
        </div>

        <!-- Form Actions -->
        <div class="flex justify-end space-x-4 pt-6">
          <a href="job_requests.php"
             class="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
            Cancel
          </a>
          <button type="submit" 
                  name="action" 
                  value="save_draft"
                  class="px-6 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300">
            Save as Draft
          </button>
          <button type="submit" 
                  name="action" 
                  value="submit"
                  class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            Submit Request
          </button>
        </div>
      </form>
    </main>
  </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
  lucide.createIcons();
  
  // Set minimum date for target start date to today
  const today = new Date().toISOString().split('T')[0];
  const dateInput = document.querySelector('input[name="target_start_date"]');
  if (dateInput) {
    dateInput.min = today;
  }
});
</script>
</body>
</html>