<?php
// File: reset-password.php
session_start();
require_once 'connections.php';

$token = $_GET['token'] ?? '';
$password = $confirm_password = $error = $success = '';

if (empty($token)) {
    $error = "Invalid reset token.";
} else {
    // Check if token is valid
    $stmt = $connections->prepare("
        SELECT id 
        FROM hr_users 
        WHERE reset_token = ? AND reset_expires > NOW()
    ");
    $stmt->execute([$token]);
    $user = $stmt->fetch();
    
    if (!$user) {
        $error = "Invalid or expired reset token.";
    } elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
        $password = $_POST['password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        
        if (empty($password)) {
            $error = "Password is required!";
        } elseif (strlen($password) < 8) {
            $error = "Password must be at least 8 characters!";
        } elseif ($password !== $confirm_password) {
            $error = "Passwords do not match!";
        } else {
            // Update password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $updateStmt = $connections->prepare("
                UPDATE hr_users 
                SET password_hash = ?, reset_token = NULL, reset_expires = NULL 
                WHERE id = ?
            ");
            $updateStmt->execute([$hashed_password, $user['id']]);
            
            $success = "Password reset successfully! You can now login with your new password.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - HR1 System</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        :root {
            --blue-600: #004AAD;
            --blue-800: #003680;
        }
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #004AAD 0%, #003680 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .card {
            background: white;
            border-radius: 18px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>
<body>
    <div class="w-full max-w-md mx-4">
        <div class="card p-8">
            <div class="text-center mb-8">
                <div class="w-16 h-16 bg-blue-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <svg class="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
                    </svg>
                </div>
                <h2 class="text-2xl font-bold text-gray-800">Reset Password</h2>
                <p class="text-gray-600 mt-2">Enter your new password</p>
            </div>
            
            <?php if ($error): ?>
                <div class="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-lg mb-4">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="bg-green-50 border border-green-200 text-green-600 px-4 py-3 rounded-lg mb-4">
                    <?php echo $success; ?>
                    <div class="mt-4">
                        <a href="login.php" class="inline-block bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700">
                            Go to Login
                        </a>
                    </div>
                </div>
            <?php elseif (empty($error)): ?>
                <form method="POST" class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">New Password</label>
                        <input type="password" name="password" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" 
                               placeholder="At least 8 characters" required>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Confirm Password</label>
                        <input type="password" name="confirm_password" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" 
                               placeholder="Re-enter your password" required>
                    </div>
                    
                    <button type="submit" class="w-full bg-blue-600 text-white py-3 px-4 rounded-lg font-semibold hover:bg-blue-700 transition duration-200">
                        Reset Password
                    </button>
                </form>
            <?php endif; ?>
            
            <div class="mt-6 text-center">
                <a href="login.php" class="text-blue-600 hover:text-blue-800 font-medium">
                    ← Back to Login
                </a>
            </div>
        </div>
    </div>
</body>
</html>