<?php
// File: performance.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

// Get user role and permissions
$is_admin = checkUserRole($_SESSION['user_id'], ['admin', 'hr_manager'], $connections);
$is_manager = checkUserRole($_SESSION['user_id'], ['manager', 'supervisor', 'department_head', 'admin', 'hr_manager'], $connections);
$user_id = $_SESSION['user_id'];

// Get current tab
$tab = isset($_GET['tab']) ? $_GET['tab'] : 'overview';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_criteria'])) {
        addAppraisalCriteria($_POST, $user_id, $connections);
    } elseif (isset($_POST['add_template'])) {
        addAppraisalTemplate($_POST, $user_id, $connections);
    } elseif (isset($_POST['add_goal'])) {
        addPerformanceGoal($_POST, $user_id, $connections);
    } elseif (isset($_POST['update_attendance'])) {
        updateAttendance($_POST, $user_id, $connections);
    } elseif (isset($_POST['schedule_appraisal'])) {
        $employee_id = intval($_POST['employee_id']);
        $appraisal_date = $_POST['appraisal_date'];
        $template_id = intval($_POST['template_id']) ?: null;
        $reviewer_id = $_SESSION['user_id']; // current user as reviewer
        $appraisal_type = 'annual'; // choose appropriate type: 'probationary','annual','promotion','special'
        $due_date = $appraisal_date; // or e.g., date('Y-m-d', strtotime($appraisal_date . ' +6 months'))

        $stmt = $connections->prepare("
            INSERT INTO appraisals 
                (employee_id, reviewer_id, template_id, appraisal_type, appraisal_date, due_date, status) 
            VALUES (?, ?, ?, ?, ?, ?, 'scheduled')
        ");
        $stmt->execute([$employee_id, $reviewer_id, $template_id, $appraisal_type, $appraisal_date, $due_date]);

        $_SESSION['flash_message'] = ['type' => 'success', 'message' => 'Appraisal scheduled.'];
        header("Location: performance.php?tab=evaluations");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HR1 - Performance Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-date-fns"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        .status-badge { padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.75rem; font-weight: 500; }
        .status-present { background-color: #d1fae5; color: #065f46; }
        .status-absent { background-color: #fee2e2; color: #991b1b; }
        .status-late { background-color: #fef3c7; color: #92400e; }
        .progress-bar { transition: width 0.3s ease-in-out; }
        .calendar-day { cursor: pointer; }
        .calendar-day:hover { background-color: #f3f4f6; }
    </style>
</head>
<body class="h-screen bg-gray-100 font-sans">
<div class="flex h-full">
  
  <!-- Sidebar -->
  <?php include 'sidebar.php'; ?>
  
  <!-- Main Content -->
  <div class="flex-1 flex flex-col overflow-y-auto">
    <main class="p-6 space-y-6">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-gray-300 pb-4">
        <div>
          <h2 class="text-2xl font-bold text-gray-800">Performance Dashboard</h2>
          <p class="text-sm text-gray-600">Comprehensive performance management system</p>
        </div>
        <div class="flex items-center space-x-4">
          <?php if($is_manager): ?>
          <button id="quickActionBtn" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center">
            <i data-lucide="plus" class="w-4 h-4 mr-2"></i>
            Quick Action
          </button>
          <?php endif; ?>
          <div class="relative">
            <select id="periodFilter" class="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="monthly">This Month</option>
              <option value="quarterly">This Quarter</option>
              <option value="yearly" selected>This Year</option>
            </select>
          </div>
          <?php include 'profile_dropdown.php'; ?>
        </div>
      </div>

      <!-- Display flash messages -->
      <?php displayFlashMessage(); ?>

      <!-- Tabs Navigation -->
      <div class="border-b border-gray-200">
        <nav class="flex space-x-8">
          <button data-tab="overview" class="tab-button py-4 px-1 border-b-2 font-medium text-sm <?php echo $tab == 'overview' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'; ?>">
            <i data-lucide="layout-dashboard" class="w-4 h-4 inline mr-2"></i>
            Overview
          </button>
          <button data-tab="attendance" class="tab-button py-4 px-1 border-b-2 font-medium text-sm <?php echo $tab == 'attendance' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'; ?>">
            <i data-lucide="calendar" class="w-4 h-4 inline mr-2"></i>
            Attendance
          </button>
          <button data-tab="evaluations" class="tab-button py-4 px-1 border-b-2 font-medium text-sm <?php echo $tab == 'evaluations' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'; ?>">
            <i data-lucide="clipboard-check" class="w-4 h-4 inline mr-2"></i>
            Evaluations
          </button>
          <button data-tab="goals" class="tab-button py-4 px-1 border-b-2 font-medium text-sm <?php echo $tab == 'goals' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'; ?>">
            <i data-lucide="target" class="w-4 h-4 inline mr-2"></i>
            Goals
          </button>
          <?php if($is_admin): ?>
          <button data-tab="configuration" class="tab-button py-4 px-1 border-b-2 font-medium text-sm <?php echo $tab == 'configuration' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'; ?>">
            <i data-lucide="settings" class="w-4 h-4 inline mr-2"></i>
            Configuration
          </button>
          <?php endif; ?>
        </nav>
      </div>

      <!-- Tab Contents -->
      <div id="tabContents">
        <!-- Overview Tab -->
        <div id="overview-tab" class="tab-content <?php echo $tab == 'overview' ? 'active' : ''; ?> space-y-6">
          <?php
          // ---------- performance_overview.php ----------
          $totalStmt = $connections->query("SELECT COUNT(*) FROM employees WHERE status = 'Active'");
          $total_employees = $totalStmt ? $totalStmt->fetchColumn() : 0;

          $avgStmt = $connections->query("SELECT AVG(overall_rating) FROM appraisals WHERE status = 'completed'");
          $avg_performance = $avgStmt ? $avgStmt->fetchColumn() : 4.2;

          $pendingStmt = $connections->query("SELECT COUNT(*) FROM appraisals WHERE status = 'scheduled'");
          $pending_reviews = $pendingStmt ? $pendingStmt->fetchColumn() : 0;

          $completedStmt = $connections->query("SELECT COUNT(*) FROM performance_goals WHERE status = 'completed'");
          $goals_completed = $completedStmt ? $completedStmt->fetchColumn() : 0;

          $recentStmt = $connections->prepare("
              SELECT a.*, CONCAT(e.first_name, ' ', e.last_name) AS full_name
              FROM appraisals a
              JOIN employees e ON a.employee_id = e.id
              WHERE a.status = 'completed'
              ORDER BY a.appraisal_date DESC
              LIMIT 5
          ");
          $recentStmt->execute();
          $recent_appraisals = $recentStmt;
          ?>
          <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div class="bg-white rounded-lg shadow p-4">
                  <div class="flex items-center">
                      <div class="p-3 bg-blue-100 rounded-full">
                          <i data-lucide="users" class="w-6 h-6 text-blue-600"></i>
                      </div>
                      <div class="ml-4">
                          <p class="text-sm text-gray-500">Total Employees</p>
                          <p class="text-2xl font-semibold"><?php echo $total_employees; ?></p>
                      </div>
                  </div>
              </div>
              <div class="bg-white rounded-lg shadow p-4">
                  <div class="flex items-center">
                      <div class="p-3 bg-green-100 rounded-full">
                          <i data-lucide="trending-up" class="w-6 h-6 text-green-600"></i>
                      </div>
                      <div class="ml-4">
                          <p class="text-sm text-gray-500">Avg Performance</p>
                          <p class="text-2xl font-semibold"><?php echo number_format($avg_performance, 1); ?>/5</p>
                      </div>
                  </div>
              </div>
              <div class="bg-white rounded-lg shadow p-4">
                  <div class="flex items-center">
                      <div class="p-3 bg-yellow-100 rounded-full">
                          <i data-lucide="clock" class="w-6 h-6 text-yellow-600"></i>
                      </div>
                      <div class="ml-4">
                          <p class="text-sm text-gray-500">Pending Reviews</p>
                          <p class="text-2xl font-semibold"><?php echo $pending_reviews; ?></p>
                      </div>
                  </div>
              </div>
              <div class="bg-white rounded-lg shadow p-4">
                  <div class="flex items-center">
                      <div class="p-3 bg-purple-100 rounded-full">
                          <i data-lucide="target" class="w-6 h-6 text-purple-600"></i>
                      </div>
                      <div class="ml-4">
                          <p class="text-sm text-gray-500">Goals Completed</p>
                          <p class="text-2xl font-semibold"><?php echo $goals_completed; ?></p>
                      </div>
                  </div>
              </div>
          </div>

          <div class="grid grid-cols-1 lg:grid-cols-2 gap-4 mt-4">
              <div class="bg-white rounded-lg shadow p-4">
                  <h3 class="text-md font-semibold mb-3">Performance Distribution</h3>
                  <canvas id="performanceDistributionChart" style="max-height: 250px;"></canvas>
              </div>
              <div class="bg-white rounded-lg shadow p-4">
                  <h3 class="text-md font-semibold mb-3">Performance Trend</h3>
                  <canvas id="performanceTrendChart" style="max-height: 250px;"></canvas>
              </div>
          </div>

          <div class="bg-white rounded-lg shadow p-4 mt-4">
              <h3 class="text-md font-semibold mb-3">Recent Appraisals</h3>
              <table class="min-w-full divide-y divide-gray-200">
                  <thead>
                      <tr>
                          <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Employee</th>
                          <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                          <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Rating</th>
                      </tr>
                  </thead>
                  <tbody class="divide-y divide-gray-200">
                      <?php while($row = $recent_appraisals->fetch(PDO::FETCH_ASSOC)): ?>
                      <tr>
                          <td class="px-4 py-2"><?php echo htmlspecialchars($row['full_name']); ?></td>
                          <td class="px-4 py-2"><?php echo formatDate($row['appraisal_date']); ?></td>
                          <td class="px-4 py-2"><?php echo $row['overall_rating'] ? number_format($row['overall_rating'],1) : 'N/A'; ?></td>
                      </tr>
                      <?php endwhile; ?>
                  </tbody>
              </table>
          </div>
        </div>

        <!-- Attendance Tab -->
        <div id="attendance-tab" class="tab-content <?php echo $tab == 'attendance' ? 'active' : ''; ?> space-y-6">
          <?php
          // ---------- attendance_dashboard.php ----------
          $today = date('Y-m-d');
          $summaryStmt = $connections->prepare("
              SELECT 
                  SUM(status = 'present') as present,
                  SUM(status = 'absent') as absent,
                  SUM(status = 'late') as late,
                  SUM(status = 'leave') as on_leave
              FROM attendance 
              WHERE attendance_date = ?
          ");
          $summaryStmt->execute([$today]);
          $summary = $summaryStmt->fetch(PDO::FETCH_ASSOC);

          $recentStmt = $connections->prepare("
              SELECT a.*, CONCAT(e.first_name, ' ', e.last_name) AS full_name
              FROM attendance a
              JOIN employees e ON a.employee_id = e.id
              ORDER BY a.attendance_date DESC, a.id DESC
              LIMIT 10
          ");
          $recentStmt->execute();
          $recent = $recentStmt;
          ?>
          <div class="bg-white rounded-lg shadow p-4">
              <div class="flex justify-between items-center mb-4">
                  <h3 class="text-lg font-semibold">Attendance Overview</h3>
                  <button onclick="showMarkAttendanceModal()" class="px-3 py-1 bg-blue-600 text-white rounded hover:bg-blue-700 text-sm">
                      <i data-lucide="calendar-check" class="w-4 h-4 inline"></i> Mark Attendance
                  </button>
              </div>

              <div class="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
                  <div class="bg-green-50 p-3 rounded">
                      <p class="text-sm text-gray-600">Present Today</p>
                      <p class="text-xl font-bold"><?php echo intval($summary['present'] ?? 0); ?></p>
                  </div>
                  <div class="bg-red-50 p-3 rounded">
                      <p class="text-sm text-gray-600">Absent</p>
                      <p class="text-xl font-bold"><?php echo intval($summary['absent'] ?? 0); ?></p>
                  </div>
                  <div class="bg-yellow-50 p-3 rounded">
                      <p class="text-sm text-gray-600">Late</p>
                      <p class="text-xl font-bold"><?php echo intval($summary['late'] ?? 0); ?></p>
                  </div>
                  <div class="bg-blue-50 p-3 rounded">
                      <p class="text-sm text-gray-600">On Leave</p>
                      <p class="text-xl font-bold"><?php echo intval($summary['on_leave'] ?? 0); ?></p>
                  </div>
              </div>

              <canvas id="attendanceTrendChart" style="max-height: 250px;"></canvas>

              <h4 class="font-medium mt-4 mb-2">Recent Attendance</h4>
              <table class="min-w-full divide-y divide-gray-200">
                  <thead>
                      <tr>
                          <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Employee</th>
                          <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                          <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                      </tr>
                  </thead>
                  <tbody>
                      <?php while($row = $recent->fetch(PDO::FETCH_ASSOC)): ?>
                      <tr>
                          <td class="px-4 py-2"><?php echo htmlspecialchars($row['full_name']); ?></td>
                          <td class="px-4 py-2"><?php echo formatDate($row['attendance_date']); ?></td>
                          <td class="px-4 py-2">
                              <span class="status-badge status-<?php echo $row['status']; ?>">
                                  <?php echo ucfirst($row['status']); ?>
                              </span>
                          </td>
                      </tr>
                      <?php endwhile; ?>
                  </tbody>
              </table>
          </div>
        </div>

        <!-- Evaluations Tab -->
        <div id="evaluations-tab" class="tab-content <?php echo $tab == 'evaluations' ? 'active' : ''; ?> space-y-6">
          <?php
          // ---------- FULL APPRAISAL LIST WITH PAGINATION ----------
          $is_admin_eval = checkUserRole($_SESSION['user_id'] ?? 0, ['admin', 'hr_manager'], $connections);

          // Pagination and search setup
          $limit = 20; // rows per page
          $page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
          $offset = ($page - 1) * $limit;
          $search = isset($_GET['search']) ? trim($_GET['search']) : '';

          // Base query
          $count_sql = "SELECT COUNT(*) FROM appraisals a";
          $sql = "SELECT a.*, 
                         CONCAT(e.first_name, ' ', e.last_name) AS employee_name,
                         t.template_name
                  FROM appraisals a
                  JOIN employees e ON a.employee_id = e.id
                  LEFT JOIN appraisal_templates t ON a.template_id = t.template_id";

          // Add search condition if provided
          $params = [];
          if (!empty($search)) {
              $where = " WHERE CONCAT(e.first_name, ' ', e.last_name) LIKE :search";
              $count_sql .= $where;
              $sql .= $where;
              $params[':search'] = "%$search%";
          }

          // Order and limit
          $sql .= " ORDER BY a.appraisal_date DESC LIMIT :limit OFFSET :offset";
          $params[':limit'] = $limit;
          $params[':offset'] = $offset;

          // Get total count for pagination
          $count_stmt = $connections->prepare($count_sql);
          if (!empty($search)) {
              $count_stmt->bindValue(':search', "%$search%", PDO::PARAM_STR);
          }
          $count_stmt->execute();
          $total_rows = $count_stmt->fetchColumn();
          $total_pages = ceil($total_rows / $limit);

          // Fetch paginated results
          $stmt = $connections->prepare($sql);
          foreach ($params as $key => $val) {
              if ($key == ':limit' || $key == ':offset') {
                  $stmt->bindValue($key, $val, PDO::PARAM_INT);
              } else {
                  $stmt->bindValue($key, $val, PDO::PARAM_STR);
              }
          }
          $stmt->execute();
          $appraisals = $stmt->fetchAll(PDO::FETCH_ASSOC);
          ?>
          
          <div class="bg-white rounded-lg shadow p-4">
            <div class="flex justify-between items-center mb-4">
              <h3 class="text-lg font-semibold">Performance Evaluations</h3>
              <?php if($is_admin_eval): ?>
              <button onclick="showScheduleAppraisalModal()" class="px-3 py-1 bg-blue-600 text-white rounded hover:bg-blue-700 text-sm">
                <i data-lucide="calendar" class="w-4 h-4 inline"></i> Schedule Appraisal
              </button>
              <?php endif; ?>
            </div>

            <!-- Search Form -->
            <form method="GET" action="performance.php" class="mb-4 flex gap-2">
              <input type="hidden" name="tab" value="evaluations">
              <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" 
                     placeholder="Search by employee name..." 
                     class="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
              <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                <i data-lucide="search" class="w-4 h-4 inline"></i> Search
              </button>
              <?php if (!empty($search)): ?>
              <a href="?tab=evaluations" class="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300">
                Clear
              </a>
              <?php endif; ?>
            </form>

            <!-- Appraisals Table -->
            <div class="overflow-x-auto">
              <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                  <tr>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Employee</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Template</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Rating</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                  <?php if (count($appraisals) > 0): ?>
                    <?php foreach($appraisals as $app): ?>
                    <tr>
                      <td class="px-4 py-3 whitespace-nowrap"><?php echo htmlspecialchars($app['employee_name']); ?></td>
                      <td class="px-4 py-3 whitespace-nowrap"><?php echo formatDate($app['appraisal_date']); ?></td>
                      <td class="px-4 py-3 whitespace-nowrap"><?php echo htmlspecialchars($app['template_name'] ?: '—'); ?></td>
                      <td class="px-4 py-3 whitespace-nowrap">
                        <?php if ($app['overall_rating'] !== null): ?>
                          <span class="font-medium"><?php echo number_format($app['overall_rating'], 1); ?></span> / 5
                        <?php else: ?>
                          —
                        <?php endif; ?>
                      </td>
                      <td class="px-4 py-3 whitespace-nowrap">
                        <span class="status-badge bg-<?php 
                          echo $app['status'] == 'completed' ? 'green' : ($app['status'] == 'scheduled' ? 'blue' : 'gray'); 
                        ?>-100 text-<?php 
                          echo $app['status'] == 'completed' ? 'green' : ($app['status'] == 'scheduled' ? 'blue' : 'gray'); 
                        ?>-800">
                          <?php echo ucfirst($app['status']); ?>
                        </span>
                      </td>
                    </tr>
                    <?php endforeach; ?>
                  <?php else: ?>
                    <tr>
                      <td colspan="5" class="px-4 py-8 text-center text-gray-500">No appraisals found.</td>
                    </tr>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>

            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
            <div class="mt-4 flex justify-center">
              <nav class="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                <!-- Previous page -->
                <a href="?tab=evaluations&page=<?php echo max(1, $page-1); ?>&search=<?php echo urlencode($search); ?>" 
                   class="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 <?php echo $page <= 1 ? 'pointer-events-none opacity-50' : ''; ?>">
                  <span class="sr-only">Previous</span>
                  <i data-lucide="chevron-left" class="h-5 w-5"></i>
                </a>
                
                <!-- Page numbers -->
                <?php 
                $start = max(1, $page - 2);
                $end = min($total_pages, $page + 2);
                for ($i = $start; $i <= $end; $i++): ?>
                  <a href="?tab=evaluations&page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>" 
                     class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium <?php echo $i == $page ? 'text-blue-600 bg-blue-50' : 'text-gray-700 hover:bg-gray-50'; ?>">
                    <?php echo $i; ?>
                  </a>
                <?php endfor; ?>
                
                <!-- Next page -->
                <a href="?tab=evaluations&page=<?php echo min($total_pages, $page+1); ?>&search=<?php echo urlencode($search); ?>" 
                   class="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 <?php echo $page >= $total_pages ? 'pointer-events-none opacity-50' : ''; ?>">
                  <span class="sr-only">Next</span>
                  <i data-lucide="chevron-right" class="h-5 w-5"></i>
                </a>
              </nav>
            </div>
            <?php endif; ?>

            <!-- Optional Chart (kept from original) -->
            <canvas id="evaluationChart" class="mt-6" style="max-height: 200px;"></canvas>
          </div>
        </div>

        <!-- Goals Tab -->
        <div id="goals-tab" class="tab-content <?php echo $tab == 'goals' ? 'active' : ''; ?> space-y-6">
          <?php
          // ---------- goals_dashboard.php ----------
          $user_id_goals = $_SESSION['user_id'] ?? 0;
          $is_manager_goals = checkUserRole($user_id_goals, ['manager', 'supervisor', 'department_head', 'admin', 'hr_manager'], $connections);

          if ($is_manager_goals) {
              $goalsStmt = $connections->prepare("
                  SELECT g.*, CONCAT(e.first_name, ' ', e.last_name) AS employee_name 
                  FROM performance_goals g
                  JOIN employees e ON g.employee_id = e.id
                  ORDER BY g.due_date DESC
              ");
              $goalsStmt->execute();
              $goals = $goalsStmt;
          } else {
              $empStmt = $connections->prepare("SELECT id FROM employees WHERE user_id = ?");
              $empStmt->execute([$user_id_goals]);
              $emp = $empStmt->fetch(PDO::FETCH_ASSOC);
              $employee_id = $emp ? $emp['id'] : 0;
              
              $goalsStmt = $connections->prepare("
                  SELECT g.*, CONCAT(e.first_name, ' ', e.last_name) AS employee_name 
                  FROM performance_goals g
                  JOIN employees e ON g.employee_id = e.id
                  WHERE g.employee_id = ?
                  ORDER BY g.due_date DESC
              ");
              $goalsStmt->execute([$employee_id]);
              $goals = $goalsStmt;
          }
          ?>
          <div class="bg-white rounded-lg shadow p-6">
              <div class="flex justify-between items-center mb-4">
                  <h3 class="text-lg font-semibold">Performance Goals</h3>
                  <?php if($is_manager_goals): ?>
                  <button onclick="showAddGoalModal()" class="px-3 py-1 bg-blue-600 text-white rounded hover:bg-blue-700 text-sm">
                      <i data-lucide="plus" class="w-4 h-4 inline"></i> Add Goal
                  </button>
                  <?php endif; ?>
              </div>

              <div class="space-y-3">
                  <?php while($goal = $goals->fetch(PDO::FETCH_ASSOC)): 
                      $status_color = [
                          'not_started' => 'gray',
                          'in_progress' => 'yellow',
                          'completed' => 'green',
                          'overdue' => 'red'
                      ][$goal['status']] ?? 'gray';
                  ?>
                  <div class="border rounded-lg p-4">
                      <div class="flex justify-between items-start">
                          <div>
                              <h4 class="font-medium"><?php echo htmlspecialchars($goal['title']); ?></h4>
                              <p class="text-sm text-gray-600">
                                  <?php if($is_manager_goals): ?>
                                      <?php echo htmlspecialchars($goal['employee_name']); ?> - 
                                  <?php endif; ?>
                                  Due: <?php echo $goal['due_date'] ? formatDate($goal['due_date']) : 'No due date'; ?>
                              </p>
                          </div>
                          <span class="status-badge bg-<?php echo $status_color; ?>-100 text-<?php echo $status_color; ?>-800">
                              <?php echo ucfirst(str_replace('_', ' ', $goal['status'])); ?>
                          </span>
                      </div>
                      <div class="mt-3">
                          <div class="flex justify-between text-sm mb-1">
                              <span>Progress</span>
                              <span><?php echo $goal['progress']; ?>%</span>
                          </div>
                          <div class="w-full bg-gray-200 rounded-full h-2">
                              <div class="bg-<?php echo $goal['progress'] == 100 ? 'green' : 'blue'; ?>-600 h-2 rounded-full progress-bar" style="width: <?php echo $goal['progress']; ?>%"></div>
                          </div>
                      </div>
                  </div>
                  <?php endwhile; ?>
              </div>

              <canvas id="goalsChart" class="mt-6" style="max-height: 300px;"></canvas>
          </div>
        </div>

        <!-- Configuration Tab (admin only) -->
        <?php if($is_admin): ?>
        <div id="configuration-tab" class="tab-content <?php echo $tab == 'configuration' ? 'active' : ''; ?> space-y-6">
          <?php
          // ---------- performance_configuration.php ----------
          if(!checkUserRole($_SESSION['user_id'] ?? 0, ['admin', 'hr_manager'], $connections)) {
              echo '<p class="text-red-500">Access denied.</p>';
          } else {
              $criteriaStmt = $connections->query("SELECT * FROM appraisal_criteria WHERE is_active = 1 ORDER BY criteria_name");
              $criteria = $criteriaStmt ? $criteriaStmt : null;
              $templatesStmt = $connections->query("SELECT * FROM appraisal_templates WHERE is_active = 1 ORDER BY template_name");
              $templates = $templatesStmt ? $templatesStmt : null;
          ?>
          <div class="bg-white rounded-lg shadow p-4">
              <h3 class="text-lg font-semibold mb-4">Performance Configuration</h3>

              <div class="grid md:grid-cols-2 gap-4">
                  <!-- Appraisal Criteria -->
                  <div class="border rounded p-3">
                      <h4 class="font-medium mb-2">Appraisal Criteria</h4>
                      <ul class="text-sm space-y-1">
                          <?php if($criteria): while($row = $criteria->fetch(PDO::FETCH_ASSOC)): ?>
                          <li><?php echo htmlspecialchars($row['criteria_name']); ?> (Weight: <?php echo $row['default_weight']; ?>%)</li>
                          <?php endwhile; endif; ?>
                      </ul>
                      <button onclick="showAddCriteriaModal()" class="mt-2 text-blue-600 text-sm">+ Add Criteria</button>
                  </div>

                  <!-- Evaluation Templates -->
                  <div class="border rounded p-3">
                      <h4 class="font-medium mb-2">Evaluation Templates</h4>
                      <ul class="text-sm space-y-1">
                          <?php if($templates): while($row = $templates->fetch(PDO::FETCH_ASSOC)): ?>
                          <li><?php echo htmlspecialchars($row['template_name']); ?></li>
                          <?php endwhile; endif; ?>
                      </ul>
                      <button onclick="showAddTemplateModal()" class="mt-2 text-blue-600 text-sm">+ Add Template</button>
                  </div>
              </div>

              <!-- Settings Form (example) -->
              <div class="mt-4 border-t pt-4">
                  <h4 class="font-medium mb-2">Settings</h4>
                  <form method="POST" action="performance.php?tab=configuration">
                      <label class="block text-sm mb-2">
                          <span>Review Period (months)</span>
                          <input type="number" name="review_period" value="12" class="mt-1 block w-full border rounded p-2">
                      </label>
                      <button type="submit" name="save_settings" class="px-4 py-2 bg-blue-600 text-white rounded">Save Settings</button>
                  </form>
              </div>
          </div>
          <?php } ?>
        </div>
        <?php endif; ?>
      </div>
    </main>
  </div>
</div>

<!-- Modals -->
<?php
// ---------- performance_modals.php ----------
$employees = getEmployeeList($connections);
$criteria_list = getActiveCriteria($connections);
$templates_list = getActiveTemplates($connections);
?>

<!-- Add Goal Modal -->
<div id="addGoalModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden items-center justify-center z-50">
    <div class="bg-white rounded-lg p-6 w-96">
        <h3 class="text-lg font-medium mb-4">Add Performance Goal</h3>
        <form method="POST" action="performance.php?tab=goals">
            <div class="space-y-3">
                <div>
                    <label class="block text-sm font-medium text-gray-700">Employee</label>
                    <select name="employee_id" class="mt-1 block w-full border rounded p-2" required>
                        <option value="">Select employee...</option>
                        <?php foreach($employees as $emp): ?>
                        <option value="<?php echo $emp['id']; ?>"><?php echo htmlspecialchars($emp['full_name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Goal Title</label>
                    <input type="text" name="goal_title" class="mt-1 block w-full border rounded p-2" required>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Description</label>
                    <textarea name="goal_description" class="mt-1 block w-full border rounded p-2"></textarea>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Due Date</label>
                    <input type="date" name="goal_due" class="mt-1 block w-full border rounded p-2">
                </div>
            </div>
            <div class="mt-4 flex justify-end space-x-2">
                <button type="button" onclick="hideModal('addGoalModal')" class="px-4 py-2 bg-gray-200 rounded">Cancel</button>
                <button type="submit" name="add_goal" class="px-4 py-2 bg-blue-600 text-white rounded">Save</button>
            </div>
        </form>
    </div>
</div>

<!-- Mark Attendance Modal -->
<div id="markAttendanceModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden items-center justify-center z-50">
    <div class="bg-white rounded-lg p-6 w-96">
        <h3 class="text-lg font-medium mb-4">Mark Attendance</h3>
        <form method="POST" action="performance.php?tab=attendance">
            <div class="space-y-3">
                <div>
                    <label class="block text-sm font-medium text-gray-700">Employee</label>
                    <select name="employee_id" class="mt-1 block w-full border rounded p-2" required>
                        <option value="">Select employee...</option>
                        <?php foreach($employees as $emp): ?>
                        <option value="<?php echo $emp['id']; ?>"><?php echo htmlspecialchars($emp['full_name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Date</label>
                    <input type="date" name="attendance_date" class="mt-1 block w-full border rounded p-2" value="<?php echo date('Y-m-d'); ?>">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Status</label>
                    <select name="status" class="mt-1 block w-full border rounded p-2" required>
                        <option value="present">Present</option>
                        <option value="absent">Absent</option>
                        <option value="late">Late</option>
                        <option value="leave">On Leave</option>
                    </select>
                </div>
            </div>
            <div class="mt-4 flex justify-end space-x-2">
                <button type="button" onclick="hideModal('markAttendanceModal')" class="px-4 py-2 bg-gray-200 rounded">Cancel</button>
                <button type="submit" name="update_attendance" class="px-4 py-2 bg-blue-600 text-white rounded">Save</button>
            </div>
        </form>
    </div>
</div>

<!-- Schedule Appraisal Modal -->
<div id="scheduleAppraisalModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden items-center justify-center z-50">
    <div class="bg-white rounded-lg p-6 w-96">
        <h3 class="text-lg font-medium mb-4">Schedule Appraisal</h3>
        <form method="POST" action="performance.php?tab=evaluations">
            <div class="space-y-3">
                <div>
                    <label class="block text-sm font-medium text-gray-700">Employee</label>
                    <select name="employee_id" class="mt-1 block w-full border rounded p-2" required>
                        <option value="">Select...</option>
                        <?php foreach($employees as $emp): ?>
                        <option value="<?php echo $emp['id']; ?>"><?php echo htmlspecialchars($emp['full_name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Appraisal Date</label>
                    <input type="date" name="appraisal_date" class="mt-1 block w-full border rounded p-2" required>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Template</label>
                    <select name="template_id" class="mt-1 block w-full border rounded p-2">
                        <option value="">None</option>
                        <?php foreach($templates_list as $tpl): ?>
                        <option value="<?php echo $tpl['template_id']; ?>"><?php echo htmlspecialchars($tpl['template_name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="mt-4 flex justify-end space-x-2">
                <button type="button" onclick="hideModal('scheduleAppraisalModal')" class="px-4 py-2 bg-gray-200 rounded">Cancel</button>
                <button type="submit" name="schedule_appraisal" class="px-4 py-2 bg-blue-600 text-white rounded">Schedule</button>
            </div>
        </form>
    </div>
</div>

<!-- Add Criteria Modal -->
<div id="addCriteriaModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden items-center justify-center z-50">
    <div class="bg-white rounded-lg p-6 w-96">
        <h3 class="text-lg font-medium mb-4">Add Appraisal Criteria</h3>
        <form method="POST" action="performance.php?tab=configuration">
            <div class="space-y-3">
                <div>
                    <label class="block text-sm font-medium text-gray-700">Criteria Name</label>
                    <input type="text" name="criteria_name" class="mt-1 block w-full border rounded p-2" required>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Description</label>
                    <textarea name="criteria_desc" class="mt-1 block w-full border rounded p-2"></textarea>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Weight (%)</label>
                    <input type="number" name="weight" min="0" max="100" class="mt-1 block w-full border rounded p-2">
                </div>
            </div>
            <div class="mt-4 flex justify-end space-x-2">
                <button type="button" onclick="hideModal('addCriteriaModal')" class="px-4 py-2 bg-gray-200 rounded">Cancel</button>
                <button type="submit" name="add_criteria" class="px-4 py-2 bg-blue-600 text-white rounded">Add</button>
            </div>
        </form>
    </div>
</div>

<!-- Add Template Modal -->
<div id="addTemplateModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden items-center justify-center z-50">
    <div class="bg-white rounded-lg p-6 w-96">
        <h3 class="text-lg font-medium mb-4">Add Evaluation Template</h3>
        <form method="POST" action="performance.php?tab=configuration">
            <div class="space-y-3">
                <div>
                    <label class="block text-sm font-medium text-gray-700">Template Name</label>
                    <input type="text" name="template_name" class="mt-1 block w-full border rounded p-2" required>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Description</label>
                    <textarea name="template_desc" class="mt-1 block w-full border rounded p-2"></textarea>
                </div>
            </div>
            <div class="mt-4 flex justify-end space-x-2">
                <button type="button" onclick="hideModal('addTemplateModal')" class="px-4 py-2 bg-gray-200 rounded">Cancel</button>
                <button type="submit" name="add_template" class="px-4 py-2 bg-blue-600 text-white rounded">Add</button>
            </div>
        </form>
    </div>
</div>

<script>
// Functions to show/hide modals
function showModal(modalId) {
    document.getElementById(modalId).classList.remove('hidden');
    document.getElementById(modalId).classList.add('flex');
}

function hideModal(modalId) {
    document.getElementById(modalId).classList.add('hidden');
    document.getElementById(modalId).classList.remove('flex');
}

function showAddGoalModal() { showModal('addGoalModal'); }
function showMarkAttendanceModal() { showModal('markAttendanceModal'); }
function showScheduleAppraisalModal() { showModal('scheduleAppraisalModal'); }
function showAddCriteriaModal() { showModal('addCriteriaModal'); }
function showAddTemplateModal() { showModal('addTemplateModal'); }

// Main dashboard JavaScript
function switchTab(tabName) {
  const url = new URL(window.location);
  url.searchParams.set('tab', tabName);
  window.history.pushState({}, '', url);
  
  document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
  document.getElementById(`${tabName}-tab`)?.classList.add('active');
  
  document.querySelectorAll('.tab-button').forEach(btn => {
    btn.classList.remove('border-blue-500', 'text-blue-600');
    btn.classList.add('border-transparent', 'text-gray-500');
  });
  const activeBtn = document.querySelector(`.tab-button[data-tab="${tabName}"]`);
  if (activeBtn) {
    activeBtn.classList.remove('border-transparent', 'text-gray-500');
    activeBtn.classList.add('border-blue-500', 'text-blue-600');
  }
  setTimeout(() => initializeCharts(), 100);
}

function initializeCharts() {
  const activeTab = document.querySelector('.tab-content.active');
  if (!activeTab) return;
  if (activeTab.id === 'overview-tab') {
    initializeOverviewCharts();
  } else if (activeTab.id === 'attendance-tab') {
    initializeAttendanceCharts();
  } else if (activeTab.id === 'goals-tab') {
    initializeGoalsCharts();
  } else if (activeTab.id === 'evaluations-tab') {
    initializeEvaluationCharts();
  }
}

function initializeOverviewCharts() {
  const ctx1 = document.getElementById('performanceDistributionChart');
  if (ctx1) {
    new Chart(ctx1.getContext('2d'), {
      type: 'doughnut',
      data: {
        labels: ['Exceeds Expectations', 'Meets Expectations', 'Needs Improvement', 'Below Expectations'],
        datasets: [{
          data: [25, 50, 15, 10],
          backgroundColor: ['#10b981', '#3b82f6', '#f59e0b', '#ef4444'],
          borderWidth: 1
        }]
      },
      options: { responsive: true, plugins: { legend: { position: 'bottom' } } }
    });
  }
  
  const ctx2 = document.getElementById('performanceTrendChart');
  if (ctx2) {
    new Chart(ctx2.getContext('2d'), {
      type: 'line',
      data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
          label: 'Average Performance',
          data: [3.8, 4.0, 4.2, 4.1, 4.3, 4.4],
          borderColor: '#3b82f6',
          backgroundColor: 'rgba(59, 130, 246, 0.1)',
          fill: true,
          tension: 0.4
        }]
      },
      options: {
        responsive: true,
        scales: { y: { beginAtZero: false, min: 3, max: 5, ticks: { stepSize: 0.5 } } }
      }
    });
  }
}

function initializeAttendanceCharts() {
  const ctx = document.getElementById('attendanceTrendChart');
  if (ctx) {
    new Chart(ctx.getContext('2d'), {
      type: 'bar',
      data: {
        labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
        datasets: [{
          label: 'Attendance Rate (%)',
          data: [95, 92, 98, 96],
          backgroundColor: '#3b82f6',
          borderColor: '#2563eb',
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        scales: { y: { beginAtZero: true, max: 100, ticks: { callback: v => v + '%' } } }
      }
    });
  }
}

function initializeGoalsCharts() {
  const ctx = document.getElementById('goalsChart');
  if (ctx) {
    new Chart(ctx.getContext('2d'), {
      type: 'bar',
      data: {
        labels: ['Sales', 'Training', 'Customer Satisfaction', 'Efficiency'],
        datasets: [{
          label: 'Progress (%)',
          data: [65, 100, 80, 45],
          backgroundColor: '#3b82f6'
        }]
      },
      options: { responsive: true }
    });
  }
}

function initializeEvaluationCharts() {
  const ctx = document.getElementById('evaluationChart');
  if (ctx) {
    new Chart(ctx.getContext('2d'), {
      type: 'radar',
      data: {
        labels: ['Quality', 'Productivity', 'Teamwork', 'Communication', 'Initiative'],
        datasets: [{
          label: 'Average Ratings',
          data: [4.2, 3.8, 4.5, 4.0, 3.9],
          backgroundColor: 'rgba(59, 130, 246, 0.2)',
          borderColor: '#3b82f6'
        }]
      },
      options: { responsive: true }
    });
  }
}

function showQuickActionModal() {
  const modalHTML = `
    <div class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
      <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
          <h3 class="text-lg font-medium text-gray-900 mb-4">Quick Actions</h3>
          <div class="space-y-3">
            <a href="#" onclick="showMarkAttendanceModal(); return false;" class="block p-3 border rounded-lg hover:bg-gray-50">
              <div class="flex items-center">
                <i data-lucide="calendar-check" class="w-5 h-5 text-blue-600 mr-3"></i>
                <div>
                  <h4 class="font-medium">Mark Attendance</h4>
                  <p class="text-sm text-gray-600">Record attendance for today</p>
                </div>
              </div>
            </a>
            <a href="#" onclick="showAddGoalModal(); return false;" class="block p-3 border rounded-lg hover:bg-gray-50">
              <div class="flex items-center">
                <i data-lucide="target" class="w-5 h-5 text-green-600 mr-3"></i>
                <div>
                  <h4 class="font-medium">Add Performance Goal</h4>
                  <p class="text-sm text-gray-600">Set new performance objective</p>
                </div>
              </div>
            </a>
            <a href="#" onclick="showScheduleAppraisalModal(); return false;" class="block p-3 border rounded-lg hover:bg-gray-50">
              <div class="flex items-center">
                <i data-lucide="clipboard-list" class="w-5 h-5 text-purple-600 mr-3"></i>
                <div>
                  <h4 class="font-medium">Schedule Appraisal</h4>
                  <p class="text-sm text-gray-600">Schedule performance review</p>
                </div>
              </div>
            </a>
          </div>
          <div class="mt-4">
            <button onclick="closeModal()" class="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 w-full">
              Cancel
            </button>
          </div>
        </div>
      </div>
    </div>
  `;
  const modalContainer = document.createElement('div');
  modalContainer.id = 'quickActionModal';
  modalContainer.innerHTML = modalHTML;
  document.body.appendChild(modalContainer);
  setTimeout(() => lucide.createIcons(), 100);
}

function closeModal() {
  const modal = document.getElementById('quickActionModal');
  if (modal) modal.remove();
}

function updateDashboardData(period) {
  const activeTab = document.querySelector('.tab-content.active');
  activeTab.innerHTML = `
    <div class="flex items-center justify-center h-64">
      <div class="text-center">
        <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
        <p class="mt-2 text-gray-600">Loading data for ${period} period...</p>
      </div>
    </div>
  `;
  setTimeout(() => window.location.reload(), 1000);
}

// Initialize everything when DOM is ready
document.addEventListener("DOMContentLoaded", () => {
  lucide.createIcons();
  
  // Attach click handlers to all tab buttons
  document.querySelectorAll('.tab-button').forEach(btn => {
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      switchTab(this.dataset.tab);
    });
  });
  
  // Set the active tab based on URL (in case of direct link)
  const urlParams = new URLSearchParams(window.location.search);
  const activeTab = urlParams.get('tab') || 'overview';
  switchTab(activeTab);
  
  // Initialize charts
  initializeCharts();
  
  // Quick action button
  document.getElementById('quickActionBtn')?.addEventListener('click', showQuickActionModal);
  
  // Period filter change
  document.getElementById('periodFilter')?.addEventListener('change', function(e) {
    updateDashboardData(e.target.value);
  });
});
</script>
</body>
</html>