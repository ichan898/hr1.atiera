<?php
// File: screen_applicant.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

// Check if ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: applicants.php');
    exit();
}

$applicant_id = $_GET['id'];

// Fetch applicant details with job requirements
$query = "SELECT a.*, j.job_title, j.department, j.requirements, j.experience_level 
          FROM applicants a 
          LEFT JOIN job_postings j ON a.job_id = j.id 
          WHERE a.id = ?";
$stmt = $connections->prepare($query);
$stmt->execute([$applicant_id]);
$applicant = $stmt->fetch();

if (!$applicant) {
    header('Location: applicants.php');
    exit();
}

// Fetch HR user ID (assuming it's stored in session)
$hr_user_id = $_SESSION['hr_user_id'] ?? 1; // Default to admin if not set

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $screening_result = $_POST['screening_result'] ?? '';
    $education_score = (int)($_POST['education_score'] ?? 0);
    $experience_score = (int)($_POST['experience_score'] ?? 0);
    $skills_score = (int)($_POST['skills_score'] ?? 0);
    $notes = $_POST['notes'] ?? '';
    $next_steps = isset($_POST['next_steps']) ? implode(', ', $_POST['next_steps']) : '';
    
    // Calculate total qualification score (out of 100)
    $qualification_score = 0;
    $edu_percent = $exp_percent = $skills_percent = 0;
    
    if ($education_score && $experience_score && $skills_score) {
        $edu_percent = ($education_score / 5) * 33.33;
        $exp_percent = ($experience_score / 5) * 33.33;
        $skills_percent = ($skills_score / 5) * 34.34; // Makes total 100 exactly
        $qualification_score = round($edu_percent + $exp_percent + $skills_percent);
    }
    
    try {
        // Start transaction
        $connections->beginTransaction();
        
        // Determine if applicant is qualified (threshold 70)
        $is_qualified = $qualification_score >= 70 ? 1 : 0;
        $new_status = $is_qualified ? 'shortlisted' : 'reviewed';
        
        // --- Store breakdown in qualifications JSON column ---
        // Fetch existing qualifications JSON (if any)
        $existing_qualifications = [];
        if (!empty($applicant['qualifications'])) {
            $existing_qualifications = json_decode($applicant['qualifications'], true);
            if (!is_array($existing_qualifications)) $existing_qualifications = [];
        }
        
        // Add breakdown scores
        $existing_qualifications['score_breakdown'] = [
            'education_score' => $education_score,
            'experience_score' => $experience_score,
            'skills_score' => $skills_score,
            'education_percent' => round($edu_percent, 2),
            'experience_percent' => round($exp_percent, 2),
            'skills_percent' => round($skills_percent, 2),
            'total' => $qualification_score
        ];
        
        $new_qualifications_json = json_encode($existing_qualifications);
        
        // Update applicant with qualification score, status, and JSON breakdown
        $update_query = "UPDATE applicants 
                        SET qualification_score = ?, 
                            is_qualified = ?,
                            application_status = ?,
                            qualifications = ?,
                            notes = COALESCE(CONCAT(notes, '\n', ?), ?),
                            updated_at = NOW()
                        WHERE id = ?";
        
        $update_stmt = $connections->prepare($update_query);
        $update_stmt->execute([
            $qualification_score,
            $is_qualified,
            $new_status,
            $new_qualifications_json,
            $notes,
            $notes,
            $applicant_id
        ]);
        
        // Create activity log entry
        $activity_query = "INSERT INTO activity_logs 
                          (user_id, action, details, description, table_name, record_id, ip_address, user_agent, created_at) 
                          VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())";
        
        $activity_details = json_encode([
            'applicant_id' => $applicant_id,
            'qualification_score' => $qualification_score,
            'is_qualified' => $is_qualified,
            'screening_result' => $screening_result,
            'education_score' => $education_score,
            'experience_score' => $experience_score,
            'skills_score' => $skills_score
        ]);
        
        $activity_desc = "Screened applicant: {$applicant['first_name']} {$applicant['last_name']} - " . 
                        ($is_qualified ? 'Qualified' : 'Not Qualified') . " ($qualification_score/100)";
        
        $activity_stmt = $connections->prepare($activity_query);
        $activity_stmt->execute([
            $hr_user_id,
            'applicant_screened',
            $activity_details,
            $activity_desc,
            'applicants',
            $applicant_id,
            $_SERVER['REMOTE_ADDR'] ?? 'Unknown',
            $_SERVER['HTTP_USER_AGENT'] ?? 'HR System'
        ]);
        
        // If qualified, optionally call auto-scheduling procedure
        if ($is_qualified) {
            $proc_query = "CALL ProcessApplicantQualification(?, ?, ?, ?)";
            $proc_stmt = $connections->prepare($proc_query);
            $proc_stmt->execute([
                $applicant_id,
                $is_qualified,
                $qualification_score,
                $hr_user_id
            ]);
        }
        
        $connections->commit();
        
        // Redirect to applicant view
        header("Location: view_applicant.php?id=$applicant_id&success=1");
        exit();
        
    } catch (PDOException $e) {
        $connections->rollBack();
        $error = "Error saving screening results: " . $e->getMessage();
    }
}

// Fetch existing screening data if any
$existing_scores_query = "SELECT qualification_score, is_qualified, notes, qualifications 
                         FROM applicants 
                         WHERE id = ?";
$existing_stmt = $connections->prepare($existing_scores_query);
$existing_stmt->execute([$applicant_id]);
$existing_data = $existing_stmt->fetch();

// Pre-fill sliders if breakdown exists in qualifications
$default_edu = 3;
$default_exp = 3;
$default_skills = 3;
if (!empty($existing_data['qualifications'])) {
    $qual_data = json_decode($existing_data['qualifications'], true);
    if (isset($qual_data['score_breakdown'])) {
        $default_edu = $qual_data['score_breakdown']['education_score'] ?? 3;
        $default_exp = $qual_data['score_breakdown']['experience_score'] ?? 3;
        $default_skills = $qual_data['score_breakdown']['skills_score'] ?? 3;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>HR1 - Screen Applicant</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<style>
.score-slider {
    -webkit-appearance: none;
    width: 100%;
    height: 8px;
    border-radius: 4px;
    background: #e5e7eb;
    outline: none;
}
.score-slider::-webkit-slider-thumb {
    -webkit-appearance: none;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    background: #3b82f6;
    cursor: pointer;
}
</style>
</head>

<body class="h-screen bg-gray-100 font-sans">
<div class="flex h-full">
  
  <!-- Sidebar -->
  <?php include 'sidebar.php'; ?>
  
  <!-- Main Content -->
  <div class="flex-1 flex flex-col overflow-y-auto">
    <main class="p-6 space-y-6">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-gray-300 pb-4">
        <div class="flex items-center space-x-4">
          <a href="view_applicant.php?id=<?php echo $applicant_id; ?>" class="text-blue-600 hover:text-blue-800">
            <i data-lucide="arrow-left" class="w-5 h-5"></i>
          </a>
          <div>
            <h2 class="text-2xl font-bold text-gray-800">Screen & Qualify Applicant</h2>
            <p class="text-sm text-gray-600">Evaluate applicant qualifications and set qualification score</p>
          </div>
        </div>
        <div class="flex items-center space-x-4">
          <?php include 'profile_dropdown.php'; ?>
        </div>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Applicant Information -->
        <div class="lg:col-span-1">
          <div class="bg-white rounded-lg shadow p-6">
            <div class="flex items-center space-x-4 mb-6">
              <div class="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center">
                <i data-lucide="user" class="w-6 h-6 text-gray-600"></i>
              </div>
              <div>
                <h3 class="font-bold text-gray-800">
                  <?php echo htmlspecialchars($applicant['first_name'] . ' ' . $applicant['last_name']); ?>
                </h3>
                <p class="text-sm text-gray-600"><?php echo htmlspecialchars($applicant['email']); ?></p>
              </div>
            </div>
            
            <div class="space-y-4">
              <div>
                <label class="text-sm text-gray-500">Applied Position</label>
                <p class="font-medium"><?php echo htmlspecialchars($applicant['job_title']); ?></p>
              </div>
              <div>
                <label class="text-sm text-gray-500">Department</label>
                <p class="font-medium"><?php echo htmlspecialchars($applicant['department']); ?></p>
              </div>
              <div>
                <label class="text-sm text-gray-500">Experience Level Required</label>
                <p class="font-medium"><?php echo htmlspecialchars($applicant['experience_level'] ?? 'Not specified'); ?></p>
              </div>
              <div>
                <label class="text-sm text-gray-500">Years of Experience</label>
                <p class="font-medium"><?php echo htmlspecialchars($applicant['experience_years'] ?? '0'); ?> years</p>
              </div>
              <div>
                <label class="text-sm text-gray-500">Current Qualification Status</label>
                <?php 
                $qual_score = $existing_data['qualification_score'] ?? 0;
                $is_qualified = $existing_data['is_qualified'] ?? 0;
                
                if ($qual_score > 0) {
                    if ($is_qualified == 1) {
                        $badge_class = 'bg-green-100 text-green-800';
                        $badge_text = 'Qualified (' . $qual_score . '/100)';
                    } else {
                        $badge_class = 'bg-red-100 text-red-800';
                        $badge_text = 'Not Qualified (' . $qual_score . '/100)';
                    }
                } else {
                    $badge_class = 'bg-gray-100 text-gray-800';
                    $badge_text = 'Not Scored';
                }
                ?>
                <span class="px-2 py-1 text-xs rounded <?php echo $badge_class; ?>">
                  <?php echo $badge_text; ?>
                </span>
              </div>
            </div>
            
            <?php if ($applicant['resume_path']): ?>
            <div class="mt-6 pt-6 border-t border-gray-200">
              <a href="<?php echo htmlspecialchars($applicant['resume_path']); ?>" 
                 target="_blank"
                 class="flex items-center justify-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                <i data-lucide="file-text" class="w-4 h-4"></i>
                <span>View Resume</span>
              </a>
            </div>
            <?php endif; ?>
            
            <!-- View Qualifications JSON data if available -->
            <?php 
            if (!empty($applicant['qualifications'])) {
                $qualifications = json_decode($applicant['qualifications'], true);
                if ($qualifications && is_array($qualifications) && !isset($qualifications['score_breakdown'])): 
            ?>
            <div class="mt-6 pt-6 border-t border-gray-200">
              <h4 class="font-medium text-gray-700 mb-2">Applicant's Qualifications</h4>
              <ul class="text-sm text-gray-600 space-y-1">
                <?php if (!empty($qualifications['education'])): ?>
                <li><strong>Education:</strong> <?php echo htmlspecialchars($qualifications['education']); ?></li>
                <?php endif; ?>
                <?php if (!empty($qualifications['skills']) && is_array($qualifications['skills'])): ?>
                <li><strong>Skills:</strong> <?php echo htmlspecialchars(implode(', ', $qualifications['skills'])); ?></li>
                <?php endif; ?>
                <?php if (!empty($qualifications['certifications']) && is_array($qualifications['certifications'])): ?>
                <li><strong>Certifications:</strong> <?php echo htmlspecialchars(implode(', ', $qualifications['certifications'])); ?></li>
                <?php endif; ?>
              </ul>
            </div>
            <?php endif; } ?>
          </div>
          
          <!-- Job Requirements -->
          <div class="bg-white rounded-lg shadow p-6 mt-6">
            <h3 class="font-semibold text-gray-800 mb-4">Job Requirements</h3>
            <div class="text-sm text-gray-700">
              <?php echo nl2br(htmlspecialchars($applicant['requirements'] ?? 'No specific requirements listed.')); ?>
            </div>
          </div>
          
          <!-- Qualification Guidelines -->
          <div class="bg-blue-50 border border-blue-200 rounded-lg shadow p-6 mt-6">
            <h3 class="font-semibold text-blue-800 mb-3">Qualification Guidelines</h3>
            <ul class="space-y-2 text-sm text-blue-700">
              <li class="flex items-start">
                <i data-lucide="check-circle" class="w-4 h-4 mr-2 mt-0.5 text-green-500 flex-shrink-0"></i>
                <span><strong>70+ points</strong>: Qualified (auto-shortlisted)</span>
              </li>
              <li class="flex items-start">
                <i data-lucide="x-circle" class="w-4 h-4 mr-2 mt-0.5 text-red-500 flex-shrink-0"></i>
                <span><strong>Below 70 points</strong>: Not Qualified (needs review)</span>
              </li>
              <li class="flex items-start">
                <i data-lucide="info" class="w-4 h-4 mr-2 mt-0.5 text-blue-500 flex-shrink-0"></i>
                <span>Qualified applicants may be auto-scheduled for interviews</span>
              </li>
            </ul>
          </div>
        </div>

        <!-- Screening Form -->
        <div class="lg:col-span-2">
          <div class="bg-white rounded-lg shadow">
            <div class="p-6 border-b border-gray-200">
              <h3 class="text-lg font-semibold text-gray-800">Qualification Assessment</h3>
              <p class="text-sm text-gray-600 mt-1">Score each category (1-5) to calculate qualification score</p>
            </div>
            
            <form method="POST" action="" class="p-6 space-y-6">
              <?php if (isset($error)): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
                  <?php echo htmlspecialchars($error); ?>
                </div>
              <?php endif; ?>
              
              <?php if (isset($_GET['success'])): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded">
                  Qualification assessment saved successfully!
                </div>
              <?php endif; ?>
              
              <!-- Education Match -->
              <div>
                <div class="flex justify-between items-center mb-2">
                  <label class="block text-sm font-medium text-gray-700">Education Match</label>
                  <span id="educationValue" class="text-sm font-semibold text-blue-600"><?php echo $default_edu; ?></span>
                </div>
                <input type="range" name="education_score" min="1" max="5" value="<?php echo $default_edu; ?>" step="1" 
                       class="score-slider" id="educationSlider">
                <div class="flex justify-between text-xs text-gray-500 mt-1">
                  <span>1 - No match</span>
                  <span>2 - Poor match</span>
                  <span>3 - Adequate</span>
                  <span>4 - Good match</span>
                  <span>5 - Excellent</span>
                </div>
              </div>
              
              <!-- Experience Level -->
              <div>
                <div class="flex justify-between items-center mb-2">
                  <label class="block text-sm font-medium text-gray-700">Experience Level</label>
                  <span id="experienceValue" class="text-sm font-semibold text-blue-600"><?php echo $default_exp; ?></span>
                </div>
                <input type="range" name="experience_score" min="1" max="5" value="<?php echo $default_exp; ?>" step="1" 
                       class="score-slider" id="experienceSlider">
                <div class="flex justify-between text-xs text-gray-500 mt-1">
                  <span>1 - No experience</span>
                  <span>2 - Below required</span>
                  <span>3 - Nearly meets</span>
                  <span>4 - Meets required</span>
                  <span>5 - Exceeds required</span>
                </div>
              </div>
              
              <!-- Skills Match -->
              <div>
                <div class="flex justify-between items-center mb-2">
                  <label class="block text-sm font-medium text-gray-700">Skills Match</label>
                  <span id="skillsValue" class="text-sm font-semibold text-blue-600"><?php echo $default_skills; ?></span>
                </div>
                <input type="range" name="skills_score" min="1" max="5" value="<?php echo $default_skills; ?>" step="1" 
                       class="score-slider" id="skillsSlider">
                <div class="flex justify-between text-xs text-gray-500 mt-1">
                  <span>1 - No skills</span>
                  <span>2 - Few skills</span>
                  <span>3 - Some skills</span>
                  <span>4 - Most skills</span>
                  <span>5 - All skills</span>
                </div>
              </div>
              
              <!-- Total Score Preview -->
              <div class="bg-gray-50 p-4 rounded-lg border">
                <div class="flex justify-between items-center">
                  <div>
                    <p class="text-sm font-medium text-gray-700">Estimated Qualification Score</p>
                    <p class="text-xs text-gray-500">Based on current selections</p>
                  </div>
                  <div class="text-right">
                    <p id="totalScore" class="text-2xl font-bold text-blue-600">0</p>
                    <p id="qualificationStatus" class="text-sm font-medium text-red-600">Not Qualified</p>
                  </div>
                </div>
                <div class="mt-3">
                  <div class="w-full bg-gray-200 rounded-full h-2">
                    <div id="scoreBar" class="bg-blue-600 h-2 rounded-full" style="width: 0%"></div>
                  </div>
                  <div class="flex justify-between text-xs text-gray-500 mt-1">
                    <span>0</span>
                    <span class="text-red-600 font-medium">70 (Qualified)</span>
                    <span>100</span>
                  </div>
                </div>
              </div>
              
              <!-- Assessment Result -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Assessment Result</label>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <label class="flex items-center space-x-3 p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
                    <input type="radio" name="screening_result" value="passed" class="text-green-600" required>
                    <div>
                      <div class="font-medium text-green-700">Qualified</div>
                      <div class="text-sm text-gray-600">Score ≥ 70, ready for interview</div>
                    </div>
                  </label>
                  
                  <label class="flex items-center space-x-3 p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
                    <input type="radio" name="screening_result" value="conditional" class="text-yellow-600">
                    <div>
                      <div class="font-medium text-yellow-700">Conditional</div>
                      <div class="text-sm text-gray-600">Needs further review</div>
                    </div>
                  </label>
                  
                  <label class="flex items-center space-x-3 p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
                    <input type="radio" name="screening_result" value="failed" class="text-red-600">
                    <div>
                      <div class="font-medium text-red-700">Not Qualified</div>
                      <div class="text-sm text-gray-600">Score &lt; 70, does not meet requirements</div>
                    </div>
                  </label>
                </div>
              </div>
              
              <!-- Notes -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Assessment Notes</label>
                <textarea name="notes" rows="4" class="w-full px-3 py-2 border border-gray-300 rounded-lg" 
                          placeholder="Detailed evaluation notes, strengths, weaknesses, specific qualifications..."><?php echo htmlspecialchars($existing_data['notes'] ?? ''); ?></textarea>
                <p class="text-sm text-gray-500 mt-1">Include specific reasons for qualification decision.</p>
              </div>
              
              <!-- Next Steps -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Recommended Actions</label>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-2">
                  <label class="flex items-center space-x-2 p-3 border rounded-lg hover:bg-gray-50">
                    <input type="checkbox" name="next_steps[]" value="schedule_interview" class="rounded text-blue-600">
                    <span class="text-sm">Schedule interview</span>
                  </label>
                  <label class="flex items-center space-x-2 p-3 border rounded-lg hover:bg-gray-50">
                    <input type="checkbox" name="next_steps[]" value="technical_test" class="rounded text-blue-600">
                    <span class="text-sm">Send technical test</span>
                  </label>
                  <label class="flex items-center space-x-2 p-3 border rounded-lg hover:bg-gray-50">
                    <input type="checkbox" name="next_steps[]" value="reference_check" class="rounded text-blue-600">
                    <span class="text-sm">Check references</span>
                  </label>
                  <label class="flex items-center space-x-2 p-3 border rounded-lg hover:bg-gray-50">
                    <input type="checkbox" name="next_steps[]" value="request_portfolio" class="rounded text-blue-600">
                    <span class="text-sm">Request portfolio</span>
                  </label>
                </div>
              </div>
              
              <!-- Form Actions -->
              <div class="flex space-x-3 pt-4">
                <a href="view_applicant.php?id=<?php echo $applicant_id; ?>" 
                   class="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50">
                  Cancel
                </a>
                <button type="submit" name="action" value="save" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                  Save Qualification
                </button>
                <button type="submit" name="action" value="save_and_schedule" class="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">
                  Save & Auto-Schedule
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </main>
  </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
  lucide.createIcons();
  
  // Get slider elements
  const educationSlider = document.getElementById('educationSlider');
  const experienceSlider = document.getElementById('experienceSlider');
  const skillsSlider = document.getElementById('skillsSlider');
  
  const educationValue = document.getElementById('educationValue');
  const experienceValue = document.getElementById('experienceValue');
  const skillsValue = document.getElementById('skillsValue');
  
  const totalScoreElement = document.getElementById('totalScore');
  const scoreBar = document.getElementById('scoreBar');
  const qualificationStatus = document.getElementById('qualificationStatus');
  
  // Function to calculate total score
  function calculateTotalScore() {
    const edu = parseInt(educationSlider.value);
    const exp = parseInt(experienceSlider.value);
    const skills = parseInt(skillsSlider.value);
    
    const eduPercent = (edu / 5) * 33.33;
    const expPercent = (exp / 5) * 33.33;
    const skillsPercent = (skills / 5) * 34.34;
    
    const total = Math.round(eduPercent + expPercent + skillsPercent);
    
    totalScoreElement.textContent = total;
    scoreBar.style.width = total + '%';
    
    if (total >= 70) {
      qualificationStatus.textContent = 'Qualified';
      qualificationStatus.className = 'text-sm font-medium text-green-600';
      scoreBar.className = 'bg-green-600 h-2 rounded-full';
    } else {
      qualificationStatus.textContent = 'Not Qualified';
      qualificationStatus.className = 'text-sm font-medium text-red-600';
      scoreBar.className = 'bg-blue-600 h-2 rounded-full';
    }
    
    const radios = document.getElementsByName('screening_result');
    if (total >= 70) {
      radios[0].checked = true;
    } else {
      radios[2].checked = true;
    }
  }
  
  educationSlider.addEventListener('input', function() {
    educationValue.textContent = this.value;
    calculateTotalScore();
  });
  
  experienceSlider.addEventListener('input', function() {
    experienceValue.textContent = this.value;
    calculateTotalScore();
  });
  
  skillsSlider.addEventListener('input', function() {
    skillsValue.textContent = this.value;
    calculateTotalScore();
  });
  
  calculateTotalScore();
  
  const screeningRadios = document.getElementsByName('screening_result');
  const interviewCheckbox = document.querySelector('input[value="schedule_interview"]');
  screeningRadios.forEach(radio => {
    radio.addEventListener('change', function() {
      if (this.value === 'passed') {
        interviewCheckbox.checked = true;
      }
    });
  });
});
</script>
</body>
</html>