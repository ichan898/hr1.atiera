<?php
require_once 'connections.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer(true);
try {
    $mail->SMTPDebug = 2;  // Enable verbose debug output
    $mail->Debugoutput = 'html';
    $mail->isSMTP();
    $mail->Host       = SMTP_HOST;
    $mail->SMTPAuth   = true;
    $mail->Username   = SMTP_USERNAME;
    $mail->Password   = SMTP_PASSWORD;
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;  // Try TLS on port 587
    $mail->Port       = 587;
    
    $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
    $mail->addAddress('vergarajamesryan47@gmail.com');
    $mail->isHTML(true);
    $mail->Subject = 'SMTP Debug Test';
    $mail->Body    = 'This is a test email with debug output.';
    
    $mail->send();
    echo "✅ Email sent successfully!";
} catch (Exception $e) {
    echo "❌ Failed: " . $mail->ErrorInfo;
}
?>