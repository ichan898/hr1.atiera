<?php
// File: recognition_settings.php - Configuration for Recognition & Milestones
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

// Only admin and HR managers can access settings
if (!in_array($_SESSION['user_role'], ['admin', 'hr_manager'])) {
    $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'You do not have permission to access settings.'];
    header('Location: recognition.php');
    exit;
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add_milestone':
                $result = createMilestone($_POST, $connections);
                if ($result['success']) {
                    $_SESSION['flash_message'] = ['type' => 'success', 'message' => 'Milestone added successfully.'];
                } else {
                    $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Failed to add milestone: ' . ($result['error'] ?? 'Unknown error')];
                }
                break;
            case 'edit_milestone':
                $result = updateMilestone($_POST['id'], $_POST, $connections);
                if ($result['success']) {
                    $_SESSION['flash_message'] = ['type' => 'success', 'message' => 'Milestone updated successfully.'];
                } else {
                    $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Failed to update milestone.'];
                }
                break;
            case 'delete_milestone':
                $result = deleteMilestone($_POST['id'], $connections);
                if ($result['success']) {
                    $_SESSION['flash_message'] = ['type' => 'success', 'message' => 'Milestone deleted.'];
                } else {
                    $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Failed to delete milestone.'];
                }
                break;
            case 'add_criteria':
                $result = createAwardCriterion($_POST, $connections);
                if ($result['success']) {
                    $_SESSION['flash_message'] = ['type' => 'success', 'message' => 'Award criterion added.'];
                } else {
                    $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Failed to add award criterion.'];
                }
                break;
            case 'edit_criteria':
                $result = updateAwardCriterion($_POST['id'], $_POST, $connections);
                if ($result['success']) {
                    $_SESSION['flash_message'] = ['type' => 'success', 'message' => 'Award criterion updated.'];
                } else {
                    $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Failed to update award criterion.'];
                }
                break;
            case 'delete_criteria':
                $result = deleteAwardCriterion($_POST['id'], $connections);
                if ($result['success']) {
                    $_SESSION['flash_message'] = ['type' => 'success', 'message' => 'Award criterion deleted.'];
                } else {
                    $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Failed to delete award criterion.'];
                }
                break;
        }
        header('Location: recognition_settings.php');
        exit;
    }
}

// Get data for display
$milestones = function_exists('getMilestones') ? getMilestones($connections) : [];
$award_criteria = function_exists('getAwardCriteria') ? getAwardCriteria($connections) : [];

// Helper for milestone types
$milestone_types = [
    'count' => 'Recognition Count',
    'points' => 'Total Points'
];

// Helper for award types
$award_types = [
    'recognition'   => 'Recognition',
    'excellence'    => 'Excellence',
    'innovation'    => 'Innovation',
    'teamwork'      => 'Teamwork',
    'leadership'    => 'Leadership',
    'service'       => 'Service'
];

// Frequency options
$frequencies = [
    'daily'     => 'Daily',
    'weekly'    => 'Weekly',
    'monthly'   => 'Monthly',
    'quarterly' => 'Quarterly',
    'yearly'    => 'Yearly',
    'as_needed' => 'As Needed'
];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>HR1 - Recognition Settings</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="h-screen bg-gray-100 font-sans">
<div class="flex h-full">
    <?php include 'sidebar.php'; ?>
    <div class="flex-1 flex flex-col overflow-y-auto">
        <main class="p-6">
            <!-- Header -->
            <div class="flex items-center justify-between border-b border-gray-300 pb-4 mb-6">
                <div>
                    <h2 class="text-2xl font-bold text-gray-800">Recognition Settings</h2>
                    <p class="text-sm text-gray-600">Configure milestones, awards, and recognition criteria</p>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="recognition.php" class="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                        <i data-lucide="arrow-left" class="w-4 h-4"></i>
                        <span>Back to Dashboard</span>
                    </a>
                    <?php include 'profile_dropdown.php'; ?>
                </div>
            </div>

            <!-- Flash Messages -->
            <?php if (isset($_SESSION['flash_message'])): ?>
                <div class="mb-6 p-4 bg-<?php echo $_SESSION['flash_message']['type'] == 'success' ? 'green' : 'red'; ?>-50 border border-<?php echo $_SESSION['flash_message']['type'] == 'success' ? 'green' : 'red'; ?>-400 text-<?php echo $_SESSION['flash_message']['type'] == 'success' ? 'green' : 'red'; ?>-700 rounded-lg">
                    <div class="flex items-center">
                        <i data-lucide="<?php echo $_SESSION['flash_message']['type'] == 'success' ? 'check-circle' : 'alert-circle'; ?>" class="w-5 h-5 mr-2"></i>
                        <span><?php echo $_SESSION['flash_message']['message']; ?></span>
                    </div>
                </div>
                <?php unset($_SESSION['flash_message']); ?>
            <?php endif; ?>

            <!-- Tabs -->
            <div class="bg-white rounded-lg shadow mb-6">
                <div class="border-b">
                    <nav class="flex -mb-px">
                        <a href="#milestones" class="tab-link py-4 px-6 border-b-2 border-blue-500 text-blue-600 font-medium text-sm" data-tab="milestones">Milestones</a>
                        <a href="#award-criteria" class="tab-link py-4 px-6 border-b-2 border-transparent text-gray-500 hover:text-gray-700 font-medium text-sm" data-tab="award-criteria">Award Criteria</a>
                        <a href="#categories" class="tab-link py-4 px-6 border-b-2 border-transparent text-gray-500 hover:text-gray-700 font-medium text-sm" data-tab="categories">Categories</a>
                        <a href="#recognition-types" class="tab-link py-4 px-6 border-b-2 border-transparent text-gray-500 hover:text-gray-700 font-medium text-sm" data-tab="recognition-types">Recognition Types</a>
                    </nav>
                </div>

                <!-- Milestones Tab -->
                <div id="milestones" class="tab-content p-6">
                    <div class="flex justify-between items-center mb-4">
                        <h3 class="text-lg font-semibold">Milestones</h3>
                        <button onclick="openMilestoneModal()" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center">
                            <i data-lucide="plus" class="w-4 h-4 mr-2"></i> Add Milestone
                        </button>
                    </div>

                    <?php if (empty($milestones)): ?>
                        <p class="text-gray-500 text-center py-8">No milestones configured yet.</p>
                    <?php else: ?>
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Threshold</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Badge</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Points Awarded</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    <?php foreach ($milestones as $m): ?>
                                    <tr>
                                        <td class="px-6 py-4"><?php echo htmlspecialchars($m['name']); ?></td>
                                        <td class="px-6 py-4"><?php echo $milestone_types[$m['type']] ?? $m['type']; ?></td>
                                        <td class="px-6 py-4"><?php echo $m['threshold']; ?></td>
                                        <td class="px-6 py-4">
                                            <?php if (!empty($m['badge_name'])): ?>
                                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                                                    <?php echo htmlspecialchars($m['badge_name']); ?>
                                                </span>
                                            <?php else: ?>
                                                <span class="text-gray-400">—</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-6 py-4"><?php echo $m['points_awarded']; ?></td>
                                        <td class="px-6 py-4">
                                            <?php if ($m['is_active']): ?>
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">Active</span>
                                            <?php else: ?>
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">Inactive</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-6 py-4">
                                            <div class="flex space-x-2">
                                                <button onclick="editMilestone(<?php echo htmlspecialchars(json_encode($m)); ?>)" class="text-blue-600 hover:text-blue-800">
                                                    <i data-lucide="edit" class="w-4 h-4"></i>
                                                </button>
                                                <form method="POST" class="inline" onsubmit="return confirm('Are you sure?')">
                                                    <input type="hidden" name="action" value="delete_milestone">
                                                    <input type="hidden" name="id" value="<?php echo $m['id']; ?>">
                                                    <button type="submit" class="text-red-600 hover:text-red-800">
                                                        <i data-lucide="trash-2" class="w-4 h-4"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Award Criteria Tab -->
                <div id="award-criteria" class="tab-content p-6 hidden">
                    <div class="flex justify-between items-center mb-4">
                        <h3 class="text-lg font-semibold">Award Criteria</h3>
                        <button onclick="openCriteriaModal()" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center">
                            <i data-lucide="plus" class="w-4 h-4 mr-2"></i> Add Award Criterion
                        </button>
                    </div>

                    <?php if (empty($award_criteria)): ?>
                        <p class="text-gray-500 text-center py-8">No award criteria configured yet.</p>
                    <?php else: ?>
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Min Score</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Points</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Frequency</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Auto Award</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    <?php foreach ($award_criteria as $c): ?>
                                    <tr>
                                        <td class="px-6 py-4"><?php echo htmlspecialchars($c['name']); ?></td>
                                        <td class="px-6 py-4"><?php echo $award_types[$c['award_type']] ?? $c['award_type']; ?></td>
                                        <td class="px-6 py-4"><?php echo $c['min_score']; ?></td>
                                        <td class="px-6 py-4"><?php echo $c['points']; ?></td>
                                        <td class="px-6 py-4"><?php echo $frequencies[$c['frequency']] ?? $c['frequency']; ?></td>
                                        <td class="px-6 py-4">
                                            <?php if ($c['auto_award']): ?>
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">Yes</span>
                                            <?php else: ?>
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">No</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-6 py-4">
                                            <?php if ($c['is_active']): ?>
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">Active</span>
                                            <?php else: ?>
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">Inactive</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-6 py-4">
                                            <div class="flex space-x-2">
                                                <button onclick="editCriteria(<?php echo htmlspecialchars(json_encode($c)); ?>)" class="text-blue-600 hover:text-blue-800">
                                                    <i data-lucide="edit" class="w-4 h-4"></i>
                                                </button>
                                                <form method="POST" class="inline" onsubmit="return confirm('Are you sure?')">
                                                    <input type="hidden" name="action" value="delete_criteria">
                                                    <input type="hidden" name="id" value="<?php echo $c['id']; ?>">
                                                    <button type="submit" class="text-red-600 hover:text-red-800">
                                                        <i data-lucide="trash-2" class="w-4 h-4"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Categories Tab (updated) -->
<div id="categories" class="tab-content p-6 hidden">
    <div class="flex justify-between items-center mb-4">
        <h3 class="text-lg font-semibold">Recognition Categories</h3>
        <!-- <p class="text-sm text-gray-500">Defined in <code>getRecognitionCategories()</code></p> -->
    </div>
    
    <div class="bg-white rounded-lg shadow overflow-hidden">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Key</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Label</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php 
                $categories = getRecognitionCategories(); 
                foreach ($categories as $key => $label): 
                ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-mono text-gray-900"><?php echo htmlspecialchars($key); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?php echo htmlspecialchars($label); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Recognition Types Tab (updated) -->
<div id="recognition-types" class="tab-content p-6 hidden">
    <div class="flex justify-between items-center mb-4">
        <h3 class="text-lg font-semibold">Recognition Types</h3>
        <!-- <p class="text-sm text-gray-500">Defined in <code>getRecognitionTypes()</code></p> -->
    </div>
    
    <div class="bg-white rounded-lg shadow overflow-hidden">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Key</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Label</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php 
                $types = getRecognitionTypes(); 
                foreach ($types as $key => $label): 
                ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-mono text-gray-900"><?php echo htmlspecialchars($key); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?php echo htmlspecialchars($label); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Milestone Modal -->
<div id="milestoneModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden items-center justify-center z-50">
    <div class="bg-white rounded-lg shadow-xl max-w-md w-full">
        <form method="POST" class="p-6">
            <input type="hidden" name="action" id="milestoneAction" value="add_milestone">
            <input type="hidden" name="id" id="milestoneId" value="">
            <h3 id="milestoneModalTitle" class="text-lg font-semibold mb-4">Add Milestone</h3>
            
            <div class="space-y-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700">Milestone Name</label>
                    <input type="text" name="name" id="milestoneName" required class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Type</label>
                    <select name="type" id="milestoneType" required class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2">
                        <option value="count">Recognition Count</option>
                        <option value="points">Total Points</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Threshold</label>
                    <input type="number" name="threshold" id="milestoneThreshold" required min="1" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Badge Name (optional)</label>
                    <input type="text" name="badge_name" id="milestoneBadge" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Badge Icon (optional)</label>
                    <input type="text" name="badge_icon" id="milestoneIcon" placeholder="e.g., 🏆" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Bonus Points</label>
                    <input type="number" name="points_awarded" id="milestonePoints" value="0" min="0" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2">
                </div>
                <div>
                    <label class="flex items-center">
                        <input type="checkbox" name="is_active" value="1" id="milestoneActive" checked class="rounded border-gray-300 text-blue-600 shadow-sm">
                        <span class="ml-2 text-sm text-gray-600">Active</span>
                    </label>
                </div>
            </div>

            <div class="mt-6 flex justify-end space-x-3">
                <button type="button" onclick="closeMilestoneModal()" class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">Cancel</button>
                <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">Save</button>
            </div>
        </form>
    </div>
</div>

<!-- Award Criteria Modal -->
<div id="criteriaModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden items-center justify-center z-50">
    <div class="bg-white rounded-lg shadow-xl max-w-md w-full">
        <form method="POST" class="p-6">
            <input type="hidden" name="action" id="criteriaAction" value="add_criteria">
            <input type="hidden" name="id" id="criteriaId" value="">
            <h3 id="criteriaModalTitle" class="text-lg font-semibold mb-4">Add Award Criterion</h3>
            
            <div class="space-y-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700">Name</label>
                    <input type="text" name="name" id="criteriaName" required class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Award Type</label>
                    <select name="award_type" id="criteriaType" required class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2">
                        <?php foreach ($award_types as $key => $label): ?>
                            <option value="<?php echo $key; ?>"><?php echo $label; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Description (optional)</label>
                    <textarea name="description" id="criteriaDesc" rows="2" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"></textarea>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Minimum Score (0-100)</label>
                    <input type="number" name="min_score" id="criteriaMinScore" value="0" min="0" max="100" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Points Awarded</label>
                    <input type="number" name="points" id="criteriaPoints" value="10" min="0" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Frequency</label>
                    <select name="frequency" id="criteriaFreq" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2">
                        <?php foreach ($frequencies as $key => $label): ?>
                            <option value="<?php echo $key; ?>"><?php echo $label; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label class="flex items-center">
                        <input type="checkbox" name="auto_award" value="1" id="criteriaAuto" class="rounded border-gray-300 text-blue-600 shadow-sm">
                        <span class="ml-2 text-sm text-gray-600">Auto-award (when conditions met)</span>
                    </label>
                </div>
                <div>
                    <label class="flex items-center">
                        <input type="checkbox" name="is_active" value="1" id="criteriaActive" checked class="rounded border-gray-300 text-blue-600 shadow-sm">
                        <span class="ml-2 text-sm text-gray-600">Active</span>
                    </label>
                </div>
            </div>

            <div class="mt-6 flex justify-end space-x-3">
                <button type="button" onclick="closeCriteriaModal()" class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">Cancel</button>
                <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">Save</button>
            </div>
        </form>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    lucide.createIcons();

    // Tab switching
    const tabs = document.querySelectorAll('.tab-link');
    const contents = document.querySelectorAll('.tab-content');
    tabs.forEach(tab => {
        tab.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('data-tab');
            
            // Update tab styles
            tabs.forEach(t => {
                t.classList.remove('border-blue-500', 'text-blue-600');
                t.classList.add('border-transparent', 'text-gray-500');
            });
            this.classList.remove('border-transparent', 'text-gray-500');
            this.classList.add('border-blue-500', 'text-blue-600');
            
            // Show target content
            contents.forEach(c => c.classList.add('hidden'));
            document.getElementById(targetId).classList.remove('hidden');
        });
    });

    // Check for hash in URL
    if (window.location.hash) {
        const hash = window.location.hash.substring(1);
        const targetTab = document.querySelector(`.tab-link[data-tab="${hash}"]`);
        if (targetTab) targetTab.click();
    }
});

// Milestone modal functions
function openMilestoneModal() {
    document.getElementById('milestoneAction').value = 'add_milestone';
    document.getElementById('milestoneId').value = '';
    document.getElementById('milestoneModalTitle').innerText = 'Add Milestone';
    document.getElementById('milestoneName').value = '';
    document.getElementById('milestoneType').value = 'count';
    document.getElementById('milestoneThreshold').value = '';
    document.getElementById('milestoneBadge').value = '';
    document.getElementById('milestoneIcon').value = '';
    document.getElementById('milestonePoints').value = '0';
    document.getElementById('milestoneActive').checked = true;
    document.getElementById('milestoneModal').classList.remove('hidden');
    document.getElementById('milestoneModal').classList.add('flex');
}

function editMilestone(milestone) {
    document.getElementById('milestoneAction').value = 'edit_milestone';
    document.getElementById('milestoneId').value = milestone.id;
    document.getElementById('milestoneModalTitle').innerText = 'Edit Milestone';
    document.getElementById('milestoneName').value = milestone.name;
    document.getElementById('milestoneType').value = milestone.type;
    document.getElementById('milestoneThreshold').value = milestone.threshold;
    document.getElementById('milestoneBadge').value = milestone.badge_name || '';
    document.getElementById('milestoneIcon').value = milestone.badge_icon || '';
    document.getElementById('milestonePoints').value = milestone.points_awarded || 0;
    document.getElementById('milestoneActive').checked = milestone.is_active == 1;
    document.getElementById('milestoneModal').classList.remove('hidden');
    document.getElementById('milestoneModal').classList.add('flex');
}

function closeMilestoneModal() {
    document.getElementById('milestoneModal').classList.add('hidden');
    document.getElementById('milestoneModal').classList.remove('flex');
}

// Award criteria modal functions
function openCriteriaModal() {
    document.getElementById('criteriaAction').value = 'add_criteria';
    document.getElementById('criteriaId').value = '';
    document.getElementById('criteriaModalTitle').innerText = 'Add Award Criterion';
    document.getElementById('criteriaName').value = '';
    document.getElementById('criteriaType').value = 'recognition';
    document.getElementById('criteriaDesc').value = '';
    document.getElementById('criteriaMinScore').value = '0';
    document.getElementById('criteriaPoints').value = '10';
    document.getElementById('criteriaFreq').value = 'as_needed';
    document.getElementById('criteriaAuto').checked = false;
    document.getElementById('criteriaActive').checked = true;
    document.getElementById('criteriaModal').classList.remove('hidden');
    document.getElementById('criteriaModal').classList.add('flex');
}

function editCriteria(criteria) {
    document.getElementById('criteriaAction').value = 'edit_criteria';
    document.getElementById('criteriaId').value = criteria.id;
    document.getElementById('criteriaModalTitle').innerText = 'Edit Award Criterion';
    document.getElementById('criteriaName').value = criteria.name;
    document.getElementById('criteriaType').value = criteria.award_type;
    document.getElementById('criteriaDesc').value = criteria.description || '';
    document.getElementById('criteriaMinScore').value = criteria.min_score || 0;
    document.getElementById('criteriaPoints').value = criteria.points || 10;
    document.getElementById('criteriaFreq').value = criteria.frequency || 'as_needed';
    document.getElementById('criteriaAuto').checked = criteria.auto_award == 1;
    document.getElementById('criteriaActive').checked = criteria.is_active == 1;
    document.getElementById('criteriaModal').classList.remove('hidden');
    document.getElementById('criteriaModal').classList.add('flex');
}

function closeCriteriaModal() {
    document.getElementById('criteriaModal').classList.add('hidden');
    document.getElementById('criteriaModal').classList.remove('flex');
}

// Close modals when clicking outside (optional)
window.onclick = function(event) {
    if (event.target.classList.contains('fixed')) {
        closeMilestoneModal();
        closeCriteriaModal();
    }
}
</script>
</body>
</html>