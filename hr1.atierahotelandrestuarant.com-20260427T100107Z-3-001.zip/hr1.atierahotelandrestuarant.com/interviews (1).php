<?php
// File: interviews.php
session_start();
require_once 'connections.php';
require_once 'functions.php'; // Include functions instead
requireAuth(); // This will work now

// Get interviews
$status = $_GET['status'] ?? 'upcoming';
$query = "SELECT i.*, a.first_name, a.last_name, a.email, a.job_id, j.job_title 
          FROM interviews i
          JOIN applicants a ON i.applicant_id = a.id
          LEFT JOIN job_postings j ON a.job_id = j.id
          WHERE 1=1";

// Fix: Use scheduled_date instead of interview_date
if ($status == 'upcoming') {
    $query .= " AND i.scheduled_date >= CURDATE()";
} elseif ($status == 'past') {
    $query .= " AND i.scheduled_date < CURDATE()";
} elseif ($status == 'today') {
    $query .= " AND DATE(i.scheduled_date) = CURDATE()";
}

$query .= " ORDER BY i.scheduled_date ASC";

$stmt = $connections->prepare($query);
$stmt->execute();
$interviews = $stmt->fetchAll();

// Get stats - Fix: Use scheduled_date instead of interview_date
$stats_stmt = $connections->prepare("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN DATE(scheduled_date) = CURDATE() THEN 1 ELSE 0 END) as today,
        SUM(CASE WHEN scheduled_date >= CURDATE() THEN 1 ELSE 0 END) as upcoming,
        SUM(CASE WHEN scheduled_date < CURDATE() THEN 1 ELSE 0 END) as past
    FROM interviews
");
$stats_stmt->execute();
$stats = $stats_stmt->fetch();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>HR1 - Interviews</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
</head>

<body class="h-screen bg-gray-100 font-sans">
<div class="flex h-full">
  
  <!-- Sidebar -->
  <?php include 'sidebar.php'; ?>
  
  <!-- Main Content -->
  <div class="flex-1 flex flex-col overflow-y-auto">
    <main class="p-6 space-y-6">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-gray-300 pb-4">
        <div>
          <h2 class="text-2xl font-bold text-gray-800">Interviews</h2>
          <p class="text-sm text-gray-600">Manage interview schedules and evaluations</p>
        </div>
        <div class="flex items-center space-x-4">
          <a href="schedule_interview.php" class="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            <i data-lucide="calendar-plus" class="w-4 h-4"></i>
            <span>Schedule Interview</span>
          </a>
          <?php include 'profile_dropdown.php'; ?>
        </div>
      </div>

      <!-- Stats -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div class="bg-white p-6 rounded-lg shadow border">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-600">Total Interviews</p>
              <p class="text-2xl font-bold text-gray-800"><?php echo $stats['total']; ?></p>
            </div>
            <i data-lucide="calendar" class="w-8 h-8 text-blue-500"></i>
          </div>
        </div>
        
        <div class="bg-white p-6 rounded-lg shadow border border-l-4 border-l-yellow-500">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-600">Today</p>
              <p class="text-2xl font-bold text-gray-800"><?php echo $stats['today']; ?></p>
            </div>
            <i data-lucide="clock" class="w-8 h-8 text-yellow-500"></i>
          </div>
        </div>
        
        <div class="bg-white p-6 rounded-lg shadow border border-l-4 border-l-green-500">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-600">Upcoming</p>
              <p class="text-2xl font-bold text-gray-800"><?php echo $stats['upcoming']; ?></p>
            </div>
            <i data-lucide="calendar-check" class="w-8 h-8 text-green-500"></i>
          </div>
        </div>
        
        <div class="bg-white p-6 rounded-lg shadow border border-l-4 border-l-gray-500">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-600">Past</p>
              <p class="text-2xl font-bold text-gray-800"><?php echo $stats['past']; ?></p>
            </div>
            <i data-lucide="history" class="w-8 h-8 text-gray-500"></i>
          </div>
        </div>
      </div>

      <!-- Tabs -->
      <div class="bg-white rounded-lg shadow">
        <div class="border-b">
          <nav class="flex -mb-px">
            <a href="?status=today" class="py-4 px-6 border-b-2 font-medium text-sm 
              <?php echo $status == 'today' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'; ?>">
              Today (<?php echo $stats['today']; ?>)
            </a>
            <a href="?status=upcoming" class="py-4 px-6 border-b-2 font-medium text-sm 
              <?php echo $status == 'upcoming' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'; ?>">
              Upcoming (<?php echo $stats['upcoming']; ?>)
            </a>
            <a href="?status=past" class="py-4 px-6 border-b-2 font-medium text-sm 
              <?php echo $status == 'past' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'; ?>">
              Past (<?php echo $stats['past']; ?>)
            </a>
            <a href="?status=all" class="py-4 px-6 border-b-2 font-medium text-sm 
              <?php echo $status == 'all' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'; ?>">
              All
            </a>
          </nav>
        </div>

        <!-- Interviews Table -->
        <div class="overflow-x-auto">
          <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
              <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Applicant</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Position</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Scheduled Date</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Interviewers</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
              <?php foreach($interviews as $interview): ?>
              <?php
                // Extract date and time from scheduled_date
                $scheduled_date = new DateTime($interview['scheduled_date']);
                $date_display = $scheduled_date->format('M d, Y');
                $time_display = $scheduled_date->format('h:i A');
              ?>
              <tr class="hover:bg-gray-50">
                <td class="px-6 py-4">
                  <div class="flex items-center">
                    <div class="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center mr-3">
                      <i data-lucide="user" class="w-5 h-5 text-gray-600"></i>
                    </div>
                    <div>
                      <div class="text-sm font-medium text-gray-900">
                        <?php echo htmlspecialchars($interview['first_name'] . ' ' . $interview['last_name']); ?>
                      </div>
                      <div class="text-sm text-gray-500"><?php echo htmlspecialchars($interview['email']); ?></div>
                    </div>
                  </div>
                </td>
                <td class="px-6 py-4 text-sm text-gray-900"><?php echo !empty($interview['job_title']) ? htmlspecialchars($interview['job_title']) : 'N/A'; ?></td>
                <td class="px-6 py-4">
                  <div class="text-sm font-medium text-gray-900">
                    <?php echo $date_display; ?>
                  </div>
                  <div class="text-sm text-gray-500">
                    <?php echo $time_display; ?>
                  </div>
                </td>
                <td class="px-6 py-4 text-sm text-gray-900"><?php echo htmlspecialchars($interview['interviewers']); ?></td>
                <td class="px-6 py-4">
                  <span class="px-3 py-1 text-xs rounded-full 
                    <?php echo $interview['status'] == 'scheduled' ? 'bg-blue-100 text-blue-800' : 
                           ($interview['status'] == 'completed' ? 'bg-green-100 text-green-800' : 
                           ($interview['status'] == 'cancelled' ? 'bg-red-100 text-red-800' : 
                           'bg-gray-100 text-gray-800')); ?>">
                    <?php echo ucfirst($interview['status']); ?>
                  </span>
                </td>
                <td class="px-6 py-4">
                  <div class="flex space-x-2">
                    <a href="view_interview.php?id=<?php echo $interview['id']; ?>" 
                       class="px-3 py-1 text-sm bg-gray-100 rounded hover:bg-gray-200">
                      <i data-lucide="eye" class="w-4 h-4"></i>
                    </a>
                    <?php if($interview['status'] == 'scheduled'): ?>
                    <a href="conduct_interview.php?id=<?php echo $interview['id']; ?>" 
                       class="px-3 py-1 text-sm bg-green-100 text-green-700 rounded hover:bg-green-200">
                      <i data-lucide="video" class="w-4 h-4"></i>
                    </a>
                    <a href="reschedule_interview.php?id=<?php echo $interview['id']; ?>" 
                       class="px-3 py-1 text-sm bg-yellow-100 text-yellow-700 rounded hover:bg-yellow-200">
                      <i data-lucide="calendar" class="w-4 h-4"></i>
                    </a>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
          
          <?php if(empty($interviews)): ?>
          <div class="text-center py-12">
            <i data-lucide="calendar" class="w-12 h-12 text-gray-400 mx-auto mb-4"></i>
            <p class="text-gray-500">No interviews scheduled</p>
            <a href="schedule_interview.php" class="mt-2 inline-block text-blue-600 hover:underline">
              Schedule your first interview
            </a>
          </div>
          <?php endif; ?>
        </div>
      </div>
    </main>
  </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
  lucide.createIcons();
});
</script>
</body>
</html>