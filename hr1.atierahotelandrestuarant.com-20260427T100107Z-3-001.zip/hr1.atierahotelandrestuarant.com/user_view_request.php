<?php
// File: view_request.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

$requestId = $_GET['id'] ?? 0;
$request = getJobRequest($requestId, $connections);

if (!$request) {
    header('Location: job_requests.php');
    exit();
}

$timeline = getRequestTimeline($requestId, $connections);
$canEdit = canEditJobRequest($requestId, $_SESSION['user_id'], $_SESSION['user_role'], $connections);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>HR1 - Job Request Details</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
</head>

<body class="h-screen bg-gray-100 font-sans">
<div class="flex h-full">
  
  <!-- Sidebar -->
  <?php include 'user_sidebar.php'; ?>
  
  <!-- Main Content -->
  <div class="flex-1 flex flex-col overflow-y-auto">
    <main class="p-6 space-y-6">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-gray-300 pb-4">
        <div>
          <h2 class="text-2xl font-bold text-gray-800">Job Request Details</h2>
          <p class="text-sm text-gray-600">View and manage job requisition request</p>
        </div>
        <div class="flex items-center space-x-4">
          <a href="user_job_requests.php" class="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
            <i data-lucide="arrow-left" class="w-4 h-4"></i>
            <span>Back to List</span>
          </a>
          <?php if ($canEdit): ?>
            <a href="user_edit_request.php?id=<?php echo $requestId; ?>" class="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
              <i data-lucide="edit" class="w-4 h-4"></i>
              <span>Edit Request</span>
            </a>
          <?php endif; ?>
          <?php if (in_array($_SESSION['user_role'], ['admin', 'hr_manager', 'hr_officer'])): ?>
            <div class="relative">
              <button onclick="toggleStatusMenu()" class="flex items-center space-x-2 px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300">
                <i data-lucide="settings" class="w-4 h-4"></i>
                <span>Update Status</span>
              </button>
              <div id="statusMenu" class="hidden absolute right-0 mt-1 bg-white shadow-lg rounded-lg border w-48 z-10">
                <?php $statuses = ['pending', 'approved', 'rejected', 'draft']; ?>
                <?php foreach ($statuses as $status): ?>
                  <?php if ($status != $request['overall_status']): ?>
                    <button onclick="updateStatus('<?php echo $status; ?>')" class="block w-full text-left px-4 py-2 hover:bg-gray-100">
                      <i data-lucide="<?php echo $status == 'approved' ? 'check' : ($status == 'rejected' ? 'x' : 'clock'); ?>" class="w-4 h-4 mr-2 inline"></i>
                      Mark as <?php echo ucfirst($status); ?>
                    </button>
                  <?php endif; ?>
                <?php endforeach; ?>
              </div>
            </div>
          <?php endif; ?>
          <?php include 'user_profile_dropdown.php'; ?>
        </div>
      </div>

      <!-- Flash Messages -->
      <?php 
      if (isset($_SESSION['flash_message'])) {
          $type = $_SESSION['flash_message']['type'];
          $message = $_SESSION['flash_message']['message'];
          $color = $type == 'success' ? 'green' : ($type == 'warning' ? 'yellow' : ($type == 'info' ? 'blue' : 'red'));
          $icon = $type == 'success' ? 'check-circle' : ($type == 'warning' ? 'alert-triangle' : ($type == 'info' ? 'info' : 'alert-circle'));
          
          echo "
          <div class='bg-{$color}-50 border border-{$color}-400 text-{$color}-700 px-4 py-3 rounded-lg'>
              <div class='flex items-center'>
                  <i data-lucide='{$icon}' class='w-5 h-5 mr-2'></i>
                  <span>{$message}</span>
              </div>
          </div>
          ";
          
          unset($_SESSION['flash_message']);
      }
      ?>

      <!-- Request Info Bar -->
      <div class="bg-white rounded-lg shadow p-6">
        <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div class="flex items-center space-x-4">
            <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <i data-lucide="file-text" class="w-6 h-6 text-blue-600"></i>
            </div>
            <div>
              <h3 class="text-lg font-semibold text-gray-900"><?php echo htmlspecialchars($request['position_title']); ?></h3>
              <div class="flex items-center space-x-3 mt-1">
                <span class="text-sm text-gray-600"><?php echo htmlspecialchars($request['department']); ?></span>
                <span class="text-gray-400">•</span>
                <span class="text-sm text-gray-600">ID: <?php echo $request['job_code']; ?></span>
                <span class="text-gray-400">•</span>
                <span class="px-2 py-1 text-xs font-medium rounded-full <?php echo getJobRequestStatusColor($request['overall_status']); ?>">
                  <?php echo strtoupper($request['overall_status']); ?>
                </span>
                <?php 
                // Check if job posting exists for this request
                $hasPosting = hasJobPosting($requestId, $connections);
                if ($hasPosting && $request['overall_status'] == 'approved'): 
                    $postingStmt = $connections->prepare("SELECT id FROM job_postings WHERE job_request_id = ?");
                    $postingStmt->execute([$requestId]);
                    $posting = $postingStmt->fetch();
                ?>
                <span class="text-gray-400">•</span>
                <a href="view_posting.php?id=<?php echo $posting['id']; ?>" class="text-sm text-green-600 hover:underline flex items-center">
                  <i data-lucide="external-link" class="w-3 h-3 mr-1"></i>
                  View Job Posting
                </a>
                <?php endif; ?>
              </div>
            </div>
          </div>
          <div class="flex flex-wrap gap-2">
            <span class="px-3 py-1 text-sm font-medium rounded-full <?php echo getUrgencyColor($request['urgency_level'] ?? 'medium'); ?>">
              <i data-lucide="alert-circle" class="w-3 h-3 inline mr-1"></i>
              <?php echo strtoupper($request['urgency_level'] ?? 'MEDIUM'); ?> URGENCY
            </span>
            <span class="px-3 py-1 text-sm font-medium rounded-full bg-blue-100 text-blue-800">
              <i data-lucide="pesso-sign" class="w-3 h-3 inline mr-1"></i>
              &#8369;<?php echo number_format($request['salary_budget'] ?? 0); ?>
            </span>
            <span class="px-3 py-1 text-sm font-medium rounded-full bg-purple-100 text-purple-800">
              <i data-lucide="calendar" class="w-3 h-3 inline mr-1"></i>
              <?php echo date('M d, Y', strtotime($request['target_start_date'])); ?>
            </span>
          </div>
        </div>
      </div>

      <!-- Main Content Grid -->
      <div class="grid lg:grid-cols-3 gap-6">
        <!-- Left Column - Position Details -->
        <div class="lg:col-span-2 space-y-6">
          <!-- Position Details Card -->
          <div class="bg-white rounded-lg shadow">
            <div class="border-b border-gray-200 px-6 py-4">
              <h3 class="text-lg font-semibold text-gray-900">Position Details</h3>
            </div>
            <div class="p-6 space-y-6">
              <div class="grid md:grid-cols-2 gap-6">
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">Position Type</label>
                  <p class="text-gray-900">
                    <?php 
                    if ($request['position_type'] == 'new_position') echo 'New Position';
                    elseif ($request['position_type'] == 'replacement') echo 'Replacement';
                    else echo ucfirst(str_replace('_', ' ', $request['position_type'] ?? 'New Position'));
                    ?>
                  </p>
                </div>
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">Number Needed</label>
                  <p class="text-gray-900"><?php echo $request['number_needed'] ?? 1; ?> position(s)</p>
                </div>
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">Reason for Request</label>
                  <p class="text-gray-900">
                    <?php 
                    if ($request['reason'] == 'new') echo 'New Position';
                    elseif ($request['reason'] == 'replacement') echo 'Replacement';
                    else echo ucfirst($request['reason'] ?? 'New Position');
                    ?>
                  </p>
                </div>
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">Budget Approved</label>
                  <p class="text-gray-900">
                    <span class="px-2 py-1 text-xs rounded-full <?php echo $request['budget_approved'] ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                      <?php echo $request['budget_approved'] ? 'Yes' : 'No'; ?>
                    </span>
                  </p>
                </div>
              </div>

              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Justification</label>
                <div class="mt-2 text-gray-900 bg-gray-50 rounded-lg p-4">
                  <?php echo nl2br(htmlspecialchars($request['justification'] ?? 'No justification provided')); ?>
                </div>
              </div>

              <?php if (!empty($request['qualifications'])): ?>
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Qualifications</label>
                <div class="mt-2 text-gray-900 bg-gray-50 rounded-lg p-4">
                  <?php echo nl2br(htmlspecialchars($request['qualifications'])); ?>
                </div>
              </div>
              <?php endif; ?>
            </div>
          </div>

          <!-- Requirements Card -->
          <div class="bg-white rounded-lg shadow">
            <div class="border-b border-gray-200 px-6 py-4">
              <h3 class="text-lg font-semibold text-gray-900">Requirements</h3>
            </div>
            <div class="p-6">
              <div class="grid md:grid-cols-2 gap-6">
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">Experience Level</label>
                  <p class="text-gray-900">
                    <?php 
                    if ($request['experience_level'] == 'entry') echo 'Entry Level (0-2 years)';
                    elseif ($request['experience_level'] == 'mid') echo 'Mid Level (3-5 years)';
                    elseif ($request['experience_level'] == 'senior') echo 'Senior (6-10 years)';
                    elseif ($request['experience_level'] == 'executive') echo 'Executive (10+ years)';
                    else echo 'Not specified';
                    ?>
                  </p>
                </div>
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">Education Level</label>
                  <p class="text-gray-900">
                    <?php 
                    if ($request['education_level'] == 'high_school') echo 'High School';
                    elseif ($request['education_level'] == 'associate') echo 'Associate Degree';
                    elseif ($request['education_level'] == 'bachelor') echo 'Bachelor\'s Degree';
                    elseif ($request['education_level'] == 'master') echo 'Master\'s Degree';
                    elseif ($request['education_level'] == 'phd') echo 'PhD';
                    else echo 'Not specified';
                    ?>
                  </p>
                </div>
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">Reporting To</label>
                  <p class="text-gray-900"><?php echo htmlspecialchars($request['reporting_to'] ?? 'Not specified'); ?></p>
                </div>
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">Required Skills</label>
                  <p class="text-gray-900"><?php echo htmlspecialchars($request['required_skills'] ?? 'Not specified'); ?></p>
                </div>
              </div>
              
              <?php if (!empty($request['responsibilities'])): ?>
              <div class="mt-6">
                <label class="block text-sm font-medium text-gray-700 mb-2">Responsibilities</label>
                <div class="mt-2 text-gray-900 bg-gray-50 rounded-lg p-4">
                  <?php echo nl2br(htmlspecialchars($request['responsibilities'])); ?>
                </div>
              </div>
              <?php endif; ?>
            </div>
          </div>
        </div>

        <!-- Right Column - Sidebar -->
        <div class="space-y-6">
          <!-- Request Information Card -->
          <div class="bg-white rounded-lg shadow">
            <div class="border-b border-gray-200 px-6 py-4">
              <h3 class="text-lg font-semibold text-gray-900">Request Information</h3>
            </div>
            <div class="p-6 space-y-4">
              <div class="flex items-start">
                <i data-lucide="user" class="w-5 h-5 text-gray-400 mt-0.5 mr-3"></i>
                <div>
                  <p class="text-sm font-medium text-gray-700">Requested By</p>
                  <p class="text-gray-900"><?php echo htmlspecialchars($request['requested_by']); ?></p>
                  <p class="text-sm text-gray-600"><?php echo htmlspecialchars($request['requested_by_email'] ?? ''); ?></p>
                </div>
              </div>
              
              <div class="flex items-start">
                <i data-lucide="briefcase" class="w-5 h-5 text-gray-400 mt-0.5 mr-3"></i>
                <div>
                  <p class="text-sm font-medium text-gray-700">Hiring Manager</p>
                  <p class="text-gray-900"><?php echo htmlspecialchars($request['hiring_manager_name'] ?? $request['requested_by']); ?></p>
                  <?php if (!empty($request['hiring_manager_email'])): ?>
                  <p class="text-sm text-gray-600"><?php echo htmlspecialchars($request['hiring_manager_email']); ?></p>
                  <?php endif; ?>
                </div>
              </div>
              
              <div class="flex items-start">
                <i data-lucide="calendar" class="w-5 h-5 text-gray-400 mt-0.5 mr-3"></i>
                <div>
                  <p class="text-sm font-medium text-gray-700">Created Date</p>
                  <p class="text-gray-900"><?php echo date('M d, Y', strtotime($request['created_at'])); ?></p>
                  <p class="text-sm text-gray-600"><?php echo date('h:i A', strtotime($request['created_at'])); ?></p>
                </div>
              </div>
              
              <?php if ($request['reviewed_by']): ?>
              <div class="flex items-start">
                <i data-lucide="check-circle" class="w-5 h-5 text-gray-400 mt-0.5 mr-3"></i>
                <div>
                  <p class="text-sm font-medium text-gray-700">Reviewed By</p>
                  <p class="text-gray-900"><?php echo htmlspecialchars($request['reviewed_by']); ?></p>
                  <p class="text-sm text-gray-600"><?php echo date('M d, Y', strtotime($request['reviewed_at'])); ?></p>
                </div>
              </div>
              <?php endif; ?>
              
              <?php if (!empty($request['review_comments'])): ?>
              <div class="flex items-start">
                <i data-lucide="message-square" class="w-5 h-5 text-gray-400 mt-0.5 mr-3"></i>
                <div>
                  <p class="text-sm font-medium text-gray-700">Review Comments</p>
                  <p class="text-gray-900 text-sm"><?php echo htmlspecialchars($request['review_comments']); ?></p>
                </div>
              </div>
              <?php endif; ?>
            </div>
          </div>

          <!-- Approval Status Card -->
          <div class="bg-white rounded-lg shadow">
            <div class="border-b border-gray-200 px-6 py-4">
              <h3 class="text-lg font-semibold text-gray-900">Approval Status</h3>
            </div>
            <div class="p-6 space-y-4">
              <div>
                <div class="flex justify-between items-center mb-2">
                  <span class="text-sm font-medium text-gray-700">Supervisor Approval</span>
                  <span class="px-2 py-1 text-xs font-medium rounded-full <?php echo getApprovalStatusColor($request['supervisor_approval'] ?? 'pending'); ?>">
                    <?php echo strtoupper($request['supervisor_approval'] ?? 'PENDING'); ?>
                  </span>
                </div>
                <?php if (!empty($request['supervisor_comments'])): ?>
                <p class="text-sm text-gray-600 bg-gray-50 rounded p-2 mt-1"><?php echo htmlspecialchars($request['supervisor_comments']); ?></p>
                <?php endif; ?>
              </div>
              
              <div>
                <div class="flex justify-between items-center mb-2">
                  <span class="text-sm font-medium text-gray-700">Management Approval</span>
                  <span class="px-2 py-1 text-xs font-medium rounded-full <?php echo getApprovalStatusColor($request['management_approval'] ?? 'pending'); ?>">
                    <?php echo strtoupper($request['management_approval'] ?? 'PENDING'); ?>
                  </span>
                </div>
                <?php if (!empty($request['management_comments'])): ?>
                <p class="text-sm text-gray-600 bg-gray-50 rounded p-2 mt-1"><?php echo htmlspecialchars($request['management_comments']); ?></p>
                <?php endif; ?>
              </div>
            </div>
          </div>

          <!-- Activity Timeline -->
          <?php if (!empty($timeline)): ?>
          <div class="bg-white rounded-lg shadow">
            <div class="border-b border-gray-200 px-6 py-4">
              <h3 class="text-lg font-semibold text-gray-900">Activity Timeline</h3>
            </div>
            <div class="p-6">
              <div class="space-y-4">
                <?php foreach ($timeline as $event): ?>
                <div class="flex">
                  <div class="flex-shrink-0 mr-4">
                    <div class="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                      <i data-lucide="activity" class="w-4 h-4 text-blue-600"></i>
                    </div>
                  </div>
                  <div class="flex-1">
                    <p class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($event['action']); ?></p>
                    <p class="text-xs text-gray-600">
                      <?php echo date('M d, Y h:i A', strtotime($event['created_at'])); ?>
                      <?php if (!empty($event['user_name'])): ?>
                      • by <?php echo htmlspecialchars($event['user_name']); ?>
                      <?php endif; ?>
                    </p>
                    <?php if (!empty($event['description'])): ?>
                    <p class="text-xs text-gray-500 mt-1"><?php echo htmlspecialchars($event['description']); ?></p>
                    <?php endif; ?>
                  </div>
                </div>
                <?php endforeach; ?>
              </div>
            </div>
          </div>
          <?php endif; ?>
        </div>
      </div>
    </main>
  </div>
</div>

<script>
function toggleStatusMenu() {
  document.getElementById('statusMenu').classList.toggle('hidden');
}

function updateStatus(newStatus) {
  const comments = prompt('Enter comments (optional):');
  if (comments !== null) { // User didn't cancel
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = 'update_request_status.php';
    
    const idInput = document.createElement('input');
    idInput.type = 'hidden';
    idInput.name = 'request_id';
    idInput.value = '<?php echo $requestId; ?>';
    form.appendChild(idInput);
    
    const statusInput = document.createElement('input');
    statusInput.type = 'hidden';
    statusInput.name = 'status';
    statusInput.value = newStatus;
    form.appendChild(statusInput);
    
    if (comments.trim() !== '') {
      const commentsInput = document.createElement('input');
      commentsInput.type = 'hidden';
      commentsInput.name = 'comments';
      commentsInput.value = comments;
      form.appendChild(commentsInput);
    }
    
    document.body.appendChild(form);
    form.submit();
  }
}

document.addEventListener('click', function(e) {
  if (!e.target.closest('#statusMenu') && !e.target.closest('button[onclick*="toggleStatusMenu"]')) {
    const menu = document.getElementById('statusMenu');
    if (menu && !menu.classList.contains('hidden')) {
      menu.classList.add('hidden');
    }
  }
});

document.addEventListener("DOMContentLoaded", () => {
  lucide.createIcons();
});
</script>
</body>
</html>