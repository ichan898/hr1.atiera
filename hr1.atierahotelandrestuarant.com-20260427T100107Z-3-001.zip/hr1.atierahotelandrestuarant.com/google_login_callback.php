<?php
// google_login_callback.php
session_start();
require_once 'connections.php';
require_once 'email_functions.php';

if (isset($_GET['error'])) {
    $_SESSION['google_error'] = 'Google login failed: ' . htmlspecialchars($_GET['error']);
    header('Location: login.php');
    exit;
}
if (!isset($_GET['code'])) {
    $_SESSION['google_error'] = 'No authorization code received.';
    header('Location: login.php');
    exit;
}

$code = $_GET['code'];
$token_url = 'https://oauth2.googleapis.com/token';
$post_data = [
    'code' => $code,
    'client_id' => GOOGLE_CLIENT_ID,
    'client_secret' => GOOGLE_CLIENT_SECRET,
    'redirect_uri' => GOOGLE_REDIRECT_URI,
    'grant_type' => 'authorization_code',
];
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $token_url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);
$token_data = json_decode($response, true);
if (isset($token_data['error'])) {
    $_SESSION['google_error'] = 'Token exchange failed: ' . ($token_data['error_description'] ?? 'Unknown error');
    header('Location: login.php');
    exit;
}
$access_token = $token_data['access_token'];

$userinfo_url = 'https://www.googleapis.com/oauth2/v2/userinfo';
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $userinfo_url);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer ' . $access_token]);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$userinfo = curl_exec($ch);
curl_close($ch);
$user = json_decode($userinfo, true);
if (!isset($user['email'])) {
    $_SESSION['google_error'] = 'Could not retrieve email from Google.';
    header('Location: login.php');
    exit;
}
$google_email = $user['email'];
$google_name = $user['name'] ?? '';

try {
    $stmt = $connections->prepare("SELECT id, email, full_name, otp_enabled FROM hr_users WHERE email = ? AND is_active = TRUE");
    $stmt->execute([$google_email]);
    $hr_user = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$hr_user) {
        $_SESSION['google_error'] = 'This Google account is not authorized as an HR administrator.';
        header('Location: login.php');
        exit;
    }
    $otpCode = generateOtp();
    $updateStmt = $connections->prepare("UPDATE hr_users SET otp_secret = ?, otp_created_at = NOW() WHERE id = ?");
    $updateStmt->execute([$otpCode, $hr_user['id']]);
    $emailSent = sendOtpEmail($hr_user['email'], $hr_user['full_name'], $otpCode);
    if (!$emailSent) {
        $_SESSION['google_error'] = 'Failed to send OTP email. Please try again.';
        header('Location: login.php');
        exit;
    }
    $_SESSION['temp_user_id'] = $hr_user['id'];
    $_SESSION['temp_user_type'] = 'hr';
    $_SESSION['temp_user_source'] = 'google';
    $_SESSION['temp_user_email'] = $hr_user['email'];
    $_SESSION['temp_user_name'] = $hr_user['full_name'];
    $_SESSION['show_otp_form'] = true;
    $_SESSION['otp_success_msg'] = 'OTP has been sent to your Google email (' . $hr_user['email'] . ').';
    header('Location: login.php');
    exit;
} catch (PDOException $e) {
    error_log('Google OTP error: ' . $e->getMessage());
    $_SESSION['google_error'] = 'System error. Please try again later.';
    header('Location: login.php');
    exit;
}
?>