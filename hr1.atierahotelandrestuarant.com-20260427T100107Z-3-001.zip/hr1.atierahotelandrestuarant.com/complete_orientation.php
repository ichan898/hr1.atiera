<?php
// File: complete_orientation.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: onboarding.php');
    exit();
}

$id = $_GET['id'];

$query = "SELECT o.*, d.name as department_name 
          FROM onboarding o 
          LEFT JOIN departments d ON o.department = d.id 
          WHERE o.id = ?";
$stmt = $connections->prepare($query);
$stmt->execute([$id]);
$onboarding = $stmt->fetch();

if (!$onboarding) {
    header('Location: onboarding.php');
    exit();
}

// --- FIX: Ensure all orientation fields exist with default values ---
$defaults = [
    'orientation_date'      => null,
    'orientation_trainer'   => '',
    'orientation_score'     => null,
    'orientation_complete'  => 0,
    'orientation_location'  => '',
    'orientation_notes'     => ''
];
$onboarding = array_merge($defaults, $onboarding);
// -------------------------------------------------------------------

// Get upcoming training sessions
$training_query = "SELECT ts.*, 
                   (SELECT COUNT(*) FROM training_participants tp WHERE tp.training_id = ts.id AND tp.employee_id = ?) as is_registered
                   FROM training_sessions ts 
                   WHERE ts.type = 'orientation' 
                   AND ts.status IN ('scheduled', 'ongoing')
                   AND ts.training_date >= CURDATE()
                   ORDER BY ts.training_date ASC";
$training_stmt = $connections->prepare($training_query);
$training_stmt->execute([$onboarding['employee_record_id']]);
$training_sessions = $training_stmt->fetchAll();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_orientation'])) {
        $orientation_complete = isset($_POST['orientation_complete']) ? 1 : 0;
        $orientation_date = $_POST['orientation_date'] ?? null;
        $orientation_trainer = $_POST['orientation_trainer'] ?? '';
        $orientation_location = $_POST['orientation_location'] ?? '';
        $training_id = $_POST['training_id'] ?? null;
        $orientation_score = $_POST['orientation_score'] ?? null;
        $orientation_notes = $_POST['orientation_notes'] ?? '';
        
        $update_query = "UPDATE onboarding SET 
            orientation_complete = ?,
            orientation_date = ?,
            orientation_trainer = ?,
            orientation_location = ?,
            orientation_score = ?,
            notes = CONCAT(COALESCE(notes, ''), ?),
            updated_at = NOW()
            WHERE id = ?";
        
        $update_notes = "\n\nOrientation updated on " . date('Y-m-d H:i:s') . ": " . $orientation_notes;
        
        $update_stmt = $connections->prepare($update_query);
        $update_stmt->execute([
            $orientation_complete,
            $orientation_date,
            $orientation_trainer,
            $orientation_location,
            $orientation_score,
            $update_notes,
            $id
        ]);
        
        // Register for training session if selected
        if ($training_id && $onboarding['employee_record_id']) {
            $register_query = "INSERT INTO training_participants (training_id, employee_id, attendance_status, registered_at)
                              VALUES (?, ?, 'registered', NOW())
                              ON DUPLICATE KEY UPDATE attendance_status = VALUES(attendance_status)";
            $register_stmt = $connections->prepare($register_query);
            $register_stmt->execute([$training_id, $onboarding['employee_record_id']]);
        }
        
        $_SESSION['success'] = "Orientation details updated!";
        header("Location: view_onboarding.php?id=$id");
        exit();
    }
    
    // Handle manual attendance marking
    if (isset($_POST['mark_attendance'])) {
        $training_id = $_POST['training_id'];
        $attendance_status = $_POST['attendance_status'];
        $attendance_notes = $_POST['attendance_notes'] ?? '';
        
        if ($onboarding['employee_record_id']) {
            $attendance_query = "UPDATE training_participants 
                                SET attendance_status = ?, 
                                    feedback = ?,
                                    completion_date = ?,
                                    updated_at = NOW()
                                WHERE training_id = ? AND employee_id = ?";
            $attendance_stmt = $connections->prepare($attendance_query);
            $attendance_stmt->execute([
                $attendance_status,
                $attendance_notes,
                date('Y-m-d'),
                $training_id,
                $onboarding['employee_record_id']
            ]);
            
            // If attended, mark orientation as complete
            if ($attendance_status === 'attended') {
                $complete_query = "UPDATE onboarding SET 
                    orientation_complete = 1,
                    orientation_date = ?,
                    updated_at = NOW()
                    WHERE id = ?";
                $complete_stmt = $connections->prepare($complete_query);
                $complete_stmt->execute([date('Y-m-d'), $id]);
            }
            
            $_SESSION['success'] = "Attendance updated successfully!";
            header("Location: complete_orientation.php?id=$id");
            exit();
        }
    }
}

// Get current training registration
$current_training = null;
if ($onboarding['employee_record_id']) {
    $current_query = "SELECT tp.*, ts.title, ts.training_date 
                     FROM training_participants tp
                     JOIN training_sessions ts ON tp.training_id = ts.id
                     WHERE tp.employee_id = ? AND ts.type = 'orientation'
                     ORDER BY ts.training_date DESC LIMIT 1";
    $current_stmt = $connections->prepare($current_query);
    $current_stmt->execute([$onboarding['employee_record_id']]);
    $current_training = $current_stmt->fetch();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HR1 - Company Orientation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="bg-gray-50 min-h-screen">
    <div class="flex">
        <?php include 'sidebar.php'; ?>
        
        <div class="flex-1 p-6">
            <!-- Header -->
            <div class="flex justify-between items-center mb-6">
                <div>
                    <h1 class="text-2xl font-bold text-gray-800">Company Orientation</h1>
                    <p class="text-gray-600">
                        <?php echo htmlspecialchars($onboarding['first_name'] . ' ' . $onboarding['last_name']); ?> - 
                        <?php echo htmlspecialchars($onboarding['job_position']); ?>
                    </p>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="view_onboarding.php?id=<?php echo $id; ?>" 
                       class="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 flex items-center">
                        <i data-lucide="arrow-left" class="w-4 h-4 mr-2"></i>
                        Back to Onboarding
                    </a>
                    <?php include 'profile_dropdown.php'; ?>
                </div>
            </div>

            <?php if (isset($_SESSION['success'])): ?>
            <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-6">
                <div class="flex items-center">
                    <i data-lucide="check-circle" class="w-5 h-5 mr-2"></i>
                    <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                </div>
            </div>
            <?php endif; ?>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <!-- Main Content -->
                <div class="lg:col-span-2">
                    <!-- Current Status -->
                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
                        <h2 class="text-xl font-bold text-gray-800 mb-4">Orientation Details</h2>
                        <form method="POST">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Orientation Date</label>
                                    <input type="date" name="orientation_date" 
                                           class="w-full border border-gray-300 rounded-lg p-2"
                                           value="<?php echo !empty($onboarding['orientation_date']) ? date('Y-m-d', strtotime($onboarding['orientation_date'])) : ''; ?>">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Trainer/Facilitator</label>
                                    <input type="text" name="orientation_trainer" 
                                           class="w-full border border-gray-300 rounded-lg p-2"
                                           value="<?php echo htmlspecialchars($onboarding['orientation_trainer'] ?? ''); ?>"
                                           placeholder="Enter trainer name">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Location</label>
                                    <input type="text" name="orientation_location" 
                                           class="w-full border border-gray-300 rounded-lg p-2"
                                           value="<?php echo htmlspecialchars($onboarding['orientation_location'] ?? ''); ?>"
                                           placeholder="Training room or venue">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Score/Evaluation</label>
                                    <input type="number" name="orientation_score" min="0" max="100" step="1"
                                           class="w-full border border-gray-300 rounded-lg p-2"
                                           value="<?php echo htmlspecialchars($onboarding['orientation_score'] ?? ''); ?>"
                                           placeholder="0-100">
                                </div>
                            </div>

                            <!-- Training Session Selection -->
                            <div class="mb-6">
                                <label class="block text-sm font-medium text-gray-700 mb-2">Schedule Training Session</label>
                                <select name="training_id" class="w-full border border-gray-300 rounded-lg p-2">
                                    <option value="">Select Training Session</option>
                                    <?php foreach ($training_sessions as $session): ?>
                                    <option value="<?php echo $session['id']; ?>" 
                                            <?php echo ($current_training['training_id'] ?? '') == $session['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($session['title']); ?> - 
                                        <?php echo date('M d, Y', strtotime($session['training_date'])); ?> 
                                        (<?php echo $session['start_time']; ?> to <?php echo $session['end_time']; ?>)
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                                <p class="text-sm text-gray-500 mt-1">Select a scheduled orientation session</p>
                            </div>

                            <div class="flex items-center mb-4">
                                <input type="checkbox" name="orientation_complete" id="orientation_complete" value="1" 
                                       class="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                                       <?php echo $onboarding['orientation_complete'] ? 'checked' : ''; ?>>
                                <label for="orientation_complete" class="ml-2 block text-sm font-medium text-gray-700">
                                    Mark orientation as complete
                                </label>
                            </div>
                            
                            <div class="mb-4">
                                <label class="block text-sm font-medium text-gray-700 mb-2">Notes</label>
                                <textarea name="orientation_notes" rows="3" 
                                          class="w-full border border-gray-300 rounded-lg p-2"
                                          placeholder="Add orientation notes..."><?php echo htmlspecialchars($onboarding['orientation_notes'] ?? ''); ?></textarea>
                            </div>
                            
                            <button type="submit" name="update_orientation"
                                    class="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 font-medium">
                                <i data-lucide="save" class="w-5 h-5 inline mr-2"></i>
                                Update Orientation Details
                            </button>
                        </form>
                    </div>

                    <!-- Attendance Management -->
                    <?php if ($current_training): ?>
                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                        <h3 class="text-lg font-semibold mb-4">Attendance Management</h3>
                        <form method="POST">
                            <input type="hidden" name="training_id" value="<?php echo $current_training['training_id']; ?>">
                            
                            <div class="mb-4">
                                <p class="text-sm text-gray-500">Training Session</p>
                                <p class="font-medium"><?php echo htmlspecialchars($current_training['title']); ?></p>
                                <p class="text-sm text-gray-600"><?php echo date('M d, Y', strtotime($current_training['training_date'])); ?></p>
                            </div>
                            
                            <div class="mb-4">
                                <label class="block text-sm font-medium text-gray-700 mb-2">Attendance Status</label>
                                <select name="attendance_status" class="w-full border border-gray-300 rounded-lg p-2">
                                    <option value="registered" <?php echo $current_training['attendance_status'] == 'registered' ? 'selected' : ''; ?>>Registered</option>
                                    <option value="attended" <?php echo $current_training['attendance_status'] == 'attended' ? 'selected' : ''; ?>>Attended</option>
                                    <option value="absent" <?php echo $current_training['attendance_status'] == 'absent' ? 'selected' : ''; ?>>Absent</option>
                                    <option value="excused" <?php echo $current_training['attendance_status'] == 'excused' ? 'selected' : ''; ?>>Excused</option>
                                </select>
                            </div>
                            
                            <div class="mb-4">
                                <label class="block text-sm font-medium text-gray-700 mb-2">Feedback/Notes</label>
                                <textarea name="attendance_notes" rows="3" 
                                          class="w-full border border-gray-300 rounded-lg p-2"
                                          placeholder="Add attendance notes..."><?php echo htmlspecialchars($current_training['feedback'] ?? ''); ?></textarea>
                            </div>
                            
                            <button type="submit" name="mark_attendance"
                                    class="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700">
                                <i data-lucide="clipboard-check" class="w-4 h-4 inline mr-2"></i>
                                Update Attendance
                            </button>
                        </form>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Right Column -->
                <div class="space-y-6">
                    <!-- Status -->
                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                        <h3 class="text-lg font-semibold mb-4">Orientation Status</h3>
                        <div class="space-y-4">
                            <div class="flex justify-between items-center">
                                <span class="text-gray-600">Completion Status</span>
                                <span class="px-3 py-1 rounded-full text-sm font-medium 
                                    <?php echo $onboarding['orientation_complete'] ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'; ?>">
                                    <?php echo $onboarding['orientation_complete'] ? 'Complete' : 'Pending'; ?>
                                </span>
                            </div>
                            
                            <?php if (!empty($onboarding['orientation_date'])): ?>
                            <div class="border-t pt-4">
                                <p class="text-sm text-gray-500">Orientation Date</p>
                                <p class="font-medium"><?php echo date('M d, Y', strtotime($onboarding['orientation_date'])); ?></p>
                            </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($onboarding['orientation_trainer'])): ?>
                            <div class="border-t pt-4">
                                <p class="text-sm text-gray-500">Trainer</p>
                                <p class="font-medium"><?php echo htmlspecialchars($onboarding['orientation_trainer']); ?></p>
                            </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($onboarding['orientation_score'])): ?>
                            <div class="border-t pt-4">
                                <p class="text-sm text-gray-500">Evaluation Score</p>
                                <div class="flex items-center">
                                    <span class="font-medium"><?php echo $onboarding['orientation_score']; ?>%</span>
                                    <div class="ml-2 w-24 bg-gray-200 rounded-full h-2">
                                        <div class="bg-blue-600 h-2 rounded-full" 
                                             style="width: <?php echo min($onboarding['orientation_score'], 100); ?>%"></div>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Upcoming Sessions -->
                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                        <h3 class="text-lg font-semibold mb-4">Upcoming Orientation Sessions</h3>
                        <div class="space-y-3">
                            <?php if (empty($training_sessions)): ?>
                            <p class="text-gray-500 text-sm">No upcoming orientation sessions scheduled.</p>
                            <?php else: ?>
                            <?php foreach ($training_sessions as $session): ?>
                            <div class="border border-gray-200 rounded-lg p-3">
                                <p class="font-medium text-sm"><?php echo htmlspecialchars($session['title']); ?></p>
                                <p class="text-xs text-gray-500 mt-1">
                                    <i data-lucide="calendar" class="w-3 h-3 inline mr-1"></i>
                                    <?php echo date('M d, Y', strtotime($session['training_date'])); ?>
                                </p>
                                <p class="text-xs text-gray-500">
                                    <i data-lucide="clock" class="w-3 h-3 inline mr-1"></i>
                                    <?php echo $session['start_time']; ?> - <?php echo $session['end_time']; ?>
                                </p>
                                <p class="text-xs text-gray-500">
                                    <i data-lucide="map-pin" class="w-3 h-3 inline mr-1"></i>
                                    <?php echo htmlspecialchars($session['location']); ?>
                                </p>
                                <?php if ($session['is_registered']): ?>
                                <span class="inline-block mt-2 px-2 py-1 text-xs bg-green-100 text-green-800 rounded-full">
                                    Registered
                                </span>
                                <?php endif; ?>
                            </div>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Orientation Checklist -->
                    <div class="bg-blue-50 border border-blue-200 rounded-xl p-6">
                        <h3 class="text-lg font-semibold mb-2 text-blue-800">Orientation Agenda</h3>
                        <ul class="space-y-2 text-blue-700 text-sm">
                            <li class="flex items-start">
                                <i data-lucide="check-circle" class="w-4 h-4 mr-2 mt-0.5 text-blue-600"></i>
                                <span>Company History & Culture</span>
                            </li>
                            <li class="flex items-start">
                                <i data-lucide="check-circle" class="w-4 h-4 mr-2 mt-0.5 text-blue-600"></i>
                                <span>Organizational Structure</span>
                            </li>
                            <li class="flex items-start">
                                <i data-lucide="check-circle" class="w-4 h-4 mr-2 mt-0.5 text-blue-600"></i>
                                <span>Policies & Procedures</span>
                            </li>
                            <li class="flex items-start">
                                <i data-lucide="check-circle" class="w-4 h-4 mr-2 mt-0.5 text-blue-600"></i>
                                <span>Benefits Overview</span>
                            </li>
                            <li class="flex items-start">
                                <i data-lucide="check-circle" class="w-4 h-4 mr-2 mt-0.5 text-blue-600"></i>
                                <span>Safety & Security Protocols</span>
                            </li>
                            <li class="flex items-start">
                                <i data-lucide="check-circle" class="w-4 h-4 mr-2 mt-0.5 text-blue-600"></i>
                                <span>Department Introduction</span>
                            </li>
                            <li class="flex items-start">
                                <i data-lucide="check-circle" class="w-4 h-4 mr-2 mt-0.5 text-blue-600"></i>
                                <span>Systems & Tools Training</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener("DOMContentLoaded", () => {
        lucide.createIcons();
        
        // Auto-fill today's date if marking as complete
        const completeCheckbox = document.querySelector('#orientation_complete');
        const dateField = document.querySelector('input[name="orientation_date"]');
        
        if (completeCheckbox && dateField) {
            completeCheckbox.addEventListener('change', function() {
                if (this.checked && !dateField.value) {
                    dateField.valueAsDate = new Date();
                }
            });
        }
    });
    </script>
</body>
</html>