<?php
// email_functions.php – with fallback to PHP mail()
require_once 'connections.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if (!function_exists('sendEmailViaSMTP')) {
    function sendEmailViaSMTP($to, $subject, $htmlMessage, $isHtml = true, $fromEmail = null, $fromName = null) {
        if ($fromEmail === null) $fromEmail = SMTP_FROM_EMAIL;
        if ($fromName === null) $fromName = SMTP_FROM_NAME;
        
        // First attempt: SMTP
        $mail = new PHPMailer(true);
        $smtpSuccess = false;
        try {
            $mail->isSMTP();
            $mail->Host       = SMTP_HOST;
            $mail->SMTPAuth   = true;
            $mail->Username   = SMTP_USERNAME;
            $mail->Password   = SMTP_PASSWORD;
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; // SSL for port 465
            $mail->Port       = SMTP_PORT;
            
            $mail->setFrom($fromEmail, $fromName);
            $mail->addAddress($to);
            $mail->isHTML($isHtml);
            $mail->Subject = $subject;
            $mail->Body    = $htmlMessage;
            if (!$isHtml) {
                $mail->AltBody = strip_tags($htmlMessage);
            }
            
            $mail->send();
            $smtpSuccess = true;
            error_log("Email sent via SMTP to $to");
        } catch (Exception $e) {
            error_log("SMTP failed: " . $mail->ErrorInfo);
            // If the error is a network error (e.g., "Network is unreachable"), fallback to mail()
            if (strpos($mail->ErrorInfo, 'Network is unreachable') !== false || strpos($mail->ErrorInfo, 'Could not connect') !== false) {
                error_log("Falling back to PHP mail() function");
                $smtpSuccess = false;
            } else {
                // Other SMTP error – still return false
                return false;
            }
        }
        
        // If SMTP succeeded, return true
        if ($smtpSuccess) return true;
        
        // Fallback to PHP's mail() function
        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        $headers .= "From: $fromName <$fromEmail>\r\n";
        
        $plainMessage = $isHtml ? strip_tags($htmlMessage) : $htmlMessage;
        $mailResult = mail($to, $subject, $isHtml ? $htmlMessage : $plainMessage, $headers);
        
        if ($mailResult) {
            error_log("Email sent via PHP mail() to $to");
            return true;
        } else {
            error_log("PHP mail() also failed to send to $to");
            return false;
        }
    }
}

if (!function_exists('generateOtp')) {
    function generateOtp() {
        return str_pad(random_int(0, 999999), OTP_LENGTH, '0', STR_PAD_LEFT);
    }
}

if (!function_exists('sendOtpEmail')) {
    function sendOtpEmail($email, $name, $otp) {
        $subject = "Your HR1 Login OTP Code";
        $message = '
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .otp-code { 
                    font-size: 32px; 
                    font-weight: bold; 
                    color: #004AAD;
                    letter-spacing: 5px;
                    text-align: center;
                    margin: 20px 0;
                    padding: 15px;
                    background: #f0f7ff;
                    border-radius: 8px;
                    border: 2px dashed #004AAD;
                }
                .expiry { color: #666; font-size: 14px; }
                .footer { margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; color: #777; }
            </style>
        </head>
        <body>
            <div class="container">
                <h2>HR1 Login Verification</h2>
                <p>Hello ' . htmlspecialchars($name) . ',</p>
                <p>Your One-Time Password (OTP) for HR1 login is:</p>
                <div class="otp-code">' . $otp . '</div>
                <p class="expiry">This OTP is valid for ' . OTP_EXPIRY_MINUTES . ' minutes.</p>
                <p>If you didn\'t request this OTP, please ignore this email.</p>
                <div class="footer">
                    <p>Best regards,<br>HR1 Team</p>
                </div>
            </div>
        </body>
        </html>';
        return sendEmailViaSMTP($email, $subject, $message, true, SMTP_FROM_EMAIL, SMTP_FROM_NAME);
    }
}
?>