<?php
// File: hr_analytics_dashboard.php
// Comprehensive HR Analytics Dashboard - FULLY RESPONSIVE with Weather Widget
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

// Helper function to safely get count from query
function fetchCount($pdo, $sql, $params = []) {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return (int) $stmt->fetchColumn();
}

// Initialize arrays for dashboard data
$dashboard = [];

try {
    // ========== 1. RECRUITMENT METRICS ==========
    $dashboard['job_requests'] = [
        'total' => fetchCount($connections, "SELECT COUNT(*) FROM job_requests WHERE is_active = 1"),
        'pending' => fetchCount($connections, "SELECT COUNT(*) FROM job_requests WHERE overall_status = 'pending' AND is_active = 1"),
        'approved' => fetchCount($connections, "SELECT COUNT(*) FROM job_requests WHERE overall_status = 'approved' AND is_active = 1"),
        'rejected' => fetchCount($connections, "SELECT COUNT(*) FROM job_requests WHERE overall_status = 'rejected' AND is_active = 1")
    ];
    
    $dashboard['job_postings'] = [
        'total' => fetchCount($connections, "SELECT COUNT(*) FROM job_postings"),
        'active' => fetchCount($connections, "SELECT COUNT(*) FROM job_postings WHERE status = 'active'"),
        'closed' => fetchCount($connections, "SELECT COUNT(*) FROM job_postings WHERE status = 'closed'"),
        'draft' => fetchCount($connections, "SELECT COUNT(*) FROM job_postings WHERE status = 'draft'")
    ];
    
    $dashboard['applicants'] = [
        'total' => fetchCount($connections, "SELECT COUNT(*) FROM applicants"),
        'new' => fetchCount($connections, "SELECT COUNT(*) FROM applicants WHERE application_status = 'new'"),
        'reviewed' => fetchCount($connections, "SELECT COUNT(*) FROM applicants WHERE application_status = 'reviewed'"),
        'shortlisted' => fetchCount($connections, "SELECT COUNT(*) FROM applicants WHERE application_status = 'shortlisted'"),
        'interviewed' => fetchCount($connections, "SELECT COUNT(*) FROM applicants WHERE application_status = 'interviewed'"),
        'hired' => fetchCount($connections, "SELECT COUNT(*) FROM applicants WHERE application_status = 'hired'"),
        'rejected' => fetchCount($connections, "SELECT COUNT(*) FROM applicants WHERE application_status = 'rejected'")
    ];
    
    $dashboard['qualified'] = [
        'qualified_count' => fetchCount($connections, "SELECT COUNT(*) FROM applicants WHERE is_qualified = 1"),
        'avg_score' => fetchCount($connections, "SELECT AVG(qualification_score) FROM applicants WHERE qualification_score > 0") ?: 0,
        'auto_scheduled' => fetchCount($connections, "SELECT COUNT(*) FROM applicants WHERE auto_scheduled = 1")
    ];
    
    // ========== 2. INTERVIEW ANALYTICS ==========
    $dashboard['interviews'] = [
        'total' => fetchCount($connections, "SELECT COUNT(*) FROM interviews"),
        'scheduled' => fetchCount($connections, "SELECT COUNT(*) FROM interviews WHERE status = 'scheduled'"),
        'completed' => fetchCount($connections, "SELECT COUNT(*) FROM interviews WHERE status = 'completed'"),
        'cancelled' => fetchCount($connections, "SELECT COUNT(*) FROM interviews WHERE status = 'cancelled'"),
        'auto_scheduled' => fetchCount($connections, "SELECT COUNT(*) FROM interviews WHERE is_auto_scheduled = 1"),
        'upcoming' => fetchCount($connections, "SELECT COUNT(*) FROM interviews WHERE scheduled_date > NOW() AND status = 'scheduled'")
    ];
    
    $stmt = $connections->prepare("
        SELECT 
            SUM(CASE WHEN recommendation = 'hire' THEN 1 ELSE 0 END) as hired_recommend,
            SUM(CASE WHEN recommendation = 'reject' THEN 1 ELSE 0 END) as reject_recommend,
            SUM(CASE WHEN recommendation = 'maybe' THEN 1 ELSE 0 END) as maybe_recommend,
            COUNT(*) as total_eval
        FROM interview_evaluations
    ");
    $stmt->execute();
    $dashboard['interview_eval'] = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // ========== 3. ONBOARDING STATUS ==========
    $dashboard['onboarding'] = [
        'pending' => fetchCount($connections, "SELECT COUNT(*) FROM onboarding WHERE status = 'pending'"),
        'onboarding' => fetchCount($connections, "SELECT COUNT(*) FROM onboarding WHERE status = 'onboarding'"),
        'completed' => fetchCount($connections, "SELECT COUNT(*) FROM onboarding WHERE status = 'completed'"),
        'cancelled' => fetchCount($connections, "SELECT COUNT(*) FROM onboarding WHERE status = 'cancelled'"),
        'contract_pending' => fetchCount($connections, "SELECT COUNT(*) FROM onboarding WHERE contract_status = 'Pending HR' OR contract_status = 'HR Approved'"),
        'contract_completed' => fetchCount($connections, "SELECT COUNT(*) FROM onboarding WHERE contract_status = 'Completed'")
    ];
    
    // ========== 4. EMPLOYEE STATISTICS ==========
    $dashboard['employees'] = [
        'total' => fetchCount($connections, "SELECT COUNT(*) FROM employees"),
        'active' => fetchCount($connections, "SELECT COUNT(*) FROM employees WHERE status = 'Active'"),
        'on_leave' => fetchCount($connections, "SELECT COUNT(*) FROM employees WHERE status = 'On Leave'"),
        'inactive' => fetchCount($connections, "SELECT COUNT(*) FROM employees WHERE status = 'Inactive'"),
        'terminated' => fetchCount($connections, "SELECT COUNT(*) FROM employees WHERE status = 'Terminated'"),
        'new_hires_month' => fetchCount($connections, "SELECT COUNT(*) FROM employees WHERE hire_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)"),
        'new_hires_year' => fetchCount($connections, "SELECT COUNT(*) FROM employees WHERE YEAR(hire_date) = YEAR(CURDATE())")
    ];
    
    $stmt = $connections->prepare("
        SELECT d.name, COUNT(e.id) as count 
        FROM departments d
        LEFT JOIN employees e ON d.id = e.department_id AND e.status = 'Active'
        GROUP BY d.id
        ORDER BY count DESC
    ");
    $stmt->execute();
    $dashboard['dept_distribution'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // ========== 5. PERFORMANCE REVIEWS ==========
    $dashboard['performance'] = [
        'total_reviews' => fetchCount($connections, "SELECT COUNT(*) FROM performance_reviews"),
        'completed' => fetchCount($connections, "SELECT COUNT(*) FROM performance_reviews WHERE status = 'completed'"),
        'scheduled' => fetchCount($connections, "SELECT COUNT(*) FROM performance_reviews WHERE status = 'scheduled'"),
        'avg_rating' => round(fetchCount($connections, "SELECT AVG(rating) FROM performance_reviews WHERE rating IS NOT NULL"), 2),
        'upcoming' => fetchCount($connections, "SELECT COUNT(*) FROM performance_reviews WHERE due_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)")
    ];
    
    $stmt = $connections->prepare("
        SELECT 
            CASE 
                WHEN rating >= 4.5 THEN 'Excellent (4.5-5.0)'
                WHEN rating >= 3.5 THEN 'Good (3.5-4.4)'
                WHEN rating >= 2.5 THEN 'Average (2.5-3.4)'
                ELSE 'Below Average (<2.5)'
            END as rating_group,
            COUNT(*) as count
        FROM performance_reviews
        WHERE rating IS NOT NULL
        GROUP BY rating_group
    ");
    $stmt->execute();
    $dashboard['rating_distribution'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // ========== 6. AWARDS & RECOGNITIONS ==========
    $dashboard['awards'] = [
        'total_awards' => fetchCount($connections, "SELECT COUNT(*) FROM awards WHERE status = 'active'"),
        'total_points' => fetchCount($connections, "SELECT SUM(points) FROM awards WHERE status = 'active'"),
        'recent_month' => fetchCount($connections, "SELECT COUNT(*) FROM awards WHERE award_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)"),
        'by_type' => $connections->query("SELECT award_type, COUNT(*) as count FROM awards WHERE status = 'active' GROUP BY award_type")->fetchAll(PDO::FETCH_ASSOC)
    ];
    
    $dashboard['recognitions'] = [
        'total' => fetchCount($connections, "SELECT COUNT(*) FROM recognitions WHERE status = 'published'"),
        'total_points' => fetchCount($connections, "SELECT SUM(points_awarded) FROM recognitions WHERE status = 'published'")
    ];
    
    // ========== 7. ATTENDANCE SUMMARY (last 30 days) ==========
    $stmt = $connections->prepare("
        SELECT 
            COUNT(*) as total_records,
            SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) as present,
            SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END) as absent,
            SUM(CASE WHEN status = 'late' THEN 1 ELSE 0 END) as late,
            SUM(CASE WHEN status = 'leave' THEN 1 ELSE 0 END) as on_leave,
            ROUND(AVG(hours_worked), 2) as avg_hours
        FROM attendance 
        WHERE attendance_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
    ");
    $stmt->execute();
    $dashboard['attendance'] = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // ========== 8. TRAINING SESSIONS ==========
    $dashboard['training'] = [
        'total_sessions' => fetchCount($connections, "SELECT COUNT(*) FROM training_sessions"),
        'scheduled' => fetchCount($connections, "SELECT COUNT(*) FROM training_sessions WHERE status = 'scheduled'"),
        'completed' => fetchCount($connections, "SELECT COUNT(*) FROM training_sessions WHERE status = 'completed'"),
        'total_participants' => fetchCount($connections, "SELECT COUNT(*) FROM training_participants"),
        'certificates_issued' => fetchCount($connections, "SELECT COUNT(*) FROM training_participants WHERE certificate_issued = 1")
    ];
    
    // ========== 9. RECENT ACTIVITY LOGS ==========
    $stmt = $connections->prepare("
        SELECT action, description, table_name, created_at 
        FROM activity_logs 
        ORDER BY created_at DESC 
        LIMIT 15
    ");
    $stmt->execute();
    $dashboard['recent_activity'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // ========== 10. TRENDS OVER TIME ==========
    $stmt = $connections->prepare("
        SELECT 
            DATE_FORMAT(applied_at, '%Y-%m') as month,
            COUNT(*) as count
        FROM applicants
        WHERE applied_at >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
        GROUP BY DATE_FORMAT(applied_at, '%Y-%m')
        ORDER BY month ASC
    ");
    $stmt->execute();
    $dashboard['applications_trend'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $stmt = $connections->prepare("
        SELECT 
            DATE_FORMAT(hire_date, '%Y-%m') as month,
            COUNT(*) as count
        FROM employees
        WHERE hire_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
        GROUP BY DATE_FORMAT(hire_date, '%Y-%m')
        ORDER BY month ASC
    ");
    $stmt->execute();
    $dashboard['hires_trend'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    error_log("Dashboard stats error: " . $e->getMessage());
    $dashboard['error'] = "Unable to load some statistics. Please try again later.";
}

// Prepare chart data as JSON
$applications_trend_labels = json_encode(array_column($dashboard['applications_trend'], 'month'));
$applications_trend_data = json_encode(array_column($dashboard['applications_trend'], 'count'));
$hires_trend_labels = json_encode(array_column($dashboard['hires_trend'], 'month'));
$hires_trend_data = json_encode(array_column($dashboard['hires_trend'], 'count'));
$dept_labels = json_encode(array_column($dashboard['dept_distribution'], 'name'));
$dept_data = json_encode(array_column($dashboard['dept_distribution'], 'count'));
$rating_labels = json_encode(array_column($dashboard['rating_distribution'], 'rating_group'));
$rating_data = json_encode(array_column($dashboard['rating_distribution'], 'count'));
$award_types = json_encode(array_column($dashboard['awards']['by_type'], 'award_type'));
$award_counts = json_encode(array_column($dashboard['awards']['by_type'], 'count'));
$interview_outcome_labels = json_encode(['Hire', 'Reject', 'Maybe']);
$interview_outcome_data = json_encode([
    (int)$dashboard['interview_eval']['hired_recommend'],
    (int)$dashboard['interview_eval']['reject_recommend'],
    (int)$dashboard['interview_eval']['maybe_recommend']
]);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>HR Analytics Dashboard | Responsive Insights</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* Responsive chart containers */
        .chart-container {
            position: relative;
            width: 100%;
            min-height: 200px;
        }
        canvas {
            max-width: 100%;
            height: auto !important;
        }
        /* Touch-friendly card hover effect */
        .stat-card {
            transition: transform 0.2s, box-shadow 0.2s;
            cursor: pointer;
        }
        @media (hover: hover) {
            .stat-card:hover {
                transform: translateY(-3px);
                box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1);
            }
        }
        /* Responsive text adjustments */
        @media (max-width: 640px) {
            .stat-card p.text-2xl {
                font-size: 1.5rem;
            }
            .section-title {
                font-size: 1.1rem;
            }
        }
        .badge {
            padding: 2px 8px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
            display: inline-block;
        }
        .badge-success { background: #d1fae5; color: #065f46; }
        .badge-warning { background: #fef3c7; color: #b45309; }
        .badge-danger { background: #fee2e2; color: #991b1b; }
        .badge-info { background: #dbeafe; color: #1e40af; }
        
        /* Weather widget specific styles */
        .weather-widget {
            transition: all 0.2s ease;
        }
        .weather-widget:hover {
            transform: scale(1.02);
            background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
        }
    </style>
</head>
<body class="bg-gray-100 font-sans">

<div class="flex flex-col md:flex-row h-screen">
    <!-- Sidebar (responsive - assuming sidebar.php is also responsive) -->
    <?php include 'sidebar.php'; ?>

    <!-- Main Content - Scrollable -->
    <div class="flex-1 overflow-y-auto">
        <main class="p-4 sm:p-6 space-y-6">
            <!-- Header with Weather Widget -->
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between border-b border-gray-200 pb-4 gap-3">
                <div>
                    <h1 class="text-xl sm:text-2xl font-bold text-gray-800">📊 HR Analytics Dashboard</h1>
                    <p class="text-xs sm:text-sm text-gray-500 mt-1">Complete overview of recruitment, employees, performance, and more</p>
                </div>
                <div class="flex items-center space-x-3">
                    <!-- WEATHER WIDGET - Enhanced for better visibility -->
                    <div id="weather-widget" class="weather-widget flex items-center space-x-3 bg-white/90 backdrop-blur-sm rounded-xl px-4 py-2 shadow-md border border-gray-200 min-w-[180px]">
                        <i data-lucide="cloud" class="w-6 h-6 text-blue-500"></i>
                        <span class="text-sm font-semibold text-gray-700">Loading weather...</span>
                    </div>
                    <?php include 'profile_dropdown.php'; ?>
                </div>
            </div>

            <?php if (isset($dashboard['error'])): ?>
                <div class="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded text-sm">
                    <p class="text-yellow-700"><?php echo htmlspecialchars($dashboard['error']); ?></p>
                </div>
            <?php endif; ?>

            <!-- ========== SECTION 1: KEY METRICS CARDS ========== -->
            <div>
                <h2 class="section-title text-base sm:text-lg font-semibold text-gray-800 border-l-4 border-blue-500 pl-3 mb-4">📈 Core Metrics</h2>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
                    <!-- Job Requests -->
                    <div class="bg-white rounded-lg shadow p-4 stat-card" onclick="window.location.href='job_requests.php'">
                        <div class="flex items-center justify-between">
                            <h3 class="text-xs sm:text-sm font-medium text-gray-500">Job Requests</h3>
                            <i data-lucide="file-text" class="w-5 h-5 text-blue-500"></i>
                        </div>
                        <p class="text-2xl sm:text-3xl font-bold mt-2"><?php echo $dashboard['job_requests']['total']; ?></p>
                        <div class="flex justify-between text-xs mt-2">
                            <span class="text-green-600">Approved: <?php echo $dashboard['job_requests']['approved']; ?></span>
                            <span class="text-amber-600">Pending: <?php echo $dashboard['job_requests']['pending']; ?></span>
                        </div>
                    </div>
                    <!-- Active Jobs -->
                    <div class="bg-white rounded-lg shadow p-4 stat-card" onclick="window.location.href='job_postings.php'">
                        <div class="flex items-center justify-between">
                            <h3 class="text-xs sm:text-sm font-medium text-gray-500">Active Jobs</h3>
                            <i data-lucide="briefcase" class="w-5 h-5 text-green-500"></i>
                        </div>
                        <p class="text-2xl sm:text-3xl font-bold mt-2"><?php echo $dashboard['job_postings']['active']; ?></p>
                        <p class="text-xs text-gray-500 mt-1">Total: <?php echo $dashboard['job_postings']['total']; ?></p>
                    </div>
                    <!-- Total Applicants -->
                    <div class="bg-white rounded-lg shadow p-4 stat-card" onclick="window.location.href='applicants.php'">
                        <div class="flex items-center justify-between">
                            <h3 class="text-xs sm:text-sm font-medium text-gray-500">Total Applicants</h3>
                            <i data-lucide="users" class="w-5 h-5 text-purple-500"></i>
                        </div>
                        <p class="text-2xl sm:text-3xl font-bold mt-2"><?php echo $dashboard['applicants']['total']; ?></p>
                        <p class="text-xs text-gray-500 mt-1">New: <?php echo $dashboard['applicants']['new']; ?> | Hired: <?php echo $dashboard['applicants']['hired']; ?></p>
                    </div>
                    <!-- Qualified Rate -->
                    <div class="bg-white rounded-lg shadow p-4 stat-card">
                        <div class="flex items-center justify-between">
                            <h3 class="text-xs sm:text-sm font-medium text-gray-500">Qualified Rate</h3>
                            <i data-lucide="star" class="w-5 h-5 text-yellow-500"></i>
                        </div>
                        <?php $qualifRate = $dashboard['applicants']['total'] > 0 ? round(($dashboard['qualified']['qualified_count'] / $dashboard['applicants']['total']) * 100) : 0; ?>
                        <p class="text-2xl sm:text-3xl font-bold mt-2"><?php echo $qualifRate; ?>%</p>
                        <p class="text-xs text-gray-500">Avg Score: <?php echo round($dashboard['qualified']['avg_score']); ?>/100</p>
                    </div>
                    <!-- Active Employees -->
                    <div class="bg-white rounded-lg shadow p-4 stat-card" onclick="window.location.href='employees.php'">
                        <div class="flex items-center justify-between">
                            <h3 class="text-xs sm:text-sm font-medium text-gray-500">Active Employees</h3>
                            <i data-lucide="users-round" class="w-5 h-5 text-indigo-500"></i>
                        </div>
                        <p class="text-2xl sm:text-3xl font-bold mt-2"><?php echo $dashboard['employees']['active']; ?></p>
                        <p class="text-xs text-gray-500">On Leave: <?php echo $dashboard['employees']['on_leave']; ?></p>
                    </div>
                </div>
            </div>

            <!-- ========== SECTION 2: RECRUITMENT FUNNEL & INTERVIEWS ========== -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <!-- Recruitment Funnel -->
                <div class="bg-white rounded-lg shadow p-5">
                    <h3 class="font-semibold text-gray-800 mb-3 flex items-center text-sm sm:text-base"><i data-lucide="funnel" class="w-5 h-5 mr-2 text-blue-500"></i> Recruitment Funnel</h3>
                    <div class="space-y-3">
                        <?php
                        $funnel = [
                            'Job Requests' => $dashboard['job_requests']['total'],
                            'Active Postings' => $dashboard['job_postings']['active'],
                            'Applicants' => $dashboard['applicants']['total'],
                            'Shortlisted' => $dashboard['applicants']['shortlisted'],
                            'Interviewed' => $dashboard['applicants']['interviewed'],
                            'Hired' => $dashboard['applicants']['hired']
                        ];
                        $maxVal = max($funnel) ?: 1;
                        foreach ($funnel as $label => $value):
                            $width = ($value / $maxVal) * 100;
                        ?>
                        <div>
                            <div class="flex justify-between text-xs sm:text-sm">
                                <span><?php echo $label; ?></span>
                                <span class="font-semibold"><?php echo $value; ?></span>
                            </div>
                            <div class="w-full bg-gray-200 rounded-full h-2 mt-1">
                                <div class="bg-blue-500 h-2 rounded-full" style="width: <?php echo $width; ?>%"></div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Interview Analytics -->
                <div class="bg-white rounded-lg shadow p-5">
                    <h3 class="font-semibold text-gray-800 mb-3 flex items-center text-sm sm:text-base"><i data-lucide="calendar-check" class="w-5 h-5 mr-2 text-green-500"></i> Interview Analytics</h3>
                    <div class="grid grid-cols-2 gap-3 mb-4">
                        <div class="text-center p-2 sm:p-3 bg-gray-50 rounded">
                            <p class="text-xl sm:text-2xl font-bold"><?php echo $dashboard['interviews']['total']; ?></p>
                            <p class="text-xs text-gray-500">Total Interviews</p>
                        </div>
                        <div class="text-center p-2 sm:p-3 bg-gray-50 rounded">
                            <p class="text-xl sm:text-2xl font-bold"><?php echo $dashboard['interviews']['scheduled']; ?></p>
                            <p class="text-xs text-gray-500">Scheduled</p>
                        </div>
                        <div class="text-center p-2 sm:p-3 bg-gray-50 rounded">
                            <p class="text-xl sm:text-2xl font-bold"><?php echo $dashboard['interviews']['completed']; ?></p>
                            <p class="text-xs text-gray-500">Completed</p>
                        </div>
                        <div class="text-center p-2 sm:p-3 bg-gray-50 rounded">
                            <p class="text-xl sm:text-2xl font-bold"><?php echo $dashboard['interviews']['upcoming']; ?></p>
                            <p class="text-xs text-gray-500">Upcoming (7d)</p>
                        </div>
                    </div>
                    <div class="chart-container">
                        <canvas id="interviewOutcomeChart"></canvas>
                    </div>
                </div>
            </div>

            <!-- ========== SECTION 3: TREND CHARTS ========== -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div class="bg-white rounded-lg shadow p-5">
                    <h3 class="font-semibold text-gray-800 mb-3 text-sm sm:text-base">📅 Applications Trend (Last 6 Months)</h3>
                    <div class="chart-container">
                        <canvas id="applicationsTrendChart"></canvas>
                    </div>
                </div>
                <div class="bg-white rounded-lg shadow p-5">
                    <h3 class="font-semibold text-gray-800 mb-3 text-sm sm:text-base">🎉 Hires Trend (Last 6 Months)</h3>
                    <div class="chart-container">
                        <canvas id="hiresTrendChart"></canvas>
                    </div>
                </div>
            </div>

            <!-- ========== SECTION 4: ONBOARDING & EMPLOYEE DISTRIBUTION ========== -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div class="bg-white rounded-lg shadow p-5">
                    <h3 class="font-semibold text-gray-800 mb-3 flex items-center text-sm sm:text-base"><i data-lucide="clipboard-list" class="w-5 h-5 mr-2 text-teal-500"></i> Onboarding Status</h3>
                    <div class="grid grid-cols-2 gap-3 text-center">
                        <div class="p-2 sm:p-3 bg-yellow-50 rounded">
                            <p class="text-xl sm:text-2xl font-bold text-yellow-700"><?php echo $dashboard['onboarding']['pending']; ?></p>
                            <p class="text-xs">Pending</p>
                        </div>
                        <div class="p-2 sm:p-3 bg-blue-50 rounded">
                            <p class="text-xl sm:text-2xl font-bold text-blue-700"><?php echo $dashboard['onboarding']['onboarding']; ?></p>
                            <p class="text-xs">In Progress</p>
                        </div>
                        <div class="p-2 sm:p-3 bg-green-50 rounded">
                            <p class="text-xl sm:text-2xl font-bold text-green-700"><?php echo $dashboard['onboarding']['completed']; ?></p>
                            <p class="text-xs">Completed</p>
                        </div>
                        <div class="p-2 sm:p-3 bg-purple-50 rounded">
                            <p class="text-xl sm:text-2xl font-bold text-purple-700"><?php echo $dashboard['onboarding']['contract_pending']; ?></p>
                            <p class="text-xs">Contract Pending</p>
                        </div>
                    </div>
                </div>
                <div class="bg-white rounded-lg shadow p-5">
                    <h3 class="font-semibold text-gray-800 mb-3 text-sm sm:text-base">👥 Employees by Department</h3>
                    <div class="chart-container">
                        <canvas id="deptChart"></canvas>
                    </div>
                </div>
            </div>

            <!-- ========== SECTION 5: PERFORMANCE & AWARDS ========== -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div class="bg-white rounded-lg shadow p-5">
                    <h3 class="font-semibold text-gray-800 mb-3 text-sm sm:text-base">⭐ Performance Review Summary</h3>
                    <div class="flex justify-between mb-4">
                        <div class="text-center">
                            <p class="text-xl sm:text-2xl font-bold"><?php echo $dashboard['performance']['total_reviews']; ?></p>
                            <p class="text-xs text-gray-500">Total Reviews</p>
                        </div>
                        <div class="text-center">
                            <p class="text-xl sm:text-2xl font-bold"><?php echo $dashboard['performance']['completed']; ?></p>
                            <p class="text-xs text-gray-500">Completed</p>
                        </div>
                        <div class="text-center">
                            <p class="text-xl sm:text-2xl font-bold"><?php echo $dashboard['performance']['avg_rating']; ?></p>
                            <p class="text-xs text-gray-500">Avg Rating</p>
                        </div>
                    </div>
                    <div class="chart-container">
                        <canvas id="ratingChart"></canvas>
                    </div>
                </div>
                <div class="bg-white rounded-lg shadow p-5">
                    <h3 class="font-semibold text-gray-800 mb-3 text-sm sm:text-base">🏆 Awards & Recognitions</h3>
                    <div class="grid grid-cols-2 gap-3 mb-4">
                        <div class="bg-gradient-to-r from-amber-50 to-amber-100 p-2 sm:p-3 rounded text-center">
                            <p class="text-xl sm:text-2xl font-bold text-amber-700"><?php echo $dashboard['awards']['total_awards']; ?></p>
                            <p class="text-xs">Total Awards</p>
                        </div>
                        <div class="bg-gradient-to-r from-emerald-50 to-emerald-100 p-2 sm:p-3 rounded text-center">
                            <p class="text-xl sm:text-2xl font-bold text-emerald-700"><?php echo number_format($dashboard['awards']['total_points']); ?></p>
                            <p class="text-xs">Points Awarded</p>
                        </div>
                    </div>
                    <div class="chart-container">
                        <canvas id="awardChart"></canvas>
                    </div>
                </div>
            </div>

            <!-- ========== SECTION 6: ATTENDANCE & TRAINING ========== -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div class="bg-white rounded-lg shadow p-5">
                    <h3 class="font-semibold text-gray-800 mb-3 text-sm sm:text-base">📆 Attendance (Last 30 Days)</h3>
                    <?php 
                        $att = $dashboard['attendance'];
                        $totalDays = max(1, $att['total_records']);
                        $presentRate = round(($att['present'] / $totalDays) * 100, 1);
                    ?>
                    <div class="mb-3 flex flex-wrap justify-between text-xs sm:text-sm gap-2">
                        <span>Present: <?php echo $att['present']; ?></span>
                        <span>Absent: <?php echo $att['absent']; ?></span>
                        <span>Late: <?php echo $att['late']; ?></span>
                        <span>On Leave: <?php echo $att['on_leave']; ?></span>
                    </div>
                    <div class="w-full bg-gray-200 rounded-full h-3">
                        <div class="bg-green-500 h-3 rounded-full" style="width: <?php echo $presentRate; ?>%"></div>
                    </div>
                    <p class="text-xs text-gray-500 mt-2">Attendance Rate: <?php echo $presentRate; ?>% | Avg Hours: <?php echo $att['avg_hours'] ?? 0; ?></p>
                </div>
                <div class="bg-white rounded-lg shadow p-5">
                    <h3 class="font-semibold text-gray-800 mb-3 text-sm sm:text-base">📚 Training Overview</h3>
                    <div class="grid grid-cols-2 gap-3">
                        <div class="text-center p-2 bg-gray-50 rounded">
                            <p class="text-xl sm:text-2xl font-bold"><?php echo $dashboard['training']['total_sessions']; ?></p>
                            <p class="text-xs">Sessions</p>
                        </div>
                        <div class="text-center p-2 bg-gray-50 rounded">
                            <p class="text-xl sm:text-2xl font-bold"><?php echo $dashboard['training']['total_participants']; ?></p>
                            <p class="text-xs">Participants</p>
                        </div>
                        <div class="text-center p-2 bg-gray-50 rounded">
                            <p class="text-xl sm:text-2xl font-bold"><?php echo $dashboard['training']['certificates_issued']; ?></p>
                            <p class="text-xs">Certificates</p>
                        </div>
                        <div class="text-center p-2 bg-gray-50 rounded">
                            <p class="text-xl sm:text-2xl font-bold"><?php echo $dashboard['training']['completed']; ?></p>
                            <p class="text-xs">Completed</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ========== SECTION 7: RECENT ACTIVITY LOG ========== -->
            <div class="bg-white rounded-lg shadow p-5">
                <h3 class="font-semibold text-gray-800 mb-3 flex items-center text-sm sm:text-base"><i data-lucide="activity" class="w-5 h-5 mr-2 text-gray-500"></i> Recent System Activity</h3>
                <div class="overflow-x-auto -mx-2 px-2">
                    <table class="min-w-full text-xs sm:text-sm">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-2 sm:px-4 py-2 text-left">Action</th>
                                <th class="px-2 sm:px-4 py-2 text-left">Description</th>
                                <th class="px-2 sm:px-4 py-2 text-left hidden sm:table-cell">Table</th>
                                <th class="px-2 sm:px-4 py-2 text-left">Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($dashboard['recent_activity'] as $log): ?>
                            <tr class="border-b">
                                <td class="px-2 sm:px-4 py-2"><span class="badge badge-info"><?php echo htmlspecialchars($log['action']); ?></span></td>
                                <td class="px-2 sm:px-4 py-2 max-w-[150px] sm:max-w-none truncate"><?php echo htmlspecialchars(substr($log['description'], 0, 50)); ?></td>
                                <td class="px-2 sm:px-4 py-2 hidden sm:table-cell"><?php echo htmlspecialchars($log['table_name'] ?? '-'); ?></td>
                                <td class="px-2 sm:px-4 py-2 text-gray-500 whitespace-nowrap"><?php echo date('M j, g:i a', strtotime($log['created_at'])); ?></td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if (empty($dashboard['recent_activity'])): ?>
                            <tr><td colspan="4" class="text-center py-4 text-gray-500">No recent activity found</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
    lucide.createIcons();

    // Helper to make charts responsive - resize on window resize
    function initCharts() {
        // Applications Trend Chart
        const appCtx = document.getElementById('applicationsTrendChart').getContext('2d');
        new Chart(appCtx, {
            type: 'line',
            data: {
                labels: <?php echo $applications_trend_labels; ?>,
                datasets: [{
                    label: 'Applications',
                    data: <?php echo $applications_trend_data; ?>,
                    borderColor: '#3b82f6',
                    backgroundColor: 'rgba(59,130,246,0.1)',
                    tension: 0.3,
                    fill: true
                }]
            },
            options: { responsive: true, maintainAspectRatio: true }
        });

        // Hires Trend Chart
        const hiresCtx = document.getElementById('hiresTrendChart').getContext('2d');
        new Chart(hiresCtx, {
            type: 'bar',
            data: {
                labels: <?php echo $hires_trend_labels; ?>,
                datasets: [{
                    label: 'New Hires',
                    data: <?php echo $hires_trend_data; ?>,
                    backgroundColor: '#10b981',
                    borderRadius: 6
                }]
            },
            options: { responsive: true, maintainAspectRatio: true }
        });

        // Department Distribution (Pie)
        const deptCtx = document.getElementById('deptChart').getContext('2d');
        new Chart(deptCtx, {
            type: 'pie',
            data: {
                labels: <?php echo $dept_labels; ?>,
                datasets: [{
                    data: <?php echo $dept_data; ?>,
                    backgroundColor: ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec489a', '#06b6d4']
                }]
            },
            options: { responsive: true, maintainAspectRatio: true, plugins: { legend: { position: 'right' } } }
        });

        // Performance Rating Distribution
        const ratingCtx = document.getElementById('ratingChart').getContext('2d');
        new Chart(ratingCtx, {
            type: 'doughnut',
            data: {
                labels: <?php echo $rating_labels; ?>,
                datasets: [{
                    data: <?php echo $rating_data; ?>,
                    backgroundColor: ['#22c55e', '#3b82f6', '#f59e0b', '#ef4444']
                }]
            },
            options: { responsive: true, maintainAspectRatio: true }
        });

        // Award Types Distribution (Horizontal Bar)
        const awardCtx = document.getElementById('awardChart').getContext('2d');
        new Chart(awardCtx, {
            type: 'bar',
            data: {
                labels: <?php echo $award_types; ?>,
                datasets: [{
                    label: 'Number of Awards',
                    data: <?php echo $award_counts; ?>,
                    backgroundColor: '#f97316'
                }]
            },
            options: { responsive: true, maintainAspectRatio: true, indexAxis: 'y' }
        });

        // Interview Outcome Chart
        const outcomeCtx = document.getElementById('interviewOutcomeChart').getContext('2d');
        new Chart(outcomeCtx, {
            type: 'pie',
            data: {
                labels: <?php echo $interview_outcome_labels; ?>,
                datasets: [{
                    data: <?php echo $interview_outcome_data; ?>,
                    backgroundColor: ['#10b981', '#ef4444', '#f59e0b']
                }]
            },
            options: { responsive: true, maintainAspectRatio: true, plugins: { legend: { position: 'bottom' } } }
        });
    }

    // ========== WEATHER WIDGET FUNCTIONALITY ==========
    function loadWeather() {
        const widget = document.getElementById('weather-widget');
        if (!widget) return;

        // Show loading state with larger spinner
        widget.innerHTML = `<i data-lucide="loader-2" class="w-6 h-6 text-blue-500 animate-spin"></i><span class="text-sm font-semibold text-gray-700">Fetching weather...</span>`;
        lucide.createIcons();

        // Try to get user's location
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    const lat = position.coords.latitude;
                    const lon = position.coords.longitude;
                    fetchWeather(`weather.php?lat=${lat}&lon=${lon}`);
                },
                (error) => {
                    console.warn('Geolocation error:', error);
                    // Fallback to default city
                    fetchWeather('weather.php?city=Manila');
                }
            );
        } else {
            // Geolocation not supported
            fetchWeather('weather.php?city=Manila');
        }
    }

    function fetchWeather(url) {
        fetch(url)
            .then(response => response.json())
            .then(data => {
                if (data.error) throw new Error(data.error);
                updateWeatherWidget(data);
            })
            .catch(error => {
                console.error('Weather fetch error:', error);
                const widget = document.getElementById('weather-widget');
                if (widget) {
                    widget.innerHTML = `<i data-lucide="cloud-off" class="w-6 h-6 text-red-500"></i><span class="text-sm font-semibold text-gray-700">Weather unavailable</span>`;
                    lucide.createIcons();
                }
            });
    }

    function updateWeatherWidget(data) {
        const widget = document.getElementById('weather-widget');
        if (!widget) return;

        // Choose a Lucide icon based on weather condition
        let iconName = 'cloud';
        const cond = data.condition.toLowerCase();
        if (cond.includes('clear')) iconName = 'sun';
        else if (cond.includes('rain')) iconName = 'cloud-rain';
        else if (cond.includes('snow')) iconName = 'cloud-snow';
        else if (cond.includes('thunder')) iconName = 'cloud-lightning';
        else if (cond.includes('drizzle')) iconName = 'cloud-drizzle';
        else if (cond.includes('mist') || cond.includes('fog')) iconName = 'cloud-fog';

        // Enhanced widget with larger text and icons
        widget.innerHTML = `
            <div class="flex items-center space-x-2">
                <i data-lucide="${iconName}" class="w-7 h-7 text-blue-600"></i>
                <div class="flex flex-col">
                    <span class="text-lg font-bold text-gray-800">${data.temp}°C</span>
                    <span class="text-xs text-gray-500">${data.condition}</span>
                </div>
                <div class="border-l border-gray-300 h-8 mx-2"></div>
                <div class="flex flex-col">
                    <span class="text-sm font-semibold text-gray-700">${data.city}</span>
                    <span class="text-xs text-gray-400">Feels like ${data.feels_like}°C</span>
                </div>
            </div>
        `;
        lucide.createIcons();
    }
    // ===========================================

    // Initialize charts and weather when DOM ready
    document.addEventListener('DOMContentLoaded', () => {
        initCharts();
        loadWeather();
        // Auto-refresh weather every 10 minutes
        setInterval(loadWeather, 600000);
    });
</script>
</body>
</html>