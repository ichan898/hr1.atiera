<?php
// File: employee_list.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

// Handle delete action
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    
    try {
        // Get employee info before deletion for logging
        $stmt = $connections->prepare("SELECT * FROM employees WHERE id = ?");
        $stmt->execute([$delete_id]);
        $employee = $stmt->fetch();
        
        if ($employee) {
            // Soft delete (update status to Inactive instead of actual deletion)
            $stmt = $connections->prepare("UPDATE employees SET status = 'Inactive', updated_at = NOW() WHERE id = ?");
            $stmt->execute([$delete_id]);
            
            // Log activity
            logActivity('employee_deleted', 
                "Deleted (inactivated) employee: {$employee['first_name']} {$employee['last_name']} ({$employee['employee_id']})",
                'employees', 
                $delete_id
            );
            
            $_SESSION['flash_message'] = [
                'type' => 'success',
                'message' => "Employee {$employee['employee_id']} has been deleted (inactivated) successfully!"
            ];
        } else {
            $_SESSION['flash_message'] = [
                'type' => 'error',
                'message' => 'Employee not found!'
            ];
        }
    } catch(PDOException $e) {
        error_log("Delete employee error: " . $e->getMessage());
        $_SESSION['flash_message'] = [
            'type' => 'error',
            'message' => 'Error deleting employee: ' . $e->getMessage()
        ];
    }
    
    header('Location: employee_list.php');
    exit;
}

// Handle bulk delete
if (isset($_POST['bulk_delete']) && isset($_POST['selected_employees'])) {
    $selected_ids = $_POST['selected_employees'];
    $count = 0;
    
    foreach ($selected_ids as $id) {
        $id = intval($id);
        try {
            // Soft delete (update status to Inactive)
            $stmt = $connections->prepare("UPDATE employees SET status = 'Inactive', updated_at = NOW() WHERE id = ?");
            $stmt->execute([$id]);
            $count++;
        } catch(PDOException $e) {
            error_log("Bulk delete employee error: " . $e->getMessage());
        }
    }
    
    if ($count > 0) {
        logActivity('employees_bulk_deleted', 
            "Bulk deleted (inactivated) {$count} employees",
            'employees', 
            0
        );
        
        $_SESSION['flash_message'] = [
            'type' => 'success',
            'message' => "Successfully deleted (inactivated) {$count} employee(s)!"
        ];
    }
    
    header('Location: employee_list.php');
    exit;
}

// Handle bulk status change
if (isset($_POST['bulk_status']) && isset($_POST['selected_employees']) && isset($_POST['new_status'])) {
    $selected_ids = $_POST['selected_employees'];
    $new_status = $_POST['new_status'];
    $count = 0;
    
    foreach ($selected_ids as $id) {
        $id = intval($id);
        try {
            $stmt = $connections->prepare("UPDATE employees SET status = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$new_status, $id]);
            $count++;
        } catch(PDOException $e) {
            error_log("Bulk status change error: " . $e->getMessage());
        }
    }
    
    if ($count > 0) {
        logActivity('employees_bulk_status_changed', 
            "Changed status to '{$new_status}' for {$count} employees",
            'employees', 
            0
        );
        
        $_SESSION['flash_message'] = [
            'type' => 'success',
            'message' => "Updated status to '{$new_status}' for {$count} employee(s)!"
        ];
    }
    
    header('Location: employee_list.php');
    exit;
}

// Handle quick status update
if (isset($_GET['quick_status']) && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $new_status = $_GET['quick_status'];
    
    try {
        $stmt = $connections->prepare("UPDATE employees SET status = ?, updated_at = NOW() WHERE id = ?");
        $stmt->execute([$new_status, $id]);
        
        logActivity('employee_status_quick_changed', 
            "Quick status change to '{$new_status}' for employee ID: {$id}",
            'employees', 
            $id
        );
        
        $_SESSION['flash_message'] = [
            'type' => 'success',
            'message' => "Employee status updated to '{$new_status}'!"
        ];
    } catch(PDOException $e) {
        error_log("Quick status change error: " . $e->getMessage());
        $_SESSION['flash_message'] = [
            'type' => 'error',
            'message' => 'Error updating status: ' . $e->getMessage()
        ];
    }
    
    header('Location: employee_list.php');
    exit;
}

// Get filters
$status = $_GET['status'] ?? '';
$department = $_GET['department'] ?? '';
$search = $_GET['search'] ?? '';
$sort_by = $_GET['sort_by'] ?? 'last_name';
$sort_order = $_GET['sort_order'] ?? 'ASC';

// Build filters array
$filters = [
    'status' => $status,
    'department' => $department,
    'search' => $search,
    'sort_by' => $sort_by,
    'sort_order' => $sort_order
];

// Get employees with direct query
try {
    $sql = "SELECT e.*, d.name as department_name 
            FROM employees e 
            LEFT JOIN departments d ON e.department_id = d.id 
            WHERE 1=1";
    
    $params = [];
    
    if (!empty($status)) {
        $sql .= " AND e.status = ?";
        $params[] = $status;
    } else {
        // Default: show all except Inactive (if you want to hide deleted)
        // $sql .= " AND e.status != 'Inactive'";
    }
    
    if (!empty($department)) {
        $sql .= " AND e.department_id = ?";
        $params[] = $department;
    }
    
    if (!empty($search)) {
        $sql .= " AND (e.first_name LIKE ? OR e.last_name LIKE ? OR e.email LIKE ? OR e.employee_id LIKE ?)";
        $searchTerm = "%$search%";
        $params[] = $searchTerm;
        $params[] = $searchTerm;
        $params[] = $searchTerm;
        $params[] = $searchTerm;
    }
    
    // Sorting
    $allowed_sort = ['id', 'last_name', 'first_name', 'hire_date', 'date_of_birth', 'employee_id'];
    $sort_by = in_array($sort_by, $allowed_sort) ? $sort_by : 'last_name';
    $sort_order = strtoupper($sort_order) === 'DESC' ? 'DESC' : 'ASC';
    
    $sql .= " ORDER BY e.$sort_by $sort_order";
    
    $stmt = $connections->prepare($sql);
    $stmt->execute($params);
    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch(PDOException $e) {
    error_log("Error getting employees: " . $e->getMessage());
    $employees = [];
}

// Get statistics
try {
    // Total employees
    $total_sql = "SELECT COUNT(*) as total FROM employees";
    $total_stmt = $connections->query($total_sql);
    $total = $total_stmt->fetchColumn();

    // Active employees
    $active_sql = "SELECT COUNT(*) as active FROM employees WHERE status = 'Active'";
    $active_stmt = $connections->query($active_sql);
    $active = $active_stmt->fetchColumn();

    // On probation (based on hire date - less than 6 months)
    $probation_sql = "SELECT COUNT(*) as probation FROM employees 
                      WHERE status = 'Active' 
                      AND hire_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)";
    $probation_stmt = $connections->query($probation_sql);
    $probation = $probation_stmt->fetchColumn();

    // On Leave
    $leave_sql = "SELECT COUNT(*) as on_leave FROM employees WHERE status = 'On Leave'";
    $leave_stmt = $connections->query($leave_sql);
    $on_leave = $leave_stmt->fetchColumn();

    // New hires (last 30 days)
    $new_hires_sql = "SELECT COUNT(*) as new_hires FROM employees 
                      WHERE hire_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) 
                      AND status = 'Active'";
    $new_hires_stmt = $connections->query($new_hires_sql);
    $new_hires = $new_hires_stmt->fetchColumn();

    $stats = [
        'total' => $total,
        'active' => $active,
        'probation' => $probation,
        'on_leave' => $on_leave,
        'new_hires' => $new_hires,
        'displayed' => count($employees)
    ];
    
} catch(PDOException $e) {
    error_log("Error getting employee stats: " . $e->getMessage());
    $stats = [
        'total' => 0,
        'active' => 0,
        'probation' => 0,
        'on_leave' => 0,
        'new_hires' => 0,
        'displayed' => 0
    ];
}

// Get departments for filter
try {
    $stmt = $connections->query("SELECT id, name FROM departments ORDER BY name");
    $departments = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    error_log("Error getting departments: " . $e->getMessage());
    $departments = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>HR1 - Employee Directory</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<style>
    .employee-card {
        transition: all 0.3s ease;
    }
    .employee-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
    }
    .view-mode-grid .table-view {
        display: none;
    }
    .view-mode-table .grid-view {
        display: none;
    }
    .status-active {
        background: linear-gradient(90deg, #10b981 0%, #34d399 100%);
    }
    .status-on-leave {
        background: linear-gradient(90deg, #3b82f6 0%, #60a5fa 100%);
    }
    .status-inactive {
        background: linear-gradient(90deg, #6b7280 0%, #9ca3af 100%);
    }
    .status-terminated {
        background: linear-gradient(90deg, #ef4444 0%, #f87171 100%);
    }
    .bulk-actions {
        transition: all 0.3s ease;
        max-height: 0;
        overflow: hidden;
    }
    .bulk-actions.active {
        max-height: 100px;
        padding: 1rem 0;
    }
</style>
</head>

<body class="h-screen bg-gray-50 font-sans">
<div class="flex h-full">
  
  <!-- Sidebar -->
  <?php include 'sidebar.php'; ?>
  
  <!-- Main Content -->
  <div class="flex-1 flex flex-col overflow-y-auto">
    <main class="p-6 space-y-6">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-gray-300 pb-4">
        <div>
          <h2 class="text-2xl font-bold text-gray-800">Employee Directory</h2>
          <p class="text-sm text-gray-600">Manage and view all employee information</p>
        </div>
        <div class="flex items-center space-x-4">
          <div class="flex space-x-2" id="viewModeToggle">
            <button onclick="setViewMode('grid')" class="px-3 py-2 rounded-lg bg-gray-200 hover:bg-gray-300">
              <i data-lucide="grid" class="w-4 h-4"></i>
            </button>
            <button onclick="setViewMode('table')" class="px-3 py-2 rounded-lg bg-gray-200 hover:bg-gray-300">
              <i data-lucide="table" class="w-4 h-4"></i>
            </button>
          </div>
          <!--<a href="employee_add.php" class="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">-->
          <!--  <i data-lucide="user-plus" class="w-4 h-4"></i>-->
          <!--  <span>Add Employee</span>-->
          <!--</a>-->
          <!--<a href="#" onclick="exportEmployees()" class="flex items-center space-x-2 px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300">-->
          <!--  <i data-lucide="download" class="w-4 h-4"></i>-->
          <!--  <span>Export</span>-->
          <!--</a>-->
          <?php include 'profile_dropdown.php'; ?>
        </div>
      </div>

      <!-- Flash Messages -->
      <?php if (isset($_SESSION['flash_message'])): ?>
        <div class="bg-<?php echo $_SESSION['flash_message']['type'] == 'success' ? 'green' : ($_SESSION['flash_message']['type'] == 'warning' ? 'yellow' : 'red'); ?>-50 border border-<?php echo $_SESSION['flash_message']['type'] == 'success' ? 'green' : ($_SESSION['flash_message']['type'] == 'warning' ? 'yellow' : 'red'); ?>-400 text-<?php echo $_SESSION['flash_message']['type'] == 'success' ? 'green' : ($_SESSION['flash_message']['type'] == 'warning' ? 'yellow' : 'red'); ?>-700 px-4 py-3 rounded-lg">
          <div class="flex items-center">
            <i data-lucide="<?php echo $_SESSION['flash_message']['type'] == 'success' ? 'check-circle' : ($_SESSION['flash_message']['type'] == 'warning' ? 'alert-triangle' : 'alert-circle'); ?>" class="w-5 h-5 mr-2"></i>
            <span><?php echo $_SESSION['flash_message']['message']; ?></span>
          </div>
        </div>
        <?php unset($_SESSION['flash_message']); ?>
      <?php endif; ?>

      <!-- Stats -->
      <div class="grid grid-cols-1 md:grid-cols-5 gap-6">
        <div class="bg-white p-6 rounded-lg shadow border">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-600">Total Employees</p>
              <p class="text-2xl font-bold text-gray-800"><?php echo $stats['total']; ?></p>
              <p class="text-xs text-gray-500 mt-1"><?php echo $stats['active']; ?> active</p>
            </div>
            <i data-lucide="users" class="w-8 h-8 text-blue-500"></i>
          </div>
        </div>
        
        <div class="bg-white p-6 rounded-lg shadow border">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-600">On Probation</p>
              <p class="text-2xl font-bold text-gray-800"><?php echo $stats['probation']; ?></p>
              <p class="text-xs text-gray-500 mt-1">Under evaluation</p>
            </div>
            <i data-lucide="clock" class="w-8 h-8 text-yellow-500"></i>
          </div>
        </div>
        
        <div class="bg-white p-6 rounded-lg shadow border">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-600">On Leave</p>
              <p class="text-2xl font-bold text-gray-800"><?php echo $stats['on_leave']; ?></p>
              <p class="text-xs text-gray-500 mt-1">Currently absent</p>
            </div>
            <i data-lucide="umbrella" class="w-8 h-8 text-blue-500"></i>
          </div>
        </div>
        
        <div class="bg-white p-6 rounded-lg shadow border">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-600">New Hires</p>
              <p class="text-2xl font-bold text-gray-800"><?php echo $stats['new_hires']; ?></p>
              <p class="text-xs text-gray-500 mt-1">Last 30 days</p>
            </div>
            <i data-lucide="user-check" class="w-8 h-8 text-green-500"></i>
          </div>
        </div>
        
        <div class="bg-white p-6 rounded-lg shadow border">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-600">Displayed</p>
              <p class="text-2xl font-bold text-gray-800"><?php echo $stats['displayed']; ?></p>
              <p class="text-xs text-gray-500 mt-1">With current filters</p>
            </div>
            <i data-lucide="list" class="w-8 h-8 text-purple-500"></i>
          </div>
        </div>
      </div>

      <!-- Tabs -->
      <div class="bg-white rounded-lg shadow">
        <div class="border-b">
          <nav class="flex -mb-px">
            <a href="?status=Active" class="py-4 px-6 border-b-2 font-medium text-sm 
              <?php echo $status == 'Active' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'; ?>">
              Active (<?php echo $stats['active']; ?>)
            </a>
            <a href="?status=On Leave" class="py-4 px-6 border-b-2 font-medium text-sm 
              <?php echo $status == 'On Leave' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'; ?>">
              On Leave (<?php echo $stats['on_leave']; ?>)
            </a>
            <a href="?status=Inactive" class="py-4 px-6 border-b-2 font-medium text-sm 
              <?php echo $status == 'Inactive' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'; ?>">
              Inactive
            </a>
            <a href="?status=Terminated" class="py-4 px-6 border-b-2 font-medium text-sm 
              <?php echo $status == 'Terminated' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'; ?>">
              Terminated
            </a>
            <a href="employee_list.php" class="py-4 px-6 border-b-2 font-medium text-sm 
              <?php echo empty($status) ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'; ?>">
              All Employees (<?php echo $stats['total']; ?>)
            </a>
          </nav>
        </div>

        <!-- Bulk Actions -->
        <div id="bulkActions" class="bulk-actions bg-blue-50 border-b">
          <div class="px-6">
            <div class="flex items-center justify-between">
              <div class="flex items-center space-x-4">
                <span id="selectedCount" class="font-medium text-blue-700">0 employees selected</span>
                <select id="bulkStatusSelect" class="px-3 py-2 border border-gray-300 rounded-lg text-sm">
                  <option value="">Change Status...</option>
                  <option value="Active">Active</option>
                  <option value="Inactive">Inactive</option>
                  <option value="On Leave">On Leave</option>
                  <option value="Terminated">Terminated</option>
                </select>
                <button onclick="applyBulkStatus()" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm">
                  Apply
                </button>
              </div>
              <div>
                <button onclick="confirmBulkDelete()" class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 text-sm">
                  <i data-lucide="trash-2" class="w-4 h-4 inline mr-1"></i>
                  Delete Selected
                </button>
                <button onclick="clearSelection()" class="ml-2 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 text-sm">
                  Clear
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- Filters -->
        <div class="p-6 border-b border-gray-200">
          <form method="GET" class="space-y-4">
            <div class="grid md:grid-cols-3 gap-4">
              <!-- Status Filter -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Status</label>
                <select name="status" 
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                  <option value="">All Status</option>
                  <option value="Active" <?php echo $status == 'Active' ? 'selected' : ''; ?>>Active</option>
                  <option value="Inactive" <?php echo $status == 'Inactive' ? 'selected' : ''; ?>>Inactive</option>
                  <option value="On Leave" <?php echo $status == 'On Leave' ? 'selected' : ''; ?>>On Leave</option>
                  <option value="Terminated" <?php echo $status == 'Terminated' ? 'selected' : ''; ?>>Terminated</option>
                </select>
              </div>
              
              <!-- Department Filter -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Department</label>
                <select name="department" 
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                  <option value="">All Departments</option>
                  <?php foreach ($departments as $dept): ?>
                    <option value="<?php echo htmlspecialchars($dept['id']); ?>"
                      <?php echo $department == $dept['id'] ? 'selected' : ''; ?>>
                      <?php echo htmlspecialchars($dept['name']); ?>
                    </option>
                  <?php endforeach; ?>
                </select>
              </div>
              
              <!-- Search -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Search</label>
                <div class="relative">
                  <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>"
                         placeholder="Search by name, email, or employee ID..."
                         class="w-full px-3 py-2 border border-gray-300 rounded-lg pl-10">
                  <i data-lucide="search" class="absolute left-3 top-2.5 w-4 h-4 text-gray-400"></i>
                </div>
              </div>
            </div>
            
            <!-- Sort Options -->
            <div class="flex justify-between items-center">
              <div class="flex space-x-4">
                <select name="sort_by" 
                        class="px-3 py-2 border border-gray-300 rounded-lg text-sm">
                  <option value="last_name" <?php echo $sort_by == 'last_name' ? 'selected' : ''; ?>>Sort by Name</option>
                  <option value="hire_date" <?php echo $sort_by == 'hire_date' ? 'selected' : ''; ?>>Sort by Hire Date</option>
                  <option value="date_of_birth" <?php echo $sort_by == 'date_of_birth' ? 'selected' : ''; ?>>Sort by Age</option>
                  <option value="employee_id" <?php echo $sort_by == 'employee_id' ? 'selected' : ''; ?>>Sort by Employee ID</option>
                </select>
                
                <select name="sort_order" 
                        class="px-3 py-2 border border-gray-300 rounded-lg text-sm">
                  <option value="ASC" <?php echo $sort_order == 'ASC' ? 'selected' : ''; ?>>Ascending</option>
                  <option value="DESC" <?php echo $sort_order == 'DESC' ? 'selected' : ''; ?>>Descending</option>
                </select>
              </div>
              
              <div class="flex space-x-3">
                <button type="submit"
                        class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                  Apply Filters
                </button>
                <a href="employee_list.php"
                   class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
                  Clear All
                </a>
              </div>
            </div>
          </form>
        </div>

        <!-- Table View (Default - Better for CRUD) -->
        <div id="tableView" class="table-view p-6">
          <form id="bulkForm" method="POST" action="">
            <div class="overflow-x-auto">
              <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                  <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      <input type="checkbox" id="selectAll" class="rounded border-gray-300">
                    </th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Employee ID</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Position</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Department</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Hire Date</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                  </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                  <?php if(empty($employees)): ?>
                    <tr>
                      <td colspan="9" class="px-6 py-12 text-center text-gray-500">
                        <i data-lucide="users" class="w-12 h-12 mx-auto text-gray-400 mb-4"></i>
                        <p>No employees found</p>
                        <a href="employee_add.php" class="mt-2 inline-block text-blue-600 hover:underline">
                          Add your first employee
                        </a>
                      </td>
                    </tr>
                  <?php else: ?>
                    <?php foreach($employees as $employee): ?>
                    <tr class="hover:bg-gray-50" id="employee-<?php echo $employee['id']; ?>">
                      <td class="px-6 py-4">
                        <input type="checkbox" name="selected_employees[]" value="<?php echo $employee['id']; ?>" 
                               class="employee-checkbox rounded border-gray-300">
                      </td>
                      <td class="px-6 py-4">
                        <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($employee['employee_id']); ?></div>
                      </td>
                      <td class="px-6 py-4">
                        <div class="flex items-center">
                          <div class="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center text-sm font-bold text-gray-700 mr-3">
                            <?php echo strtoupper(substr($employee['first_name'], 0, 1) . substr($employee['last_name'], 0, 1)); ?>
                          </div>
                          <div>
                            <div class="text-sm font-medium text-gray-900">
                              <?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?>
                            </div>
                            <div class="text-sm text-gray-500">
                              <?php echo getGenderIcon($employee['gender']); ?>
                              <span class="ml-1"><?php echo $employee['gender']; ?>, <?php echo getAge($employee['date_of_birth']); ?> yrs</span>
                            </div>
                          </div>
                        </div>
                      </td>
                      <td class="px-6 py-4">
                        <div class="text-sm text-gray-900"><?php echo htmlspecialchars($employee['position'] ?? 'N/A'); ?></div>
                      </td>
                      <td class="px-6 py-4">
                        <div class="text-sm text-gray-900"><?php echo htmlspecialchars($employee['department_name'] ?? 'N/A'); ?></div>
                      </td>
                      <td class="px-6 py-4 text-sm text-gray-900"><?php echo htmlspecialchars($employee['email']); ?></td>
                      <td class="px-6 py-4">
                        <div class="flex items-center space-x-2">
                          <span class="px-3 py-1 text-xs rounded-full <?php echo getEmployeeStatusColor($employee['status']); ?>">
                            <?php echo $employee['status']; ?>
                          </span>
                          <div class="relative group">
                            <button type="button" onclick="showQuickStatus(<?php echo $employee['id']; ?>)" 
                                    class="text-gray-400 hover:text-gray-600">
                              <i data-lucide="chevron-down" class="w-4 h-4"></i>
                            </button>
                            <div id="quickStatus-<?php echo $employee['id']; ?>" 
                                 class="absolute left-0 mt-1 w-32 bg-white rounded-lg shadow-lg border hidden z-10">
                              <div class="py-1">
                                <a href="?quick_status=Active&id=<?php echo $employee['id']; ?>" 
                                   class="block px-4 py-2 text-sm text-green-700 hover:bg-green-50">Active</a>
                                <a href="?quick_status=Inactive&id=<?php echo $employee['id']; ?>" 
                                   class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">Inactive</a>
                                <a href="?quick_status=On Leave&id=<?php echo $employee['id']; ?>" 
                                   class="block px-4 py-2 text-sm text-blue-700 hover:bg-blue-50">On Leave</a>
                                <a href="?quick_status=Terminated&id=<?php echo $employee['id']; ?>" 
                                   class="block px-4 py-2 text-sm text-red-700 hover:bg-red-50">Terminated</a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </td>
                      <td class="px-6 py-4 text-sm text-gray-500">
                        <?php echo date('M d, Y', strtotime($employee['hire_date'])); ?>
                        <div class="text-xs text-gray-400">
                          <?php echo getYearsOfService($employee['hire_date']); ?> years
                        </div>
                      </td>
                      <td class="px-6 py-4">
                        <div class="flex space-x-2">
                          <a href="view_employee.php?id=<?php echo $employee['id']; ?>" 
                             class="px-3 py-1 text-sm bg-gray-100 rounded hover:bg-gray-200" title="View">
                            <i data-lucide="eye" class="w-4 h-4"></i>
                          </a>
                          <a href="edit_employee.php?id=<?php echo $employee['id']; ?>" 
                             class="px-3 py-1 text-sm bg-blue-100 text-blue-700 rounded hover:bg-blue-200" title="Edit">
                            <i data-lucide="edit" class="w-4 h-4"></i>
                          </a>
                          <a href="#" onclick="confirmDelete(<?php echo $employee['id']; ?>, '<?php echo addslashes($employee['first_name'] . ' ' . $employee['last_name']); ?>')" 
                             class="px-3 py-1 text-sm bg-red-100 text-red-700 rounded hover:bg-red-200" title="Delete">
                            <i data-lucide="trash-2" class="w-4 h-4"></i>
                          </a>
                        </div>
                      </td>
                    </tr>
                    <?php endforeach; ?>
                  <?php endif; ?>
                </tbody>
              </table>
              
              <!-- Pagination -->
              <?php if(!empty($employees)): ?>
              <div class="px-6 py-4 border-t border-gray-200">
                <div class="flex justify-between items-center">
                  <div class="text-sm text-gray-700">
                    Showing <span class="font-medium">1</span> to 
                    <span class="font-medium"><?php echo count($employees); ?></span> of 
                    <span class="font-medium"><?php echo $stats['total']; ?></span> employees
                  </div>
                  <div class="flex space-x-2">
                    <button class="px-3 py-1 border border-gray-300 rounded text-sm hover:bg-gray-50">
                      <i data-lucide="chevron-left" class="w-4 h-4"></i>
                    </button>
                    <button class="px-3 py-1 border border-gray-300 bg-blue-600 text-white rounded text-sm">
                      1
                    </button>
                    <button class="px-3 py-1 border border-gray-300 rounded text-sm hover:bg-gray-50">
                      2
                    </button>
                    <button class="px-3 py-1 border border-gray-300 rounded text-sm hover:bg-gray-50">
                      <i data-lucide="chevron-right" class="w-4 h-4"></i>
                    </button>
                  </div>
                </div>
              </div>
              <?php endif; ?>
            </div>
          </form>
        </div>

        <!-- Grid View -->
        <div id="gridView" class="grid-view hidden p-6">
          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            <?php if(empty($employees)): ?>
              <div class="col-span-full text-center py-12">
                <i data-lucide="users" class="w-16 h-16 mx-auto text-gray-400 mb-4"></i>
                <p class="text-gray-500 text-lg mb-2">No employees found</p>
                <p class="text-gray-400 mb-6">Try adjusting your search or filters</p>
                <a href="employee_add.php" class="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                  <i data-lucide="user-plus" class="w-4 h-4 mr-2"></i>
                  Add New Employee
                </a>
              </div>
            <?php else: ?>
              <?php foreach($employees as $employee): 
                $age = getAge($employee['date_of_birth']);
                $years_service = getYearsOfService($employee['hire_date']);
              ?>
              <div class="employee-card bg-white rounded-xl shadow border border-gray-200 overflow-hidden hover:shadow-lg">
                <!-- Employee Header -->
                <div class="p-6 <?php echo strtolower($employee['status']) == 'active' ? 'status-active' : (strtolower($employee['status']) == 'on leave' ? 'status-on-leave' : (strtolower($employee['status']) == 'terminated' ? 'status-terminated' : 'status-inactive')); ?>">
                  <div class="flex items-center justify-between mb-4">
                    <div>
                      <span class="px-3 py-1 text-xs font-medium rounded-full bg-white/90 text-gray-800">
                        <?php echo $employee['employee_id']; ?>
                      </span>
                      <span class="px-2 py-1 text-xs rounded-full <?php echo getEmployeeStatusColor($employee['status']); ?> ml-2">
                        <?php echo $employee['status']; ?>
                      </span>
                    </div>
                    <div class="flex space-x-2">
                      <a href="view_employee.php?id=<?php echo $employee['id']; ?>" 
                         class="p-2 bg-white/80 rounded-full hover:bg-white" title="View">
                        <i data-lucide="eye" class="w-4 h-4"></i>
                      </a>
                      <a href="edit_employee.php?id=<?php echo $employee['id']; ?>" 
                         class="p-2 bg-white/80 rounded-full hover:bg-white" title="Edit">
                        <i data-lucide="edit" class="w-4 h-4"></i>
                      </a>
                      <a href="#" onclick="confirmDelete(<?php echo $employee['id']; ?>, '<?php echo addslashes($employee['first_name'] . ' ' . $employee['last_name']); ?>')" 
                         class="p-2 bg-white/80 rounded-full hover:bg-white" title="Delete">
                        <i data-lucide="trash-2" class="w-4 h-4 text-red-600"></i>
                      </a>
                    </div>
                  </div>
                  
                  <div class="flex items-center space-x-4">
                    <div class="w-16 h-16 bg-white rounded-full flex items-center justify-center text-2xl font-bold text-gray-800">
                      <?php echo strtoupper(substr($employee['first_name'], 0, 1) . substr($employee['last_name'], 0, 1)); ?>
                    </div>
                    <div>
                      <h3 class="text-xl font-bold text-white"><?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?></h3>
                      <p class="text-white/90"><?php echo htmlspecialchars($employee['department_name'] ?? 'Employee'); ?></p>
                      <div class="flex items-center mt-1 text-white/80">
                        <?php echo getGenderIcon($employee['gender']); ?>
                        <span class="ml-1 text-sm"><?php echo $employee['gender']; ?>, <?php echo $age; ?> years</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                <!-- Employee Details -->
                <div class="p-6">
                  <div class="space-y-4">
                    <div class="flex items-center text-gray-600">
                      <i data-lucide="building" class="w-4 h-4 mr-3"></i>
                      <span class="text-sm"><?php echo htmlspecialchars($employee['department_name'] ?? 'N/A'); ?></span>
                    </div>

                    <!-- Position added here -->
                    <div class="flex items-center text-gray-600">
                      <i data-lucide="briefcase" class="w-4 h-4 mr-3"></i>
                      <span class="text-sm"><?php echo htmlspecialchars($employee['position'] ?? 'N/A'); ?></span>
                    </div>
                    
                    <div class="flex items-center text-gray-600">
                      <i data-lucide="mail" class="w-4 h-4 mr-3"></i>
                      <span class="text-sm truncate"><?php echo htmlspecialchars($employee['email']); ?></span>
                    </div>
                    
                    <?php if(!empty($employee['contact_number'])): ?>
                    <div class="flex items-center text-gray-600">
                      <i data-lucide="phone" class="w-4 h-4 mr-3"></i>
                      <span class="text-sm"><?php echo htmlspecialchars($employee['contact_number']); ?></span>
                    </div>
                    <?php endif; ?>
                    
                    <div class="flex items-center text-gray-600">
                      <i data-lucide="calendar" class="w-4 h-4 mr-3"></i>
                      <span class="text-sm">Hired: <?php echo date('M d, Y', strtotime($employee['hire_date'])); ?></span>
                      <span class="mx-2">•</span>
                      <span class="text-sm"><?php echo $years_service; ?> years</span>
                    </div>
                    
                    <div class="pt-4 border-t border-gray-100">
                      <div class="flex justify-between items-center">
                        <div>
                          <p class="text-sm text-gray-500">Employee ID</p>
                          <p class="text-lg font-bold text-gray-800"><?php echo $employee['employee_id']; ?></p>
                        </div>
                        <div class="text-right">
                          <p class="text-sm text-gray-500">Date of Birth</p>
                          <span class="text-sm text-gray-800">
                            <?php echo date('M d, Y', strtotime($employee['date_of_birth'])); ?>
                          </span>
                        </div>
                      </div>
                    </div>
                    
                    <?php if(!empty($employee['address'])): ?>
                    <div class="pt-4 border-t border-gray-100">
                      <div class="text-sm">
                        <p class="text-gray-500 mb-1">Address</p>
                        <p class="text-gray-800 truncate"><?php echo htmlspecialchars($employee['address']); ?></p>
                      </div>
                    </div>
                    <?php endif; ?>
                  </div>
                </div>
                
                <!-- Quick Actions -->
                <div class="px-6 py-4 bg-gray-50 border-t border-gray-200">
                  <div class="flex justify-between">
                    <a href="view_employee.php?id=<?php echo $employee['id']; ?>" 
                       class="text-sm text-blue-600 hover:text-blue-800">
                      <i data-lucide="eye" class="w-4 h-4 inline mr-1"></i>
                      View
                    </a>
                    <a href="edit_employee.php?id=<?php echo $employee['id']; ?>" 
                       class="text-sm text-green-600 hover:text-green-800">
                      <i data-lucide="edit" class="w-4 h-4 inline mr-1"></i>
                      Edit
                    </a>
                  </div>
                </div>
              </div>
              <?php endforeach; ?>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </main>
  </div>
</div>

<!-- Delete Confirmation Modal -->
<div id="deleteModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full hidden z-50">
  <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
    <div class="mt-3">
      <h3 class="text-lg font-medium text-gray-900 mb-4">Delete Employee</h3>
      <p class="text-sm text-gray-500 mb-4">Are you sure you want to delete <span id="deleteEmployeeName" class="font-semibold"></span>? This will change their status to "Inactive".</p>
      
      <div class="flex justify-end space-x-3 mt-6">
        <button type="button" onclick="closeDeleteModal()"
                class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
          Cancel
        </button>
        <button id="confirmDeleteBtn" onclick="performDelete()"
                class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700">
          Delete Employee
        </button>
      </div>
    </div>
  </div>
</div>

<!-- Bulk Delete Confirmation Modal -->
<div id="bulkDeleteModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full hidden z-50">
  <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
    <div class="mt-3">
      <h3 class="text-lg font-medium text-gray-900 mb-4">Delete Selected Employees</h3>
      <p class="text-sm text-gray-500 mb-4">Are you sure you want to delete <span id="bulkDeleteCount" class="font-semibold"></span> selected employees? This will change their status to "Inactive".</p>
      
      <div class="flex justify-end space-x-3 mt-6">
        <button type="button" onclick="closeBulkDeleteModal()"
                class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
          Cancel
        </button>
        <button onclick="performBulkDelete()"
                class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700">
          Delete Selected
        </button>
      </div>
    </div>
  </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
  lucide.createIcons();
  
  // Set initial view mode from localStorage or default to table (better for CRUD)
  const viewMode = localStorage.getItem('employeeViewMode') || 'table';
  setViewMode(viewMode);
  
  // Initialize bulk selection
  initBulkSelection();
});

function setViewMode(mode) {
  if (mode === 'grid') {
    document.getElementById('gridView').classList.remove('hidden');
    document.getElementById('tableView').classList.add('hidden');
    document.getElementById('viewModeToggle').children[0].classList.add('bg-blue-600', 'text-white');
    document.getElementById('viewModeToggle').children[1].classList.remove('bg-blue-600', 'text-white');
    document.getElementById('viewModeToggle').children[1].classList.add('bg-gray-200');
  } else {
    document.getElementById('tableView').classList.remove('hidden');
    document.getElementById('gridView').classList.add('hidden');
    document.getElementById('viewModeToggle').children[1].classList.add('bg-blue-600', 'text-white');
    document.getElementById('viewModeToggle').children[0].classList.remove('bg-blue-600', 'text-white');
    document.getElementById('viewModeToggle').children[0].classList.add('bg-gray-200');
  }
  
  // Save preference to localStorage
  localStorage.setItem('employeeViewMode', mode);
}

// Bulk selection functionality
function initBulkSelection() {
  const selectAll = document.getElementById('selectAll');
  const checkboxes = document.querySelectorAll('.employee-checkbox');
  
  if (selectAll) {
    selectAll.addEventListener('change', function() {
      checkboxes.forEach(checkbox => {
        checkbox.checked = this.checked;
      });
      updateBulkActions();
    });
    
    checkboxes.forEach(checkbox => {
      checkbox.addEventListener('change', updateBulkActions);
    });
  }
}

function updateBulkActions() {
  const checkboxes = document.querySelectorAll('.employee-checkbox:checked');
  const selectedCount = checkboxes.length;
  const bulkActions = document.getElementById('bulkActions');
  const selectedCountSpan = document.getElementById('selectedCount');
  
  if (selectedCountSpan) {
    selectedCountSpan.textContent = `${selectedCount} employee${selectedCount !== 1 ? 's' : ''} selected`;
  }
  
  if (bulkActions) {
    if (selectedCount > 0) {
      bulkActions.classList.add('active');
    } else {
      bulkActions.classList.remove('active');
    }
  }
}

function clearSelection() {
  const checkboxes = document.querySelectorAll('.employee-checkbox');
  const selectAll = document.getElementById('selectAll');
  
  checkboxes.forEach(checkbox => {
    checkbox.checked = false;
  });
  
  if (selectAll) {
    selectAll.checked = false;
  }
  
  updateBulkActions();
}

function applyBulkStatus() {
  const statusSelect = document.getElementById('bulkStatusSelect');
  const newStatus = statusSelect.value;
  
  if (!newStatus) {
    alert('Please select a status');
    return;
  }
  
  const checkboxes = document.querySelectorAll('.employee-checkbox:checked');
  if (checkboxes.length === 0) {
    alert('Please select at least one employee');
    return;
  }
  
  // Create a form and submit it
  const form = document.createElement('form');
  form.method = 'POST';
  form.action = '';
  
  const bulkStatusInput = document.createElement('input');
  bulkStatusInput.type = 'hidden';
  bulkStatusInput.name = 'bulk_status';
  bulkStatusInput.value = newStatus;
  form.appendChild(bulkStatusInput);
  
  checkboxes.forEach(checkbox => {
    const input = document.createElement('input');
    input.type = 'hidden';
    input.name = 'selected_employees[]';
    input.value = checkbox.value;
    form.appendChild(input);
  });
  
  document.body.appendChild(form);
  form.submit();
}

function confirmBulkDelete() {
  const checkboxes = document.querySelectorAll('.employee-checkbox:checked');
  const count = checkboxes.length;
  
  if (count === 0) {
    alert('Please select at least one employee');
    return;
  }
  
  document.getElementById('bulkDeleteCount').textContent = `${count} employee${count !== 1 ? 's' : ''}`;
  document.getElementById('bulkDeleteModal').classList.remove('hidden');
}

function closeBulkDeleteModal() {
  document.getElementById('bulkDeleteModal').classList.add('hidden');
}

function performBulkDelete() {
  const checkboxes = document.querySelectorAll('.employee-checkbox:checked');
  
  // Create a form and submit it
  const form = document.createElement('form');
  form.method = 'POST';
  form.action = '';
  
  const bulkDeleteInput = document.createElement('input');
  bulkDeleteInput.type = 'hidden';
  bulkDeleteInput.name = 'bulk_delete';
  bulkDeleteInput.value = '1';
  form.appendChild(bulkDeleteInput);
  
  checkboxes.forEach(checkbox => {
    const input = document.createElement('input');
    input.type = 'hidden';
    input.name = 'selected_employees[]';
    input.value = checkbox.value;
    form.appendChild(input);
  });
  
  document.body.appendChild(form);
  form.submit();
}

// Single employee delete
let currentDeleteId = null;
let currentDeleteName = null;

function confirmDelete(employeeId, employeeName) {
  currentDeleteId = employeeId;
  currentDeleteName = employeeName;
  document.getElementById('deleteEmployeeName').textContent = employeeName;
  document.getElementById('deleteModal').classList.remove('hidden');
}

function closeDeleteModal() {
  document.getElementById('deleteModal').classList.add('hidden');
  currentDeleteId = null;
  currentDeleteName = null;
}

function performDelete() {
  if (currentDeleteId) {
    window.location.href = `employee_list.php?delete_id=${currentDeleteId}`;
  }
}

// Quick status dropdown
function showQuickStatus(employeeId) {
  const dropdown = document.getElementById(`quickStatus-${employeeId}`);
  dropdown.classList.toggle('hidden');
  
  // Close other dropdowns
  document.querySelectorAll('[id^="quickStatus-"]').forEach(el => {
    if (el.id !== `quickStatus-${employeeId}`) {
      el.classList.add('hidden');
    }
  });
}

// Close dropdowns when clicking outside
document.addEventListener('click', function(event) {
  // Close quick status dropdowns
  if (!event.target.closest('[id^="quickStatus-"]') && !event.target.closest('[onclick^="showQuickStatus"]')) {
    document.querySelectorAll('[id^="quickStatus-"]').forEach(el => {
      el.classList.add('hidden');
    });
  }
  
  // Close delete modal when clicking outside
  const deleteModal = document.getElementById('deleteModal');
  if (event.target == deleteModal) {
    closeDeleteModal();
  }
  
  // Close bulk delete modal when clicking outside
  const bulkDeleteModal = document.getElementById('bulkDeleteModal');
  if (event.target == bulkDeleteModal) {
    closeBulkDeleteModal();
  }
});

function exportEmployees() {
  // Create a CSV export
  const headers = ['Employee ID', 'First Name', 'Last Name', 'Position', 'Email', 'Department', 'Status', 'Hire Date', 'Date of Birth', 'Gender', 'Contact Number'];
  const rows = <?php echo json_encode($employees); ?>.map(emp => [
    emp.employee_id,
    emp.first_name,
    emp.last_name,
    emp.position || 'N/A',
    emp.email,
    emp.department_name || 'N/A',
    emp.status,
    emp.hire_date,
    emp.date_of_birth,
    emp.gender,
    emp.contact_number || ''
  ]);
  
  let csvContent = "data:text/csv;charset=utf-8," 
    + [headers, ...rows].map(row => row.map(cell => `"${cell}"`).join(",")).join("\n");
  
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement("a");
  link.setAttribute("href", encodedUri);
  link.setAttribute("download", `employees_export_${new Date().toISOString().split('T')[0]}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// Quick search functionality
document.addEventListener('keydown', function(e) {
  if (e.ctrlKey && e.key === 'k') {
    e.preventDefault();
    document.querySelector('input[name="search"]').focus();
  }
});
</script>
</body>
</html>