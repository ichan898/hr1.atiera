<?php
// File: upload_documents.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: onboarding.php');
    exit();
}

$id = $_GET['id'];

$query = "SELECT o.*, d.name as department_name 
          FROM onboarding o 
          LEFT JOIN departments d ON o.department = d.id 
          WHERE o.id = ?";
$stmt = $connections->prepare($query);
$stmt->execute([$id]);
$onboarding = $stmt->fetch();

if (!$onboarding) {
    header('Location: onboarding.php');
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_documents'])) {
        $documents_complete = isset($_POST['documents_complete']) ? 1 : 0;
        $documents_notes = $_POST['documents_notes'] ?? '';
        $sss_number = $_POST['sss_number'] ?? '';
        $pagibig_number = $_POST['pagibig_number'] ?? '';
        $philhealth_number = $_POST['philhealth_number'] ?? '';
        $tin_number = $_POST['tin_number'] ?? '';
        $bank_account = $_POST['bank_account'] ?? '';
        $emergency_contact_name = $_POST['emergency_contact_name'] ?? '';
        $emergency_contact_phone = $_POST['emergency_contact_phone'] ?? '';
        
        // Handle file uploads
        $uploaded_files = [];
        $uploadDir = 'uploads/documents/' . $onboarding['employee_id'] . '/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        
        // List of document types
        $document_types = [
            'resume', 'sss_form', 'pagibig_form', 'philhealth_form',
            'tin_form', 'id_front', 'id_back', 'diploma', 'certificates',
            'nbi_clearance', 'medical_certificate'
        ];
        
        foreach ($document_types as $doc_type) {
            if (isset($_FILES[$doc_type]) && $_FILES[$doc_type]['error'] === UPLOAD_ERR_OK) {
                $fileName = $doc_type . '_' . time() . '_' . basename($_FILES[$doc_type]['name']);
                $targetFile = $uploadDir . $fileName;
                
                if (move_uploaded_file($_FILES[$doc_type]['tmp_name'], $targetFile)) {
                    $uploaded_files[$doc_type] = $targetFile;
                }
            }
        }
        
        // Store file paths in JSON
        $document_files = json_encode($uploaded_files);
        
        $update_query = "UPDATE onboarding SET 
            documents_complete = ?,
            documents_submitted = ?,
            documents_submitted_at = ?,
            documents_notes = ?,
            notes = CONCAT(COALESCE(notes, ''), ?),
            updated_at = NOW()
            WHERE id = ?";
        
        $documents_submitted_at = $documents_complete ? date('Y-m-d H:i:s') : null;
        $documents_data = json_encode([
            'government_ids' => [
                'sss' => $sss_number,
                'pagibig' => $pagibig_number,
                'philhealth' => $philhealth_number,
                'tin' => $tin_number
            ],
            'bank_account' => $bank_account,
            'emergency_contact' => [
                'name' => $emergency_contact_name,
                'phone' => $emergency_contact_phone
            ],
            'files' => $uploaded_files
        ]);
        
        $update_notes = "\n\nDocuments updated on " . date('Y-m-d H:i:s') . ": " . $documents_notes;
        
        $update_stmt = $connections->prepare($update_query);
        $update_stmt->execute([
            $documents_complete,
            $documents_data,
            $documents_submitted_at,
            $documents_notes,
            $update_notes,
            $id
        ]);
        
        // Also update government_ids table if employee record exists
        if ($onboarding['employee_record_id']) {
            $govt_query = "INSERT INTO government_ids (employee_id, sss_number, pagibig_number, philhealth_number, tin_number)
                          VALUES (?, ?, ?, ?, ?)
                          ON DUPLICATE KEY UPDATE 
                          sss_number = VALUES(sss_number),
                          pagibig_number = VALUES(pagibig_number),
                          philhealth_number = VALUES(philhealth_number),
                          tin_number = VALUES(tin_number)";
            $govt_stmt = $connections->prepare($govt_query);
            $govt_stmt->execute([
                $onboarding['employee_record_id'],
                $sss_number,
                $pagibig_number,
                $philhealth_number,
                $tin_number
            ]);
        }
        
        $_SESSION['success'] = "Documents updated successfully!";
        header("Location: view_onboarding.php?id=$id");
        exit();
    }
}

// FIXED: Safely decode existing documents data – avoid undefined key warning
$documents_data = [];
if (!empty($onboarding['documents_submitted'])) {
    $decoded = json_decode($onboarding['documents_submitted'], true);
    $documents_data = is_array($decoded) ? $decoded : [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HR1 - Required Documents</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="bg-gray-50 min-h-screen">
    <div class="flex">
        <?php include 'sidebar.php'; ?>
        
        <div class="flex-1 p-6">
            <!-- Header -->
            <div class="flex justify-between items-center mb-6">
                <div>
                    <h1 class="text-2xl font-bold text-gray-800">Required Documents</h1>
                    <p class="text-gray-600">
                        <?php echo htmlspecialchars($onboarding['first_name'] . ' ' . $onboarding['last_name']); ?> - 
                        <?php echo htmlspecialchars($onboarding['job_position']); ?>
                    </p>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="view_onboarding.php?id=<?php echo $id; ?>" 
                       class="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 flex items-center">
                        <i data-lucide="arrow-left" class="w-4 h-4 mr-2"></i>
                        Back to Onboarding
                    </a>
                    <?php include 'profile_dropdown.php'; ?>
                </div>
            </div>

            <?php if (isset($_SESSION['success'])): ?>
            <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-6">
                <div class="flex items-center">
                    <i data-lucide="check-circle" class="w-5 h-5 mr-2"></i>
                    <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                </div>
            </div>
            <?php endif; ?>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <!-- Main Form -->
                <div class="lg:col-span-2">
                    <form method="POST" enctype="multipart/form-data">
                        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
                            <h2 class="text-xl font-bold text-gray-800 mb-6">Government IDs & Information</h2>
                            
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">SSS Number</label>
                                    <input type="text" name="sss_number" 
                                           class="w-full border border-gray-300 rounded-lg p-2"
                                           value="<?php echo htmlspecialchars($documents_data['government_ids']['sss'] ?? ''); ?>"
                                           placeholder="12-3456789-0">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Pag-IBIG Number</label>
                                    <input type="text" name="pagibig_number" 
                                           class="w-full border border-gray-300 rounded-lg p-2"
                                           value="<?php echo htmlspecialchars($documents_data['government_ids']['pagibig'] ?? ''); ?>"
                                           placeholder="1234-5678-9012">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">PhilHealth Number</label>
                                    <input type="text" name="philhealth_number" 
                                           class="w-full border border-gray-300 rounded-lg p-2"
                                           value="<?php echo htmlspecialchars($documents_data['government_ids']['philhealth'] ?? ''); ?>"
                                           placeholder="12-345678901-2">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">TIN Number</label>
                                    <input type="text" name="tin_number" 
                                           class="w-full border border-gray-300 rounded-lg p-2"
                                           value="<?php echo htmlspecialchars($documents_data['government_ids']['tin'] ?? ''); ?>"
                                           placeholder="123-456-789-000">
                                </div>
                            </div>

                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Bank Account Number</label>
                                    <input type="text" name="bank_account" 
                                           class="w-full border border-gray-300 rounded-lg p-2"
                                           value="<?php echo htmlspecialchars($documents_data['bank_account'] ?? ''); ?>"
                                           placeholder="123456789012">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Bank Name</label>
                                    <select name="bank_name" class="w-full border border-gray-300 rounded-lg p-2">
                                        <option value="">Select Bank</option>
                                        <option value="BDO" <?php echo ($documents_data['bank_name'] ?? '') == 'BDO' ? 'selected' : ''; ?>>BDO</option>
                                        <option value="BPI" <?php echo ($documents_data['bank_name'] ?? '') == 'BPI' ? 'selected' : ''; ?>>BPI</option>
                                        <option value="Metrobank" <?php echo ($documents_data['bank_name'] ?? '') == 'Metrobank' ? 'selected' : ''; ?>>Metrobank</option>
                                        <option value="UnionBank" <?php echo ($documents_data['bank_name'] ?? '') == 'UnionBank' ? 'selected' : ''; ?>>UnionBank</option>
                                        <option value="Landbank" <?php echo ($documents_data['bank_name'] ?? '') == 'Landbank' ? 'selected' : ''; ?>>Landbank</option>
                                    </select>
                                </div>
                            </div>

                            <div class="mb-6">
                                <h3 class="text-lg font-semibold mb-4">Emergency Contact</h3>
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">Contact Name</label>
                                        <input type="text" name="emergency_contact_name" 
                                               class="w-full border border-gray-300 rounded-lg p-2"
                                               value="<?php echo htmlspecialchars($documents_data['emergency_contact']['name'] ?? ''); ?>"
                                               placeholder="Full Name">
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">Contact Phone</label>
                                        <input type="text" name="emergency_contact_phone" 
                                               class="w-full border border-gray-300 rounded-lg p-2"
                                               value="<?php echo htmlspecialchars($documents_data['emergency_contact']['phone'] ?? ''); ?>"
                                               placeholder="09171234567">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Document Uploads -->
                        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
                            <h2 class="text-xl font-bold text-gray-800 mb-6">Document Uploads</h2>
                            
                            <div class="space-y-4">
                                <?php 
                                $required_docs = [
                                    'resume' => ['label' => 'Resume/CV', 'required' => true],
                                    'sss_form' => ['label' => 'SSS Form E-1', 'required' => true],
                                    'pagibig_form' => ['label' => 'Pag-IBIG Membership Form', 'required' => true],
                                    'philhealth_form' => ['label' => 'PhilHealth Form', 'required' => true],
                                    'tin_form' => ['label' => 'BIR Form 1902', 'required' => true],
                                    'id_front' => ['label' => 'Valid ID (Front)', 'required' => true],
                                    'id_back' => ['label' => 'Valid ID (Back)', 'required' => true],
                                    'diploma' => ['label' => 'Diploma/Transcript', 'required' => false],
                                    'certificates' => ['label' => 'Certifications', 'required' => false],
                                    'nbi_clearance' => ['label' => 'NBI Clearance', 'required' => true],
                                    'medical_certificate' => ['label' => 'Medical Certificate', 'required' => true]
                                ];
                                
                                foreach ($required_docs as $key => $doc):
                                ?>
                                <div class="border border-gray-200 rounded-lg p-4">
                                    <div class="flex items-center justify-between mb-2">
                                        <div class="flex items-center">
                                            <span class="font-medium"><?php echo $doc['label']; ?></span>
                                            <?php if ($doc['required']): ?>
                                            <span class="ml-2 px-2 py-1 text-xs bg-red-100 text-red-800 rounded-full">Required</span>
                                            <?php endif; ?>
                                        </div>
                                        <?php if (isset($documents_data['files'][$key])): ?>
                                        <a href="<?php echo htmlspecialchars($documents_data['files'][$key]); ?>" 
                                           target="_blank" class="text-blue-600 hover:text-blue-800 text-sm">
                                            <i data-lucide="eye" class="w-4 h-4 mr-1"></i> View
                                        </a>
                                        <?php endif; ?>
                                    </div>
                                    <input type="file" name="<?php echo $key; ?>" 
                                           class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-gray-50 file:text-gray-700 hover:file:bg-gray-100"
                                           accept=".pdf,.jpg,.jpeg,.png">
                                    <?php if (!$doc['required']): ?>
                                    <p class="text-xs text-gray-500 mt-1">Optional document</p>
                                    <?php endif; ?>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <!-- Notes and Submit -->
                        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                            <div class="flex items-center mb-4">
                                <input type="checkbox" name="documents_complete" id="documents_complete" value="1" 
                                       class="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                                       <?php echo $onboarding['documents_complete'] ? 'checked' : ''; ?>>
                                <label for="documents_complete" class="ml-2 block text-sm font-medium text-gray-700">
                                    Mark all documents as complete
                                </label>
                            </div>
                            
                            <div class="mb-4">
                                <label class="block text-sm font-medium text-gray-700 mb-2">Notes</label>
                                <textarea name="documents_notes" rows="3" 
                                          class="w-full border border-gray-300 rounded-lg p-2"
                                          placeholder="Add any notes about the documents..."><?php echo htmlspecialchars($onboarding['documents_notes'] ?? ''); ?></textarea>
                            </div>
                            
                            <button type="submit" name="update_documents"
                                    class="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 font-medium">
                                <i data-lucide="save" class="w-5 h-5 inline mr-2"></i>
                                Update Document Details
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Right Column -->
                <div class="space-y-6">
                    <!-- Status -->
                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                        <h3 class="text-lg font-semibold mb-4">Document Status</h3>
                        <div class="space-y-4">
                            <div class="flex justify-between items-center">
                                <span class="text-gray-600">Completion Status</span>
                                <span class="px-3 py-1 rounded-full text-sm font-medium 
                                    <?php echo $onboarding['documents_complete'] ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'; ?>">
                                    <?php echo $onboarding['documents_complete'] ? 'Complete' : 'Incomplete'; ?>
                                </span>
                            </div>
                            
                            <?php // FIXED: Check if the array key exists and is not empty ?>
                            <?php if (!empty($onboarding['documents_submitted_at'])): ?>
                            <div class="border-t pt-4">
                                <p class="text-sm text-gray-500">Submitted Date</p>
                                <p class="font-medium"><?php echo date('M d, Y', strtotime($onboarding['documents_submitted_at'])); ?></p>
                            </div>
                            <?php endif; ?>
                            
                            <div class="border-t pt-4">
                                <p class="text-sm text-gray-500 mb-2">Required Documents</p>
                                <ul class="space-y-1 text-sm">
                                    <?php foreach ($required_docs as $key => $doc): ?>
                                    <li class="flex items-center">
                                        <?php if (isset($documents_data['files'][$key])): ?>
                                        <i data-lucide="check-circle" class="w-4 h-4 text-green-500 mr-2"></i>
                                        <?php else: ?>
                                        <i data-lucide="circle" class="w-4 h-4 text-gray-300 mr-2"></i>
                                        <?php endif; ?>
                                        <?php echo $doc['label']; ?>
                                    </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <!-- Quick Actions -->
                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                        <h3 class="text-lg font-semibold mb-4">Quick Actions</h3>
                        <div class="space-y-3">
                            <?php if (!$onboarding['documents_complete']): ?>
                            <button type="button" onclick="markAsComplete()"
                                    class="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700">
                                <i data-lucide="check-circle" class="w-4 h-4 inline mr-2"></i>
                                Mark as Complete
                            </button>
                            <?php endif; ?>
                            
                            <a href="view_onboarding.php?id=<?php echo $id; ?>"
                               class="block w-full text-center border border-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-50">
                                <i data-lucide="eye" class="w-4 h-4 inline mr-2"></i>
                                View Onboarding
                            </a>
                            
                            <a href="https://www.sss.gov.ph/" target="_blank"
                               class="block w-full text-center border border-blue-600 text-blue-600 py-2 rounded-lg hover:bg-blue-50">
                                <i data-lucide="external-link" class="w-4 h-4 inline mr-2"></i>
                                SSS Portal
                            </a>
                        </div>
                    </div>

                    <!-- Requirements Checklist -->
                    <div class="bg-blue-50 border border-blue-200 rounded-xl p-6">
                        <h3 class="text-lg font-semibold mb-2 text-blue-800">Requirements Checklist</h3>
                        <p class="text-sm text-blue-700 mb-4">All new hires must submit:</p>
                        <ul class="space-y-2 text-blue-700 text-sm">
                            <li class="flex items-start">
                                <i data-lucide="file-text" class="w-4 h-4 mr-2 mt-0.5 text-blue-600"></i>
                                <span>Completed government forms</span>
                            </li>
                            <li class="flex items-start">
                                <i data-lucide="id-card" class="w-4 h-4 mr-2 mt-0.5 text-blue-600"></i>
                                <span>Valid government-issued ID</span>
                            </li>
                            <li class="flex items-start">
                                <i data-lucide="shield-check" class="w-4 h-4 mr-2 mt-0.5 text-blue-600"></i>
                                <span>NBI Clearance (valid within 6 months)</span>
                            </li>
                            <li class="flex items-start">
                                <i data-lucide="heart" class="w-4 h-4 mr-2 mt-0.5 text-blue-600"></i>
                                <span>Medical Certificate (company-designated clinic)</span>
                            </li>
                            <li class="flex items-start">
                                <i data-lucide="graduation-cap" class="w-4 h-4 mr-2 mt-0.5 text-blue-600"></i>
                                <span>Educational credentials</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener("DOMContentLoaded", () => {
        lucide.createIcons();
    });

    function markAsComplete() {
        if (confirm('Mark all documents as complete? This will update the status.')) {
            document.querySelector('#documents_complete').checked = true;
            document.querySelector('form').submit();
        }
    }
    </script>
</body>
</html>