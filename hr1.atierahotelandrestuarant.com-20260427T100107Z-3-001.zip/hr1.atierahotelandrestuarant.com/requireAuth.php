<?php
// File: requireAuth.php
// Authentication check helper

function requireAuth() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: login.php');
        exit;
    }
}
?>