<?php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

// Check if ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: applicants.php');
    exit();
}

$applicant_id = $_GET['id'];

// Fetch applicant details
$query = "SELECT a.id, a.first_name, a.last_name, a.email, a.phone, 
                 a.resume_path, a.application_status, a.job_id,
                 j.job_title, j.department, j.requirements 
          FROM applicants a 
          LEFT JOIN job_postings j ON a.job_id = j.id 
          WHERE a.id = ?";
    
$stmt = $connections->prepare($query);
$stmt->execute([$applicant_id]);
$applicant = $stmt->fetch();

if (!$applicant) {
    header('Location: applicants.php');
    exit();
}

// Handle form submission for scheduling interview
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $interview_date = $_POST['interview_date'];
    $interview_time = $_POST['interview_time'];
    $interview_type = $_POST['interview_type'];
    $duration = $_POST['duration'] ?? 60; // Default to 60 minutes
    $notes = $_POST['notes'] ?? '';
    $location = $_POST['location'] ?? '';
    $scheduled_by = $_SESSION['user_id']; // Assuming user_id is stored in session
    
    // Handle interviewers - check if it's an array or string
    if (isset($_POST['interviewers']) && is_array($_POST['interviewers'])) {
        $interviewers = implode(', ', array_filter($_POST['interviewers']));
    } elseif (isset($_POST['interviewers'])) {
        $interviewers = $_POST['interviewers'];
    } else {
        $interviewers = 'HR Manager'; // Default
    }
    
    // Combine date and time into scheduled_date
    $scheduled_date = $interview_date . ' ' . $interview_time;
    
    try {
        // First check if interviews table exists
        $table_check = $connections->query("SHOW TABLES LIKE 'interviews'");
        if ($table_check->rowCount() == 0) {
            // Create interviews table if it doesn't exist
            $create_table = "
                CREATE TABLE IF NOT EXISTS interviews (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    applicant_id INT NOT NULL,
                    interview_type VARCHAR(50) NOT NULL,
                    scheduled_date DATETIME NOT NULL,
                    duration INT NOT NULL,
                    interviewers TEXT NOT NULL,
                    location VARCHAR(255),
                    notes TEXT,
                    status VARCHAR(20) DEFAULT 'scheduled',
                    scheduled_by INT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    FOREIGN KEY (applicant_id) REFERENCES applicants(id) ON DELETE CASCADE
                )";
            $connections->exec($create_table);
        }
        
        // Insert interview schedule
        $insert_query = "INSERT INTO interviews (applicant_id, interview_type, scheduled_date, duration, interviewers, location, notes, scheduled_by) 
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $insert_stmt = $connections->prepare($insert_query);
        $insert_stmt->execute([
            $applicant_id, 
            $interview_type, 
            $scheduled_date, 
            $duration, 
            $interviewers, 
            $location, 
            $notes, 
            $scheduled_by
        ]);
        
        // Update applicant status
        $update_query = "UPDATE applicants SET application_status = 'interviewed' WHERE id = ?";
        $update_stmt = $connections->prepare($update_query);
        $update_stmt->execute([$applicant_id]);
        
        // Redirect to applicant view
        header("Location: view_applicant.php?id=$applicant_id&success=1");
        exit();
    } catch (PDOException $e) {
        $error = "Error saving interview schedule: " . $e->getMessage();
    }
}

// Fetch available interviewers (assuming you have a users table)
try {
    // First check if users table exists with appropriate columns
    $users_check = $connections->query("SHOW COLUMNS FROM users LIKE 'role'");
    if ($users_check->rowCount() > 0) {
        $interviewers_query = "SELECT id, CONCAT(first_name, ' ', last_name) as name FROM users WHERE role = 'interviewer' AND is_active = 1";
    } else {
        // Fallback if no role column
        $interviewers_query = "SELECT id, CONCAT(first_name, ' ', last_name) as name FROM users WHERE is_active = 1";
    }
    $interviewers_stmt = $connections->query($interviewers_query);
    $interviewers = $interviewers_stmt->fetchAll();
} catch (Exception $e) {
    $interviewers = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>HR1 - Schedule Interview</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
</head>

<body class="h-screen bg-gray-100 font-sans">
<div class="flex h-full">
  
  <!-- Sidebar -->
  <?php include 'sidebar.php'; ?>
  
  <!-- Main Content -->
  <div class="flex-1 flex flex-col overflow-y-auto">
    <main class="p-6 space-y-6">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-gray-300 pb-4">
        <div class="flex items-center space-x-4">
          <a href="view_applicant.php?id=<?php echo $applicant_id; ?>" class="text-blue-600 hover:text-blue-800">
            <i data-lucide="arrow-left" class="w-5 h-5"></i>
          </a>
          <div>
            <h2 class="text-2xl font-bold text-gray-800">Schedule Interview</h2>
            <p class="text-sm text-gray-600">Set up an interview with the applicant</p>
          </div>
        </div>
        <div class="flex items-center space-x-4">
          <?php include 'profile_dropdown.php'; ?>
        </div>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Applicant Information -->
        <div class="lg:col-span-1">
          <div class="bg-white rounded-lg shadow p-6">
            <div class="flex items-center space-x-4 mb-6">
              <div class="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center">
                <i data-lucide="user" class="w-6 h-6 text-gray-600"></i>
              </div>
              <div>
                <h3 class="font-bold text-gray-800">
                  <?php echo htmlspecialchars($applicant['first_name'] . ' ' . $applicant['last_name']); ?>
                </h3>
                <p class="text-sm text-gray-600"><?php echo htmlspecialchars($applicant['email']); ?></p>
              </div>
            </div>
            
            <div class="space-y-4">
              <div>
                <label class="text-sm text-gray-500">Applied Position</label>
                <p class="font-medium"><?php echo htmlspecialchars($applicant['job_title']); ?></p>
              </div>
              <div>
                <label class="text-sm text-gray-500">Department</label>
                <p class="font-medium"><?php echo htmlspecialchars($applicant['department']); ?></p>
              </div>
              <div>
                <label class="text-sm text-gray-500">Current Status</label>
                <span class="px-2 py-1 text-xs rounded 
                  <?php echo $applicant['application_status'] == 'new' ? 'bg-blue-100 text-blue-800' : 
                         ($applicant['application_status'] == 'reviewed' ? 'bg-yellow-100 text-yellow-800' : 
                         ($applicant['application_status'] == 'shortlisted' ? 'bg-green-100 text-green-800' : 
                         ($applicant['application_status'] == 'interviewed' ? 'bg-purple-100 text-purple-800' : 
                         ($applicant['application_status'] == 'hired' ? 'bg-green-100 text-green-800' : 
                         'bg-red-100 text-red-800')))); ?>">
                  <?php echo ucfirst($applicant['application_status']); ?>
                </span>
              </div>
              <div>
                <label class="text-sm text-gray-500">Phone</label>
                <p class="font-medium"><?php echo htmlspecialchars($applicant['phone']); ?></p>
              </div>
            </div>
            
            <?php if ($applicant['resume_path']): ?>
            <div class="mt-6 pt-6 border-t border-gray-200">
              <a href="<?php echo htmlspecialchars($applicant['resume_path']); ?>" 
                 target="_blank"
                 class="flex items-center justify-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                <i data-lucide="file-text" class="w-4 h-4"></i>
                <span>View Resume</span>
              </a>
            </div>
            <?php endif; ?>
          </div>
          
          <!-- Job Requirements -->
          <?php if (!empty($applicant['requirements'])): ?>
          <div class="bg-white rounded-lg shadow p-6 mt-6">
            <h3 class="font-semibold text-gray-800 mb-4">Job Requirements</h3>
            <div class="text-sm text-gray-700">
              <?php echo nl2br(htmlspecialchars($applicant['requirements'])); ?>
            </div>
          </div>
          <?php endif; ?>
        </div>

        <!-- Interview Scheduling Form -->
        <div class="lg:col-span-2">
          <div class="bg-white rounded-lg shadow">
            <div class="p-6 border-b border-gray-200">
              <h3 class="text-lg font-semibold text-gray-800">Schedule Interview</h3>
            </div>
            
            <form method="POST" action="" class="p-6 space-y-6">
              <?php if (isset($error)): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
                  <?php echo htmlspecialchars($error); ?>
                </div>
              <?php endif; ?>
              
              <?php if (isset($_GET['success'])): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded">
                  Interview scheduled successfully!
                </div>
              <?php endif; ?>
              
              <!-- Interview Date and Time -->
              <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">Interview Date <span class="text-red-500">*</span></label>
                  <input type="date" name="interview_date" required 
                         min="<?php echo date('Y-m-d'); ?>"
                         class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                </div>
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">Interview Time <span class="text-red-500">*</span></label>
                  <input type="time" name="interview_time" required 
                         class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                </div>
              </div>
              
              <!-- Interview Type and Interviewers -->
              <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">Interview Type <span class="text-red-500">*</span></label>
                  <select name="interview_type" required class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    <option value="">Select type</option>
                    <option value="phone">Phone Interview</option>
                    <option value="video">Video Interview</option>
                    <option value="in_person">In-Person Interview</option>
                  </select>
                </div>
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">Interviewers <span class="text-red-500">*</span></label>
                  <select name="interviewers[]" multiple required class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" style="height: 120px;">
                    <?php foreach ($interviewers as $interviewer): ?>
                      <option value="<?php echo htmlspecialchars($interviewer['name']); ?>">
                        <?php echo htmlspecialchars($interviewer['name']); ?>
                      </option>
                    <?php endforeach; ?>
                    <?php if (empty($interviewers)): ?>
                      <option value="HR Manager">HR Manager</option>
                      <option value="Department Head">Department Head</option>
                      <option value="Team Lead">Team Lead</option>
                      <option value="Technical Lead">Technical Lead</option>
                    <?php endif; ?>
                  </select>
                  <p class="text-xs text-gray-500 mt-1">Hold Ctrl/Cmd to select multiple interviewers</p>
                </div>
              </div>
              
              <!-- Duration -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Duration <span class="text-red-500">*</span></label>
                <div class="flex space-x-4">
                  <label class="flex items-center">
                    <input type="radio" name="duration" value="30" class="mr-2">
                    <span>30 minutes</span>
                  </label>
                  <label class="flex items-center">
                    <input type="radio" name="duration" value="60" class="mr-2" checked>
                    <span>1 hour</span>
                  </label>
                  <label class="flex items-center">
                    <input type="radio" name="duration" value="90" class="mr-2">
                    <span>1.5 hours</span>
                  </label>
                  <label class="flex items-center">
                    <input type="radio" name="duration" value="120" class="mr-2">
                    <span>2 hours</span>
                  </label>
                </div>
              </div>
              
              <!-- Location/Details based on type -->
              <div id="interview_details" style="display: none;">
                <div id="video_details" style="display: none;">
                  <label class="block text-sm font-medium text-gray-700 mb-2">Video Conference Link</label>
                  <input type="url" name="video_link" placeholder="https://meet.google.com/..." 
                         class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                </div>
                <div id="in_person_details" style="display: none;">
                  <label class="block text-sm font-medium text-gray-700 mb-2">Location</label>
                  <input type="text" name="location" placeholder="Office address, room number..." 
                         class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                </div>
              </div>
              
              <!-- Notes -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Interview Notes / Instructions</label>
                <textarea name="notes" rows="4" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" 
                          placeholder="Add any notes, instructions, or agenda for the interview..."></textarea>
              </div>
              
              <!-- Form Actions -->
              <div class="flex space-x-3 pt-4">
                <a href="view_applicant.php?id=<?php echo $applicant_id; ?>" 
                   class="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50">
                  Cancel
                </a>
                <button type="submit" class="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                  Schedule Interview
                </button>
              </div>
            </form>
          </div>
          
          <!-- Previous Interviews (if any) -->
          <?php
          try {
              $previous_query = "SELECT * FROM interviews WHERE applicant_id = ? ORDER BY scheduled_date DESC";
              $previous_stmt = $connections->prepare($previous_query);
              $previous_stmt->execute([$applicant_id]);
              $previous_interviews = $previous_stmt->fetchAll();
              
              if (!empty($previous_interviews)): ?>
              <div class="bg-white rounded-lg shadow mt-6">
                <div class="p-6 border-b border-gray-200">
                  <h3 class="text-lg font-semibold text-gray-800">Previous Interviews</h3>
                </div>
                <div class="p-6">
                  <div class="space-y-4">
                    <?php foreach ($previous_interviews as $interview): ?>
                    <?php
                      $scheduled_date = new DateTime($interview['scheduled_date']);
                      $date_display = $scheduled_date->format('F j, Y');
                      $time_display = $scheduled_date->format('g:i A');
                    ?>
                    <div class="border border-gray-200 rounded-lg p-4">
                      <div class="flex justify-between items-start">
                        <div>
                          <h4 class="font-medium text-gray-800">
                            <?php echo $date_display; ?> at <?php echo $time_display; ?>
                          </h4>
                          <p class="text-sm text-gray-600"><?php echo ucfirst(str_replace('_', ' ', $interview['interview_type'])); ?> Interview</p>
                          <p class="text-sm text-gray-600">Duration: <?php echo $interview['duration']; ?> minutes</p>
                          <?php if (!empty($interview['interviewers'])): ?>
                          <p class="text-sm text-gray-600">Interviewers: <?php echo htmlspecialchars($interview['interviewers']); ?></p>
                          <?php endif; ?>
                        </div>
                        <span class="px-2 py-1 text-xs rounded 
                          <?php echo $interview['status'] == 'completed' ? 'bg-green-100 text-green-800' : 
                                 ($interview['status'] == 'scheduled' ? 'bg-blue-100 text-blue-800' : 
                                 ($interview['status'] == 'cancelled' ? 'bg-red-100 text-red-800' : 
                                 'bg-gray-100 text-gray-800')); ?>">
                          <?php echo ucfirst($interview['status']); ?>
                        </span>
                      </div>
                      <?php if (!empty($interview['notes'])): ?>
                      <p class="mt-2 text-sm text-gray-700"><?php echo nl2br(htmlspecialchars($interview['notes'])); ?></p>
                      <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                  </div>
                </div>
              </div>
              <?php endif;
          } catch (Exception $e) {
              // Table doesn't exist yet, ignore
          }
          ?>
        </div>
      </div>
    </main>
  </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
  lucide.createIcons();
  
  // Show/hide additional fields based on interview type
  const interviewType = document.querySelector('select[name="interview_type"]');
  const interviewDetails = document.getElementById('interview_details');
  const videoDetails = document.getElementById('video_details');
  const inPersonDetails = document.getElementById('in_person_details');
  
  interviewType.addEventListener('change', function() {
    if (this.value === 'video') {
      interviewDetails.style.display = 'block';
      videoDetails.style.display = 'block';
      inPersonDetails.style.display = 'none';
    } else if (this.value === 'in_person') {
      interviewDetails.style.display = 'block';
      videoDetails.style.display = 'none';
      inPersonDetails.style.display = 'block';
    } else {
      interviewDetails.style.display = 'none';
    }
  });
  
  // Set minimum date to today
  const today = new Date().toISOString().split('T')[0];
  document.querySelector('input[name="interview_date"]').min = today;
  
  // Add required attribute validation for multiple select
  const interviewersSelect = document.querySelector('select[name="interviewers[]"]');
  const form = document.querySelector('form');
  
  form.addEventListener('submit', function(e) {
    if (interviewersSelect) {
      const selectedOptions = Array.from(interviewersSelect.selectedOptions);
      if (selectedOptions.length === 0) {
        e.preventDefault();
        alert('Please select at least one interviewer.');
        interviewersSelect.focus();
      }
    }
  });
});
</script>
</body>
</html>