<?php
// File: reschedule_interview.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

// Get interview ID
if (!isset($_GET['id'])) {
    header('Location: interviews.php');
    exit();
}

$interview_id = $_GET['id'];

// Fetch interview details
$query = "SELECT i.*, a.first_name, a.last_name, a.email, a.job_id, j.job_title 
          FROM interviews i
          JOIN applicants a ON i.applicant_id = a.id
          LEFT JOIN job_postings j ON a.job_id = j.id
          WHERE i.id = :id";

$stmt = $connections->prepare($query);
$stmt->bindParam(':id', $interview_id, PDO::PARAM_INT);
$stmt->execute();
$interview = $stmt->fetch();

if (!$interview) {
    $_SESSION['error'] = "Interview not found";
    header('Location: interviews.php');
    exit();
}

// Check if interview can be rescheduled
if ($interview['status'] != 'scheduled') {
    $_SESSION['error'] = "This interview cannot be rescheduled (already completed or cancelled)";
    header('Location: view_interview.php?id=' . $interview_id);
    exit();
}

// Parse current scheduled datetime
$current_date = new DateTime($interview['scheduled_date']);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        // Get form data
        $interview_date = $_POST['interview_date'];
        $interview_time = $_POST['interview_time'];
        $interviewers = $_POST['interviewers'] ?? $interview['interviewers'];
        $location = $_POST['location'] ?? $interview['location'];
        $interview_type = $_POST['interview_type'] ?? $interview['interview_type'];
        $notes = $_POST['notes'] ?? '';
        
        // Combine date and time
        $scheduled_date = $interview_date . ' ' . $interview_time . ':00';
        
        // Update interview
        $update_query = "UPDATE interviews SET 
                         scheduled_date = :scheduled_date,
                         interviewers = :interviewers,
                         location = :location,
                         interview_type = :interview_type,
                         notes = :notes,
                         rescheduled_at = NOW(),
                         rescheduled_by = :user_id,
                         updated_at = NOW()
                         WHERE id = :id";
        
        $update_stmt = $connections->prepare($update_query);
        $update_stmt->bindParam(':scheduled_date', $scheduled_date);
        $update_stmt->bindParam(':interviewers', $interviewers);
        $update_stmt->bindParam(':location', $location);
        $update_stmt->bindParam(':interview_type', $interview_type);
        $update_stmt->bindParam(':notes', $notes);
        $update_stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
        $update_stmt->bindParam(':id', $interview_id, PDO::PARAM_INT);
        $update_stmt->execute();
        
        // Log reschedule activity
        $log_query = "INSERT INTO interview_history 
                      (interview_id, action, action_by, details, created_at)
                      VALUES 
                      (:interview_id, 'rescheduled', :user_id, :details, NOW())";
        
        $log_details = json_encode([
            'old_date' => $interview['scheduled_date'],
            'new_date' => $scheduled_date,
            'old_interviewers' => $interview['interviewers'],
            'new_interviewers' => $interviewers
        ]);
        
        $log_stmt = $connections->prepare($log_query);
        $log_stmt->bindParam(':interview_id', $interview_id, PDO::PARAM_INT);
        $log_stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
        $log_stmt->bindParam(':details', $log_details);
        $log_stmt->execute();
        
        $_SESSION['success'] = "Interview rescheduled successfully!";
        header('Location: view_interview.php?id=' . $interview_id);
        exit();
        
    } catch (PDOException $e) {
        $_SESSION['error'] = "Failed to reschedule interview: " . $e->getMessage();
    }
}

// Set default values for form
$default_date = $current_date->format('Y-m-d');
$default_time = $current_date->format('H:i');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>HR1 - Reschedule Interview</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="h-screen bg-gray-100 font-sans">
<div class="flex h-full">
    
    <!-- Sidebar -->
    <?php include 'sidebar.php'; ?>
    
    <!-- Main Content -->
    <div class="flex-1 flex flex-col overflow-y-auto">
        <main class="p-6">
            <!-- Header -->
            <div class="flex items-center justify-between border-b border-gray-300 pb-4 mb-6">
                <div>
                    <div class="flex items-center space-x-3">
                        <a href="view_interview.php?id=<?php echo $interview['id']; ?>" class="text-blue-600 hover:text-blue-800">
                            <i data-lucide="arrow-left" class="w-5 h-5"></i>
                        </a>
                        <h2 class="text-2xl font-bold text-gray-800">Reschedule Interview</h2>
                    </div>
                    <p class="text-sm text-gray-600">Update interview date, time, or details</p>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="view_interview.php?id=<?php echo $interview['id']; ?>" 
                       class="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                        Cancel
                    </a>
                    <?php include 'profile_dropdown.php'; ?>
                </div>
            </div>

            <!-- Messages -->
            <?php if(isset($_SESSION['error'])): ?>
                <div class="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
                    <div class="flex items-center">
                        <i data-lucide="alert-circle" class="w-5 h-5 text-red-600 mr-2"></i>
                        <p class="text-red-700"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></p>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Main Content -->
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <!-- Left Column - Form -->
                <div class="lg:col-span-2">
                    <form method="POST" action="" class="space-y-6">
                        <div class="bg-white rounded-lg shadow border">
                            <div class="p-6 border-b border-gray-200">
                                <h3 class="text-lg font-semibold text-gray-800">Reschedule Details</h3>
                            </div>
                            <div class="p-6">
                                <!-- Date and Time -->
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">
                                            Interview Date *
                                        </label>
                                        <input type="date" name="interview_date" 
                                               value="<?php echo $default_date; ?>"
                                               min="<?php echo date('Y-m-d'); ?>"
                                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                               required>
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">
                                            Interview Time *
                                        </label>
                                        <input type="time" name="interview_time" 
                                               value="<?php echo $default_time; ?>"
                                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                               required>
                                    </div>
                                </div>

                                <!-- Interview Details -->
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">
                                            Interview Type
                                        </label>
                                        <select name="interview_type" 
                                                class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                            <option value="phone" <?php echo ($interview['interview_type'] ?? '') == 'phone' ? 'selected' : ''; ?>>Phone Screen</option>
                                            <option value="video" <?php echo ($interview['interview_type'] ?? '') == 'video' ? 'selected' : ''; ?>>Video Call</option>
                                            <option value="in_person" <?php echo ($interview['interview_type'] ?? '') == 'in_person' ? 'selected' : ''; ?>>In-Person</option>
                                            <option value="technical" <?php echo ($interview['interview_type'] ?? '') == 'technical' ? 'selected' : ''; ?>>Technical Interview</option>
                                            <option value="panel" <?php echo ($interview['interview_type'] ?? '') == 'panel' ? 'selected' : ''; ?>>Panel Interview</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">
                                            Location/Platform
                                        </label>
                                        <input type="text" name="location" 
                                               value="<?php echo htmlspecialchars($interview['location'] ?? ''); ?>"
                                               placeholder="e.g., Conference Room A, Zoom, Google Meet..."
                                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                    </div>
                                </div>

                                <!-- Interviewers -->
                                <div class="mb-6">
                                    <label class="block text-sm font-medium text-gray-700 mb-2">
                                        Interviewers *
                                    </label>
                                    <input type="text" name="interviewers" 
                                           value="<?php echo htmlspecialchars($interview['interviewers']); ?>"
                                           placeholder="Enter names separated by commas"
                                           class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                           required>
                                    <p class="mt-1 text-sm text-gray-500">Separate names with commas (e.g., John Doe, Jane Smith)</p>
                                </div>

                                <!-- Notes -->
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">
                                        Reschedule Notes
                                    </label>
                                    <textarea name="notes" rows="4" 
                                              placeholder="Optional: Add reason for rescheduling or additional details..."
                                              class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"></textarea>
                                </div>
                            </div>
                        </div>

                        <!-- Form Actions -->
                        <div class="flex items-center justify-between">
                            <a href="view_interview.php?id=<?php echo $interview['id']; ?>" 
                               class="px-6 py-3 border border-gray-300 rounded-lg hover:bg-gray-50">
                                Cancel
                            </a>
                            <div class="flex space-x-3">
                                <button type="button" onclick="previewEmail()" 
                                        class="px-6 py-3 border border-blue-300 text-blue-700 rounded-lg hover:bg-blue-50">
                                    Preview Email
                                </button>
                                <button type="submit" 
                                        class="px-6 py-3 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700">
                                    Reschedule Interview
                                </button>
                            </div>
                        </div>
                    </form>
                </div>

                <!-- Right Column - Current Details -->
                <div class="space-y-6">
                    <!-- Current Interview Details -->
                    <div class="bg-white rounded-lg shadow border">
                        <div class="p-6 border-b border-gray-200">
                            <h3 class="text-lg font-semibold text-gray-800">Current Schedule</h3>
                        </div>
                        <div class="p-6">
                            <div class="space-y-4">
                                <div>
                                    <p class="text-sm text-gray-600">Current Date & Time</p>
                                    <p class="font-medium text-gray-900">
                                        <?php echo $current_date->format('l, F j, Y'); ?>
                                    </p>
                                    <p class="text-gray-700">
                                        <?php echo $current_date->format('h:i A'); ?>
                                    </p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-600">Candidate</p>
                                    <p class="font-medium text-gray-900">
                                        <?php echo htmlspecialchars($interview['first_name'] . ' ' . $interview['last_name']); ?>
                                    </p>
                                    <p class="text-sm text-gray-600"><?php echo htmlspecialchars($interview['email']); ?></p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-600">Position</p>
                                    <p class="font-medium text-gray-900">
                                        <?php echo htmlspecialchars($interview['job_title'] ?? 'N/A'); ?>
                                    </p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-600">Current Interviewers</p>
                                    <p class="font-medium text-gray-900">
                                        <?php echo htmlspecialchars($interview['interviewers']); ?>
                                    </p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-600">Current Location</p>
                                    <p class="font-medium text-gray-900">
                                        <?php echo htmlspecialchars($interview['location'] ?? 'Not specified'); ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Time Conflict Check -->
                    <div class="bg-blue-50 border border-blue-200 rounded-lg p-6">
                        <h4 class="text-md font-semibold text-blue-800 mb-3 flex items-center">
                            <i data-lucide="alert-triangle" class="w-5 h-5 mr-2"></i>
                            Check for Conflicts
                        </h4>
                        <div class="space-y-3">
                            <div class="flex items-center justify-between">
                                <span class="text-sm text-blue-700">Interviewers Availability</span>
                                <button type="button" onclick="checkAvailability()" 
                                        class="text-sm px-3 py-1 bg-blue-100 text-blue-700 rounded hover:bg-blue-200">
                                    Check
                                </button>
                            </div>
                            <div class="flex items-center justify-between">
                                <span class="text-sm text-blue-700">Room/Platform Availability</span>
                                <button type="button" onclick="checkRoomAvailability()" 
                                        class="text-sm px-3 py-1 bg-blue-100 text-blue-700 rounded hover:bg-blue-200">
                                    Check
                                </button>
                            </div>
                        </div>
                        <div id="availabilityResult" class="mt-4 text-sm hidden"></div>
                    </div>

                    <!-- Suggested Times -->
                    <div class="bg-green-50 border border-green-200 rounded-lg p-6">
                        <h4 class="text-md font-semibold text-green-800 mb-3 flex items-center">
                            <i data-lucide="calendar" class="w-5 h-5 mr-2"></i>
                            Suggested Times
                        </h4>
                        <div class="space-y-2">
                            <?php
                            // Generate some suggested times (next 3 business days at common hours)
                            $suggested_times = [];
                            $base_date = new DateTime();
                            for ($i = 1; $i <= 3; $i++) {
                                $base_date->modify('+1 day');
                                // Skip weekends
                                while (in_array($base_date->format('N'), [6, 7])) {
                                    $base_date->modify('+1 day');
                                }
                                
                                $suggested_times[] = [
                                    'date' => $base_date->format('Y-m-d'),
                                    'time' => '09:00'
                                ];
                                $suggested_times[] = [
                                    'date' => $base_date->format('Y-m-d'),
                                    'time' => '14:00'
                                ];
                            }
                            ?>
                            <?php foreach(array_slice($suggested_times, 0, 4) as $suggested): ?>
                            <button type="button" onclick="useSuggestedTime('<?php echo $suggested['date']; ?>', '<?php echo $suggested['time']; ?>')" 
                                    class="w-full text-left p-3 border border-green-200 rounded hover:bg-green-100">
                                <div class="flex items-center justify-between">
                                    <div>
                                        <p class="text-sm font-medium text-green-900">
                                            <?php echo date('D, M j', strtotime($suggested['date'])); ?>
                                        </p>
                                        <p class="text-sm text-green-700">
                                            <?php echo date('g:i A', strtotime($suggested['time'])); ?>
                                        </p>
                                    </div>
                                    <i data-lucide="chevron-right" class="w-4 h-4 text-green-600"></i>
                                </div>
                            </button>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
function previewEmail() {
    const form = document.querySelector('form');
    const formData = new FormData(form);
    
    // Get form values
    const newDate = formData.get('interview_date');
    const newTime = formData.get('interview_time');
    const interviewers = formData.get('interviewers');
    
    // Format date for display
    const dateObj = new Date(newDate + 'T' + newTime);
    const formattedDate = dateObj.toLocaleDateString('en-US', { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    });
    const formattedTime = dateObj.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit' 
    });
    
    // Open email preview
    const emailContent = `
Subject: Interview Rescheduled - ${formattedDate}

Dear ${'<?php echo htmlspecialchars($interview["first_name"]); ?>'},

Your interview for the ${'<?php echo htmlspecialchars($interview["job_title"] ?? "position"); ?>'} has been rescheduled.

New Interview Details:
Date: ${formattedDate}
Time: ${formattedTime}
Interviewers: ${interviewers}
Location/Platform: ${formData.get('location') || 'To be confirmed'}

Best regards,
HR Team
    `.trim();
    
    // In a real application, you would send this to an email preview modal or endpoint
    alert('Email preview:\n\n' + emailContent);
}

function useSuggestedTime(date, time) {
    document.querySelector('input[name="interview_date"]').value = date;
    document.querySelector('input[name="interview_time"]').value = time;
    
    // Show confirmation
    const dateObj = new Date(date + 'T' + time);
    const formatted = dateObj.toLocaleString('en-US', {
        weekday: 'short',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
    
    const resultDiv = document.getElementById('availabilityResult');
    resultDiv.innerHTML = `
        <div class="p-3 bg-green-100 border border-green-300 rounded">
            <p class="text-green-800 font-medium">Time selected: ${formatted}</p>
            <p class="text-green-700 text-sm mt-1">Please verify availability and click "Reschedule Interview"</p>
        </div>
    `;
    resultDiv.classList.remove('hidden');
}

function checkAvailability() {
    const date = document.querySelector('input[name="interview_date"]').value;
    const time = document.querySelector('input[name="interview_time"]').value;
    
    if (!date || !time) {
        alert('Please select a date and time first');
        return;
    }
    
    const resultDiv = document.getElementById('availabilityResult');
    resultDiv.innerHTML = `
        <div class="p-3 bg-blue-100 border border-blue-300 rounded">
            <p class="text-blue-800 font-medium">Checking availability...</p>
            <p class="text-blue-700 text-sm mt-1">Simulating availability check for ${date} at ${time}</p>
        </div>
    `;
    resultDiv.classList.remove('hidden');
    
    // Simulate API call
    setTimeout(() => {
        // Simulate random availability result
        const isAvailable = Math.random() > 0.5;
        resultDiv.innerHTML = `
            <div class="p-3 ${isAvailable ? 'bg-green-100 border-green-300' : 'bg-yellow-100 border-yellow-300'} rounded">
                <p class="${isAvailable ? 'text-green-800' : 'text-yellow-800'} font-medium">
                    ${isAvailable ? '✓ Available' : '⚠ Potential Conflict'}
                </p>
                <p class="${isAvailable ? 'text-green-700' : 'text-yellow-700'} text-sm mt-1">
                    ${isAvailable ? 
                        'No conflicts detected with interviewers\' schedules.' : 
                        'Some interviewers may have scheduling conflicts. Please verify.'}
                </p>
            </div>
        `;
    }, 1500);
}

function checkRoomAvailability() {
    const location = document.querySelector('input[name="location"]').value;
    const date = document.querySelector('input[name="interview_date"]').value;
    const time = document.querySelector('input[name="interview_time"]').value;
    
    if (!location || !date || !time) {
        alert('Please fill in location, date, and time');
        return;
    }
    
    const resultDiv = document.getElementById('availabilityResult');
    resultDiv.innerHTML = `
        <div class="p-3 bg-blue-100 border border-blue-300 rounded">
            <p class="text-blue-800 font-medium">Checking room availability...</p>
            <p class="text-blue-700 text-sm mt-1">Checking ${location} for ${date} at ${time}</p>
        </div>
    `;
    resultDiv.classList.remove('hidden');
    
    // Simulate API call
    setTimeout(() => {
        // Simulate random availability result
        const isAvailable = Math.random() > 0.7;
        resultDiv.innerHTML = `
            <div class="p-3 ${isAvailable ? 'bg-green-100 border-green-300' : 'bg-red-100 border-red-300'} rounded">
                <p class="${isAvailable ? 'text-green-800' : 'text-red-800'} font-medium">
                    ${isAvailable ? '✓ Room Available' : '✗ Room Not Available'}
                </p>
                <p class="${isAvailable ? 'text-green-700' : 'text-red-700'} text-sm mt-1">
                    ${isAvailable ? 
                        `${location} is available at the selected time.` : 
                        `${location} is booked at this time. Please select a different time or location.`}
                </p>
            </div>
        `;
    }, 1500);
}

document.addEventListener("DOMContentLoaded", () => {
    lucide.createIcons();
});
</script>
</body>
</html>