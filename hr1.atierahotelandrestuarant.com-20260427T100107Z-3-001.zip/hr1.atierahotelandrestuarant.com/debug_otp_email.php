<?php
ini_set('display_errors', 1);
ini_set('log_errors', 1);
error_reporting(E_ALL);

require_once 'connections.php';

// Manually include the email functions but with detailed output
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

echo "<h2>Debugging sendOtpEmail</h2>";

// Check constants
echo "SMTP_HOST: " . SMTP_HOST . "<br>";
echo "SMTP_PORT: " . SMTP_PORT . "<br>";
echo "SMTP_USERNAME: " . SMTP_USERNAME . "<br>";
echo "SMTP_PASSWORD: " . (defined('SMTP_PASSWORD') ? 'SET' : 'NOT SET') . "<br>";
echo "SMTP_FROM_EMAIL: " . SMTP_FROM_EMAIL . "<br>";
echo "SMTP_FROM_NAME: " . SMTP_FROM_NAME . "<br>";
echo "OTP_EXPIRY_MINUTES: " . OTP_EXPIRY_MINUTES . "<br>";
echo "OTP_LENGTH: " . OTP_LENGTH . "<br><br>";

// Define a local copy of sendEmailViaSMTP with extra logging
function testSendEmailViaSMTP($to, $subject, $htmlMessage, $isHtml = true, $fromEmail = null, $fromName = null) {
    if ($fromEmail === null) $fromEmail = SMTP_FROM_EMAIL;
    if ($fromName === null) $fromName = SMTP_FROM_NAME;
    
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = SMTP_PORT;
        
        $mail->setFrom($fromEmail, $fromName);
        $mail->addAddress($to);
        $mail->isHTML($isHtml);
        $mail->Subject = $subject;
        $mail->Body    = $htmlMessage;
        if (!$isHtml) {
            $mail->AltBody = strip_tags($htmlMessage);
        }
        
        $mail->send();
        echo "✅ testSendEmailViaSMTP succeeded<br>";
        return true;
    } catch (Exception $e) {
        echo "❌ testSendEmailViaSMTP failed: " . $mail->ErrorInfo . "<br>";
        return false;
    }
}

// Now test a simple email using the local function
echo "<h3>Testing simple email via testSendEmailViaSMTP:</h3>";
$simpleResult = testSendEmailViaSMTP('vergarajamesryan47@gmail.com', 'Simple Test', 'Hello', true);
echo "Result: " . ($simpleResult ? 'SUCCESS' : 'FAILURE') . "<br><br>";

// Now test the full OTP email generation and sending
echo "<h3>Testing full OTP email (mimicking sendOtpEmail):</h3>";
$otp = '123456';
$name = 'System Administrator';
$email = 'vergarajamesryan47@gmail.com';

$subject = "Your HR1 Login OTP Code";
$message = '
<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .otp-code { 
            font-size: 32px; 
            font-weight: bold; 
            color: #004AAD;
            letter-spacing: 5px;
            text-align: center;
            margin: 20px 0;
            padding: 15px;
            background: #f0f7ff;
            border-radius: 8px;
            border: 2px dashed #004AAD;
        }
        .expiry { color: #666; font-size: 14px; }
        .footer { margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; color: #777; }
    </style>
</head>
<body>
    <div class="container">
        <h2>HR1 Login Verification</h2>
        <p>Hello ' . htmlspecialchars($name) . ',</p>
        <p>Your One-Time Password (OTP) for HR1 login is:</p>
        <div class="otp-code">' . $otp . '</div>
        <p class="expiry">This OTP is valid for ' . OTP_EXPIRY_MINUTES . ' minutes.</p>
        <p>If you didn\'t request this OTP, please ignore this email.</p>
        <div class="footer">
            <p>Best regards,<br>HR1 Team</p>
        </div>
    </div>
</body>
</html>';

$fullResult = testSendEmailViaSMTP($email, $subject, $message, true, SMTP_FROM_EMAIL, SMTP_FROM_NAME);
echo "Full OTP email result: " . ($fullResult ? 'SUCCESS' : 'FAILURE') . "<br>";

if (!$fullResult) {
    echo "<p style='color:red'>The OTP email failed. Check the error message above.</p>";
} else {
    echo "<p style='color:green'>The OTP email succeeded. Your `sendOtpEmail` function should work if it uses the same logic.</p>";
}
?>