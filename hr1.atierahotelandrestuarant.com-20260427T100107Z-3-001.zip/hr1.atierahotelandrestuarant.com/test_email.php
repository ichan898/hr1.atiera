<?php
require_once 'connections.php';
require_once 'email_functions.php';
$result = sendEmailViaSMTP('vergarajamesryan47@gmail.com', 'Test', 'SMTP works', true);
echo $result ? "OK" : "FAIL";
?>