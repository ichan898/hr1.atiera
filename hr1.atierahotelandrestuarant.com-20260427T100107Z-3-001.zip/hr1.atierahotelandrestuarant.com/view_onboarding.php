<?php
// File: view_onboarding.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

// Check if ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: onboarding.php');
    exit();
}

$id = $_GET['id'];

// Fetch employee details
$query = "SELECT * FROM onboarding WHERE id = ?";
$stmt = $connections->prepare($query);
$stmt->execute([$id]);
$employee = $stmt->fetch();

if (!$employee) {
    header('Location: onboarding.php');
    exit();
}

// Calculate completion percentage
$total_tasks = 5; // contract, documents, orientation, system, equipment
$completed_tasks = 0;
$completed_tasks += $employee['contract_signed'] ? 1 : 0;
$completed_tasks += $employee['documents_complete'] ? 1 : 0;
$completed_tasks += $employee['orientation_complete'] ? 1 : 0;
$completed_tasks += $employee['system_access_setup'] ? 1 : 0;
$completed_tasks += $employee['equipment_provided'] ? 1 : 0;
$completion_percentage = round(($completed_tasks / $total_tasks) * 100);

// Handle status updates
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_status'])) {
        $new_status = $_POST['status'];
        $notes = $_POST['notes'] ?? '';
        
        $update_query = "UPDATE onboarding SET status = ?, notes = ?, updated_at = NOW() WHERE id = ?";
        $update_stmt = $connections->prepare($update_query);
        $update_stmt->execute([$new_status, $notes, $id]);
        
        // Refresh employee data
        $stmt->execute([$id]);
        $employee = $stmt->fetch();
        $success = "Status updated successfully!";
    }
    
    // Handle task completion
    if (isset($_POST['complete_task'])) {
        $task = $_POST['task'];
        
        // Toggle the task
        $task_value = $employee[$task] ? 0 : 1;
        
        $task_query = "UPDATE onboarding SET $task = ?, updated_at = NOW() WHERE id = ?";
        $task_stmt = $connections->prepare($task_query);
        $task_stmt->execute([$task_value, $id]);
        
        // Refresh employee data
        $stmt->execute([$id]);
        $employee = $stmt->fetch();
        $success = "Task updated successfully!";
    }
}

// Recalculate after potential updates
$completed_tasks = 0;
$completed_tasks += $employee['contract_signed'] ? 1 : 0;
$completed_tasks += $employee['documents_complete'] ? 1 : 0;
$completed_tasks += $employee['orientation_complete'] ? 1 : 0;
$completed_tasks += $employee['system_access_setup'] ? 1 : 0;
$completed_tasks += $employee['equipment_provided'] ? 1 : 0;
$completion_percentage = round(($completed_tasks / $total_tasks) * 100);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HR1 - View Onboarding</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        .progress-bar {
            transition: width 0.3s ease-in-out;
        }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <!-- Main Container -->
    <div class="flex">
        <!-- Sidebar -->
        <?php include 'sidebar.php'; ?>

        <!-- Main Content -->
        <div class="flex-1 p-6">
            <!-- Header -->
            <div class="flex justify-between items-center mb-6">
                <div>
                    <h1 class="text-2xl font-bold text-gray-800">Onboarding Details</h1>
                    <p class="text-gray-600">Track and manage employee onboarding progress</p>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="onboarding.php" 
                       class="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 flex items-center">
                        <i data-lucide="arrow-left" class="w-4 h-4 mr-2"></i>
                        Back to List
                    </a>
                    <?php include 'profile_dropdown.php'; ?>
                </div>
            </div>

            <?php if (isset($success)): ?>
            <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-6">
                <div class="flex items-center">
                    <i data-lucide="check-circle" class="w-5 h-5 mr-2"></i>
                    <?php echo $success; ?>
                </div>
            </div>
            <?php endif; ?>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <!-- Left Column - Employee Info & Progress -->
                <div class="lg:col-span-2 space-y-6">
                    <!-- Employee Profile Card -->
                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                        <div class="flex items-start justify-between mb-6">
                            <div class="flex items-center">
                                <div class="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mr-4">
                                    <i data-lucide="user" class="w-10 h-10 text-blue-600"></i>
                                </div>
                                <div>
                                    <h2 class="text-xl font-bold text-gray-800">
                                        <?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?>
                                    </h2>
                                    <p class="text-gray-600"><?php echo htmlspecialchars($employee['job_position']); ?></p>
                                    <div class="flex items-center mt-1">
                                        <span class="text-sm text-gray-500">Employee ID:</span>
                                        <span class="text-sm font-medium ml-2"><?php echo htmlspecialchars($employee['employee_id']); ?></span>
                                    </div>
                                </div>
                            </div>
                            <div class="text-right">
                                <span class="inline-block px-4 py-2 text-sm font-semibold rounded-full 
                                    <?php echo $employee['status'] == 'onboarding' ? 'bg-yellow-100 text-yellow-800' : 
                                           ($employee['status'] == 'active' ? 'bg-green-100 text-green-800' : 
                                           'bg-gray-100 text-gray-800'); ?>">
                                    <?php echo ucfirst($employee['status']); ?>
                                </span>
                                <p class="text-sm text-gray-500 mt-2">Hired on <?php echo date('M d, Y', strtotime($employee['hire_date'])); ?></p>
                            </div>
                        </div>

                        <!-- Progress Bar -->
                        <div class="mb-8">
                            <div class="flex justify-between items-center mb-2">
                                <h3 class="font-medium text-gray-700">Onboarding Progress</h3>
                                <span class="text-sm font-medium"><?php echo $completion_percentage; ?>%</span>
                            </div>
                            <div class="w-full bg-gray-200 rounded-full h-3">
                                <div class="bg-blue-600 h-3 rounded-full progress-bar" style="width: <?php echo $completion_percentage; ?>%"></div>
                            </div>
                            <p class="text-sm text-gray-500 mt-1"><?php echo $completed_tasks; ?> of <?php echo $total_tasks; ?> tasks completed</p>
                        </div>

                        <!-- Quick Info Grid -->
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            <div class="bg-gray-50 p-4 rounded-lg">
                                <div class="flex items-center">
                                    <div class="p-2 bg-blue-100 rounded-lg mr-3">
                                        <i data-lucide="mail" class="w-5 h-5 text-blue-600"></i>
                                    </div>
                                    <div>
                                        <p class="text-sm text-gray-500">Email</p>
                                        <p class="font-medium"><?php echo htmlspecialchars($employee['email']); ?></p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="bg-gray-50 p-4 rounded-lg">
                                <div class="flex items-center">
                                    <div class="p-2 bg-green-100 rounded-lg mr-3">
                                        <i data-lucide="phone" class="w-5 h-5 text-green-600"></i>
                                    </div>
                                    <div>
                                        <p class="text-sm text-gray-500">Contact</p>
                                        <p class="font-medium"><?php echo htmlspecialchars($employee['contact_number']); ?></p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="bg-gray-50 p-4 rounded-lg">
                                <div class="flex items-center">
                                    <div class="p-2 bg-purple-100 rounded-lg mr-3">
                                        <i data-lucide="briefcase" class="w-5 h-5 text-purple-600"></i>
                                    </div>
                                    <div>
                                        <p class="text-sm text-gray-500">Department</p>
                                        <p class="font-medium"><?php echo htmlspecialchars($employee['department']); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Onboarding Checklist -->
                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                        <h3 class="text-lg font-semibold mb-4">Onboarding Checklist</h3>
                        <div class="space-y-4">
                            <?php
                            $tasks = [
                                'contract_signed' => [
                                    'name' => 'Employment Contract',
                                    'icon' => 'file-text',
                                    'description' => 'Sign and submit employment agreement',
                                    'action' => 'sign_contract.php?id=' . $employee['id']
                                ],
                                'documents_complete' => [
                                    'name' => 'Required Documents',
                                    'icon' => 'folder-check',
                                    'description' => 'Submit all required government IDs and forms',
                                    'action' => 'upload_documents.php?id=' . $employee['id']
                                ],
                                'orientation_complete' => [
                                    'name' => 'Company Orientation',
                                    'icon' => 'presentation',
                                    'description' => 'Complete new hire orientation session',
                                    'action' => 'complete_orientation.php?id=' . $employee['id']
                                ],
                                'system_access_setup' => [
                                    'name' => 'System Access',
                                    'icon' => 'key',
                                    'description' => 'Setup email, HR system, and other accounts',
                                    'action' => 'setup_system.php?id=' . $employee['id']
                                ],
                                'equipment_provided' => [
                                    'name' => 'Equipment Issue',
                                    'icon' => 'monitor',
                                    'description' => 'Provide work equipment and tools',
                                    'action' => 'provide_equipment.php?id=' . $employee['id']
                                ]
                            ];
                            
                            foreach ($tasks as $key => $task):
                                $completed = $employee[$key];
                            ?>
                            <div class="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 <?php echo $completed ? 'border-green-200 bg-green-50' : 'border-gray-200'; ?>">
                                <div class="flex items-center">
                                    <div class="mr-4">
                                        <?php if ($completed): ?>
                                        <div class="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                                            <i data-lucide="check-circle" class="w-6 h-6 text-green-600"></i>
                                        </div>
                                        <?php else: ?>
                                        <div class="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                                            <i data-lucide="<?php echo $task['icon']; ?>" class="w-5 h-5 text-gray-400"></i>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <div>
                                        <p class="font-medium <?php echo $completed ? 'text-green-800' : 'text-gray-800'; ?>">
                                            <?php echo $task['name']; ?>
                                        </p>
                                        <p class="text-sm <?php echo $completed ? 'text-green-600' : 'text-gray-500'; ?>">
                                            <?php echo $task['description']; ?>
                                        </p>
                                    </div>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <?php if ($completed): ?>
                                    <span class="px-3 py-1 text-xs bg-green-100 text-green-800 rounded-full">
                                        Completed
                                    </span>
                                    <?php else: ?>
                                    <form method="POST" class="inline">
                                        <input type="hidden" name="task" value="<?php echo $key; ?>">
                                        <button type="submit" name="complete_task" 
                                                class="px-3 py-1 text-xs bg-blue-100 text-blue-800 rounded-full hover:bg-blue-200">
                                            Mark Complete
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                    
                                    <?php if (!$completed && isset($task['action'])): ?>
                                    <a href="<?php echo $task['action']; ?>"
                                       class="px-3 py-1 text-xs border border-gray-300 rounded-full hover:bg-gray-50">
                                        Details
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Additional Information -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <!-- Personal Information -->
                        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                            <h3 class="text-lg font-semibold mb-4 flex items-center">
                                <i data-lucide="user-circle" class="w-5 h-5 mr-2"></i>
                                Personal Information
                            </h3>
                            <div class="space-y-3">
                                <div>
                                    <p class="text-sm text-gray-500">Full Name</p>
                                    <p class="font-medium"><?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['middle_name'] . ' ' . $employee['last_name']); ?></p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-500">Date of Birth</p>
                                    <p class="font-medium"><?php echo date('M d, Y', strtotime($employee['date_of_birth'])); ?></p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-500">Address</p>
                                    <p class="font-medium"><?php echo htmlspecialchars($employee['address']); ?></p>
                                </div>
                            </div>
                        </div>

                        <!-- Employment Details -->
                        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                            <h3 class="text-lg font-semibold mb-4 flex items-center">
                                <i data-lucide="building" class="w-5 h-5 mr-2"></i>
                                Employment Details
                            </h3>
                            <div class="space-y-3">
                                <div>
                                    <p class="text-sm text-gray-500">Position</p>
                                    <p class="font-medium"><?php echo htmlspecialchars($employee['job_position']); ?></p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-500">Employment Type</p>
                                    <p class="font-medium"><?php echo ucfirst($employee['employment_type']); ?></p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-500">Supervisor</p>
                                    <p class="font-medium"><?php echo htmlspecialchars($employee['supervisor_name'] ?: 'Not assigned'); ?></p>
                                </div>
                                <?php if ($employee['salary']): ?>
                                <div>
                                    <p class="text-sm text-gray-500">Salary</p>
                                    <p class="font-medium">₱<?php echo number_format($employee['salary'], 2); ?></p>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Right Column - Actions & Timeline -->
                <div class="space-y-6">
                    <!-- Action Panel -->
                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                        <h3 class="text-lg font-semibold mb-4">Quick Actions</h3>
                        <div class="space-y-3">
                            <!-- Update Status -->
                            <form method="POST" class="space-y-3">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Update Status</label>
                                    <select name="status" class="w-full border border-gray-300 rounded-lg p-2">
                                        <option value="onboarding" <?php echo $employee['status'] == 'onboarding' ? 'selected' : ''; ?>>Onboarding</option>
                                        <option value="active" <?php echo $employee['status'] == 'active' ? 'selected' : ''; ?>>Active</option>
                                        <option value="completed" <?php echo $employee['status'] == 'completed' ? 'selected' : ''; ?>>Completed</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Notes</label>
                                    <textarea name="notes" rows="3" 
                                              class="w-full border border-gray-300 rounded-lg p-2"
                                              placeholder="Add notes about this update..."><?php echo htmlspecialchars($employee['notes'] ?? ''); ?></textarea>
                                </div>
                                <button type="submit" name="update_status"
                                        class="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700">
                                    Update Status
                                </button>
                            </form>

                            <div class="border-t pt-4 space-y-2">
                                <?php if (!$employee['contract_signed']): ?>
                                <a href="sign_contract.php?id=<?php echo $employee['id']; ?>"
                                   class="block w-full text-center bg-green-600 text-white py-2 rounded-lg hover:bg-green-700">
                                    <i data-lucide="file-signature" class="w-4 h-4 inline mr-2"></i>
                                    Sign Contract
                                </a>
                                <?php endif; ?>

                                <?php if ($employee['resume']): ?>
                                <a href="<?php echo htmlspecialchars($employee['resume']); ?>" 
                                   target="_blank"
                                   class="block w-full text-center border border-blue-600 text-blue-600 py-2 rounded-lg hover:bg-blue-50">
                                    <i data-lucide="file-text" class="w-4 h-4 inline mr-2"></i>
                                    View Resume
                                </a>
                                <?php endif; ?>

                                <a href="edit_onboarding.php?id=<?php echo $employee['id']; ?>"
                                   class="block w-full text-center border border-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-50">
                                    <i data-lucide="edit" class="w-4 h-4 inline mr-2"></i>
                                    Edit Details
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Timeline -->
                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                        <h3 class="text-lg font-semibold mb-4 flex items-center">
                            <i data-lucide="history" class="w-5 h-5 mr-2"></i>
                            Timeline
                        </h3>
                        <div class="space-y-4">
                            <div class="flex items-start">
                                <div class="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mr-3 mt-1">
                                    <i data-lucide="user-plus" class="w-4 h-4 text-blue-600"></i>
                                </div>
                                <div>
                                    <p class="font-medium">Onboarding Started</p>
                                    <p class="text-sm text-gray-500">Added to system</p>
                                    <p class="text-xs text-gray-400"><?php echo date('M d, Y H:i', strtotime($employee['created_at'])); ?></p>
                                </div>
                            </div>

                            <?php if ($employee['contract_signed']): ?>
                            <div class="flex items-start">
                                <div class="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mr-3 mt-1">
                                    <i data-lucide="file-check" class="w-4 h-4 text-green-600"></i>
                                </div>
                                <div>
                                    <p class="font-medium">Contract Signed</p>
                                    <p class="text-sm text-gray-500">Employment agreement completed</p>
                                    <p class="text-xs text-gray-400">Last updated: <?php echo date('M d, Y', strtotime($employee['updated_at'])); ?></p>
                                </div>
                            </div>
                            <?php endif; ?>

                            <?php if ($employee['documents_complete']): ?>
                            <div class="flex items-start">
                                <div class="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mr-3 mt-1">
                                    <i data-lucide="folder-check" class="w-4 h-4 text-green-600"></i>
                                </div>
                                <div>
                                    <p class="font-medium">Documents Submitted</p>
                                    <p class="text-sm text-gray-500">All required documents received</p>
                                </div>
                            </div>
                            <?php endif; ?>

                            <div class="flex items-start">
                                <div class="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center mr-3 mt-1">
                                    <i data-lucide="calendar" class="w-4 h-4 text-gray-400"></i>
                                </div>
                                <div>
                                    <p class="font-medium">Expected Start Date</p>
                                    <p class="text-sm text-gray-500">
                                        <?php echo $employee['start_date'] ? date('M d, Y', strtotime($employee['start_date'])) : 'To be determined'; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- System Information -->
                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                        <h3 class="text-lg font-semibold mb-4 flex items-center">
                            <i data-lucide="database" class="w-5 h-5 mr-2"></i>
                            System Information
                        </h3>
                        <div class="space-y-3">
                            <div class="flex justify-between">
                                <span class="text-sm text-gray-600">Created</span>
                                <span class="text-sm font-medium"><?php echo date('M d, Y', strtotime($employee['created_at'])); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-sm text-gray-600">Last Updated</span>
                                <span class="text-sm font-medium"><?php echo date('M d, Y', strtotime($employee['updated_at'])); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-sm text-gray-600">Employee ID</span>
                                <span class="text-sm font-medium"><?php echo htmlspecialchars($employee['employee_id']); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-sm text-gray-600">Applicant ID</span>
                                <span class="text-sm font-medium"><?php echo $employee['applicant_id'] ?: 'N/A'; ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener("DOMContentLoaded", () => {
        lucide.createIcons();
        
        // Update progress bar animation
        const progressBar = document.querySelector('.progress-bar');
        if (progressBar) {
            const width = progressBar.style.width;
            progressBar.style.width = '0';
            setTimeout(() => {
                progressBar.style.width = width;
            }, 100);
        }
    });
    </script>
</body>
</html>