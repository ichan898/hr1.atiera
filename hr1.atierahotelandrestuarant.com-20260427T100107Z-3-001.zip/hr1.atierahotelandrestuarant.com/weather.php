<?php
// weather.php - Proxy for OpenWeatherMap API
header('Content-Type: application/json');

// ---------- CONFIGURATION ----------
$apiKey = '54e3874d2c9a72028f8d74fc7dcd1b45';  // Replace with your actual key
$units = 'metric';                         // 'metric' for °C, 'imperial' for °F
$defaultCity = 'Manila';                    // Fallback Philippine city
// -----------------------------------

$lat = $_GET['lat'] ?? null;
$lon = $_GET['lon'] ?? null;
$city = $_GET['city'] ?? null;

if ($lat && $lon) {
    $url = "https://api.openweathermap.org/data/2.5/weather?lat={$lat}&lon={$lon}&appid={$apiKey}&units={$units}";
} elseif ($city) {
    $url = "https://api.openweathermap.org/data/2.5/weather?q={$city}&appid={$apiKey}&units={$units}";
} else {
    $url = "https://api.openweathermap.org/data/2.5/weather?q={$defaultCity}&appid={$apiKey}&units={$units}";
}

$response = @file_get_contents($url);
if ($response === false) {
    http_response_code(500);
    echo json_encode(['error' => 'Unable to contact weather service']);
    exit;
}

$data = json_decode($response, true);
if (!$data || (isset($data['cod']) && $data['cod'] != 200)) {
    http_response_code(500);
    echo json_encode(['error' => $data['message'] ?? 'Unknown error']);
    exit;
}

// Extract only the fields we need
$weather = [
    'temp'      => round($data['main']['temp']),
    'condition' => $data['weather'][0]['description'],
    'icon'      => $data['weather'][0]['icon'],
    'city'      => $data['name'],
    'humidity'  => $data['main']['humidity'],
    'wind'      => $data['wind']['speed']
];

echo json_encode($weather);
?>