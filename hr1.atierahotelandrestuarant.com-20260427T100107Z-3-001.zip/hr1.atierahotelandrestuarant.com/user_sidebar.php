<?php
// File: sidebar.php
$current_page = basename($_SERVER['PHP_SELF']);

// Get counts for badges
$badges = [];
try {
    // Pending job requests
    $stmt = $connections->prepare("SELECT COUNT(*) as count FROM job_requests WHERE overall_status = 'pending' AND is_active = TRUE");
    $stmt->execute();
    $badges['requests'] = $stmt->fetch()['count'];
    
    // New applicants
    $stmt = $connections->prepare("SELECT COUNT(*) as count FROM applicants WHERE application_status = 'new'");
    $stmt->execute();
    $badges['applicants'] = $stmt->fetch()['count'];
    
    // Today's interviews
    $stmt = $connections->prepare("SELECT COUNT(*) as count FROM interviews WHERE DATE(interview_date) = CURDATE() AND status = 'scheduled'");
    $stmt->execute();
    $badges['interviews'] = $stmt->fetch()['count'];
    
    // Onboarding employees
    $stmt = $connections->prepare("SELECT COUNT(*) as count FROM onboarding WHERE status = 'onboarding'");
    $stmt->execute();
    $badges['onboarding'] = $stmt->fetch()['count'];
} catch (PDOException $e) {
    error_log("Sidebar error: " . $e->getMessage());
    $badges = ['requests' => 0, 'applicants' => 0, 'interviews' => 0, 'onboarding' => 0];
}
?>

<aside class="w-64 bg-gray-900 text-white shadow-lg">
  <!-- Header -->
  <div class="p-6 border-b border-gray-700">
  <div class="flex items-center space-x-3">
    <div class="w-10 h-10 bg-gray-700 rounded-lg flex items-center justify-center overflow-hidden">
      <img 
        src="assets/logo2.png" 
        alt="HR1 Logo"
        class="w-8 h-8 object-contain"
      >
    </div>
    <div>
      <h2 class="font-bold text-white">HR1 System</h2>
      <p class="text-xs text-gray-400">Recruitment</p>
    </div>
  </div>
</div>

  <!-- Navigation -->
  <nav class="p-4 space-y-1">
    
    <!-- Dashboard -->
    <a href="user_dashboard.php"
       class="flex items-center justify-between p-3 rounded-lg
       <?php echo $current_page == 'admin_dashboard.php'
         ? 'bg-gray-700 text-white'
         : 'hover:bg-gray-800 text-gray-200'; ?>">
      <div class="flex items-center space-x-3">
        <i data-lucide="layout-dashboard" class="w-5 h-5"></i>
        <span>Dashboard</span>
      </div>
    </a>

    <!-- Job Requests -->
    <a href="user_job_requests.php"
       class="flex items-center justify-between p-3 rounded-lg
       <?php echo $current_page == 'job_requests.php'
         ? 'bg-gray-700 text-white'
         : 'hover:bg-gray-800 text-gray-200'; ?>">
      <div class="flex items-center space-x-3">
        <i data-lucide="file-text" class="w-5 h-5"></i>
        <span>Job Requests</span>
      </div>
      <?php if ($badges['requests'] > 0): ?>
        <span class="bg-gray-600 text-white text-xs rounded-full px-2 py-1">
          <?php echo $badges['requests']; ?>
        </span>
      <?php endif; ?>
    </a>

    <!-- Job Postings -->
    <a href="user_job_postings.php"
       class="flex items-center justify-between p-3 rounded-lg
       <?php echo $current_page == 'job_postings.php'
         ? 'bg-gray-700 text-white'
         : 'hover:bg-gray-800 text-gray-200'; ?>">
      <div class="flex items-center space-x-3">
        <i data-lucide="megaphone" class="w-5 h-5"></i>
        <span>Job Postings</span>
      </div>
    </a>

    <!-- Applicants -->
    <a href="user_applicants.php"
       class="flex items-center justify-between p-3 rounded-lg
       <?php echo $current_page == 'applicants.php'
         ? 'bg-gray-700 text-white'
         : 'hover:bg-gray-800 text-gray-200'; ?>">
      <div class="flex items-center space-x-3">
        <i data-lucide="users" class="w-5 h-5"></i>
        <span>Applicants</span>
      </div>
      <?php if ($badges['applicants'] > 0): ?>
        <span class="bg-gray-500 text-white text-xs rounded-full px-2 py-1">
          <?php echo $badges['applicants']; ?>
        </span>
      <?php endif; ?>
    </a>

    <!-- Interviews -->
    <a href="user_interviews.php"
       class="flex items-center justify-between p-3 rounded-lg
       <?php echo $current_page == 'interviews.php'
         ? 'bg-gray-700 text-white'
         : 'hover:bg-gray-800 text-gray-200'; ?>">
      <div class="flex items-center space-x-3">
        <i data-lucide="calendar" class="w-5 h-5"></i>
        <span>Interviews</span>
      </div>
      <?php if ($badges['interviews'] > 0): ?>
        <span class="bg-gray-500 text-white text-xs rounded-full px-2 py-1">
          <?php echo $badges['interviews']; ?>
        </span>
      <?php endif; ?>
    </a>

    <!-- Onboarding -->
    <a href="user_onboarding.php"
       class="flex items-center justify-between p-3 rounded-lg
       <?php echo $current_page == 'onboarding.php'
         ? 'bg-gray-700 text-white'
         : 'hover:bg-gray-800 text-gray-200'; ?>">
      <div class="flex items-center space-x-3">
        <i data-lucide="user-check" class="w-5 h-5"></i>
        <span>Onboarding</span>
      </div>
      <?php if ($badges['onboarding'] > 0): ?>
        <span class="bg-gray-500 text-white text-xs rounded-full px-2 py-1">
          <?php echo $badges['onboarding']; ?>
        </span>
      <?php endif; ?>
    </a>

   

    <!-- Footer -->
    <div class="pt-4 border-t border-gray-700">
    

  </nav>
</aside>
