-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 27, 2026 at 09:56 AM
-- Server version: 10.11.14-MariaDB-ubu2204
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hr1_recruitment_system`
--
CREATE DATABASE IF NOT EXISTS `hr1_recruitment_system` DEFAULT CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci;
USE `hr1_recruitment_system`;

-- --------------------------------------------------------

--
-- Table structure for table `activity_logs`
--

CREATE TABLE `activity_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  `description` text DEFAULT NULL,
  `table_name` varchar(50) DEFAULT NULL,
  `record_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `activity_logs`
--

INSERT INTO `activity_logs` (`id`, `user_id`, `action`, `details`, `description`, `table_name`, `record_id`, `ip_address`, `user_agent`, `created_at`) VALUES
(1, 1, 'job_request_created', NULL, 'Created job request for Sous Chef', 'job_requests', 1, '127.0.0.1', 'System', '2026-02-27 22:03:11'),
(2, 1, 'job_posting_created', NULL, 'Created job posting from request #1', 'job_postings', 1, '127.0.0.1', 'System', '2026-02-27 22:03:11'),
(3, 2, 'applicant_screened', NULL, 'Screened applicant Charlie Parker - Qualified', 'applicants', 1, '127.0.0.1', 'System', '2026-02-27 22:03:11'),
(4, 10, 'interview_scheduled', NULL, 'Scheduled interview for Charlie Parker', 'interviews', 1, '127.0.0.1', 'System', '2026-02-27 22:03:11'),
(5, 1, 'award_given', NULL, 'Gave award to John Doe', 'awards', 1, '127.0.0.1', 'System', '2026-02-27 22:03:11'),
(6, 1, 'onboarding_created', NULL, 'Started onboarding for Charlie Parker', 'onboarding', 1, '127.0.0.1', 'System', '2026-02-27 22:03:11'),
(7, 1, 'employee_updated', NULL, 'Updated employee: David Lee', 'employees', 7, '27.49.10.194', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-02-27 22:23:24'),
(9, 1, 'employee_status_quick_changed', NULL, 'Quick status change to \'On Leave\' for employee ID: 43', 'employees', 43, '136.158.61.28', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', '2026-02-27 23:20:41'),
(10, 1, 'employee_status_quick_changed', NULL, 'Quick status change to \'On Leave\' for employee ID: 9', 'employees', 9, '136.158.61.28', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', '2026-02-27 23:20:50'),
(11, 1, 'employee_status_quick_changed', NULL, 'Quick status change to \'On Leave\' for employee ID: 38', 'employees', 38, '136.158.61.28', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', '2026-02-27 23:20:58'),
(12, 1, 'employee_status_quick_changed', NULL, 'Quick status change to \'Inactive\' for employee ID: 12', 'employees', 12, '136.158.61.28', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', '2026-02-27 23:21:09'),
(13, 1, 'employee_status_quick_changed', NULL, 'Quick status change to \'Terminated\' for employee ID: 18', 'employees', 18, '136.158.61.28', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', '2026-02-27 23:21:16'),
(14, 1, 'recognition_created', NULL, 'Created recognition #2 for employee ID: 27', 'recognitions', 2, '120.28.81.213', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-02-28 00:22:36'),
(15, 1, 'recognition_created', NULL, 'Created recognition #3 for employee ID: 20', 'recognitions', 3, '120.28.81.213', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-02-28 00:25:02'),
(16, 1, 'applicant_screened', '{\"applicant_id\":\"7\",\"qualification_score\":87,\"is_qualified\":1,\"screening_result\":\"passed\",\"education_score\":\"4\",\"experience_score\":\"4\",\"skills_score\":\"5\"}', 'Screened applicant: James Bond - Qualified (87/100)', 'applicants', 7, '209.35.167.160', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-02-28 00:40:36'),
(17, 1, 'applicant_screened', '{\"applicant_id\":\"8\",\"qualification_score\":80,\"is_qualified\":1,\"screening_result\":\"passed\",\"education_score\":\"5\",\"experience_score\":\"3\",\"skills_score\":\"4\"}', 'Screened applicant: Ronnico Espiritu - Qualified (80/100)', 'applicants', 8, '209.35.167.160', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-02-28 00:43:20'),
(18, 1, 'applicant_screened', '{\"applicant_id\":\"6\",\"qualification_score\":87,\"is_qualified\":1,\"screening_result\":\"passed\",\"education_score\":\"5\",\"experience_score\":\"4\",\"skills_score\":\"4\"}', 'Screened applicant: Nebula Prime - Qualified (87/100)', 'applicants', 6, '209.35.167.160', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-02-28 00:45:18'),
(19, 1, 'applicant_screened', '{\"applicant_id\":\"3\",\"qualification_score\":80,\"is_qualified\":1,\"screening_result\":\"passed\",\"education_score\":\"5\",\"experience_score\":\"3\",\"skills_score\":\"4\"}', 'Screened applicant: Peter Quill - Qualified (80/100)', 'applicants', 3, '209.35.167.160', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-02-28 00:45:33'),
(20, 1, 'applicant_screened', '{\"applicant_id\":\"5\",\"qualification_score\":73,\"is_qualified\":1,\"screening_result\":\"passed\",\"education_score\":\"4\",\"experience_score\":\"3\",\"skills_score\":\"4\"}', 'Screened applicant: Rocket Raccoon - Qualified (73/100)', 'applicants', 5, '209.35.167.160', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-02-28 00:45:49'),
(21, 1, 'onboarding_created', '{\"applicant_id\":\"5\",\"interview_id\":\"5\",\"onboarding_id\":\"2\",\"employee_id\":\"EMP2026020002\",\"position\":\"Accountant\"}', NULL, NULL, NULL, NULL, NULL, '2026-02-28 00:47:53'),
(22, 1, 'applicant_screened', '{\"applicant_id\":\"9\",\"qualification_score\":80,\"is_qualified\":1,\"screening_result\":\"passed\",\"education_score\":\"4\",\"experience_score\":\"4\",\"skills_score\":\"4\"}', 'Screened applicant: James Kneechtel Sabandal - Qualified (80/100)', 'applicants', 9, '27.49.10.194', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-04 00:29:24'),
(23, 1, 'applicant_screened', '{\"applicant_id\":\"2\",\"qualification_score\":93,\"is_qualified\":1,\"screening_result\":\"passed\",\"education_score\":\"4\",\"experience_score\":\"5\",\"skills_score\":\"5\"}', 'Screened applicant: Diana Prince - Qualified (93/100)', 'applicants', 2, '175.158.203.168', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-04 05:59:17'),
(24, 1, 'onboarding_created', '{\"applicant_id\":\"2\",\"interview_id\":\"12\",\"onboarding_id\":\"4\",\"employee_id\":\"EMP2026030003\",\"position\":\"Sous Chef\"}', NULL, NULL, NULL, NULL, NULL, '2026-03-04 06:00:21'),
(25, 1, 'onboarding_created', '{\"applicant_id\":\"9\",\"interview_id\":\"11\",\"onboarding_id\":\"5\",\"employee_id\":\"EMP2026030004\",\"position\":\"Driver\"}', NULL, NULL, NULL, NULL, NULL, '2026-03-04 06:03:52'),
(26, 1, 'applicant_screened', '{\"applicant_id\":\"10\",\"qualification_score\":87,\"is_qualified\":1,\"screening_result\":\"passed\",\"education_score\":\"5\",\"experience_score\":\"5\",\"skills_score\":\"3\"}', 'Screened applicant: James Kneechtel DL. Sabandal - Qualified (87/100)', 'applicants', 10, '175.158.203.168', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-04 06:35:23'),
(27, 1, 'applicant_screened', '{\"applicant_id\":\"8\",\"qualification_score\":87,\"is_qualified\":1,\"screening_result\":\"passed\",\"education_score\":\"5\",\"experience_score\":\"3\",\"skills_score\":\"5\"}', 'Screened applicant: Ronnico Espiritu - Qualified (87/100)', 'applicants', 8, '175.158.203.168', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-04 06:36:35'),
(28, 1, 'onboarding_created', '{\"applicant_id\":\"8\",\"interview_id\":\"14\",\"onboarding_id\":\"7\",\"employee_id\":\"EMP2026030005\",\"position\":\"Reservation Officer\"}', NULL, NULL, NULL, NULL, NULL, '2026-03-04 06:37:22'),
(29, 1, 'applicant_screened', '{\"applicant_id\":\"2\",\"qualification_score\":60,\"is_qualified\":0,\"screening_result\":\"failed\",\"education_score\":\"3\",\"experience_score\":\"3\",\"skills_score\":\"3\"}', 'Screened applicant: Diana Prince - Not Qualified (60/100)', 'applicants', 2, '175.158.203.166', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-04 09:08:43'),
(30, 1, 'applicant_screened', '{\"applicant_id\":\"2\",\"qualification_score\":73,\"is_qualified\":1,\"screening_result\":\"passed\",\"education_score\":\"3\",\"experience_score\":\"4\",\"skills_score\":\"4\"}', 'Screened applicant: Diana Prince - Qualified (73/100)', 'applicants', 2, '175.158.203.166', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-04 09:16:20'),
(31, 1, 'employee_updated', NULL, 'Updated employee: James Kneechtel Sabandal', 'employees', 14, '175.158.203.166', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-04 09:40:14'),
(32, 1, 'applicant_screened', '{\"applicant_id\":\"1\",\"qualification_score\":87,\"is_qualified\":1,\"screening_result\":\"passed\",\"education_score\":5,\"experience_score\":4,\"skills_score\":4}', 'Screened applicant: Charlie Parker - Qualified (87/100)', 'applicants', 1, '136.158.61.148', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0', '2026-04-07 21:44:10'),
(33, 1, 'job_request_status_updated', NULL, 'Updated job request #8 status to approved', 'job_requests', 8, '2405:8d40:4079:9b13:1dc4:413d:addb:dea1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0', '2026-04-23 01:27:51'),
(34, 1, 'job_request_updated', NULL, 'Updated job request #8: HR3 Manager', 'job_requests', 8, '2405:8d40:4079:9b13:1dc4:413d:addb:dea1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0', '2026-04-23 01:30:25'),
(35, 1, 'job_request_status_updated', NULL, 'Updated job request #8 status to pending', 'job_requests', 8, '2405:8d40:4079:9b13:1dc4:413d:addb:dea1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0', '2026-04-23 01:30:25'),
(36, 1, 'job_request_status_updated', NULL, 'Updated job request #8 status to approved', 'job_requests', 8, '2405:8d40:4079:9b13:1dc4:413d:addb:dea1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0', '2026-04-23 01:31:19'),
(37, 1, 'applicant_screened', '{\"applicant_id\":\"11\",\"qualification_score\":81,\"is_qualified\":1,\"screening_result\":\"passed\",\"education_score\":4,\"experience_score\":4,\"skills_score\":4}', 'Screened applicant: Christian Costibolo - Qualified (81/100)', 'applicants', 11, '2405:8d40:4079:9b13:1dc4:413d:addb:dea1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0', '2026-04-23 01:35:49'),
(38, 1, 'onboarding_created', '{\"applicant_id\":\"11\",\"interview_id\":\"15\",\"onboarding_id\":\"10\",\"employee_id\":\"EMP2026040007\",\"position\":\"HR1 Staff\"}', NULL, NULL, NULL, NULL, NULL, '2026-04-23 01:39:46');

-- --------------------------------------------------------

--
-- Table structure for table `applicants`
--

CREATE TABLE `applicants` (
  `id` int(11) NOT NULL,
  `job_id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` text DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `resume_path` varchar(500) DEFAULT NULL,
  `qualifications` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`qualifications`)),
  `cover_letter_path` varchar(500) DEFAULT NULL,
  `application_status` enum('new','reviewed','shortlisted','interviewed','rejected','hired') DEFAULT 'new',
  `source` varchar(50) DEFAULT 'website',
  `qualification_score` int(11) DEFAULT 0,
  `experience_years` int(11) DEFAULT 0,
  `is_qualified` tinyint(1) DEFAULT 0,
  `notes` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `applied_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `auto_scheduled` tinyint(1) DEFAULT 0,
  `auto_schedule_attempted` tinyint(1) DEFAULT 0,
  `schedule_notes` text DEFAULT NULL,
  `qualification_reviewed_by` int(11) DEFAULT NULL,
  `qualification_reviewed_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `applicants`
--

INSERT INTO `applicants` (`id`, `job_id`, `first_name`, `last_name`, `email`, `phone`, `address`, `city`, `country`, `gender`, `birthday`, `resume_path`, `qualifications`, `cover_letter_path`, `application_status`, `source`, `qualification_score`, `experience_years`, `is_qualified`, `notes`, `is_active`, `applied_at`, `created_at`, `updated_at`, `auto_scheduled`, `auto_schedule_attempted`, `schedule_notes`, `qualification_reviewed_by`, `qualification_reviewed_at`) VALUES
(1, 1, 'Charlie', 'Parker', 'charlie.parker@email.com', '09201234569', '789 Chef Rd, Manila', NULL, NULL, 'Male', '1988-09-15', 'resumes/charlie_parker.pdf', '{\"education\":\"Culinary Arts\",\"experience_years\":6,\"skills\":[\"French Cuisine\",\"Kitchen Management\"],\"score_breakdown\":{\"education_score\":5,\"experience_score\":4,\"skills_score\":4,\"education_percent\":33.33,\"experience_percent\":26.66,\"skills_percent\":27.47,\"total\":87}}', NULL, 'shortlisted', 'website', 87, 6, 1, 'Strong culinary skills', 1, '2026-02-10 01:15:00', '2026-02-27 22:03:11', '2026-04-07 22:09:18', 0, 0, NULL, NULL, NULL),
(2, 1, 'Diana', 'Prince', 'diana.prince@email.com', '09211234570', '101 Sous Chef Ln, Manila', NULL, NULL, 'Female', '1990-12-02', 'resumes/diana_prince.pdf', '{\"education\": \"BS Nutrition\", \"experience_years\": 5, \"skills\": [\"Pastry\", \"Menu Development\"], \"score_breakdown\": {\"education_score\": 4, \"experience_score\": 4, \"skills_score\": 3, \"education_percent\": 26.66, \"experience_percent\": 26.66, \"skills_percent\": 20.60, \"total\": 73}}', NULL, 'shortlisted', 'website', 73, 5, 1, '\n\n\n\r\n', 1, '2026-02-11 06:30:00', '2026-02-27 22:03:11', '2026-04-07 21:41:55', 0, 0, NULL, NULL, NULL),
(3, 2, 'Peter', 'Quill', 'peter.quill@email.com', '09221234571', '202 Server St, Manila', NULL, NULL, 'Male', '1995-03-22', 'resumes/peter_quill.pdf', '{\"education\": \"High School\", \"experience_years\": 2, \"skills\": [\"Serving\", \"Customer Service\"], \"score_breakdown\": {\"education_score\": 3, \"experience_score\": 3, \"skills_score\": 5, \"education_percent\": 20.00, \"experience_percent\": 20.00, \"skills_percent\": 34.34, \"total\": 80}}', NULL, 'shortlisted', 'website', 80, 2, 1, '\n', 1, '2026-02-12 02:00:00', '2026-02-27 22:03:11', '2026-04-07 21:41:55', 0, 0, NULL, NULL, NULL),
(4, 2, 'Gamora', 'Zen', 'gamora.zen@email.com', '09231234572', '303 Waitress Ave, Manila', NULL, NULL, 'Female', '1993-07-19', 'resumes/gamora_zen.pdf', '{\"education\": \"Associate in F&B\", \"experience_years\": 3, \"skills\": [\"Serving\", \"Wine Knowledge\"], \"score_breakdown\": {\"education_score\": 4, \"experience_score\": 3, \"skills_score\": 4, \"education_percent\": 26.66, \"experience_percent\": 20.00, \"skills_percent\": 27.47, \"total\": 75}}', NULL, 'reviewed', 'website', 75, 3, 1, 'Good potential', 1, '2026-02-13 03:45:00', '2026-02-27 22:03:11', '2026-04-07 21:41:55', 0, 0, NULL, NULL, NULL),
(5, 4, 'Rocket', 'Raccoon', 'rocket.r@email.com', '09241234573', '404 Finance Rd, Manila', NULL, NULL, 'Male', '1987-11-05', 'resumes/rocket_r.pdf', '{\"education\": \"BS Accountancy\", \"experience_years\": 8, \"skills\": [\"Audit\", \"Tax\"], \"score_breakdown\": {\"education_score\": 4, \"experience_score\": 4, \"skills_score\": 3, \"education_percent\": 26.66, \"experience_percent\": 26.66, \"skills_percent\": 20.60, \"total\": 73}}', NULL, 'interviewed', 'website', 73, 8, 1, 'CPA certified', 1, '2026-02-14 00:20:00', '2026-02-27 22:03:11', '2026-04-07 22:09:18', 0, 0, NULL, NULL, NULL),
(6, 4, 'Nebula', 'Prime', 'nebula.p@email.com', '09251234574', '505 Auditor Ln, Manila', NULL, NULL, 'Female', '1991-09-30', 'resumes/nebula_p.pdf', '{\"education\": \"MBA Finance\", \"experience_years\": 4, \"skills\": [\"Financial Analysis\", \"Reporting\"], \"score_breakdown\": {\"education_score\": 5, \"experience_score\": 4, \"skills_score\": 4, \"education_percent\": 33.33, \"experience_percent\": 26.66, \"skills_percent\": 27.47, \"total\": 87}}', NULL, 'new', 'website', 87, 4, 1, '\n', 1, '2026-02-15 05:10:00', '2026-02-27 22:03:11', '2026-04-07 21:41:55', 0, 0, NULL, NULL, NULL),
(7, 20, 'James', 'Bond', 'james.sabandal001@gmail.com', '09075627511', 'Quezon City', NULL, NULL, 'Male', '2008-02-14', 'uploads/resumes/69a2392a0c5bd_James_Sabandal_Resume_F_Pattern.pdf', '{\"education\": \"Not specified\", \"experience_years\": 0, \"skills\": [], \"certifications\": [], \"score_breakdown\": {\"education_score\": 4, \"experience_score\": 4, \"skills_score\": 5, \"education_percent\": 26.66, \"experience_percent\": 26.66, \"skills_percent\": 34.34, \"total\": 87}}', NULL, 'new', 'website', 87, 0, 1, '', 1, '2026-02-28 00:39:06', '2026-02-28 00:39:06', '2026-04-07 21:41:55', 0, 0, NULL, NULL, NULL),
(8, 20, 'Ronnico', 'Espiritu', 'ronnicoespiritu@gmail.com', '09953268825', '10 Binhagan ST San Jose, Quezon City', NULL, NULL, 'Male', '1999-11-23', 'uploads/resumes/69a23a12d20a8_Resume__Ronnico_A._Espiritu_.pdf', '{\"education\": \"Not specified\", \"experience_years\": 0, \"skills\": [], \"certifications\": [], \"score_breakdown\": {\"education_score\": 5, \"experience_score\": 3, \"skills_score\": 5, \"education_percent\": 33.33, \"experience_percent\": 20.00, \"skills_percent\": 34.34, \"total\": 87}}', NULL, 'interviewed', 'website', 87, 0, 1, '\n', 1, '2026-02-28 00:42:58', '2026-02-28 00:42:58', '2026-04-07 21:41:55', 0, 0, NULL, NULL, NULL),
(9, 16, 'James Kneechtel', 'Sabandal', 'james@gmail.com', '09123456789', 'Salvador', NULL, NULL, 'Male', '2008-03-04', 'uploads/resumes/69a77c8ddc330_James_Kneechtel_Sabandal_Resume_UPDATED.pdf', '{\"education\": \"Not specified\", \"experience_years\": 0, \"skills\": [], \"certifications\": [], \"score_breakdown\": {\"education_score\": 4, \"experience_score\": 4, \"skills_score\": 4, \"education_percent\": 26.66, \"experience_percent\": 26.66, \"skills_percent\": 27.47, \"total\": 80}}', NULL, 'interviewed', 'website', 80, 0, 1, '', 1, '2026-03-04 00:27:57', '2026-03-04 00:27:57', '2026-04-07 21:41:55', 0, 0, NULL, NULL, NULL),
(10, 14, 'James Kneechtel DL.', 'Sabandal', 'james.kneechtel.alt@email.com', '09075627522', 'Salvador', NULL, NULL, 'Male', '2008-03-04', 'uploads/resumes/69a7d294b06dd_James_Kneechtel_Sabandal_Resume.pdf', '{\"education\": \"Not specified\", \"experience_years\": 0, \"skills\": [], \"certifications\": [], \"score_breakdown\": {\"education_score\": 5, \"experience_score\": 5, \"skills_score\": 3, \"education_percent\": 33.33, \"experience_percent\": 33.33, \"skills_percent\": 20.60, \"total\": 87}}', NULL, 'interviewed', 'website', 87, 0, 1, '', 1, '2026-03-04 06:35:00', '2026-03-04 06:35:00', '2026-04-07 22:09:18', 0, 0, NULL, NULL, NULL),
(11, 6, 'Christian', 'Costibolo', 'costibolo45@gmail.com', '09686680871', '#76npc lower congress Caloocan city', NULL, NULL, 'Male', '2004-02-19', 'uploads/resumes/69d604832e6be_ABSTRACT.pdf', '{\"education\":\"Not specified\",\"experience_years\":0,\"skills\":[],\"certifications\":[],\"score_breakdown\":{\"education_score\":4,\"experience_score\":4,\"skills_score\":4,\"education_percent\":26.66,\"experience_percent\":26.66,\"skills_percent\":27.47,\"total\":81}}', NULL, 'interviewed', 'website', 81, 0, 1, '', 1, '2026-04-08 07:32:19', '2026-04-08 07:32:19', '2026-04-23 01:39:19', 0, 0, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `appraisals`
--

CREATE TABLE `appraisals` (
  `id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `reviewer_id` int(11) DEFAULT NULL,
  `template_id` int(11) DEFAULT NULL,
  `appraisal_type` enum('probationary','annual','promotion','special') DEFAULT 'annual',
  `appraisal_date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `overall_rating` decimal(3,2) DEFAULT NULL,
  `strengths` text DEFAULT NULL,
  `improvement_areas` text DEFAULT NULL,
  `development_plan` text DEFAULT NULL,
  `recommendation` enum('promotion','salary_increase','retention','probation_extension','termination') DEFAULT NULL,
  `status` enum('draft','scheduled','in_progress','completed','cancelled') DEFAULT 'draft',
  `is_annual` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appraisals`
--

INSERT INTO `appraisals` (`id`, `employee_id`, `reviewer_id`, `template_id`, `appraisal_type`, `appraisal_date`, `due_date`, `overall_rating`, `strengths`, `improvement_areas`, `development_plan`, `recommendation`, `status`, `is_annual`, `created_at`, `updated_at`) VALUES
(1, 5, 1, 5, 'probationary', '2026-07-20', '2026-07-20', 4.20, 'Quick learner, good attitude', 'Needs more experience in recruitment', NULL, NULL, 'scheduled', 0, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(17, 1, 1, 1, 'annual', '2026-02-15', '2026-02-15', 4.80, 'Excellent leadership, team motivation', 'None', NULL, NULL, 'completed', 0, '2026-02-27 23:12:37', '2026-02-27 23:12:37'),
(18, 2, 1, 1, 'annual', '2026-02-14', '2026-02-14', 4.20, 'Good HR support', 'Needs more initiative', NULL, NULL, 'completed', 0, '2026-02-27 23:12:37', '2026-02-27 23:12:37'),
(19, 3, 1, 1, 'annual', '2026-02-13', '2026-02-13', 4.00, 'Reliable', 'Communication skills', NULL, NULL, 'completed', 0, '2026-02-27 23:12:37', '2026-02-27 23:12:37'),
(20, 6, 3, 2, 'annual', '2026-02-12', '2026-02-12', 4.70, 'Excellent trainer', 'None', NULL, NULL, 'completed', 0, '2026-02-27 23:12:37', '2026-02-27 23:12:37'),
(21, 7, 3, 2, 'annual', '2026-02-11', '2026-02-11', 4.50, 'Engaging sessions', 'Material development', NULL, NULL, 'completed', 0, '2026-02-27 23:12:37', '2026-02-27 23:12:37'),
(22, 11, 4, 1, 'annual', '2026-02-10', '2026-02-10', 4.60, 'Strong compliance knowledge', 'None', NULL, NULL, 'completed', 0, '2026-02-27 23:12:37', '2026-02-27 23:12:37'),
(23, 16, 5, 3, 'annual', '2026-02-09', '2026-02-09', 4.30, 'Good employee relations', 'Documentation', NULL, NULL, 'completed', 0, '2026-02-27 23:12:37', '2026-02-27 23:12:37'),
(24, 21, 6, 3, 'annual', '2026-02-08', '2026-02-08', 4.40, 'Warehouse efficiency', 'Inventory accuracy', NULL, NULL, 'completed', 0, '2026-02-27 23:12:37', '2026-02-27 23:12:37'),
(25, 24, 6, 1, 'annual', '2026-02-07', '2026-02-07', 4.50, 'Excellent procurement', 'None', NULL, NULL, 'completed', 0, '2026-02-27 23:12:37', '2026-02-27 23:12:37'),
(26, 28, 7, 2, 'annual', '2026-02-06', '2026-02-06', 4.60, 'Fleet management', 'Cost control', NULL, NULL, 'completed', 0, '2026-02-27 23:12:37', '2026-02-27 23:12:37'),
(27, 34, 8, 1, 'annual', '2026-02-05', '2026-02-05', 4.90, 'Financial leadership', 'None', NULL, NULL, 'completed', 0, '2026-02-27 23:12:37', '2026-02-27 23:12:37'),
(28, 35, 8, 1, 'annual', '2026-02-04', '2026-02-04', 4.30, 'Accurate accounting', 'Speed', NULL, NULL, 'completed', 0, '2026-02-27 23:12:37', '2026-02-27 23:12:37'),
(29, 39, 9, 2, 'annual', '2026-02-03', '2026-02-03', 4.70, 'Restaurant operations', 'Staff turnover', NULL, NULL, 'completed', 0, '2026-02-27 23:12:37', '2026-02-27 23:12:37'),
(30, 40, 9, 2, 'annual', '2026-02-02', '2026-02-02', 4.80, 'Culinary excellence', 'None', NULL, NULL, 'completed', 0, '2026-02-27 23:12:37', '2026-02-27 23:12:37'),
(31, 41, 9, 4, 'probationary', '2026-03-01', '2026-09-01', NULL, NULL, NULL, NULL, NULL, 'scheduled', 0, '2026-02-27 23:12:37', '2026-02-27 23:12:37');

-- --------------------------------------------------------

--
-- Table structure for table `appraisal_criteria`
--

CREATE TABLE `appraisal_criteria` (
  `criteria_id` int(11) NOT NULL,
  `criteria_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `default_weight` tinyint(4) DEFAULT NULL COMMENT '0-100',
  `is_active` tinyint(1) DEFAULT 1,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appraisal_criteria`
--

INSERT INTO `appraisal_criteria` (`criteria_id`, `criteria_name`, `description`, `default_weight`, `is_active`, `created_by`, `created_at`) VALUES
(1, 'Job Knowledge', 'Understanding of role and tasks', 20, 1, 1, '2026-02-27 22:03:11'),
(2, 'Quality of Work', 'Accuracy and thoroughness', 20, 1, 1, '2026-02-27 22:03:11'),
(3, 'Initiative', 'Proactiveness and self-direction', 15, 1, 1, '2026-02-27 22:03:11');

-- --------------------------------------------------------

--
-- Table structure for table `appraisal_templates`
--

CREATE TABLE `appraisal_templates` (
  `template_id` int(11) NOT NULL,
  `template_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appraisal_templates`
--

INSERT INTO `appraisal_templates` (`template_id`, `template_name`, `description`, `is_active`, `created_by`, `created_at`) VALUES
(1, 'Probationary Review Template', 'For 6-month probation assessment', 1, 1, '2026-02-27 22:03:11'),
(2, 'Manager Review', 'For department heads and managers', 1, 1, '2026-02-27 23:12:37'),
(3, 'Staff Review', 'For regular employees', 1, 1, '2026-02-27 23:12:37'),
(4, 'Probationary Review', 'End of probation assessment', 1, 1, '2026-02-27 23:12:37');

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `attendance_date` date NOT NULL,
  `time_in` time DEFAULT NULL,
  `time_out` time DEFAULT NULL,
  `status` enum('present','absent','late','half_day','leave','holiday') DEFAULT 'present',
  `hours_worked` decimal(4,2) DEFAULT 0.00,
  `overtime_hours` decimal(4,2) DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `marked_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `employee_id`, `attendance_date`, `time_in`, `time_out`, `status`, `hours_worked`, `overtime_hours`, `notes`, `marked_by`, `created_at`, `updated_at`) VALUES
(1, 1, '2026-02-28', '08:30:00', '17:30:00', 'present', 9.00, 0.00, NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(2, 2, '2026-02-28', '08:45:00', '17:15:00', 'present', 8.50, 0.00, NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(3, 3, '2026-02-28', '09:00:00', '18:00:00', 'present', 9.00, 0.00, NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(4, 6, '2026-02-28', '08:30:00', '17:30:00', 'present', 9.00, 0.00, NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(5, 11, '2026-02-28', '08:15:00', '17:15:00', 'present', 9.00, 0.00, NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(6, 16, '2026-02-28', '08:30:00', '17:30:00', 'present', 9.00, 0.00, NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(7, 21, '2026-02-28', '07:00:00', '16:00:00', 'present', 9.00, 0.00, NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(8, 28, '2026-02-28', '08:00:00', '17:00:00', 'present', 9.00, 0.00, NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(9, 34, '2026-02-28', '09:00:00', '18:00:00', 'present', 9.00, 0.00, NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(10, 39, '2026-02-28', '10:00:00', '19:00:00', 'present', 9.00, 0.00, NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(11, 1, '2026-02-27', '08:30:00', '17:30:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(12, 1, '2026-02-25', '08:45:00', '17:15:00', 'present', 8.50, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(13, 1, '2026-02-23', '09:00:00', '18:00:00', 'late', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(14, 2, '2026-02-26', '08:30:00', '17:30:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(15, 2, '2026-02-24', NULL, NULL, 'absent', 0.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(16, 3, '2026-02-27', '08:20:00', '17:20:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(17, 3, '2026-02-22', '08:30:00', '17:30:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(18, 3, '2026-02-20', '08:10:00', '17:10:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(19, 4, '2026-02-25', '08:30:00', '17:30:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(20, 4, '2026-02-21', '09:15:00', '18:15:00', 'late', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(21, 5, '2026-02-26', '08:30:00', '17:30:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(22, 5, '2026-02-23', NULL, NULL, 'leave', 0.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(23, 6, '2026-02-27', '08:30:00', '17:30:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(24, 6, '2026-02-19', '08:30:00', '17:30:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(25, 7, '2026-02-26', '08:15:00', '17:15:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(26, 7, '2026-02-24', '08:30:00', '17:30:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(27, 7, '2026-02-18', '08:30:00', '17:30:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(28, 11, '2026-02-25', '08:30:00', '17:30:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(29, 11, '2026-02-22', '08:30:00', '17:30:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(30, 16, '2026-02-26', '08:30:00', '17:30:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(31, 16, '2026-02-20', '08:30:00', '17:30:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(32, 21, '2026-02-27', '07:00:00', '16:00:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(33, 21, '2026-02-23', '07:00:00', '16:00:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(34, 21, '2026-02-19', '07:30:00', '16:30:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(35, 22, '2026-02-26', '08:00:00', '17:00:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(36, 22, '2026-02-21', '08:00:00', '17:00:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(37, 24, '2026-02-25', '08:30:00', '17:30:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(38, 24, '2026-02-18', '08:30:00', '17:30:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(39, 28, '2026-02-27', '08:00:00', '17:00:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(40, 28, '2026-02-24', '08:00:00', '17:00:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(41, 28, '2026-02-17', '08:00:00', '17:00:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(42, 29, '2026-02-26', '08:30:00', '17:30:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(43, 29, '2026-02-22', '08:30:00', '17:30:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(44, 30, '2026-02-27', '07:30:00', '16:30:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(45, 30, '2026-02-23', '07:30:00', '16:30:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(46, 30, '2026-02-16', '08:00:00', '17:00:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(47, 34, '2026-02-25', '09:00:00', '18:00:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(48, 34, '2026-02-20', '09:00:00', '18:00:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(49, 35, '2026-02-26', '08:30:00', '17:30:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(50, 35, '2026-02-19', '08:30:00', '17:30:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(51, 39, '2026-02-27', '10:00:00', '19:00:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(52, 39, '2026-02-22', '10:00:00', '19:00:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(53, 39, '2026-02-15', '10:00:00', '19:00:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(54, 40, '2026-02-24', '06:00:00', '15:00:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(55, 40, '2026-02-18', '06:00:00', '15:00:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(56, 41, '2026-02-26', '08:00:00', '17:00:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(57, 41, '2026-02-21', '08:00:00', '17:00:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(58, 42, '2026-02-25', '09:00:00', '18:00:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(59, 42, '2026-02-17', '09:00:00', '18:00:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(60, 45, '2026-02-23', '10:00:00', '19:00:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45'),
(61, 45, '2026-02-16', '10:00:00', '19:00:00', 'present', 9.00, 0.00, NULL, 1, '2026-02-27 23:18:45', '2026-02-27 23:18:45');

-- --------------------------------------------------------

--
-- Table structure for table `awards`
--

CREATE TABLE `awards` (
  `id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `award_type` enum('recognition','excellence','innovation','teamwork','leadership','service','special') NOT NULL,
  `award_name` varchar(100) NOT NULL,
  `reason` text NOT NULL,
  `points` int(11) NOT NULL DEFAULT 10,
  `award_date` date NOT NULL,
  `given_by` int(11) NOT NULL,
  `status` enum('active','revoked') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `awards`
--

INSERT INTO `awards` (`id`, `employee_id`, `award_type`, `award_name`, `reason`, `points`, `award_date`, `given_by`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'excellence', 'HR Manager of the Month', 'Outstanding leadership in recruitment', 100, '2026-02-15', 1, 'active', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(2, 6, 'service', 'Trainer Excellence', 'Exceptional training programs', 75, '2026-02-10', 1, 'active', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(3, 21, 'teamwork', 'Warehouse Team Leader', 'Led team to record efficiency', 50, '2026-02-05', 1, 'active', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(4, 34, 'innovation', 'Process Improvement', 'Implemented new budgeting system', 80, '2026-02-20', 1, 'active', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(5, 39, 'leadership', 'Restaurant Manager of the Quarter', 'Increased revenue by 15%', 100, '2026-02-01', 1, 'active', '2026-02-27 22:03:11', '2026-02-27 22:03:11');

-- --------------------------------------------------------

--
-- Table structure for table `award_criteria`
--

CREATE TABLE `award_criteria` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `award_type` enum('recognition','excellence','innovation','teamwork','leadership','service') NOT NULL,
  `description` text DEFAULT NULL,
  `min_score` int(3) DEFAULT 0,
  `points` int(11) DEFAULT 10,
  `frequency` enum('daily','weekly','monthly','quarterly','yearly','as_needed') DEFAULT 'as_needed',
  `auto_award` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `award_criteria`
--

INSERT INTO `award_criteria` (`id`, `name`, `award_type`, `description`, `min_score`, `points`, `frequency`, `auto_award`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Perfect Attendance', 'recognition', 'No absences for 3 months', 0, 50, 'quarterly', 1, 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(2, 'Innovation of the Month', 'innovation', 'Best new idea implemented', 0, 100, 'monthly', 0, 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11');

-- --------------------------------------------------------

--
-- Table structure for table `competencies`
--

CREATE TABLE `competencies` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `category` enum('technical','soft','management','industry') NOT NULL,
  `description` text DEFAULT NULL,
  `skill_level` enum('basic','intermediate','advanced','expert') DEFAULT 'intermediate',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `competencies`
--

INSERT INTO `competencies` (`id`, `name`, `category`, `description`, `skill_level`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Customer Service', 'soft', 'Ability to handle guest inquiries and complaints', 'advanced', 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(2, 'Reservation Systems', 'technical', 'Proficiency in PMS and booking software', 'intermediate', 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(3, 'Culinary Skills', 'technical', 'Food preparation and cooking techniques', 'advanced', 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(4, 'Housekeeping Standards', 'industry', 'Knowledge of cleanliness and room setup standards', 'intermediate', 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(5, 'Revenue Management', 'technical', 'Rate optimization and forecasting', 'advanced', 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(6, 'Communication', 'soft', 'Effective verbal and written communication', 'intermediate', 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(7, 'Leadership', 'management', 'Team supervision and motivation', 'intermediate', 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(8, 'Data Analysis', 'technical', 'Ability to analyze and interpret data', 'intermediate', 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `code` varchar(20) DEFAULT NULL,
  `head_employee_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `name`, `description`, `code`, `head_employee_id`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'HR1', 'Primary Human Resources - Hotel Operations', 'HR1', 1, 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(2, 'HR2', 'Secondary Human Resources - Restaurant Operations', 'HR2', 6, 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(3, 'HR3', 'Tertiary Human Resources - Support Services', 'HR3', 11, 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(4, 'HR4', 'Quaternary Human Resources - Administrative Support', 'HR4', 16, 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(5, 'Core 1', 'Front Office & Guest Services Department', 'CORE1', NULL, 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(6, 'Core 2', 'Food & Beverage Operations Department', 'CORE2', 39, 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(7, 'Logistics 1', 'Housekeeping & Maintenance Department', 'LOG1', 21, 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(8, 'Logistics 2', 'Inventory & Supply Chain Department', 'LOG2', 28, 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(9, 'Administrative', 'General Administration & Office Management', 'ADMIN', NULL, 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(10, 'Financials', 'Finance, Accounting & Revenue Management', 'FIN', 34, 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11');

-- --------------------------------------------------------

--
-- Table structure for table `dependents`
--

CREATE TABLE `dependents` (
  `id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `relationship` varchar(50) NOT NULL,
  `date_of_birth` date NOT NULL,
  `is_beneficiary` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dependents`
--

INSERT INTO `dependents` (`id`, `employee_id`, `full_name`, `relationship`, `date_of_birth`, `is_beneficiary`, `created_at`, `updated_at`) VALUES
(1, 1, 'Mary Doe', 'Spouse', '1987-05-20', 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(2, 1, 'James Doe', 'Child', '2015-08-12', 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(3, 6, 'Michael Johnson', 'Spouse', '1989-11-03', 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(4, 11, 'Laura Clark', 'Spouse', '1986-02-14', 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(5, 16, 'Robert Moore', 'Spouse', '1981-07-30', 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(6, 21, 'Sandra Baker', 'Spouse', '1984-09-22', 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(7, 28, 'Jessica Phillips', 'Spouse', '1983-12-11', 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(8, 34, 'Emily Stewart', 'Spouse', '1980-04-17', 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(9, 39, 'Peggy Rogers', 'Spouse', '1982-03-10', 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(10, 40, 'Pepper Stark', 'Spouse', '1980-01-15', 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(11) NOT NULL,
  `employee_id` varchar(50) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(100) NOT NULL,
  `position` varchar(100) DEFAULT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `department_id` int(11) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `date_of_birth` date NOT NULL,
  `hire_date` date NOT NULL,
  `status` enum('Active','Inactive','On Leave','Terminated') DEFAULT 'Active',
  `user_id` int(11) DEFAULT NULL COMMENT 'Link to users table if employee has system access',
  `applicant_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `employee_id`, `first_name`, `middle_name`, `last_name`, `position`, `gender`, `department_id`, `email`, `contact_number`, `address`, `date_of_birth`, `hire_date`, `status`, `user_id`, `applicant_id`, `created_at`, `updated_at`) VALUES
(1, 'EMP2026001', 'John', 'A', 'Doe', 'HR1 Manager', 'Male', 1, 'john.doe@hr1.com', '09171230001', '123 Main St, Manila', '1985-03-15', '2026-01-10', 'Active', 2, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(2, 'EMP2026002', 'Jane', 'B', 'Smith', 'HR1 Staff', 'Female', 1, 'jane.smith@hr1.com', '09171230002', '456 Elm St, Manila', '1990-07-22', '2026-01-10', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(3, 'EMP2026003', 'Mike', 'C', 'Brown', 'HR1 Staff', 'Male', 1, 'mike.brown@hr1.com', '09171230003', '789 Oak St, Manila', '1992-11-05', '2026-01-15', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(4, 'EMP2026004', 'Emily', 'D', 'Davis', 'HR1 Staff', 'Female', 1, 'emily.davis@hr1.com', '09171230004', '101 Pine St, Manila', '1995-02-18', '2026-01-20', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(5, 'EMP2026005', 'Robert', 'E', 'Wilson', 'HR1 Staff', 'Male', 1, 'robert.wilson@hr1.com', '09171230005', '202 Cedar St, Manila', '1988-09-30', '2026-02-01', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(6, 'EMP2026006', 'Sarah', 'F', 'Johnson', 'HR2 Manager', 'Female', 2, 'sarah.johnson@hr2.com', '09172230001', '303 Birch St, Manila', '1987-04-12', '2026-01-10', 'Active', 3, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(7, 'EMP2026007', 'David', '', 'Lee', 'Trainer', 'Male', 2, 'david.lee@hr2.com', '09172230002', '404 Spruce St, Manila', '1991-08-25', '2026-01-15', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:23:24'),
(8, 'EMP2026008', 'Laura', 'H', 'Martin', 'Training Coordinator', 'Female', 2, 'laura.martin@hr2.com', '09172230003', '505 Willow St, Manila', '1993-12-03', '2026-01-20', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(9, 'EMP2026009', 'Chris', 'I', 'Evans', 'HR Associate', 'Male', 2, 'chris.evans@hr2.com', '09172230004', '606 Ash St, Manila', '1989-06-17', '2026-02-01', 'On Leave', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 23:20:50'),
(10, 'EMP2026010', 'Anna', 'J', 'Taylor', 'HR Clerk', 'Female', 2, 'anna.taylor@hr2.com', '09172230005', '707 Poplar St, Manila', '1994-10-29', '2026-02-05', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(11, 'EMP2026011', 'Michael', 'K', 'Clark', 'HR3 Manager', 'Male', 3, 'michael.clark@hr3.com', '09173230001', '808 Maple St, Manila', '1984-02-20', '2026-01-10', 'Active', 4, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(12, 'EMP2026012', 'Jessica', 'L', 'White', 'HR3 Officer', 'Female', 3, 'jessica.white@hr3.com', '09173230002', '909 Oakwood St, Manila', '1990-05-14', '2026-01-15', 'Inactive', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 23:21:09'),
(13, 'EMP2026013', 'Daniel', 'M', 'Harris', 'HR3 Assistant', 'Male', 3, 'daniel.harris@hr3.com', '09173230003', '111 Pinecrest St, Manila', '1992-09-08', '2026-01-20', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(14, 'EMP2026014', 'James Kneechtel', '', 'Sabandal', 'Benefits Coordinator', 'Male', 3, 'james.sabandal001@gmail.com', '09173230004', '222 Cedarhill St, Manila', '1988-11-23', '2026-02-01', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-03-04 09:40:14'),
(15, 'EMP2026015', 'Thomas', 'O', 'King', 'Compliance Officer', 'Male', 3, 'thomas.king@hr3.com', '09173230005', '333 Redwood St, Manila', '1986-07-19', '2026-02-05', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(16, 'EMP2026016', 'Lisa', 'P', 'Moore', 'HR4 Manager', 'Female', 4, 'lisa.moore@hr4.com', '09174230001', '444 Walnut St, Manila', '1983-12-01', '2026-01-10', 'Active', 5, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(17, 'EMP2026017', 'Paul', 'Q', 'Walker', 'HR4 Specialist', 'Male', 4, 'paul.walker@hr4.com', '09174230002', '555 Chestnut St, Manila', '1989-04-27', '2026-01-15', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(18, 'EMP2026018', 'Betty', 'R', 'Young', 'Payroll Clerk', 'Female', 4, 'betty.young@hr4.com', '09174230003', '666 Hickory St, Manila', '1991-08-13', '2026-01-20', 'Terminated', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 23:21:16'),
(19, 'EMP2026019', 'Kevin', 'S', 'Scott', 'HR4 Assistant', 'Male', 4, 'kevin.scott@hr4.com', '09174230004', '777 Beech St, Manila', '1994-03-22', '2026-02-01', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(20, 'EMP2026020', 'Angela', 'T', 'Adams', 'Employee Relations Officer', 'Female', 4, 'angela.adams@hr4.com', '09174230005', '888 Sycamore St, Manila', '1987-10-05', '2026-02-05', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(21, 'EMP2026021', 'Richard', 'U', 'Baker', 'Warehouse Supervisor', 'Male', 7, 'richard.baker@log1.com', '09175230001', '999 Fir St, Manila', '1982-06-18', '2026-01-10', 'Active', 6, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(22, 'EMP2026022', 'Joseph', 'V', 'Perez', 'Warehouse Staff', 'Male', 7, 'joseph.perez@log1.com', '09175230002', '1010 Spruce Ln, Manila', '1990-09-14', '2026-01-15', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(23, 'EMP2026023', 'Charles', 'W', 'Roberts', 'Warehouse Staff', 'Male', 7, 'charles.roberts@log1.com', '09175230003', '1111 Cedar Ave, Manila', '1992-12-23', '2026-01-20', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(24, 'EMP2026024', 'Patricia', 'X', 'Gonzalez', 'Procurement Officer', 'Female', 7, 'patricia.gonzalez@log1.com', '09175230004', '1212 Elm St, Manila', '1985-03-11', '2026-02-01', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(25, 'EMP2026025', 'Jennifer', 'Y', 'Nelson', 'Project Manager', 'Female', 7, 'jennifer.nelson@log1.com', '09175230005', '1313 Pine St, Manila', '1980-07-29', '2026-02-05', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(26, 'EMP2026026', 'Christopher', 'Z', 'Carter', 'Asset Manager', 'Male', 7, 'christopher.carter@log1.com', '09175230006', '1414 Oak St, Manila', '1983-11-02', '2026-02-10', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(27, 'EMP2026027', 'Amanda', 'AA', 'Mitchell', 'Record Officer', 'Female', 7, 'amanda.mitchell@log1.com', '09175230007', '1515 Maple Ave, Manila', '1991-04-17', '2026-02-15', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(28, 'EMP2026028', 'Matthew', 'AB', 'Phillips', 'Fleet Manager', 'Male', 8, 'matthew.phillips@log2.com', '09176230001', '1616 Birch St, Manila', '1981-08-05', '2026-01-10', 'Active', 7, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(29, 'EMP2026029', 'Kimberly', 'AC', 'Campbell', 'Dispatcher', 'Female', 8, 'kimberly.campbell@log2.com', '09176230002', '1717 Cedar Ln, Manila', '1989-12-12', '2026-01-15', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(30, 'EMP2026030', 'Anthony', 'AD', 'Parker', 'Driver', 'Male', 8, 'anthony.parker@log2.com', '09176230003', '1818 Spruce St, Manila', '1993-02-28', '2026-01-20', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(31, 'EMP2026031', 'Sandra', 'AE', 'Evans', 'Driver', 'Female', 8, 'sandra.evans@log2.com', '09176230004', '1919 Pine St, Manila', '1990-05-09', '2026-02-01', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(32, 'EMP2026032', 'George', 'AF', 'Edwards', 'Driver', 'Male', 8, 'george.edwards@log2.com', '09176230005', '2020 Oakwood Dr, Manila', '1987-09-19', '2026-02-05', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(33, 'EMP2026033', 'Sharon', 'AG', 'Collins', 'Logistics Coordinator', 'Female', 8, 'sharon.collins@log2.com', '09176230006', '2121 Maple St, Manila', '1984-11-30', '2026-02-10', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(34, 'EMP2026034', 'William', 'AH', 'Stewart', 'Financial Manager', 'Male', 10, 'william.stewart@fin.com', '09177230001', '2222 Ash St, Manila', '1979-10-10', '2026-01-10', 'Active', 8, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(35, 'EMP2026035', 'Donna', 'AI', 'Morris', 'Accountant', 'Female', 10, 'donna.morris@fin.com', '09177230002', '2323 Beech St, Manila', '1988-01-25', '2026-01-15', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(36, 'EMP2026036', 'Ronald', 'AJ', 'Murphy', 'Accountant', 'Male', 10, 'ronald.murphy@fin.com', '09177230003', '2424 Chestnut St, Manila', '1985-06-30', '2026-01-20', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(37, 'EMP2026037', 'Carol', 'AK', 'Rivera', 'Finance Assistant', 'Female', 10, 'carol.rivera@fin.com', '09177230004', '2525 Elm St, Manila', '1992-03-15', '2026-02-01', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(38, 'EMP2026038', 'Kenneth', 'AL', 'Cook', 'Budget Analyst', 'Male', 10, 'kenneth.cook@fin.com', '09177230005', '2626 Fir St, Manila', '1983-12-20', '2026-02-05', 'On Leave', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 23:20:58'),
(39, 'EMP2026039', 'Steven', 'AM', 'Rogers', 'Restaurant Manager', 'Male', 6, 'steven.rogers@core2.com', '09178230001', '2727 Hickory St, Manila', '1980-07-04', '2026-01-10', 'Active', 9, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(40, 'EMP2026040', 'Anthony', 'AN', 'Stark', 'Head Chef', 'Male', 6, 'anthony.stark@core2.com', '09178230002', '2828 Pine St, Manila', '1975-05-29', '2026-01-10', 'Active', 10, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(41, 'EMP2026041', 'Peter', 'AO', 'Parker', 'Sous Chef', 'Male', 6, 'peter.parker@core2.com', '09178230003', '2929 Oak St, Manila', '1990-08-10', '2026-01-15', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(42, 'EMP2026042', 'Natasha', 'AP', 'Romanoff', 'Reservation Officer', 'Female', 6, 'natasha.romanoff@core2.com', '09178230004', '3030 Maple Dr, Manila', '1984-11-22', '2026-01-15', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(43, 'EMP2026043', 'Bruce', 'AQ', 'Banner', 'Event Coordinator', 'Male', 6, 'bruce.banner@core2.com', '09178230005', '3131 Elm St, Manila', '1979-12-18', '2026-01-20', 'On Leave', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 23:20:41'),
(44, 'EMP2026044', 'Wanda', 'AR', 'Maximoff', 'Hostess', 'Female', 6, 'wanda.maximoff@core2.com', '09178230006', '3232 Cedar St, Manila', '1993-02-14', '2026-01-20', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(45, 'EMP2026045', 'Thor', 'AS', 'Odinson', 'Server', 'Male', 6, 'thor.odinson@core2.com', '09178230007', '3333 Spruce St, Manila', '1988-06-07', '2026-02-01', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(46, 'EMP2026046', 'Clint', 'AT', 'Barton', 'Server', 'Male', 6, 'clint.barton@core2.com', '09178230008', '3434 Beech St, Manila', '1985-01-09', '2026-02-01', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(47, 'EMP2026047', 'Scott', 'AU', 'Lang', 'Cashier', 'Male', 6, 'scott.lang@core2.com', '09178230009', '3535 Chestnut St, Manila', '1991-09-15', '2026-02-05', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(48, 'EMP2026048', 'Hope', 'AV', 'Pym', 'KOT Staff', 'Female', 6, 'hope.pym@core2.com', '09178230010', '3636 Walnut St, Manila', '1992-04-23', '2026-02-05', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(49, 'EMP2026049', 'Vision', 'AW', 'S', 'Inventory Clerk', 'Male', 6, 'vision.s@core2.com', '09178230011', '3737 Sycamore St, Manila', '1987-11-11', '2026-02-10', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(50, 'EMP2026050', 'T\'Challa', 'AX', 'Wakanda', 'Pastry Chef', 'Male', 6, 'tchalla.w@core2.com', '09178230012', '3838 Redwood St, Manila', '1982-03-19', '2026-02-10', 'Active', NULL, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(63, 'EMP2026051', 'Rocket', NULL, 'Raccoon', 'Accountant', 'Male', 10, 'rocket.r@email.com', '09241234573', NULL, '1987-11-05', '2026-03-14', 'Active', NULL, 5, '2026-04-07 22:33:12', '2026-04-07 22:33:12'),
(64, 'EMP2026052', 'Diana', NULL, 'Prince', 'Sous Chef', 'Female', 6, 'diana.prince@email.com', '09211234570', NULL, '1990-12-02', '2026-03-18', 'Active', NULL, 2, '2026-04-07 22:33:12', '2026-04-07 22:33:12'),
(65, 'EMP2026053', 'Ronnico', NULL, 'Espiritu', 'Reservation Officer', 'Male', 6, 'ronnicoespiritu@gmail.com', '09953268825', NULL, '1999-11-23', '2026-03-18', 'Active', NULL, 8, '2026-04-07 22:33:12', '2026-04-07 22:33:12');

-- --------------------------------------------------------

--
-- Table structure for table `employee_milestones`
--

CREATE TABLE `employee_milestones` (
  `id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `milestone_id` int(11) NOT NULL,
  `achieved_at` date NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee_milestones`
--

INSERT INTO `employee_milestones` (`id`, `employee_id`, `milestone_id`, `achieved_at`, `created_at`) VALUES
(1, 1, 1, '2026-02-15', '2026-02-28 06:03:11');

-- --------------------------------------------------------

--
-- Table structure for table `employment_details`
--

CREATE TABLE `employment_details` (
  `id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `employment_type` enum('Regular','Probationary','Contractual','Project_based','Trainee','Part_time') DEFAULT 'Probationary',
  `job_title` varchar(150) NOT NULL,
  `basic_salary` decimal(10,2) NOT NULL,
  `salary_type` enum('Monthly','Weekly','Daily','Hourly') DEFAULT 'Monthly',
  `probation_end` date DEFAULT NULL,
  `effective_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employment_details`
--

INSERT INTO `employment_details` (`id`, `employee_id`, `employment_type`, `job_title`, `basic_salary`, `salary_type`, `probation_end`, `effective_date`, `created_at`, `updated_at`) VALUES
(1, 1, 'Regular', 'HR1 Manager', 65000.00, 'Monthly', '2026-07-10', '2026-01-10', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(2, 2, 'Regular', 'HR1 Staff', 35000.00, 'Monthly', '2026-07-10', '2026-01-10', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(3, 3, 'Regular', 'HR1 Staff', 35000.00, 'Monthly', '2026-07-15', '2026-01-15', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(4, 4, 'Regular', 'HR1 Staff', 35000.00, 'Monthly', '2026-07-20', '2026-01-20', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(5, 5, 'Regular', 'HR1 Staff', 35000.00, 'Monthly', '2026-08-01', '2026-02-01', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(6, 6, 'Regular', 'HR2 Manager', 62000.00, 'Monthly', '2026-07-10', '2026-01-10', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(7, 7, 'Regular', 'Trainer', 40000.00, 'Monthly', '2026-07-15', '2026-01-15', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(8, 8, 'Regular', 'Training Coordinator', 36000.00, 'Monthly', '2026-07-20', '2026-01-20', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(9, 9, 'Regular', 'HR Associate', 32000.00, 'Monthly', '2026-08-01', '2026-02-01', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(10, 10, 'Regular', 'HR Clerk', 28000.00, 'Monthly', '2026-08-05', '2026-02-05', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(11, 11, 'Regular', 'HR3 Manager', 63000.00, 'Monthly', '2026-07-10', '2026-01-10', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(12, 12, 'Regular', 'HR3 Officer', 38000.00, 'Monthly', '2026-07-15', '2026-01-15', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(13, 13, 'Regular', 'HR3 Assistant', 30000.00, 'Monthly', '2026-07-20', '2026-01-20', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(14, 14, 'Regular', 'Benefits Coordinator', 36000.00, 'Monthly', '2026-08-01', '2026-02-01', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(15, 15, 'Regular', 'Compliance Officer', 42000.00, 'Monthly', '2026-08-05', '2026-02-05', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(16, 16, 'Regular', 'HR4 Manager', 64000.00, 'Monthly', '2026-07-10', '2026-01-10', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(17, 17, 'Regular', 'HR4 Specialist', 39000.00, 'Monthly', '2026-07-15', '2026-01-15', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(18, 18, 'Regular', 'Payroll Clerk', 33000.00, 'Monthly', '2026-07-20', '2026-01-20', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(19, 19, 'Regular', 'HR4 Assistant', 30000.00, 'Monthly', '2026-08-01', '2026-02-01', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(20, 20, 'Regular', 'Employee Relations Officer', 41000.00, 'Monthly', '2026-08-05', '2026-02-05', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(21, 21, 'Regular', 'Warehouse Supervisor', 40000.00, 'Monthly', '2026-07-10', '2026-01-10', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(22, 22, 'Regular', 'Warehouse Staff', 25000.00, 'Monthly', '2026-07-15', '2026-01-15', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(23, 23, 'Regular', 'Warehouse Staff', 25000.00, 'Monthly', '2026-07-20', '2026-01-20', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(24, 24, 'Regular', 'Procurement Officer', 38000.00, 'Monthly', '2026-08-01', '2026-02-01', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(25, 25, 'Regular', 'Project Manager', 55000.00, 'Monthly', '2026-08-05', '2026-02-05', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(26, 26, 'Regular', 'Asset Manager', 42000.00, 'Monthly', '2026-08-10', '2026-02-10', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(27, 27, 'Regular', 'Record Officer', 32000.00, 'Monthly', '2026-08-15', '2026-02-15', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(28, 28, 'Regular', 'Fleet Manager', 45000.00, 'Monthly', '2026-07-10', '2026-01-10', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(29, 29, 'Regular', 'Dispatcher', 28000.00, 'Monthly', '2026-07-15', '2026-01-15', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(30, 30, 'Regular', 'Driver', 22000.00, 'Monthly', '2026-07-20', '2026-01-20', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(31, 31, 'Regular', 'Driver', 22000.00, 'Monthly', '2026-08-01', '2026-02-01', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(32, 32, 'Regular', 'Driver', 22000.00, 'Monthly', '2026-08-05', '2026-02-05', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(33, 33, 'Regular', 'Logistics Coordinator', 35000.00, 'Monthly', '2026-08-10', '2026-02-10', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(34, 34, 'Regular', 'Financial Manager', 70000.00, 'Monthly', '2026-07-10', '2026-01-10', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(35, 35, 'Regular', 'Accountant', 45000.00, 'Monthly', '2026-07-15', '2026-01-15', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(36, 36, 'Regular', 'Accountant', 45000.00, 'Monthly', '2026-07-20', '2026-01-20', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(37, 37, 'Regular', 'Finance Assistant', 30000.00, 'Monthly', '2026-08-01', '2026-02-01', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(38, 38, 'Regular', 'Budget Analyst', 48000.00, 'Monthly', '2026-08-05', '2026-02-05', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(39, 39, 'Regular', 'Restaurant Manager', 55000.00, 'Monthly', '2026-07-10', '2026-01-10', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(40, 40, 'Regular', 'Head Chef', 60000.00, 'Monthly', '2026-07-10', '2026-01-10', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(41, 41, 'Regular', 'Sous Chef', 42000.00, 'Monthly', '2026-07-15', '2026-01-15', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(42, 42, 'Regular', 'Reservation Officer', 32000.00, 'Monthly', '2026-07-15', '2026-01-15', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(43, 43, 'Regular', 'Event Coordinator', 38000.00, 'Monthly', '2026-07-20', '2026-01-20', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(44, 44, 'Regular', 'Hostess', 25000.00, 'Monthly', '2026-07-20', '2026-01-20', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(45, 45, 'Regular', 'Server', 22000.00, 'Monthly', '2026-08-01', '2026-02-01', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(46, 46, 'Regular', 'Server', 22000.00, 'Monthly', '2026-08-01', '2026-02-01', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(47, 47, 'Regular', 'Cashier', 23000.00, 'Monthly', '2026-08-05', '2026-02-05', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(48, 48, 'Regular', 'KOT Staff', 24000.00, 'Monthly', '2026-08-05', '2026-02-05', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(49, 49, 'Regular', 'Inventory Clerk', 26000.00, 'Monthly', '2026-08-10', '2026-02-10', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(50, 50, 'Regular', 'Pastry Chef', 38000.00, 'Monthly', '2026-08-10', '2026-02-10', '2026-02-27 22:03:11', '2026-02-27 22:03:11');

-- --------------------------------------------------------

--
-- Table structure for table `evaluation_criteria`
--

CREATE TABLE `evaluation_criteria` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `category` enum('job_performance','competency','behavioral','goal_achievement') NOT NULL,
  `description` text DEFAULT NULL,
  `weight` int(3) NOT NULL DEFAULT 100,
  `min_score` int(3) NOT NULL DEFAULT 0,
  `max_score` int(3) NOT NULL DEFAULT 100,
  `is_active` tinyint(1) DEFAULT 1,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `evaluation_criteria`
--

INSERT INTO `evaluation_criteria` (`id`, `name`, `category`, `description`, `weight`, `min_score`, `max_score`, `is_active`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 'Guest Satisfaction', 'job_performance', 'Guest feedback scores and service quality', 25, 0, 100, 1, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(2, 'Operational Efficiency', 'job_performance', 'Work accuracy and process adherence', 20, 0, 100, 1, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(3, 'Team Collaboration', 'behavioral', 'Working effectively with team members', 15, 0, 100, 1, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(4, 'Upselling Skills', 'competency', 'Ability to promote hotel services and upgrades', 10, 0, 100, 1, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(5, 'Cleanliness Standards', 'job_performance', 'Adherence to hygiene and cleanliness protocols', 15, 0, 100, 1, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(6, 'Attendance & Punctuality', 'behavioral', 'Reliability in attendance and timeliness', 15, 0, 100, 1, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(7, 'Leadership Skills', 'competency', 'Ability to lead and motivate team members', 20, 0, 100, 1, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(8, 'Innovation & Creativity', 'behavioral', 'Contributing new ideas and improvements', 10, 0, 100, 1, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11');

-- --------------------------------------------------------

--
-- Table structure for table `evaluation_templates`
--

CREATE TABLE `evaluation_templates` (
  `template_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `evaluation_templates`
--

INSERT INTO `evaluation_templates` (`template_id`, `name`, `description`, `is_active`, `created_by`, `created_at`) VALUES
(1, 'Annual Review', 'Full-year performance evaluation covering all criteria', 1, 1, '2026-02-27 22:03:11'),
(2, 'Quarterly Review', 'Quarterly check-in focusing on recent performance', 1, 1, '2026-02-27 22:03:11'),
(3, 'Probationary Review', 'End of probation assessment', 1, 2, '2026-02-27 22:03:11'),
(4, 'Promotion Review', 'Evaluation for potential promotion', 1, 3, '2026-02-27 22:03:11');

-- --------------------------------------------------------

--
-- Table structure for table `government_ids`
--

CREATE TABLE `government_ids` (
  `id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `sss_number` varchar(50) DEFAULT NULL,
  `pagibig_number` varchar(50) DEFAULT NULL,
  `philhealth_number` varchar(50) DEFAULT NULL,
  `tin_number` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `government_ids`
--

INSERT INTO `government_ids` (`id`, `employee_id`, `sss_number`, `pagibig_number`, `philhealth_number`, `tin_number`, `created_at`, `updated_at`) VALUES
(1, 1, '01-1234567-8', '1234-5678-9012', '01-123456789-0', '123-456-789-000', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(2, 2, '02-2345678-9', '2345-6789-0123', '02-234567890-1', '234-567-890-001', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(3, 3, '03-3456789-0', '3456-7890-1234', '03-345678901-2', '345-678-901-002', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(4, 4, '04-4567890-1', '4567-8901-2345', '04-456789012-3', '456-789-012-003', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(5, 5, '05-5678901-2', '5678-9012-3456', '05-567890123-4', '567-890-123-004', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(6, 6, '06-6789012-3', '6789-0123-4567', '06-678901234-5', '678-901-234-005', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(7, 7, '07-7890123-4', '7890-1234-5678', '07-789012345-6', '789-012-345-006', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(8, 8, '08-8901234-5', '8901-2345-6789', '08-890123456-7', '890-123-456-007', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(9, 9, '09-9012345-6', '9012-3456-7890', '09-901234567-8', '901-234-567-008', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(10, 10, '10-0123456-7', '0123-4567-8901', '10-012345678-9', '012-345-678-009', '2026-02-27 22:03:11', '2026-02-27 22:03:11');

-- --------------------------------------------------------

--
-- Table structure for table `holidays`
--

CREATE TABLE `holidays` (
  `id` int(11) NOT NULL,
  `holiday_date` date NOT NULL,
  `description` varchar(255) NOT NULL,
  `yearly_recurring` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `holidays`
--

INSERT INTO `holidays` (`id`, `holiday_date`, `description`, `yearly_recurring`, `is_active`, `created_at`, `updated_at`) VALUES
(1, '2026-01-01', 'New Year\'s Day', 1, 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(2, '2026-04-17', 'Maundy Thursday', 1, 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(3, '2026-04-18', 'Good Friday', 1, 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(4, '2026-05-01', 'Labor Day', 1, 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(5, '2026-06-12', 'Independence Day', 1, 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(6, '2026-12-25', 'Christmas Day', 1, 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(7, '2026-12-30', 'Rizal Day', 1, 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11');

-- --------------------------------------------------------

--
-- Table structure for table `hr_users`
--

CREATE TABLE `hr_users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `role` varchar(50) DEFAULT 'hr_officer',
  `department` varchar(100) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `otp_secret` varchar(255) DEFAULT NULL,
  `otp_verified` tinyint(1) DEFAULT 0,
  `otp_enabled` tinyint(1) DEFAULT 0,
  `otp_created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hr_users`
--

INSERT INTO `hr_users` (`id`, `username`, `email`, `password_hash`, `full_name`, `role`, `department`, `is_active`, `last_login`, `created_at`, `updated_at`, `otp_secret`, `otp_verified`, `otp_enabled`, `otp_created_at`) VALUES
(1, 'admin', 'james.sabandal001@gmail.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'System Administrator', 'admin', 'HR1', 1, '2026-04-26 14:26:06', '2026-02-27 22:03:11', '2026-04-26 06:26:06', NULL, 0, 1, NULL),
(2, 'jdoe', 'john.doe@hr1.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'John Doe', 'hr_manager', 'HR1', 1, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, 0, 0, NULL),
(3, 'sjohnson', 'sarah.johnson@hr2.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Sarah Johnson', 'hr_manager', 'HR2', 1, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, 0, 0, NULL),
(4, 'mclark', 'michael.clark@hr3.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Michael Clark', 'hr_manager', 'HR3', 1, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, 0, 0, NULL),
(5, 'lmoore', 'lisa.moore@hr4.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Lisa Moore', 'hr_manager', 'HR4', 1, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, 0, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `interviews`
--

CREATE TABLE `interviews` (
  `id` int(11) NOT NULL,
  `applicant_id` int(11) NOT NULL,
  `interview_type` varchar(50) NOT NULL,
  `scheduled_date` datetime NOT NULL,
  `duration` int(11) NOT NULL,
  `interviewers` varchar(255) NOT NULL,
  `location` varchar(100) NOT NULL,
  `notes` text DEFAULT NULL,
  `status` varchar(20) DEFAULT 'scheduled',
  `scheduled_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `rescheduled_at` datetime DEFAULT NULL,
  `rescheduled_by` int(11) DEFAULT NULL,
  `is_auto_scheduled` tinyint(1) DEFAULT 0,
  `slot_number` int(11) DEFAULT NULL,
  `interview_round` int(11) DEFAULT 1,
  `feedback_provided` tinyint(1) DEFAULT 0,
  `feedback_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `interviews`
--

INSERT INTO `interviews` (`id`, `applicant_id`, `interview_type`, `scheduled_date`, `duration`, `interviewers`, `location`, `notes`, `status`, `scheduled_by`, `created_at`, `updated_at`, `rescheduled_at`, `rescheduled_by`, `is_auto_scheduled`, `slot_number`, `interview_round`, `feedback_provided`, `feedback_date`) VALUES
(1, 1, 'Technical Interview', '2026-02-20 14:00:00', 90, 'Head Chef, Restaurant Manager', 'Kitchen Office', 'Cooking demo required', 'completed', 10, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, NULL, 0, NULL, 1, 0, NULL),
(2, 2, 'Initial Screening', '2026-02-21 10:00:00', 60, 'HR Department', 'HR Office', '', 'scheduled', 2, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, NULL, 0, NULL, 1, 0, NULL),
(3, 4, 'Initial Screening', '2026-02-22 09:30:00', 60, 'HR Department', 'HR Office', '', 'scheduled', 2, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, NULL, 0, NULL, 1, 0, NULL),
(4, 5, 'Panel Interview', '2026-02-23 11:00:00', 120, 'Finance Manager, HR Manager', 'Conference Room', 'Final interview', 'scheduled', 8, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, NULL, 0, NULL, 2, 0, NULL),
(5, 5, 'phone', '2026-03-02 18:28:00', 60, 'Technical Lead', '', '', 'completed', 1, '2026-02-28 00:41:31', '2026-02-28 00:47:53', NULL, NULL, 0, NULL, 1, 0, NULL),
(6, 5, 'in_person', '2026-02-28 05:42:00', 60, 'Department Head', '', '', 'scheduled', 1, '2026-02-28 00:42:06', '2026-02-28 00:42:06', NULL, NULL, 0, NULL, 1, 0, NULL),
(7, 5, 'in_person', '2026-02-28 06:43:00', 60, 'Department Head', '', '', 'scheduled', 1, '2026-02-28 00:43:57', '2026-02-28 00:43:57', NULL, NULL, 0, NULL, 1, 0, NULL),
(8, 5, 'phone', '2026-03-14 06:44:00', 60, 'Team Lead', '', '', 'scheduled', 1, '2026-02-28 00:44:28', '2026-02-28 00:44:28', NULL, NULL, 0, NULL, 1, 0, NULL),
(9, 5, 'phone', '2026-03-03 06:30:00', 30, 'Department Head', '', '', 'scheduled', 1, '2026-02-28 00:46:28', '2026-02-28 00:46:28', NULL, NULL, 0, NULL, 1, 0, NULL),
(10, 9, 'phone', '2026-03-04 04:18:00', 60, 'HR Manager', '', '', 'completed', 1, '2026-03-04 00:29:59', '2026-03-04 00:30:25', NULL, NULL, 0, NULL, 1, 0, NULL),
(11, 9, 'phone', '2026-03-13 01:54:00', 60, 'Department Head', '', '', 'completed', 1, '2026-03-04 05:48:23', '2026-03-04 06:03:52', NULL, NULL, 0, NULL, 1, 0, NULL),
(12, 2, 'phone', '2026-03-08 14:02:00', 60, 'HR Manager', '', '', 'completed', 1, '2026-03-04 06:00:03', '2026-03-04 06:00:21', NULL, NULL, 0, NULL, 1, 0, NULL),
(13, 10, 'phone', '2026-03-14 14:38:00', 60, 'HR Manager', '', '', 'scheduled', 1, '2026-03-04 06:35:50', '2026-03-04 06:35:50', NULL, NULL, 0, NULL, 1, 0, NULL),
(14, 8, 'phone', '2026-03-15 16:37:00', 60, 'Department Head', '', '', 'completed', 1, '2026-03-04 06:37:05', '2026-03-04 06:37:22', NULL, NULL, 0, NULL, 1, 0, NULL),
(15, 11, 'in_person', '2026-04-23 13:00:00', 60, 'HR Manager', 'Personel Devision', '', 'completed', 1, '2026-04-23 01:39:19', '2026-04-23 01:39:46', NULL, NULL, 0, NULL, 1, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `interview_evaluations`
--

CREATE TABLE `interview_evaluations` (
  `id` int(11) NOT NULL,
  `interview_id` int(11) NOT NULL,
  `technical_skills` decimal(3,1) DEFAULT 0.0,
  `communication` decimal(3,1) DEFAULT 0.0,
  `cultural_fit` decimal(3,1) DEFAULT 0.0,
  `problem_solving` decimal(3,1) DEFAULT 0.0,
  `attitude` decimal(3,1) DEFAULT 0.0,
  `overall_rating` decimal(3,1) DEFAULT 0.0,
  `strengths` text DEFAULT NULL,
  `weaknesses` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `recommendation` enum('hire','maybe','reject','next_round') DEFAULT NULL,
  `next_steps` text DEFAULT NULL,
  `evaluated_by` int(11) DEFAULT NULL,
  `evaluated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `interview_evaluations`
--

INSERT INTO `interview_evaluations` (`id`, `interview_id`, `technical_skills`, `communication`, `cultural_fit`, `problem_solving`, `attitude`, `overall_rating`, `strengths`, `weaknesses`, `notes`, `recommendation`, `next_steps`, `evaluated_by`, `evaluated_at`, `created_at`, `updated_at`) VALUES
(1, 1, 9.0, 8.5, 9.0, 8.5, 9.5, 8.9, 'Excellent culinary skills, good leadership', 'None significant', NULL, 'hire', NULL, 10, '2026-02-27 22:03:11', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(2, 5, 5.0, 5.0, 5.0, 5.0, 0.0, 5.0, '', '', '', 'hire', '', 1, '2026-02-28 00:47:53', '2026-02-28 00:47:53', '2026-02-28 00:47:53'),
(3, 10, 5.0, 5.0, 5.0, 5.0, 0.0, 5.0, '', '', '', 'maybe', '', 1, '2026-03-04 00:30:25', '2026-03-04 00:30:25', '2026-03-04 00:30:25'),
(5, 12, 5.0, 5.0, 5.0, 5.0, 0.0, 5.0, '', '', '', 'hire', '', 1, '2026-03-04 06:00:21', '2026-03-04 06:00:21', '2026-03-04 06:00:21'),
(6, 11, 5.0, 5.0, 5.0, 5.0, 0.0, 5.0, '', '', '', 'hire', '', 1, '2026-03-04 06:03:52', '2026-03-04 06:03:52', '2026-03-04 06:03:52'),
(8, 14, 5.0, 5.0, 5.0, 5.0, 0.0, 5.0, '', '', '', 'hire', '', 1, '2026-03-04 06:37:22', '2026-03-04 06:37:22', '2026-03-04 06:37:22'),
(9, 15, 0.0, 5.0, 0.0, 5.0, 0.0, 5.0, '', '', '', 'hire', '', 1, '2026-04-23 01:39:46', '2026-04-23 01:39:46', '2026-04-23 01:39:46');

-- --------------------------------------------------------

--
-- Table structure for table `interview_history`
--

CREATE TABLE `interview_history` (
  `id` int(11) NOT NULL,
  `interview_id` int(11) NOT NULL,
  `action` varchar(50) NOT NULL,
  `action_by` int(11) DEFAULT NULL,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `interview_history`
--

INSERT INTO `interview_history` (`id`, `interview_id`, `action`, `action_by`, `details`, `created_at`) VALUES
(1, 1, 'scheduled', 10, '{\"date\":\"2026-02-20 14:00\",\"interviewers\":\"Head Chef, Restaurant Manager\"}', '2026-02-27 22:03:11');

-- --------------------------------------------------------

--
-- Table structure for table `interview_slots`
--

CREATE TABLE `interview_slots` (
  `id` int(11) NOT NULL,
  `slot_date` date NOT NULL,
  `slot_time` time NOT NULL,
  `duration_minutes` int(11) DEFAULT 60,
  `max_capacity` int(11) DEFAULT 1,
  `booked_count` int(11) DEFAULT 0,
  `interviewer_id` int(11) DEFAULT NULL,
  `is_available` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `interview_slots`
--

INSERT INTO `interview_slots` (`id`, `slot_date`, `slot_time`, `duration_minutes`, `max_capacity`, `booked_count`, `interviewer_id`, `is_available`, `created_at`, `updated_at`) VALUES
(1, '2026-03-05', '09:00:00', 60, 1, 0, 2, 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(2, '2026-03-05', '10:30:00', 60, 1, 0, 2, 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11');

-- --------------------------------------------------------

--
-- Table structure for table `job_postings`
--

CREATE TABLE `job_postings` (
  `id` int(11) NOT NULL,
  `job_title` varchar(100) NOT NULL,
  `job_code` varchar(50) DEFAULT NULL,
  `department` varchar(100) NOT NULL,
  `department_id` int(11) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `employment_type` enum('full_time','part_time','contract','temporary','internship') DEFAULT 'full_time',
  `salary_range` varchar(100) DEFAULT NULL,
  `salary_min` decimal(10,2) DEFAULT NULL,
  `salary_max` decimal(10,2) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `requirements` text DEFAULT NULL,
  `responsibilities` text DEFAULT NULL,
  `status` enum('draft','active','closed','archived') DEFAULT 'draft',
  `posting_date` date DEFAULT NULL,
  `closing_date` date DEFAULT NULL,
  `views` int(11) DEFAULT 0,
  `applications_count` int(11) DEFAULT 0,
  `created_by` int(11) DEFAULT NULL,
  `job_request_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `vacancies` int(11) DEFAULT 1,
  `filled_positions` int(11) DEFAULT 0,
  `experience_level` varchar(50) DEFAULT 'mid',
  `published_date` date DEFAULT NULL,
  `benefits` text DEFAULT NULL,
  `is_urgent` tinyint(1) DEFAULT 0,
  `approval_status` enum('pending','approved','rejected') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `job_postings`
--

INSERT INTO `job_postings` (`id`, `job_title`, `job_code`, `department`, `department_id`, `location`, `employment_type`, `salary_range`, `salary_min`, `salary_max`, `description`, `requirements`, `responsibilities`, `status`, `posting_date`, `closing_date`, `views`, `applications_count`, `created_by`, `job_request_id`, `created_at`, `updated_at`, `vacancies`, `filled_positions`, `experience_level`, `published_date`, `benefits`, `is_urgent`, `approval_status`, `approved_by`, `approved_at`) VALUES
(1, 'Sous Chef', 'POST-REQ-CORE2-SC-001', 'Core 2', 6, '', 'full_time', '₱38,000.00 - ₱50,000.00', 38000.00, 50000.00, '<p>Lead kitchen team in culinary operations.</p>', '<p>5+ years kitchen experience, culinary degree preferred</p>', '<p>Menu planning, staff supervision, quality control</p>', 'active', '2026-02-01', '2026-05-01', 0, 0, 1, 1, '2026-02-27 22:03:11', '2026-04-06 02:10:56', 1, 0, 'senior', NULL, '<p><br></p>', 0, 'approved', 1, '2026-02-28 06:03:11'),
(2, 'Server', 'POST-REQ-CORE2-SRV-002', 'Core 2', 6, '', 'full_time', '₱20,000.00 - ₱25,000.00', 20000.00, 25000.00, '<p>Provide excellent service to restaurant guests.</p>', '<p>1+ year serving experience, good communication</p>', '<p>Take orders, serve food, handle guest requests</p>', 'active', '2026-02-05', '2026-05-05', 0, 0, 1, 2, '2026-02-27 22:03:11', '2026-04-06 02:11:15', 2, 0, 'entry', NULL, '<p><br></p>', 0, 'approved', 1, '2026-02-28 06:03:11'),
(3, 'Warehouse Staff', 'POST-REQ-LOG1-WS-003', 'Logistics 1', 7, NULL, 'full_time', NULL, 18000.00, 25000.00, 'Support warehouse operations.', 'Physical fitness, basic inventory knowledge', 'Loading/unloading, stock keeping', 'draft', NULL, NULL, 0, 0, 6, 3, '2026-02-27 22:03:11', '2026-02-27 22:03:11', 2, 0, 'entry', NULL, NULL, 0, 'pending', NULL, NULL),
(4, 'Accountant', 'POST-REQ-FIN-ACC-004', 'Financials', 10, '', 'full_time', '₱40,000.00 - ₱55,000.00', 40000.00, 55000.00, '<p>Manage financial records and reports.</p>', '<p>CPA preferred, 3+ years experience</p>', '<p>Bookkeeping, tax compliance, financial analysis</p>', 'active', '2026-02-10', '2026-04-07', 0, 0, 8, 4, '2026-02-27 22:03:11', '2026-04-06 02:12:12', 1, 0, 'mid', NULL, '<p><br></p>', 0, 'approved', 8, '2026-02-28 06:03:11'),
(5, 'HR Assistant', 'POST-REQ-HR1-HRA-005', 'HR1', 1, '', 'full_time', '₱24,000.00 - ₱32,000.00', 24000.00, 32000.00, '<p>Assist HR department with daily tasks.</p>', '<p>HR degree, 1+ year experience</p>', '<p>File management, interview scheduling, onboarding support</p>', 'active', NULL, '2026-05-15', 0, 0, 2, 5, '2026-02-27 22:03:11', '2026-04-06 02:12:22', 1, 0, 'entry', '2026-02-28', '<p><br></p>', 0, 'pending', NULL, NULL),
(6, 'HR1 Staff', 'POST-REQ-HR1-STF-006', 'HR1', 1, '', 'full_time', '₱24,000.00 - ₱32,000.00', 24000.00, 32000.00, '<p>Assist HR team with daily operations.</p>', '<p>Bachelor’s degree in HR or related, 1+ year experience</p>', '<p>Recruitment support, employee records</p>', 'active', '2026-02-20', '2026-05-20', 0, 1, 1, 6, '2026-02-27 22:31:24', '2026-04-08 07:32:19', 2, 0, 'entry', NULL, '<p><br></p>', 0, 'approved', 1, '2026-02-28 06:31:24'),
(7, 'Trainer', 'POST-REQ-HR2-TRN-007', 'HR2', 2, '', 'full_time', '₱35,000.00 - ₱45,000.00', 35000.00, 45000.00, '<p>Deliver training programs to employees.</p>', '<p>3+ years training experience, excellent communication</p>', '<p>Develop materials, conduct sessions</p>', 'active', '2026-02-21', '2026-05-21', 0, 0, 1, 7, '2026-02-27 22:31:24', '2026-04-06 02:08:33', 1, 0, 'mid', NULL, '<p><br></p>', 0, 'approved', 1, '2026-02-28 06:31:24'),
(8, 'HR3 Manager', 'POST-REQ-HR3-MGR-008', 'HR3', 3, '', 'full_time', '₱55,000.00 - ₱70,000.00', 55000.00, 70000.00, '<p>Lead HR3 department.</p>', '<p>5+ years HR management, labor law knowledge</p>', '<p>Oversee HR operations, compliance</p>', 'draft', NULL, '2026-05-23', 0, 0, 1, 8, '2026-02-27 22:31:24', '2026-04-23 01:33:37', 1, 0, 'senior', '2026-04-23', '<p><br></p>', 0, 'pending', NULL, NULL),
(9, 'HR4 Manager', 'POST-REQ-HR4-MGR-009', 'HR4', 4, '', 'full_time', '₱60,000.00 - ₱75,000.00', 60000.00, 75000.00, '<p>Strategic HR leadership.</p>', '<p>7+ years HR leadership, strategic planning</p>', '<p>Develop HR strategies, manage team</p>', 'active', '2026-02-22', '2026-05-22', 0, 0, 1, 9, '2026-02-27 22:31:24', '2026-04-06 02:09:16', 1, 0, 'executive', NULL, '<p><br></p>', 0, 'approved', 1, '2026-02-28 06:31:24'),
(10, 'Warehouse Staff', 'POST-REQ-LOG1-WS-010', 'Logistics 1', 7, '', 'full_time', '₱18,000.00 - ₱25,000.00', 18000.00, 25000.00, '<p>Support warehouse operations.</p>', '<p>Physical fitness, basic inventory knowledge</p>', '<p>Loading/unloading, stock keeping</p>', 'active', '2026-02-23', '2026-05-23', 0, 0, 1, 10, '2026-02-27 22:31:24', '2026-04-06 02:09:28', 3, 0, 'entry', NULL, '<p><br></p>', 0, 'approved', 1, '2026-02-28 06:31:24'),
(11, 'Procurement Officer', 'POST-REQ-LOG1-PRO-011', 'Logistics 1', 7, NULL, 'full_time', NULL, 32000.00, 42000.00, 'Manage procurement processes.', '3+ years procurement, negotiation skills', 'Source suppliers, negotiate contracts', 'draft', NULL, NULL, 0, 0, 1, 11, '2026-02-27 22:31:24', '2026-02-27 22:31:24', 1, 0, 'mid', NULL, NULL, 0, 'pending', NULL, NULL),
(12, 'Project Manager', 'POST-REQ-LOG1-PM-012', 'Logistics 1', 7, NULL, 'full_time', NULL, 48000.00, 60000.00, 'Lead warehouse projects.', 'PMP, 5+ years project management', 'Plan and execute projects', 'draft', NULL, NULL, 0, 0, 1, 12, '2026-02-27 22:31:24', '2026-02-27 22:31:24', 1, 0, 'senior', NULL, NULL, 0, 'pending', NULL, NULL),
(13, 'Asset Manager', 'POST-REQ-LOG1-AM-013', 'Logistics 1', 7, '', 'full_time', '₱36,000.00 - ₱48,000.00', 36000.00, 48000.00, '<p>Manage company assets.</p>', '<p>4+ years asset management, accounting</p>', '<p>Track assets, lifecycle management</p>', 'active', '2026-02-24', '2026-05-24', 0, 0, 1, 13, '2026-02-27 22:31:24', '2026-04-06 02:09:38', 1, 0, 'mid', NULL, '<p><br></p>', 0, 'approved', 1, '2026-02-28 06:31:24'),
(14, 'Record Officer', 'POST-REQ-LOG1-RO-014', 'Logistics 1', 7, '', 'full_time', '₱26,000.00 - ₱34,000.00', 26000.00, 34000.00, '<p>Maintain records and documents.</p>', '<p>2+ years records management, detail-oriented</p>', '<p>Organize files, digitization</p>', 'active', '2026-02-25', '2026-05-25', 0, 1, 1, 14, '2026-02-27 22:31:24', '2026-04-06 02:09:48', 1, 0, 'entry', NULL, '<p><br></p>', 0, 'approved', 1, '2026-02-28 06:31:24'),
(15, 'Fleet Manager', 'POST-REQ-LOG2-FM-015', 'Logistics 2', 8, '', 'full_time', '₱42,000.00 - ₱54,000.00', 42000.00, 54000.00, '<p>Oversee fleet operations.</p>', '<p>5+ years fleet management, logistics degree</p>', '<p>Manage vehicles, maintenance</p>', 'active', '2026-02-26', '2026-05-26', 0, 0, 1, 15, '2026-02-27 22:31:24', '2026-04-06 02:09:58', 1, 0, 'senior', NULL, '<p><br></p>', 0, 'approved', 1, '2026-02-28 06:31:24'),
(16, 'Driver', 'POST-REQ-LOG2-DRV-016', 'Logistics 2', 8, '', 'full_time', '₱20,000.00 - ₱25,000.00', 20000.00, 25000.00, '<p>Deliver goods to clients.</p>', '<p>Valid driver’s license, clean record</p>', '<p>Safe driving, timely deliveries</p>', 'active', '2026-02-27', '2026-05-27', 0, 1, 1, 16, '2026-02-27 22:31:24', '2026-04-06 02:10:16', 2, 0, 'entry', NULL, '<p><br></p>', 0, 'approved', 1, '2026-02-28 06:31:24'),
(17, 'Dispatcher', 'POST-REQ-LOG2-DSP-017', 'Logistics 2', 8, NULL, 'full_time', NULL, 24000.00, 32000.00, 'Coordinate driver schedules.', '2+ years dispatching, multitasking', 'Assign routes, communicate with drivers', 'draft', NULL, NULL, 0, 0, 1, 17, '2026-02-27 22:31:24', '2026-02-27 22:31:24', 1, 0, 'mid', NULL, NULL, 0, 'pending', NULL, NULL),
(18, 'Financial Manager', 'POST-REQ-FIN-FM-018', 'Financials', 10, '', 'full_time', '₱65,000.00 - ₱80,000.00', 65000.00, 80000.00, '<p>Lead finance team.</p>', '<p>CPA, 8+ years finance leadership</p>', '<p>Financial planning, reporting</p>', 'active', '2026-02-28', '2026-05-28', 0, 0, 1, 18, '2026-02-27 22:31:24', '2026-04-06 02:10:27', 1, 0, 'executive', NULL, '<p><br></p>', 0, 'approved', 1, '2026-02-28 06:31:24'),
(19, 'Accountant', 'POST-REQ-FIN-ACC-019', 'Financials', 10, '', 'full_time', '₱38,000.00 - ₱50,000.00', 38000.00, 50000.00, '<p>Handle accounting tasks.</p>', '<p>CPA preferred, 3+ years</p>', '<p>Bookkeeping, tax preparation</p>', 'active', '2026-02-28', '2026-05-28', 0, 0, 1, 19, '2026-02-27 22:31:24', '2026-04-06 02:10:38', 1, 0, 'mid', NULL, '<p><br></p>', 0, 'approved', 1, '2026-02-28 06:31:24'),
(20, 'Reservation Officer', 'POST-REQ-CORE2-RES-020', 'Core 2', 6, '', 'full_time', '₱24,000.00 - ₱32,000.00', 24000.00, 32000.00, '<p>Handle guest reservations.</p>', '<p>1+ year reservation experience, PMS knowledge</p>', '<p>Manage bookings, answer inquiries</p>', 'active', '2026-02-28', '2026-05-28', 0, 2, 1, 20, '2026-02-27 22:31:24', '2026-04-06 02:10:47', 2, 0, 'entry', NULL, '<p><br></p>', 0, 'approved', 1, '2026-02-28 06:31:24');

-- --------------------------------------------------------

--
-- Table structure for table `job_requests`
--

CREATE TABLE `job_requests` (
  `id` int(11) NOT NULL,
  `position_title` varchar(100) NOT NULL,
  `department` varchar(100) NOT NULL,
  `department_id` int(11) DEFAULT NULL,
  `number_needed` int(11) DEFAULT 1,
  `reason` enum('new','replacement') DEFAULT 'new',
  `qualifications` text DEFAULT NULL,
  `target_start_date` date DEFAULT NULL,
  `requested_by` varchar(100) DEFAULT NULL,
  `requested_by_email` varchar(100) DEFAULT NULL,
  `justification` text DEFAULT NULL,
  `budget_approved` tinyint(1) DEFAULT 0,
  `overall_status` enum('draft','pending','approved','rejected') DEFAULT 'draft',
  `supervisor_approval` enum('pending','approved','rejected') DEFAULT 'pending',
  `management_approval` enum('pending','approved','rejected') DEFAULT 'pending',
  `rejection_reason` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_by` int(11) DEFAULT NULL,
  `job_code` varchar(50) DEFAULT NULL,
  `position_type` enum('new_position','replacement','backfill','temporary','contract') DEFAULT 'new_position',
  `required_skills` text DEFAULT NULL,
  `experience_level` enum('entry','mid','senior','executive') DEFAULT NULL,
  `education_level` enum('high_school','associate','bachelor','master','phd') DEFAULT NULL,
  `responsibilities` text DEFAULT NULL,
  `reporting_to` varchar(100) DEFAULT NULL,
  `salary_budget` decimal(10,2) DEFAULT NULL,
  `urgency_level` enum('critical','high','medium','low') DEFAULT 'medium',
  `hiring_manager_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `reviewed_by` int(11) DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `review_comments` text DEFAULT NULL,
  `supervisor_comments` text DEFAULT NULL,
  `supervisor_approved_at` datetime DEFAULT NULL,
  `supervisor_approved_by` int(11) DEFAULT NULL,
  `management_comments` text DEFAULT NULL,
  `management_approved_at` datetime DEFAULT NULL,
  `management_approved_by` int(11) DEFAULT NULL,
  `competency_summary` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `job_requests`
--

INSERT INTO `job_requests` (`id`, `position_title`, `department`, `department_id`, `number_needed`, `reason`, `qualifications`, `target_start_date`, `requested_by`, `requested_by_email`, `justification`, `budget_approved`, `overall_status`, `supervisor_approval`, `management_approval`, `rejection_reason`, `is_active`, `created_at`, `updated_at`, `updated_by`, `job_code`, `position_type`, `required_skills`, `experience_level`, `education_level`, `responsibilities`, `reporting_to`, `salary_budget`, `urgency_level`, `hiring_manager_id`, `created_by`, `reviewed_by`, `reviewed_at`, `review_comments`, `supervisor_comments`, `supervisor_approved_at`, `supervisor_approved_by`, `management_comments`, `management_approved_at`, `management_approved_by`, `competency_summary`) VALUES
(1, 'Sous Chef', 'Core 2', 6, 1, 'replacement', '5+ years kitchen experience, culinary degree preferred', '2026-03-15', 'Anthony Stark', 'anthony.stark@core2.com', 'Current sous chef resigned', 1, 'approved', 'approved', 'approved', NULL, 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, 'REQ-CORE2-SC-001', 'replacement', NULL, 'senior', NULL, NULL, NULL, 42000.00, 'critical', 10, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 'Server', 'Core 2', 6, 2, 'new', '1+ year serving experience, good communication', '2026-04-01', 'Steven Rogers', 'steven.rogers@core2.com', 'Restaurant expansion', 1, 'approved', 'approved', 'approved', NULL, 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, 'REQ-CORE2-SRV-002', 'new_position', NULL, 'entry', NULL, NULL, NULL, 22000.00, 'high', 9, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 'Warehouse Staff', 'Logistics 1', 7, 2, 'new', 'Physical fitness, basic inventory knowledge', '2026-03-20', 'Richard Baker', 'richard.baker@log1.com', 'Increased warehouse workload', 1, 'pending', 'pending', 'pending', NULL, 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, 'REQ-LOG1-WS-003', 'new_position', NULL, 'entry', NULL, NULL, NULL, 20000.00, 'medium', 6, 6, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 'Accountant', 'Financials', 10, 1, 'new', 'CPA preferred, 3+ years experience', '2026-05-01', 'William Stewart', 'william.stewart@fin.com', 'Year-end workload', 1, 'approved', 'approved', 'approved', NULL, 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, 'REQ-FIN-ACC-004', 'new_position', NULL, 'mid', NULL, NULL, NULL, 45000.00, 'medium', 8, 8, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(5, 'HR Assistant', 'HR1', 1, 1, 'new', 'HR degree, 1+ year experience', '2026-04-15', 'John Doe', 'john.doe@hr1.com', 'Support for HR team', 1, 'draft', 'pending', 'pending', NULL, 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, 'REQ-HR1-HRA-005', 'new_position', NULL, 'entry', NULL, NULL, NULL, 28000.00, 'low', 2, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 'HR1 Staff', 'HR1', 1, 2, 'new', 'Bachelor’s degree in HR or related field, 1+ year experience', '2026-05-01', 'John Doe', 'john.doe@hr1.com', 'HR workload increase', 1, 'approved', 'approved', 'approved', NULL, 1, '2026-02-27 22:26:49', '2026-02-27 22:26:49', NULL, 'REQ-HR1-STF-006', 'new_position', NULL, 'entry', NULL, NULL, NULL, 30000.00, 'medium', 2, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7, 'Trainer', 'HR2', 2, 1, 'replacement', '3+ years training experience, excellent communication', '2026-04-15', 'Sarah Johnson', 'sarah.johnson@hr2.com', 'Previous trainer resigned', 1, 'approved', 'approved', 'approved', NULL, 1, '2026-02-27 22:26:49', '2026-02-27 22:26:49', NULL, 'REQ-HR2-TRN-007', 'replacement', NULL, 'mid', NULL, NULL, NULL, 40000.00, 'high', 3, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8, 'HR3 Manager', 'HR3', 3, 1, 'replacement', '5+ years HR management experience, labor law knowledge', '2026-06-05', 'Michael Clark', 'michael.clark@hr3.com', 'Manager moving to new role', 1, 'approved', 'approved', 'pending', NULL, 1, '2026-02-27 22:26:49', '2026-04-23 01:31:19', 1, 'REQ-HR3-MGR-008', 'replacement', '', 'senior', 'bachelor', '', '', 65000.00, 'high', 4, 1, 1, '2026-04-23 09:31:19', 'askdasjk', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9, 'HR4 Manager', 'HR4', 4, 1, 'new', '7+ years HR leadership, strategic planning', '2026-07-01', 'Lisa Moore', 'lisa.moore@hr4.com', 'Department expansion', 1, 'approved', 'approved', 'approved', NULL, 1, '2026-02-27 22:26:49', '2026-02-27 22:26:49', NULL, 'REQ-HR4-MGR-009', 'new_position', NULL, 'executive', NULL, NULL, NULL, 70000.00, 'medium', 5, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(10, 'Warehouse Staff', 'Logistics 1', 7, 3, 'new', 'Physical fitness, basic inventory knowledge', '2026-04-10', 'Richard Baker', 'richard.baker@log1.com', 'Peak season demand', 1, 'approved', 'approved', 'approved', NULL, 1, '2026-02-27 22:26:49', '2026-02-27 22:26:49', NULL, 'REQ-LOG1-WS-010', 'new_position', NULL, 'entry', NULL, NULL, NULL, 20000.00, 'high', 6, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(11, 'Procurement Officer', 'Logistics 1', 7, 1, 'new', '3+ years procurement experience, negotiation skills', '2026-05-15', 'Richard Baker', 'richard.baker@log1.com', 'New vendor management', 1, 'pending', 'pending', 'pending', NULL, 1, '2026-02-27 22:26:49', '2026-02-27 22:26:49', NULL, 'REQ-LOG1-PRO-011', 'new_position', NULL, 'mid', NULL, NULL, NULL, 38000.00, 'medium', 6, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(12, 'Project Manager', 'Logistics 1', 7, 1, 'new', 'PMP certification, 5+ years project management', '2026-06-01', 'Richard Baker', 'richard.baker@log1.com', 'Major warehouse upgrade', 1, 'draft', 'pending', 'pending', NULL, 1, '2026-02-27 22:26:49', '2026-02-27 22:26:49', NULL, 'REQ-LOG1-PM-012', 'new_position', NULL, 'senior', NULL, NULL, NULL, 55000.00, 'low', 6, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(13, 'Asset Manager', 'Logistics 1', 7, 1, 'replacement', '4+ years asset management, accounting background', '2026-04-20', 'Richard Baker', 'richard.baker@log1.com', 'Current manager retiring', 1, 'approved', 'approved', 'approved', NULL, 1, '2026-02-27 22:26:49', '2026-02-27 22:26:49', NULL, 'REQ-LOG1-AM-013', 'replacement', NULL, 'mid', NULL, NULL, NULL, 42000.00, 'medium', 6, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(14, 'Record Officer', 'Logistics 1', 7, 1, 'new', '2+ years records management, attention to detail', '2026-05-05', 'Richard Baker', 'richard.baker@log1.com', 'Document digitization project', 1, 'approved', 'approved', 'approved', NULL, 1, '2026-02-27 22:26:49', '2026-02-27 22:26:49', NULL, 'REQ-LOG1-RO-014', 'new_position', NULL, 'entry', NULL, NULL, NULL, 30000.00, 'medium', 6, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(15, 'Fleet Manager', 'Logistics 2', 8, 1, 'replacement', '5+ years fleet management, logistics degree', '2026-04-01', 'Matthew Phillips', 'matthew.phillips@log2.com', 'Current manager promoted', 1, 'approved', 'approved', 'approved', NULL, 1, '2026-02-27 22:26:49', '2026-02-27 22:26:49', NULL, 'REQ-LOG2-FM-015', 'replacement', NULL, 'senior', NULL, NULL, NULL, 48000.00, 'high', 7, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(16, 'Driver', 'Logistics 2', 8, 2, 'new', 'Valid driver’s license, clean record', '2026-04-10', 'Matthew Phillips', 'matthew.phillips@log2.com', 'New delivery routes', 1, 'approved', 'approved', 'approved', NULL, 1, '2026-02-27 22:26:49', '2026-02-27 22:26:49', NULL, 'REQ-LOG2-DRV-016', 'new_position', NULL, 'entry', NULL, NULL, NULL, 22000.00, 'high', 7, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(17, 'Dispatcher', 'Logistics 2', 8, 1, 'new', '2+ years dispatching, multitasking', '2026-05-01', 'Matthew Phillips', 'matthew.phillips@log2.com', 'Expanding operations', 1, 'pending', 'pending', 'pending', NULL, 1, '2026-02-27 22:26:49', '2026-02-27 22:26:49', NULL, 'REQ-LOG2-DSP-017', 'new_position', NULL, 'mid', NULL, NULL, NULL, 28000.00, 'medium', 7, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(18, 'Financial Manager', 'Financials', 10, 1, 'new', 'CPA, 8+ years finance leadership', '2026-06-15', 'William Stewart', 'william.stewart@fin.com', 'New financial planning unit', 1, 'approved', 'approved', 'approved', NULL, 1, '2026-02-27 22:26:49', '2026-02-27 22:26:49', NULL, 'REQ-FIN-FM-018', 'new_position', NULL, 'executive', NULL, NULL, NULL, 75000.00, 'medium', 8, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(19, 'Accountant', 'Financials', 10, 1, 'replacement', 'CPA preferred, 3+ years', '2026-04-20', 'William Stewart', 'william.stewart@fin.com', 'Resignation', 1, 'approved', 'approved', 'approved', NULL, 1, '2026-02-27 22:26:49', '2026-02-27 22:26:49', NULL, 'REQ-FIN-ACC-019', 'replacement', NULL, 'mid', NULL, NULL, NULL, 45000.00, 'high', 8, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20, 'Reservation Officer', 'Core 2', 6, 2, 'new', '1+ year reservation experience, PMS knowledge', '2026-05-10', 'Steven Rogers', 'steven.rogers@core2.com', 'Booking volume increase', 1, 'approved', 'approved', 'approved', NULL, 1, '2026-02-27 22:26:49', '2026-02-27 22:26:49', NULL, 'REQ-CORE2-RES-020', 'new_position', NULL, 'entry', NULL, NULL, NULL, 28000.00, 'high', 9, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `job_request_competencies`
--

CREATE TABLE `job_request_competencies` (
  `id` int(11) NOT NULL,
  `job_request_id` int(11) NOT NULL,
  `competency_id` int(11) NOT NULL,
  `required_level` enum('basic','intermediate','advanced','expert') DEFAULT 'intermediate',
  `weight` int(3) DEFAULT 100,
  `is_critical` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `job_request_competencies`
--

INSERT INTO `job_request_competencies` (`id`, `job_request_id`, `competency_id`, `required_level`, `weight`, `is_critical`, `created_at`) VALUES
(1, 1, 3, 'advanced', 100, 1, '2026-02-27 22:03:11'),
(2, 1, 7, 'intermediate', 90, 1, '2026-02-27 22:03:11'),
(3, 2, 1, 'intermediate', 80, 1, '2026-02-27 22:03:11'),
(4, 2, 6, 'intermediate', 70, 0, '2026-02-27 22:03:11'),
(5, 3, 4, 'basic', 80, 1, '2026-02-27 22:03:11'),
(6, 4, 5, 'intermediate', 90, 1, '2026-02-27 22:03:11'),
(7, 4, 8, 'intermediate', 85, 0, '2026-02-27 22:03:11'),
(8, 5, 1, 'basic', 70, 0, '2026-02-27 22:03:11'),
(9, 5, 6, 'intermediate', 80, 1, '2026-02-27 22:03:11');

-- --------------------------------------------------------

--
-- Table structure for table `onboarding`
--

CREATE TABLE `onboarding` (
  `id` int(11) NOT NULL,
  `employee_id` varchar(50) DEFAULT NULL,
  `first_name` varchar(50) NOT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `job_position` varchar(100) NOT NULL,
  `department` varchar(100) NOT NULL,
  `system_email` varchar(255) DEFAULT NULL,
  `system_username` varchar(100) DEFAULT NULL,
  `system_password` varchar(255) DEFAULT NULL,
  `system_access_groups` text DEFAULT NULL,
  `system_software_licenses` text DEFAULT NULL,
  `hire_date` date NOT NULL,
  `start_date` date DEFAULT NULL,
  `employment_type` enum('regular','probationary','contractual','project_based') DEFAULT 'probationary',
  `salary` decimal(10,2) DEFAULT NULL,
  `supervisor_name` varchar(100) DEFAULT NULL,
  `status` enum('pending','onboarding','completed','cancelled') DEFAULT 'pending',
  `contract_status` enum('Pending HR','HR Approved','Manager Approved','Completed','Rejected') DEFAULT 'Pending HR',
  `signature_path` varchar(500) DEFAULT NULL,
  `approved_by_hr` datetime DEFAULT NULL,
  `approved_by_manager` datetime DEFAULT NULL,
  `resume` varchar(500) DEFAULT NULL,
  `contract_signed` tinyint(1) DEFAULT 0,
  `documents_complete` tinyint(1) DEFAULT 0,
  `orientation_complete` tinyint(1) DEFAULT 0,
  `system_access_setup` tinyint(1) DEFAULT 0,
  `system_setup_at` datetime DEFAULT NULL,
  `system_notes` text DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `equipment_provided` tinyint(1) DEFAULT 0,
  `training_complete` tinyint(1) DEFAULT 0,
  `compliance_complete` tinyint(1) DEFAULT 0,
  `notes` text DEFAULT NULL,
  `applicant_id` int(11) DEFAULT NULL,
  `employee_record_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `interview_id` int(11) DEFAULT NULL,
  `salary_range` varchar(50) DEFAULT NULL,
  `onboarding_progress` int(3) DEFAULT 0,
  `documents_submitted` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`documents_submitted`)),
  `documents_submitted_at` datetime DEFAULT NULL,
  `documents_notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `onboarding`
--

INSERT INTO `onboarding` (`id`, `employee_id`, `first_name`, `middle_name`, `last_name`, `email`, `contact_number`, `address`, `date_of_birth`, `phone`, `job_position`, `department`, `system_email`, `system_username`, `system_password`, `system_access_groups`, `system_software_licenses`, `hire_date`, `start_date`, `employment_type`, `salary`, `supervisor_name`, `status`, `contract_status`, `signature_path`, `approved_by_hr`, `approved_by_manager`, `resume`, `contract_signed`, `documents_complete`, `orientation_complete`, `system_access_setup`, `system_setup_at`, `system_notes`, `user_id`, `equipment_provided`, `training_complete`, `compliance_complete`, `notes`, `applicant_id`, `employee_record_id`, `created_at`, `updated_at`, `interview_id`, `salary_range`, `onboarding_progress`, `documents_submitted`, `documents_submitted_at`, `documents_notes`) VALUES
(1, 'EMP202605001', 'Charlie', NULL, 'Parker', 'charlie.parker@luxuryhotel.com', NULL, NULL, NULL, NULL, 'Sous Chef', 'Core 2', NULL, NULL, NULL, NULL, NULL, '2026-03-01', '2026-03-15', 'regular', NULL, NULL, 'completed', 'Completed', NULL, NULL, NULL, NULL, 1, 1, 1, 1, NULL, NULL, NULL, 1, 0, 0, '', 1, NULL, '2026-02-27 22:03:11', '2026-04-08 10:13:47', 1, NULL, 0, NULL, NULL, NULL),
(2, 'EMP2026020002', 'Rocket', NULL, 'Raccoon', 'rocket.r@email.com', NULL, NULL, NULL, '09241234573', 'Accountant', 'Financials', NULL, NULL, NULL, NULL, NULL, '2026-03-14', NULL, 'probationary', NULL, NULL, 'completed', 'Pending HR', NULL, NULL, NULL, NULL, 1, 1, 1, 1, NULL, NULL, NULL, 1, 0, 0, '', 5, 63, '2026-02-28 00:47:53', '2026-04-08 10:11:13', 5, NULL, 0, NULL, NULL, NULL),
(4, 'EMP2026030003', 'Diana', NULL, 'Prince', 'diana.prince@email.com', NULL, NULL, NULL, '09211234570', 'Sous Chef', 'Core 2', NULL, NULL, NULL, NULL, NULL, '2026-03-18', NULL, 'probationary', NULL, NULL, 'completed', 'Pending HR', NULL, NULL, NULL, NULL, 1, 1, 1, 1, NULL, NULL, NULL, 1, 0, 0, '', 2, 64, '2026-03-04 06:00:21', '2026-04-08 10:11:13', 12, NULL, 0, NULL, NULL, NULL),
(5, 'EMP2026030004', 'James Kneechtel', NULL, 'Sabandal', 'james@gmail.com', NULL, NULL, NULL, '09123456789', 'Driver', 'Logistics 2', NULL, NULL, NULL, NULL, NULL, '2026-03-18', NULL, 'probationary', NULL, NULL, 'completed', 'Pending HR', NULL, NULL, NULL, NULL, 1, 1, 1, 1, NULL, NULL, NULL, 1, 0, 0, '', 9, 14, '2026-03-04 06:03:52', '2026-04-08 10:11:13', 11, NULL, 0, NULL, NULL, NULL),
(7, 'EMP2026030005', 'Ronnico', NULL, 'Espiritu', 'ronnicoespiritu@gmail.com', NULL, NULL, NULL, '09953268825', 'Reservation Officer', 'Core 2', NULL, NULL, NULL, NULL, NULL, '2026-03-18', NULL, 'probationary', NULL, NULL, 'completed', 'Pending HR', NULL, NULL, NULL, NULL, 1, 1, 1, 1, NULL, NULL, NULL, 1, 0, 0, '', 8, 65, '2026-03-04 06:37:22', '2026-04-08 10:11:13', 14, NULL, 0, NULL, NULL, NULL),
(9, 'EMP202603001', 'James', 'Deleon', 'Sabandal', 'jameskneechtel@gmail.com', '098736512', 'salvador', '2005-06-08', NULL, 'Housekeeper', 'Management', NULL, NULL, NULL, NULL, NULL, '2026-03-04', NULL, 'regular', 18000.00, '', 'completed', 'Pending HR', NULL, NULL, NULL, NULL, 1, 1, 1, 1, NULL, NULL, NULL, 1, 0, 0, '', NULL, NULL, '2026-03-04 09:19:28', '2026-04-08 10:13:22', NULL, NULL, 0, NULL, NULL, NULL),
(10, 'EMP2026040007', 'Christian', NULL, 'Costibolo', 'costibolo45@gmail.com', NULL, NULL, NULL, '09686680871', 'HR1 Staff', 'HR1', NULL, NULL, NULL, NULL, NULL, '2026-05-07', NULL, 'probationary', NULL, NULL, 'onboarding', 'Pending HR', NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, 0, 0, 0, NULL, 11, NULL, '2026-04-23 01:39:46', '2026-04-23 01:39:46', 15, '₱24,000.00 - ₱32,000.00', 0, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `performance_evaluation_details`
--

CREATE TABLE `performance_evaluation_details` (
  `id` int(11) NOT NULL,
  `review_id` int(11) NOT NULL,
  `criteria_id` int(11) NOT NULL,
  `score` int(3) NOT NULL,
  `comments` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `performance_evaluation_details`
--

INSERT INTO `performance_evaluation_details` (`id`, `review_id`, `criteria_id`, `score`, `comments`, `created_at`) VALUES
(1, 1, 1, 95, 'Great guest feedback', '2026-02-27 22:03:11'),
(2, 1, 2, 92, 'Efficient processes', '2026-02-27 22:03:11'),
(3, 1, 3, 96, 'Team player', '2026-02-27 22:03:11'),
(4, 1, 4, 90, 'Good upselling', '2026-02-27 22:03:11'),
(5, 1, 6, 98, 'Excellent attendance', '2026-02-27 22:03:11'),
(6, 2, 1, 94, 'Positive training feedback', '2026-02-27 22:03:11'),
(7, 2, 2, 90, 'Well-organized', '2026-02-27 22:03:11'),
(8, 2, 3, 92, 'Collaborative', '2026-02-27 22:03:11'),
(9, 2, 5, 95, 'High standards', '2026-02-27 22:03:11'),
(10, 3, 2, 88, 'Efficient', '2026-02-27 22:03:11'),
(11, 3, 3, 90, 'Team leader', '2026-02-27 22:03:11'),
(12, 3, 5, 92, 'Cleanliness maintained', '2026-02-27 22:03:11'),
(13, 3, 6, 85, 'Good attendance', '2026-02-27 22:03:11'),
(14, 4, 1, 96, 'Excellent financial reports', '2026-02-27 22:03:11'),
(15, 4, 2, 94, 'Accurate and timely', '2026-02-27 22:03:11'),
(16, 4, 7, 92, 'Leads team well', '2026-02-27 22:03:11'),
(17, 4, 8, 90, 'Innovative ideas', '2026-02-27 22:03:11'),
(18, 5, 1, 95, 'Great service', '2026-02-27 22:03:11'),
(19, 5, 2, 92, 'Efficient', '2026-02-27 22:03:11'),
(20, 5, 3, 94, 'Strong collaboration', '2026-02-27 22:03:11'),
(21, 5, 4, 88, 'Upselling improved', '2026-02-27 22:03:11');

-- --------------------------------------------------------

--
-- Table structure for table `performance_goals`
--

CREATE TABLE `performance_goals` (
  `goal_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `progress` tinyint(4) DEFAULT 0,
  `status` enum('not_started','in_progress','completed','cancelled') DEFAULT 'not_started',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `performance_goals`
--

INSERT INTO `performance_goals` (`goal_id`, `employee_id`, `title`, `description`, `due_date`, `progress`, `status`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 1, 'Reduce hiring time', 'Decrease average time-to-hire by 10%', '2026-06-30', 30, 'in_progress', 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(2, 6, 'Develop new training module', 'Create onboarding program for new hires', '2026-05-31', 50, 'in_progress', 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(3, 21, 'Inventory accuracy', 'Achieve 99% inventory accuracy', '2026-04-30', 20, 'in_progress', 6, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(4, 34, 'Budget compliance', 'Ensure all departments stay within budget', '2026-12-31', 10, 'not_started', 1, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(5, 39, 'Increase customer satisfaction', 'Raise restaurant satisfaction score to 4.8', '2026-07-31', 40, 'in_progress', 9, '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(6, 1, 'Reduce time-to-hire', 'Decrease average hiring time from 30 to 25 days', '2026-06-30', 40, 'in_progress', 1, '2026-02-27 23:18:54', '2026-02-27 23:18:54'),
(7, 2, 'Complete HR certification', 'Pass SHRM-CP exam', '2026-08-15', 10, 'not_started', 1, '2026-02-27 23:18:54', '2026-02-27 23:18:54'),
(8, 3, 'Improve file organization', 'Digitize all employee records', '2026-05-01', 80, 'in_progress', 1, '2026-02-27 23:18:54', '2026-02-27 23:18:54'),
(9, 6, 'Develop 3 new training modules', 'Create onboarding, safety, and leadership modules', '2026-07-31', 60, 'in_progress', 1, '2026-02-27 23:18:54', '2026-02-27 23:18:54'),
(10, 7, 'Train 20 new hires', 'Conduct orientation for all new employees in Q2', '2026-06-30', 30, 'in_progress', 1, '2026-02-27 23:18:54', '2026-02-27 23:18:54'),
(11, 11, 'Update compliance handbook', 'Revise employee handbook for 2026 regulations', '2026-05-15', 100, 'completed', 1, '2026-02-27 23:18:54', '2026-02-27 23:18:54'),
(12, 16, 'Reduce payroll errors', 'Achieve 99.9% accuracy in payroll processing', '2026-09-01', 25, 'in_progress', 1, '2026-02-27 23:18:54', '2026-02-27 23:18:54'),
(13, 21, 'Inventory accuracy', 'Maintain 98% inventory accuracy for 3 months', '2026-04-30', 90, 'in_progress', 1, '2026-02-27 23:18:54', '2026-02-27 23:18:54'),
(14, 24, 'Negotiate 5% cost savings', 'Reduce procurement costs by 5% through vendor negotiation', '2026-08-01', 20, 'not_started', 1, '2026-02-27 23:18:54', '2026-02-27 23:18:54'),
(15, 25, 'Complete warehouse project', 'Finish warehouse renovation by deadline', '2026-06-15', 70, 'in_progress', 1, '2026-02-27 23:18:54', '2026-02-27 23:18:54'),
(16, 28, 'Reduce fuel costs by 8%', 'Optimize delivery routes to cut fuel expenses', '2026-07-01', 50, 'in_progress', 1, '2026-02-27 23:18:54', '2026-02-27 23:18:54'),
(17, 29, 'Improve dispatch response time', 'Decrease average dispatch time to under 10 minutes', '2026-05-20', 40, 'in_progress', 1, '2026-02-27 23:18:54', '2026-02-27 23:18:54'),
(18, 34, 'Prepare annual budget', 'Complete FY2027 budget proposal by deadline', '2026-11-15', 5, 'not_started', 1, '2026-02-27 23:18:54', '2026-02-27 23:18:54'),
(19, 39, 'Increase customer satisfaction', 'Achieve 4.8/5 rating on guest surveys', '2026-12-31', 15, 'in_progress', 1, '2026-02-27 23:18:54', '2026-02-27 23:18:54'),
(20, 40, 'Create 5 new seasonal menu items', 'Develop and test new dishes for summer menu', '2026-04-01', 60, 'in_progress', 1, '2026-02-27 23:18:54', '2026-02-27 23:18:54');

-- --------------------------------------------------------

--
-- Table structure for table `performance_reviews`
--

CREATE TABLE `performance_reviews` (
  `id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `reviewer_id` int(11) NOT NULL,
  `review_date` date DEFAULT NULL,
  `due_date` date NOT NULL,
  `rating` decimal(3,2) DEFAULT NULL,
  `summary` text DEFAULT NULL,
  `status` enum('draft','scheduled','completed','cancelled') DEFAULT 'draft',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `performance_reviews`
--

INSERT INTO `performance_reviews` (`id`, `employee_id`, `reviewer_id`, `review_date`, `due_date`, `rating`, `summary`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2026-02-20', '2026-02-20', 4.80, 'Excellent performance, exceeded goals', 'completed', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(2, 6, 1, '2026-02-18', '2026-02-18', 4.50, 'Great training delivery', 'completed', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(3, 21, 6, '2026-02-15', '2026-02-15', 4.20, 'Good warehouse management', 'completed', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(4, 34, 1, '2026-02-12', '2026-02-12', 4.70, 'Strong financial oversight', 'completed', '2026-02-27 22:03:11', '2026-02-27 22:03:11'),
(5, 39, 9, '2026-02-10', '2026-02-10', 4.60, 'Excellent restaurant operations', 'completed', '2026-02-27 22:03:11', '2026-02-27 22:03:11');

-- --------------------------------------------------------

--
-- Table structure for table `recognitions`
--

CREATE TABLE `recognitions` (
  `id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL COMMENT 'Employee receiving recognition',
  `recognizer_id` int(11) DEFAULT NULL COMMENT 'User ID who gave recognition',
  `recognition_type` varchar(50) NOT NULL COMMENT 'e.g., spot_award, peer_recognition, manager_recognition',
  `category` varchar(50) NOT NULL COMMENT 'e.g., teamwork, innovation, leadership',
  `points_awarded` int(11) NOT NULL DEFAULT 0,
  `description` text NOT NULL,
  `recognition_date` date NOT NULL,
  `status` enum('published','draft','archived') NOT NULL DEFAULT 'draft',
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `recognitions`
--

INSERT INTO `recognitions` (`id`, `employee_id`, `recognizer_id`, `recognition_type`, `category`, `points_awarded`, `description`, `recognition_date`, `status`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'manager_recognition', 'leadership', 20, 'Great job leading the HR team this month', '2026-02-15', 'published', 1, '2026-02-28 06:03:11', '2026-02-28 06:03:11'),
(2, 27, 1, 'manager_recognition', 'leadership', 20, 'Very Productive', '2026-02-06', 'draft', 1, '2026-02-28 08:22:36', '2026-02-28 08:22:36'),
(3, 20, 1, 'manager_recognition', 'leadership', 20, 'Good Employee', '2026-02-27', 'published', 1, '2026-02-28 08:25:02', '2026-02-28 08:25:02');

-- --------------------------------------------------------

--
-- Table structure for table `recognition_milestones`
--

CREATE TABLE `recognition_milestones` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL COMMENT 'e.g., "5 Recognitions", "100 Points Club"',
  `type` enum('count','points') NOT NULL,
  `threshold` int(11) NOT NULL,
  `badge_name` varchar(100) DEFAULT NULL,
  `badge_icon` varchar(255) DEFAULT NULL,
  `points_awarded` int(11) DEFAULT 0 COMMENT 'Bonus points when milestone achieved',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `recognition_milestones`
--

INSERT INTO `recognition_milestones` (`id`, `name`, `type`, `threshold`, `badge_name`, `badge_icon`, `points_awarded`, `is_active`, `created_at`, `updated_at`) VALUES
(1, '5 Recognitions Club', 'count', 5, 'Star Performer', NULL, 50, 1, '2026-02-28 06:03:11', '2026-02-28 06:03:11'),
(2, '100 Points Club', 'points', 100, 'Century Award', NULL, 100, 1, '2026-02-28 06:03:11', '2026-02-28 06:03:11');

-- --------------------------------------------------------

--
-- Table structure for table `template_criteria`
--

CREATE TABLE `template_criteria` (
  `template_id` int(11) NOT NULL,
  `criteria_id` int(11) NOT NULL,
  `weight` decimal(5,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `template_criteria`
--

INSERT INTO `template_criteria` (`template_id`, `criteria_id`, `weight`) VALUES
(1, 1, 12.50),
(1, 2, 12.50),
(1, 3, 12.50),
(1, 4, 12.50),
(1, 5, 12.50),
(1, 6, 12.50),
(1, 7, 12.50),
(1, 8, 12.50),
(2, 1, 30.00),
(2, 2, 30.00),
(2, 3, 20.00),
(2, 6, 20.00),
(3, 2, 25.00),
(3, 3, 25.00),
(3, 5, 25.00),
(3, 6, 25.00),
(5, 3, 20.00),
(5, 6, 20.00),
(5, 9, 20.00),
(5, 10, 25.00),
(5, 11, 15.00);

-- --------------------------------------------------------

--
-- Table structure for table `training_participants`
--

CREATE TABLE `training_participants` (
  `id` int(11) NOT NULL,
  `training_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `attendance_status` enum('registered','attended','absent','excused') DEFAULT 'registered',
  `feedback` text DEFAULT NULL,
  `rating` int(2) DEFAULT NULL,
  `certificate_issued` tinyint(1) DEFAULT 0,
  `certificate_path` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `completion_date` date DEFAULT NULL,
  `score` decimal(5,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `training_participants`
--

INSERT INTO `training_participants` (`id`, `training_id`, `employee_id`, `attendance_status`, `feedback`, `rating`, `certificate_issued`, `certificate_path`, `created_at`, `updated_at`, `completion_date`, `score`) VALUES
(1, 1, 5, 'registered', NULL, NULL, 0, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, NULL),
(2, 1, 10, 'registered', NULL, NULL, 0, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, NULL),
(3, 1, 13, 'registered', NULL, NULL, 0, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, NULL),
(4, 1, 19, 'registered', NULL, NULL, 0, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, NULL),
(5, 1, 23, 'registered', NULL, NULL, 0, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, NULL),
(6, 1, 27, 'registered', NULL, NULL, 0, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, NULL),
(7, 1, 33, 'registered', NULL, NULL, 0, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, NULL),
(8, 1, 37, 'registered', NULL, NULL, 0, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, NULL),
(9, 1, 41, 'registered', NULL, NULL, 0, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, NULL),
(10, 1, 45, 'registered', NULL, NULL, 0, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, NULL),
(11, 2, 40, 'registered', NULL, NULL, 0, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, NULL),
(12, 2, 41, 'registered', NULL, NULL, 0, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, NULL),
(13, 2, 44, 'registered', NULL, NULL, 0, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, NULL),
(14, 2, 45, 'registered', NULL, NULL, 0, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, NULL),
(15, 2, 46, 'registered', NULL, NULL, 0, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, NULL),
(16, 3, 39, 'registered', NULL, NULL, 0, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, NULL),
(17, 3, 42, 'registered', NULL, NULL, 0, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, NULL),
(18, 3, 43, 'registered', NULL, NULL, 0, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, NULL),
(19, 3, 44, 'registered', NULL, NULL, 0, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, NULL),
(20, 4, 1, 'registered', NULL, NULL, 0, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, NULL),
(21, 4, 6, 'registered', NULL, NULL, 0, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, NULL),
(22, 4, 11, 'registered', NULL, NULL, 0, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, NULL),
(23, 4, 16, 'registered', NULL, NULL, 0, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, NULL),
(24, 4, 21, 'registered', NULL, NULL, 0, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, NULL),
(25, 4, 28, 'registered', NULL, NULL, 0, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, NULL),
(26, 4, 34, 'registered', NULL, NULL, 0, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, NULL),
(27, 4, 39, 'registered', NULL, NULL, 0, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `training_sessions`
--

CREATE TABLE `training_sessions` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `type` enum('orientation','technical','soft_skills','compliance','leadership','safety','onboarding') NOT NULL,
  `instructor` varchar(100) NOT NULL,
  `training_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `location` varchar(100) NOT NULL,
  `capacity` int(11) DEFAULT 20,
  `participant_count` int(11) DEFAULT 0,
  `status` enum('scheduled','ongoing','completed','cancelled') DEFAULT 'scheduled',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_mandatory` tinyint(1) DEFAULT 0,
  `department_id` int(11) DEFAULT NULL,
  `training_materials` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `training_sessions`
--

INSERT INTO `training_sessions` (`id`, `title`, `description`, `type`, `instructor`, `training_date`, `start_time`, `end_time`, `location`, `capacity`, `participant_count`, `status`, `created_at`, `updated_at`, `is_mandatory`, `department_id`, `training_materials`) VALUES
(1, 'New Hire Orientation', 'Orientation for all new employees', 'orientation', 'HR Department', '2026-03-01', '09:00:00', '17:00:00', 'Training Room A', 30, 0, 'scheduled', '2026-02-27 22:03:11', '2026-02-27 22:03:11', 1, NULL, NULL),
(2, 'Food Safety Certification', 'HACCP training for kitchen staff', 'compliance', 'Head Chef', '2026-03-05', '08:00:00', '12:00:00', 'Kitchen Training Area', 20, 0, 'scheduled', '2026-02-27 22:03:11', '2026-02-27 22:03:11', 1, NULL, NULL),
(3, 'Customer Service Excellence', 'Advanced guest service skills', 'soft_skills', 'Guest Relations Manager', '2026-03-10', '13:00:00', '17:00:00', 'Conference Room', 25, 0, 'scheduled', '2026-02-27 22:03:11', '2026-02-27 22:03:11', 0, NULL, NULL),
(4, 'Leadership Development', 'For supervisors and managers', 'leadership', 'HR Manager', '2026-03-15', '09:00:00', '16:00:00', 'Boardroom', 15, 0, 'scheduled', '2026-02-27 22:03:11', '2026-02-27 22:03:11', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `role` enum('admin','hr_manager','hr_officer','department_head','manager','supervisor','employee') DEFAULT 'hr_officer',
  `department` varchar(100) DEFAULT NULL,
  `employee_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `profile_picture` varchar(500) DEFAULT NULL,
  `notification_preferences` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`notification_preferences`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password_hash`, `full_name`, `role`, `department`, `employee_id`, `is_active`, `last_login`, `created_at`, `updated_at`, `profile_picture`, `notification_preferences`) VALUES
(1, 'officer', 'officer@hr1.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'System Administrator', 'hr_officer', 'HR1', NULL, 1, '2026-02-27 09:00:00', '2026-02-27 22:03:11', '2026-02-27 22:03:56', NULL, '{\"email\":true,\"push\":true,\"sms\":false}'),
(2, 'jdoe', 'john.doe@hr1.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'John Doe', 'hr_manager', 'HR1', NULL, 1, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, '{\"email\":true,\"push\":true,\"sms\":true}'),
(3, 'sjohnson', 'sarah.johnson@hr2.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Sarah Johnson', 'hr_manager', 'HR2', NULL, 1, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, '{\"email\":true,\"push\":true,\"sms\":false}'),
(4, 'mclark', 'michael.clark@hr3.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Michael Clark', 'hr_manager', 'HR3', NULL, 1, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, '{\"email\":true,\"push\":false,\"sms\":false}'),
(5, 'lmoore', 'lisa.moore@hr4.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Lisa Moore', 'hr_manager', 'HR4', NULL, 1, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, '{\"email\":true,\"push\":true,\"sms\":false}'),
(6, 'rbaker', 'richard.baker@log1.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Richard Baker', 'department_head', 'Logistics 1', NULL, 1, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, '{\"email\":true,\"push\":true,\"sms\":false}'),
(7, 'mphillips', 'matthew.phillips@log2.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Matthew Phillips', 'department_head', 'Logistics 2', NULL, 1, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, '{\"email\":true,\"push\":true,\"sms\":false}'),
(8, 'wstewart', 'william.stewart@fin.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'William Stewart', 'department_head', 'Financials', NULL, 1, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, '{\"email\":true,\"push\":true,\"sms\":true}'),
(9, 'srogers', 'steven.rogers@core2.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Steven Rogers', 'manager', 'Core 2', NULL, 1, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, '{\"email\":true,\"push\":true,\"sms\":false}'),
(10, 'astark', 'anthony.stark@core2.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Anthony Stark', 'supervisor', 'Core 2', NULL, 1, NULL, '2026-02-27 22:03:11', '2026-02-27 22:03:11', NULL, '{\"email\":true,\"push\":false,\"sms\":false}');

-- --------------------------------------------------------

--
-- Table structure for table `working_hours`
--

CREATE TABLE `working_hours` (
  `id` int(11) NOT NULL,
  `day_of_week` int(1) NOT NULL COMMENT '0=Sunday, 1=Monday, etc.',
  `is_working_day` tinyint(1) DEFAULT 1,
  `start_time` time DEFAULT '09:00:00',
  `end_time` time DEFAULT '17:00:00',
  `lunch_start` time DEFAULT '12:00:00',
  `lunch_end` time DEFAULT '13:00:00',
  `max_interviews_per_day` int(11) DEFAULT 8,
  `interview_start_time` time DEFAULT '09:00:00',
  `interview_end_time` time DEFAULT '16:00:00',
  `interview_interval` int(11) DEFAULT 60 COMMENT 'in minutes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `working_hours`
--

INSERT INTO `working_hours` (`id`, `day_of_week`, `is_working_day`, `start_time`, `end_time`, `lunch_start`, `lunch_end`, `max_interviews_per_day`, `interview_start_time`, `interview_end_time`, `interview_interval`) VALUES
(1, 0, 0, '09:00:00', '17:00:00', '12:00:00', '13:00:00', 0, '09:00:00', '16:00:00', 60),
(2, 1, 1, '08:30:00', '17:30:00', '12:00:00', '13:00:00', 6, '09:00:00', '16:00:00', 60),
(3, 2, 1, '08:30:00', '17:30:00', '12:00:00', '13:00:00', 6, '09:00:00', '16:00:00', 60),
(4, 3, 1, '08:30:00', '17:30:00', '12:00:00', '13:00:00', 6, '09:00:00', '16:00:00', 60),
(5, 4, 1, '08:30:00', '17:30:00', '12:00:00', '13:00:00', 6, '09:00:00', '16:00:00', 60),
(6, 5, 1, '08:30:00', '17:00:00', '12:00:00', '13:00:00', 4, '09:00:00', '15:00:00', 60),
(7, 6, 0, '09:00:00', '17:00:00', '12:00:00', '13:00:00', 0, '09:00:00', '16:00:00', 60);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `applicants`
--
ALTER TABLE `applicants`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `idx_unique_email` (`email`),
  ADD KEY `idx_job_id` (`job_id`),
  ADD KEY `qualification_reviewed_by` (`qualification_reviewed_by`);

--
-- Indexes for table `appraisals`
--
ALTER TABLE `appraisals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_id` (`employee_id`),
  ADD KEY `reviewer_id` (`reviewer_id`),
  ADD KEY `template_id` (`template_id`);

--
-- Indexes for table `appraisal_criteria`
--
ALTER TABLE `appraisal_criteria`
  ADD PRIMARY KEY (`criteria_id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `appraisal_templates`
--
ALTER TABLE `appraisal_templates`
  ADD PRIMARY KEY (`template_id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_employee_date` (`employee_id`,`attendance_date`),
  ADD KEY `marked_by` (`marked_by`);

--
-- Indexes for table `awards`
--
ALTER TABLE `awards`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_id` (`employee_id`),
  ADD KEY `given_by` (`given_by`);

--
-- Indexes for table `award_criteria`
--
ALTER TABLE `award_criteria`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `competencies`
--
ALTER TABLE `competencies`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `dependents`
--
ALTER TABLE `dependents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_id` (`employee_id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `employee_id` (`employee_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `department_id` (`department_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `employee_milestones`
--
ALTER TABLE `employee_milestones`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_employee_milestone` (`employee_id`,`milestone_id`),
  ADD KEY `milestone_id` (`milestone_id`);

--
-- Indexes for table `employment_details`
--
ALTER TABLE `employment_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_id` (`employee_id`);

--
-- Indexes for table `evaluation_criteria`
--
ALTER TABLE `evaluation_criteria`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `evaluation_templates`
--
ALTER TABLE `evaluation_templates`
  ADD PRIMARY KEY (`template_id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `government_ids`
--
ALTER TABLE `government_ids`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `employee_id` (`employee_id`);

--
-- Indexes for table `holidays`
--
ALTER TABLE `holidays`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `holiday_date` (`holiday_date`);

--
-- Indexes for table `hr_users`
--
ALTER TABLE `hr_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `interviews`
--
ALTER TABLE `interviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `applicant_id` (`applicant_id`),
  ADD KEY `scheduled_by` (`scheduled_by`);

--
-- Indexes for table `interview_evaluations`
--
ALTER TABLE `interview_evaluations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `interview_id` (`interview_id`),
  ADD KEY `evaluated_by` (`evaluated_by`);

--
-- Indexes for table `interview_history`
--
ALTER TABLE `interview_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `interview_id` (`interview_id`),
  ADD KEY `action_by` (`action_by`);

--
-- Indexes for table `interview_slots`
--
ALTER TABLE `interview_slots`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_slot` (`slot_date`,`slot_time`);

--
-- Indexes for table `job_postings`
--
ALTER TABLE `job_postings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `job_code` (`job_code`),
  ADD KEY `department_id` (`department_id`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `job_request_id` (`job_request_id`),
  ADD KEY `approved_by` (`approved_by`);

--
-- Indexes for table `job_requests`
--
ALTER TABLE `job_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department_id` (`department_id`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `hiring_manager_id` (`hiring_manager_id`),
  ADD KEY `reviewed_by` (`reviewed_by`),
  ADD KEY `supervisor_approved_by` (`supervisor_approved_by`),
  ADD KEY `management_approved_by` (`management_approved_by`);

--
-- Indexes for table `job_request_competencies`
--
ALTER TABLE `job_request_competencies`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_request_competency` (`job_request_id`,`competency_id`),
  ADD KEY `competency_id` (`competency_id`);

--
-- Indexes for table `onboarding`
--
ALTER TABLE `onboarding`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `employee_id` (`employee_id`),
  ADD KEY `applicant_id` (`applicant_id`),
  ADD KEY `employee_record_id` (`employee_record_id`),
  ADD KEY `interview_id` (`interview_id`);

--
-- Indexes for table `performance_evaluation_details`
--
ALTER TABLE `performance_evaluation_details`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_review_criteria` (`review_id`,`criteria_id`),
  ADD KEY `criteria_id` (`criteria_id`);

--
-- Indexes for table `performance_goals`
--
ALTER TABLE `performance_goals`
  ADD PRIMARY KEY (`goal_id`),
  ADD KEY `employee_id` (`employee_id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `performance_reviews`
--
ALTER TABLE `performance_reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_id` (`employee_id`),
  ADD KEY `reviewer_id` (`reviewer_id`);

--
-- Indexes for table `recognitions`
--
ALTER TABLE `recognitions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_id` (`employee_id`),
  ADD KEY `recognizer_id` (`recognizer_id`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `status` (`status`),
  ADD KEY `recognition_date` (`recognition_date`),
  ADD KEY `idx_employee_status` (`employee_id`,`status`),
  ADD KEY `idx_date_status` (`recognition_date`,`status`);

--
-- Indexes for table `recognition_milestones`
--
ALTER TABLE `recognition_milestones`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `template_criteria`
--
ALTER TABLE `template_criteria`
  ADD PRIMARY KEY (`template_id`,`criteria_id`),
  ADD KEY `criteria_id` (`criteria_id`);

--
-- Indexes for table `training_participants`
--
ALTER TABLE `training_participants`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_training_participant` (`training_id`,`employee_id`),
  ADD KEY `employee_id` (`employee_id`);

--
-- Indexes for table `training_sessions`
--
ALTER TABLE `training_sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department_id` (`department_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `working_hours`
--
ALTER TABLE `working_hours`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `day_of_week` (`day_of_week`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_logs`
--
ALTER TABLE `activity_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `applicants`
--
ALTER TABLE `applicants`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `appraisals`
--
ALTER TABLE `appraisals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `appraisal_criteria`
--
ALTER TABLE `appraisal_criteria`
  MODIFY `criteria_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `appraisal_templates`
--
ALTER TABLE `appraisal_templates`
  MODIFY `template_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `awards`
--
ALTER TABLE `awards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `award_criteria`
--
ALTER TABLE `award_criteria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `competencies`
--
ALTER TABLE `competencies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `dependents`
--
ALTER TABLE `dependents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `employee_milestones`
--
ALTER TABLE `employee_milestones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `employment_details`
--
ALTER TABLE `employment_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `evaluation_criteria`
--
ALTER TABLE `evaluation_criteria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `evaluation_templates`
--
ALTER TABLE `evaluation_templates`
  MODIFY `template_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `government_ids`
--
ALTER TABLE `government_ids`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `holidays`
--
ALTER TABLE `holidays`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `hr_users`
--
ALTER TABLE `hr_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `interviews`
--
ALTER TABLE `interviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `interview_evaluations`
--
ALTER TABLE `interview_evaluations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `interview_history`
--
ALTER TABLE `interview_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `interview_slots`
--
ALTER TABLE `interview_slots`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `job_postings`
--
ALTER TABLE `job_postings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `job_requests`
--
ALTER TABLE `job_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `job_request_competencies`
--
ALTER TABLE `job_request_competencies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `onboarding`
--
ALTER TABLE `onboarding`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `performance_evaluation_details`
--
ALTER TABLE `performance_evaluation_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `performance_goals`
--
ALTER TABLE `performance_goals`
  MODIFY `goal_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `performance_reviews`
--
ALTER TABLE `performance_reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `recognitions`
--
ALTER TABLE `recognitions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `recognition_milestones`
--
ALTER TABLE `recognition_milestones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `training_participants`
--
ALTER TABLE `training_participants`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `training_sessions`
--
ALTER TABLE `training_sessions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `working_hours`
--
ALTER TABLE `working_hours`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD CONSTRAINT `activity_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `applicants`
--
ALTER TABLE `applicants`
  ADD CONSTRAINT `applicants_ibfk_1` FOREIGN KEY (`job_id`) REFERENCES `job_postings` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `applicants_ibfk_2` FOREIGN KEY (`qualification_reviewed_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `appraisals`
--
ALTER TABLE `appraisals`
  ADD CONSTRAINT `appraisals_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`),
  ADD CONSTRAINT `appraisals_ibfk_2` FOREIGN KEY (`reviewer_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `appraisals_ibfk_3` FOREIGN KEY (`template_id`) REFERENCES `appraisal_templates` (`template_id`) ON DELETE SET NULL;

--
-- Constraints for table `appraisal_criteria`
--
ALTER TABLE `appraisal_criteria`
  ADD CONSTRAINT `appraisal_criteria_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `appraisal_templates`
--
ALTER TABLE `appraisal_templates`
  ADD CONSTRAINT `appraisal_templates_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`),
  ADD CONSTRAINT `attendance_ibfk_2` FOREIGN KEY (`marked_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `awards`
--
ALTER TABLE `awards`
  ADD CONSTRAINT `awards_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`),
  ADD CONSTRAINT `awards_ibfk_2` FOREIGN KEY (`given_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `dependents`
--
ALTER TABLE `dependents`
  ADD CONSTRAINT `dependents_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`);

--
-- Constraints for table `employees`
--
ALTER TABLE `employees`
  ADD CONSTRAINT `employees_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  ADD CONSTRAINT `employees_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `employee_milestones`
--
ALTER TABLE `employee_milestones`
  ADD CONSTRAINT `employee_milestones_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `employee_milestones_ibfk_2` FOREIGN KEY (`milestone_id`) REFERENCES `recognition_milestones` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `employment_details`
--
ALTER TABLE `employment_details`
  ADD CONSTRAINT `employment_details_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`);

--
-- Constraints for table `evaluation_templates`
--
ALTER TABLE `evaluation_templates`
  ADD CONSTRAINT `evaluation_templates_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `government_ids`
--
ALTER TABLE `government_ids`
  ADD CONSTRAINT `government_ids_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`);

--
-- Constraints for table `interviews`
--
ALTER TABLE `interviews`
  ADD CONSTRAINT `interviews_ibfk_1` FOREIGN KEY (`applicant_id`) REFERENCES `applicants` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `interviews_ibfk_2` FOREIGN KEY (`scheduled_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `interview_evaluations`
--
ALTER TABLE `interview_evaluations`
  ADD CONSTRAINT `interview_evaluations_ibfk_1` FOREIGN KEY (`interview_id`) REFERENCES `interviews` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `interview_evaluations_ibfk_2` FOREIGN KEY (`evaluated_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `interview_history`
--
ALTER TABLE `interview_history`
  ADD CONSTRAINT `interview_history_ibfk_1` FOREIGN KEY (`interview_id`) REFERENCES `interviews` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `interview_history_ibfk_2` FOREIGN KEY (`action_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `job_postings`
--
ALTER TABLE `job_postings`
  ADD CONSTRAINT `job_postings_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  ADD CONSTRAINT `job_postings_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `job_postings_ibfk_3` FOREIGN KEY (`job_request_id`) REFERENCES `job_requests` (`id`),
  ADD CONSTRAINT `job_postings_ibfk_4` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `job_requests`
--
ALTER TABLE `job_requests`
  ADD CONSTRAINT `job_requests_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  ADD CONSTRAINT `job_requests_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `job_requests_ibfk_3` FOREIGN KEY (`hiring_manager_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `job_requests_ibfk_4` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `job_requests_ibfk_5` FOREIGN KEY (`supervisor_approved_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `job_requests_ibfk_6` FOREIGN KEY (`management_approved_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `job_request_competencies`
--
ALTER TABLE `job_request_competencies`
  ADD CONSTRAINT `job_request_competencies_ibfk_1` FOREIGN KEY (`job_request_id`) REFERENCES `job_requests` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `job_request_competencies_ibfk_2` FOREIGN KEY (`competency_id`) REFERENCES `competencies` (`id`);

--
-- Constraints for table `onboarding`
--
ALTER TABLE `onboarding`
  ADD CONSTRAINT `onboarding_ibfk_1` FOREIGN KEY (`applicant_id`) REFERENCES `applicants` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `onboarding_ibfk_2` FOREIGN KEY (`employee_record_id`) REFERENCES `employees` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `onboarding_ibfk_3` FOREIGN KEY (`interview_id`) REFERENCES `interviews` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `performance_evaluation_details`
--
ALTER TABLE `performance_evaluation_details`
  ADD CONSTRAINT `performance_evaluation_details_ibfk_1` FOREIGN KEY (`review_id`) REFERENCES `performance_reviews` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `performance_evaluation_details_ibfk_2` FOREIGN KEY (`criteria_id`) REFERENCES `evaluation_criteria` (`id`);

--
-- Constraints for table `performance_goals`
--
ALTER TABLE `performance_goals`
  ADD CONSTRAINT `performance_goals_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `performance_goals_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `performance_reviews`
--
ALTER TABLE `performance_reviews`
  ADD CONSTRAINT `performance_reviews_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`),
  ADD CONSTRAINT `performance_reviews_ibfk_2` FOREIGN KEY (`reviewer_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `recognitions`
--
ALTER TABLE `recognitions`
  ADD CONSTRAINT `recognitions_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `recognitions_ibfk_2` FOREIGN KEY (`recognizer_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `recognitions_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `template_criteria`
--
ALTER TABLE `template_criteria`
  ADD CONSTRAINT `template_criteria_ibfk_1` FOREIGN KEY (`template_id`) REFERENCES `evaluation_templates` (`template_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `template_criteria_ibfk_2` FOREIGN KEY (`criteria_id`) REFERENCES `evaluation_criteria` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `training_participants`
--
ALTER TABLE `training_participants`
  ADD CONSTRAINT `training_participants_ibfk_1` FOREIGN KEY (`training_id`) REFERENCES `training_sessions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `training_participants_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`);

--
-- Constraints for table `training_sessions`
--
ALTER TABLE `training_sessions`
  ADD CONSTRAINT `training_sessions_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
