<?php
// File: update_status.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $applicant_id = $_POST['applicant_id'] ?? '';
    $status = $_POST['status'] ?? '';
    $notes = $_POST['notes'] ?? '';
    
    if ($applicant_id && $status) {
        try {
            // Update applicant status
            $update_query = "UPDATE applicants SET application_status = ? WHERE id = ?";
            $update_stmt = $connections->prepare($update_query);
            $update_stmt->execute([$status, $applicant_id]);
            
            // Log the status change (optional)
            $log_query = "INSERT INTO status_changes (applicant_id, changed_by, old_status, new_status, notes) 
                         VALUES (?, ?, ?, ?, ?)";
            $log_stmt = $connections->prepare($log_query);
            $log_stmt->execute([
                $applicant_id, 
                $_SESSION['user_id'] ?? 1, 
                $_POST['old_status'] ?? 'unknown', 
                $status, 
                $notes
            ]);
            
            // Redirect back to applicant view
            header("Location: view_applicant.php?id=$applicant_id&success=1");
            exit();
        } catch (PDOException $e) {
            header("Location: view_applicant.php?id=$applicant_id&error=" . urlencode($e->getMessage()));
            exit();
        }
    } else {
        header("Location: applicants.php");
        exit();
    }
} else {
    header("Location: applicants.php");
    exit();
}
?>