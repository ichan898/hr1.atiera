<?php
// File: edit_employee.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

$id = intval($_GET['id'] ?? 0);

// Get current employee data
try {
    $sql = "SELECT * FROM employees WHERE id = ?";
    $stmt = $connections->prepare($sql);
    $stmt->execute([$id]);
    $employee = $stmt->fetch();
    
    if (!$employee) {
        $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Employee not found'];
        header('Location: employee_list.php');
        exit;
    }
} catch(PDOException $e) {
    error_log("Edit employee error: " . $e->getMessage());
    $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Error loading employee'];
    header('Location: employee_list.php');
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $errors = [];
    
    // Validate required fields
    $required = ['first_name', 'last_name', 'gender', 'department_id', 'email', 'date_of_birth', 'hire_date', 'status'];
    foreach ($required as $field) {
        if (empty($_POST[$field])) {
            $errors[] = ucfirst(str_replace('_', ' ', $field)) . ' is required';
        }
    }
    
    // Validate email
    if (!empty($_POST['email']) && !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Invalid email format';
    }
    
    // If no errors, update employee
    if (empty($errors)) {
        try {
            $sql = "UPDATE employees SET
                first_name = ?,
                middle_name = ?,
                last_name = ?,
                gender = ?,
                department_id = ?,
                email = ?,
                contact_number = ?,
                address = ?,
                date_of_birth = ?,
                hire_date = ?,
                status = ?,
                updated_at = NOW()
                WHERE id = ?";
            
            $stmt = $connections->prepare($sql);
            $stmt->execute([
                sanitizeInput($_POST['first_name']),
                sanitizeInput($_POST['middle_name'] ?? ''),
                sanitizeInput($_POST['last_name']),
                $_POST['gender'],
                $_POST['department_id'],
                sanitizeInput($_POST['email']),
                sanitizeInput($_POST['contact_number'] ?? ''),
                sanitizeInput($_POST['address'] ?? ''),
                $_POST['date_of_birth'],
                $_POST['hire_date'],
                $_POST['status'],
                $id
            ]);
            
            logActivity('employee_updated', 
                "Updated employee: {$_POST['first_name']} {$_POST['last_name']}",
                'employees', 
                $id
            );
            
            $_SESSION['flash_message'] = [
                'type' => 'success',
                'message' => "Employee updated successfully!"
            ];
            
            header('Location: view_employee.php?id=' . $id);
            exit;
            
        } catch(PDOException $e) {
            $errors[] = 'Database error: ' . $e->getMessage();
            error_log("Update employee error: " . $e->getMessage());
        }
    }
}

// Get departments
try {
    $stmt = $connections->query("SELECT id, name FROM departments ORDER BY name");
    $departments = $stmt->fetchAll();
} catch(PDOException $e) {
    $departments = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit Employee: <?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?></title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="bg-gray-50">
<div class="min-h-screen flex">
    <?php include 'sidebar.php'; ?>
    <div class="flex-1 p-6">
        <div class="max-w-4xl mx-auto">
            <div class="mb-6">
                <h1 class="text-2xl font-bold">Edit Employee</h1>
                <a href="view_employee.php?id=<?php echo $employee['id']; ?>" class="text-blue-600 hover:text-blue-800">← Back to Employee Details</a>
            </div>
            
            <?php if (!empty($errors)): ?>
                <div class="mb-4 p-4 bg-red-50 border border-red-200 rounded">
                    <h3 class="text-red-800 font-semibold">Please fix the following errors:</h3>
                    <ul class="list-disc list-inside mt-2">
                        <?php foreach ($errors as $error): ?>
                            <li class="text-red-600"><?php echo $error; ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <form method="POST" class="bg-white rounded-lg shadow p-6">
                <div class="grid md:grid-cols-2 gap-6">
                    <div>
                        <label class="block text-sm font-medium mb-2">First Name *</label>
                        <input type="text" name="first_name" required 
                               value="<?php echo htmlspecialchars($employee['first_name']); ?>"
                               class="w-full p-2 border rounded">
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-2">Last Name *</label>
                        <input type="text" name="last_name" required 
                               value="<?php echo htmlspecialchars($employee['last_name']); ?>"
                               class="w-full p-2 border rounded">
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-2">Gender *</label>
                        <select name="gender" required class="w-full p-2 border rounded">
                            <option value="">Select</option>
                            <option value="Male" <?php echo $employee['gender'] == 'Male' ? 'selected' : ''; ?>>Male</option>
                            <option value="Female" <?php echo $employee['gender'] == 'Female' ? 'selected' : ''; ?>>Female</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-2">Department *</label>
                        <select name="department_id" required class="w-full p-2 border rounded">
                            <option value="">Select Department</option>
                            <?php foreach ($departments as $dept): ?>
                                <option value="<?php echo $dept['id']; ?>"
                                    <?php echo $employee['department_id'] == $dept['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($dept['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-2">Email *</label>
                        <input type="email" name="email" required 
                               value="<?php echo htmlspecialchars($employee['email']); ?>"
                               class="w-full p-2 border rounded">
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-2">Date of Birth *</label>
                        <input type="date" name="date_of_birth" required 
                               value="<?php echo $employee['date_of_birth']; ?>"
                               class="w-full p-2 border rounded">
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-2">Hire Date *</label>
                        <input type="date" name="hire_date" required 
                               value="<?php echo $employee['hire_date']; ?>"
                               class="w-full p-2 border rounded">
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-2">Status *</label>
                        <select name="status" required class="w-full p-2 border rounded">
                            <option value="Active" <?php echo $employee['status'] == 'Active' ? 'selected' : ''; ?>>Active</option>
                            <option value="Inactive" <?php echo $employee['status'] == 'Inactive' ? 'selected' : ''; ?>>Inactive</option>
                            <option value="On Leave" <?php echo $employee['status'] == 'On Leave' ? 'selected' : ''; ?>>On Leave</option>
                            <option value="Terminated" <?php echo $employee['status'] == 'Terminated' ? 'selected' : ''; ?>>Terminated</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-2">Contact Number</label>
                        <input type="tel" name="contact_number" 
                               value="<?php echo htmlspecialchars($employee['contact_number'] ?? ''); ?>"
                               class="w-full p-2 border rounded">
                    </div>
                </div>
                
                <div class="mt-6">
                    <label class="block text-sm font-medium mb-2">Address</label>
                    <textarea name="address" rows="3" class="w-full p-2 border rounded"><?php echo htmlspecialchars($employee['address'] ?? ''); ?></textarea>
                </div>
                
                <div class="mt-8 flex justify-between items-center">
                    <div>
                        <span class="text-gray-600">Employee ID: <?php echo $employee['employee_id']; ?></span>
                    </div>
                    <div class="flex space-x-4">
                        <a href="view_employee.php?id=<?php echo $employee['id']; ?>" 
                           class="px-6 py-2 border rounded hover:bg-gray-50">Cancel</a>
                        <button type="submit" class="px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Save Changes</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<script>lucide.createIcons();</script>
</body>
</html>