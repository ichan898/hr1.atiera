<?php
// File: job_postings.php
session_start();
require_once 'connections.php';
require_once 'functions.php'; // Include functions instead
requireAuth(); // This will work now

// Get job postings
$status = $_GET['status'] ?? 'active';
$query = "SELECT * FROM job_postings WHERE 1=1";
$params = [];

if ($status && $status != 'all') {
    $query .= " AND status = ?";
    $params[] = $status;
}

$query .= " ORDER BY created_at DESC";

$stmt = $connections->prepare($query);
$stmt->execute($params);
$job_postings = $stmt->fetchAll();

// Get stats
$stats_stmt = $connections->prepare("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
        SUM(CASE WHEN status = 'closed' THEN 1 ELSE 0 END) as closed,
        SUM(CASE WHEN status = 'draft' THEN 1 ELSE 0 END) as draft
    FROM job_postings
");
$stats_stmt->execute();
$stats = $stats_stmt->fetch();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>HR1 - Job Postings</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
</head>

<body class="h-screen bg-gray-100 font-sans">
<div class="flex h-full">
  
  <!-- Sidebar -->
  <?php include 'user_sidebar.php'; ?>
  
  <!-- Main Content -->
  <div class="flex-1 flex flex-col overflow-y-auto">
    <main class="p-6 space-y-6">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-gray-300 pb-4">
        <div>
          <h2 class="text-2xl font-bold text-gray-800">Job Postings</h2>
          <p class="text-sm text-gray-600">Manage published job openings</p>
        </div>
        <div class="flex items-center space-x-4">
          
          <?php include 'user_profile_dropdown.php'; ?>
        </div>
      </div>

      <!-- Stats -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div class="bg-white p-6 rounded-lg shadow border">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-600">Total Postings</p>
              <p class="text-2xl font-bold text-gray-800"><?php echo $stats['total']; ?></p>
            </div>
            <i data-lucide="briefcase" class="w-8 h-8 text-blue-500"></i>
          </div>
        </div>
        
        <div class="bg-white p-6 rounded-lg shadow border">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-600">Active</p>
              <p class="text-2xl font-bold text-gray-800"><?php echo $stats['active']; ?></p>
            </div>
            <i data-lucide="activity" class="w-8 h-8 text-green-500"></i>
          </div>
        </div>
        
        <div class="bg-white p-6 rounded-lg shadow border">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-600">Draft</p>
              <p class="text-2xl font-bold text-gray-800"><?php echo $stats['draft']; ?></p>
            </div>
            <i data-lucide="edit" class="w-8 h-8 text-yellow-500"></i>
          </div>
        </div>
        
        <div class="bg-white p-6 rounded-lg shadow border">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-600">Closed</p>
              <p class="text-2xl font-bold text-gray-800"><?php echo $stats['closed']; ?></p>
            </div>
            <i data-lucide="archive" class="w-8 h-8 text-gray-500"></i>
          </div>
        </div>
      </div>

      <!-- Tabs -->
      <div class="bg-white rounded-lg shadow">
        <div class="border-b">
          <nav class="flex -mb-px">
            <a href="?status=active" class="py-4 px-6 border-b-2 font-medium text-sm 
              <?php echo $status == 'active' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'; ?>">
              Active (<?php echo $stats['active']; ?>)
            </a>
            <a href="?status=draft" class="py-4 px-6 border-b-2 font-medium text-sm 
              <?php echo $status == 'draft' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'; ?>">
              Draft (<?php echo $stats['draft']; ?>)
            </a>
            <a href="?status=closed" class="py-4 px-6 border-b-2 font-medium text-sm 
              <?php echo $status == 'closed' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'; ?>">
              Closed (<?php echo $stats['closed']; ?>)
            </a>
            <a href="?status=all" class="py-4 px-6 border-b-2 font-medium text-sm 
              <?php echo $status == 'all' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'; ?>">
              All
            </a>
          </nav>
        </div>

        <!-- Job Postings Table -->
        <div class="overflow-x-auto">
          <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
              <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Job Title</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Department</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Posted Date</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Applications</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
              <?php foreach($job_postings as $posting): 
                // Get application count
                $app_stmt = $connections->prepare("SELECT COUNT(*) as count FROM applicants WHERE job_id = ?");
                $app_stmt->execute([$posting['id']]);
                $app_count = $app_stmt->fetch()['count'];
              ?>
              <tr class="hover:bg-gray-50">
                <td class="px-6 py-4">
                  <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($posting['job_title']); ?></div>
                  <div class="text-sm text-gray-500">Ref: <?php echo $posting['job_code']; ?></div>
                </td>
                <td class="px-6 py-4 text-sm text-gray-900"><?php echo htmlspecialchars($posting['department']); ?></td>
                <td class="px-6 py-4 text-sm text-gray-500"><?php echo date('M d, Y', strtotime($posting['created_at'])); ?></td>
                <td class="px-6 py-4">
                  <span class="px-3 py-1 text-sm bg-blue-100 text-blue-800 rounded-full">
                    <?php echo $app_count; ?> applicants
                  </span>
                </td>
                <td class="px-6 py-4">
                  <span class="px-3 py-1 text-xs rounded-full 
                    <?php echo $posting['status'] == 'active' ? 'bg-green-100 text-green-800' : 
                           ($posting['status'] == 'draft' ? 'bg-yellow-100 text-yellow-800' : 
                           'bg-gray-100 text-gray-800'); ?>">
                    <?php echo ucfirst($posting['status']); ?>
                  </span>
                </td>
                <td class="px-6 py-4">
                  <div class="flex space-x-2">
                    <a href="user_view_posting.php?id=<?php echo $posting['id']; ?>" 
                       class="px-3 py-1 text-sm bg-gray-100 rounded hover:bg-gray-200">
                      <i data-lucide="eye" class="w-4 h-4"></i>
                    </a>
                    <a href="user_edit_posting.php?id=<?php echo $posting['id']; ?>" 
                       class="px-3 py-1 text-sm bg-blue-100 text-blue-700 rounded hover:bg-blue-200">
                      <i data-lucide="edit" class="w-4 h-4"></i>
                    </a>
                    <?php if($posting['status'] == 'active'): ?>
                    <a href="user_close_posting.php?id=<?php echo $posting['id']; ?>" 
                       class="px-3 py-1 text-sm bg-red-100 text-red-700 rounded hover:bg-red-200">
                      <i data-lucide="archive" class="w-4 h-4"></i>
                    </a>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
          
          <?php if(empty($job_postings)): ?>
          <div class="text-center py-12">
            <i data-lucide="briefcase" class="w-12 h-12 text-gray-400 mx-auto mb-4"></i>
            <p class="text-gray-500">No job postings found</p>
            <a href="user_new_job_posting.php" class="mt-2 inline-block text-blue-600 hover:underline">
              Create your first job posting
            </a>
          </div>
          <?php endif; ?>
        </div>
      </div>
    </main>
  </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
  lucide.createIcons();
});
</script>
</body>
</html>