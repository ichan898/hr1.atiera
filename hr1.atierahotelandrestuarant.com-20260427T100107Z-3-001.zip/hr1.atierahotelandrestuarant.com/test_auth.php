<?php
// test_auth.php - Simulate what admin_dashboard.php checks
session_start();
require_once 'functions.php';

echo "<h2>Dashboard Authentication Test</h2>";

// Simulate the check in requireAuth() function
if (!isset($_SESSION['user_id'])) {
    echo "<p style='color:red'>✗ FAIL: user_id not set in session</p>";
} else {
    echo "<p style='color:green'>✓ user_id is set: {$_SESSION['user_id']}</p>";
}

if (!isset($_SESSION['otp_verified'])) {
    echo "<p style='color:red'>✗ FAIL: otp_verified not set in session</p>";
} elseif ($_SESSION['otp_verified'] !== true) {
    echo "<p style='color:red'>✗ FAIL: otp_verified is not true (value: {$_SESSION['otp_verified']})</p>";
} else {
    echo "<p style='color:green'>✓ otp_verified is true</p>";
}

// Check if both conditions pass
if (isset($_SESSION['user_id']) && isset($_SESSION['otp_verified']) && $_SESSION['otp_verified'] === true) {
    echo "<p style='color:green; font-size:18px'>✅ AUTHENTICATION WOULD PASS! You would be allowed into admin_dashboard.php.</p>";
    echo "<p>Session would allow access. If you are still redirected to login, the problem is elsewhere (maybe the dashboard file has a different check or output before session_start).</p>";
} else {
    echo "<p style='color:red'>❌ AUTHENTICATION WOULD FAIL. Redirect to login would happen.</p>";
    echo "<p>Check why session variables are missing. Possible causes:</p>";
    echo "<ul>";
    echo "<li>Session not persisting between requests (check session.save_path permissions)</li>";
    echo "<li>Output before session_start() in connections.php or email_functions.php</li>";
    echo "<li>Cookie domain/path mismatch</li>";
    echo "<li>Session was destroyed somewhere</li>";
    echo "</ul>";
}

echo "<hr><h3>Full Session:</h3>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";
?>