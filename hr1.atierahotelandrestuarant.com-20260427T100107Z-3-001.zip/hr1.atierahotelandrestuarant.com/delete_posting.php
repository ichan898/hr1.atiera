<?php
// File: delete_posting.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

$id = $_GET['id'] ?? null;
if (!$id) {
    header('Location: job_postings.php');
    exit();
}

// Check if posting exists
$stmt = $connections->prepare("SELECT * FROM job_postings WHERE id = ?");
$stmt->execute([$id]);
$posting = $stmt->fetch();

if (!$posting) {
    header('Location: job_postings.php?error=notfound');
    exit();
}

// Delete the posting
$stmt = $connections->prepare("DELETE FROM job_postings WHERE id = ?");
$stmt->execute([$id]);

header('Location: job_postings.php?success=deleted');
exit();
?>