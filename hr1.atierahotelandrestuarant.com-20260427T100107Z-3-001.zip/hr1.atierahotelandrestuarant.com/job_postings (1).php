<?php
// File: job_postings.php
session_start();
require_once 'connections.php';
require_once 'functions.php'; // Include functions instead
requireAuth(); // This will work now

// Get job postings
$status = $_GET['status'] ?? 'active';
$query = "SELECT * FROM job_postings WHERE 1=1";
$params = [];

if ($status && $status != 'all') {
    $query .= " AND status = ?";
    $params[] = $status;
}

$query .= " ORDER BY created_at DESC";

$stmt = $connections->prepare($query);
$stmt->execute($params);
$job_postings = $stmt->fetchAll();

// Get stats
$stats_stmt = $connections->prepare("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
        SUM(CASE WHEN status = 'closed' THEN 1 ELSE 0 END) as closed,
        SUM(CASE WHEN status = 'draft' THEN 1 ELSE 0 END) as draft
    FROM job_postings
");
$stats_stmt->execute();
$stats = $stats_stmt->fetch();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover, user-scalable=yes">
<title>HR1 - Job Postings | Responsive Dashboard</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<style>
    /* Responsive customizations - preserves sidebar while making layout mobile-friendly */
    * {
        -webkit-tap-highlight-color: transparent;
    }
    
    /* On mobile, switch main layout to column so sidebar appears above content */
    @media (max-width: 768px) {
        .flex.h-full {
            flex-direction: column;
        }
        /* Make sidebar take full width on mobile */
        .flex.h-full > div:first-child {
            width: 100% !important;
            flex-shrink: 0;
        }
        /* Adjust main content padding */
        main {
            padding: 1rem !important;
        }
        /* Stats grid becomes 2 columns on small screens */
        .stats-grid {
            grid-template-columns: repeat(2, 1fr) !important;
            gap: 0.75rem !important;
        }
        /* Make stats cards more compact */
        .stats-card {
            padding: 0.75rem !important;
        }
        .stats-card p.text-sm {
            font-size: 0.7rem;
        }
        .stats-card .text-2xl {
            font-size: 1.25rem !important;
        }
        .stats-card i {
            width: 1.5rem;
            height: 1.5rem;
        }
        /* Adjust tab buttons for small screens */
        .tab-btn {
            padding: 0.5rem 0.75rem !important;
            font-size: 0.75rem !important;
        }
        /* Table cell padding reduce */
        td, th {
            padding: 0.5rem 0.75rem !important;
        }
        /* Action buttons touch friendly */
        .action-btn {
            padding: 0.4rem 0.6rem !important;
        }
        .action-btn i {
            width: 1rem;
            height: 1rem;
        }
    }
    
    /* For tablets and up, ensure sidebar has reasonable width */
    @media (min-width: 769px) {
        .flex.h-full > div:first-child {
            flex-shrink: 0;
            width: auto; /* sidebar.php should define its width */
        }
    }
    
    /* Horizontal scroll for table wrapper */
    .table-wrapper {
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
        scrollbar-width: thin;
    }
    
    /* Touch-friendly hover effects */
    .action-btn, .tab-btn, .stats-card, .new-job-btn {
        transition: all 0.2s ease;
    }
    .action-btn:active, .tab-btn:active, .new-job-btn:active {
        transform: scale(0.96);
    }
    
    /* Ensure sidebar links are readable on mobile (if sidebar uses flex column) */
    @media (max-width: 768px) {
        .sidebar-nav a, .sidebar-menu li {
            padding: 0.5rem 0.75rem !important;
        }
    }
    
    /* Custom scrollbar for table */
    .table-wrapper::-webkit-scrollbar {
        height: 6px;
    }
    .table-wrapper::-webkit-scrollbar-track {
        background: #f1f1f1;
        border-radius: 10px;
    }
    .table-wrapper::-webkit-scrollbar-thumb {
        background: #cbd5e1;
        border-radius: 10px;
    }
    
    /* Keep original sidebar styles intact but improve responsiveness */
    /* Any existing sidebar classes will be overridden only for small screens */
</style>
</head>

<body class="h-screen bg-gray-100 font-sans antialiased overflow-hidden">
<div class="flex h-full w-full">
  
  <!-- Sidebar (unchanged, external include) - will stack on mobile -->
  <?php include 'sidebar.php'; ?>
  
  <!-- Main Content - fully responsive -->
  <div class="flex-1 flex flex-col overflow-y-auto">
    <main class="p-4 md:p-6 space-y-4 md:space-y-6">
      
      <!-- Header with responsive wrap -->
      <div class="flex flex-wrap items-center justify-between gap-3 border-b border-gray-300 pb-4">
        <div>
          <h2 class="text-xl md:text-2xl font-bold text-gray-800">Job Postings</h2>
          <p class="text-xs md:text-sm text-gray-600">Manage published job openings & track applicants</p>
        </div>
        <div class="flex items-center gap-3">
          <!--<a href="new_job_posting.php" class="new-job-btn inline-flex items-center gap-2 px-3 py-2 md:px-4 md:py-2 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 transition shadow-sm whitespace-nowrap">-->
          <!--  <i data-lucide="plus" class="w-4 h-4"></i>-->
          <!--  <span>New Job Posting</span>-->
          <!--</a>-->
          <?php include 'profile_dropdown.php'; ?>
        </div>
      </div>

      <!-- Stats Cards - responsive grid (2 columns on mobile, 4 on desktop) -->
      <div class="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-6 stats-grid">
        <div class="stats-card bg-white p-4 md:p-6 rounded-xl shadow-sm border border-gray-100 transition hover:shadow-md">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-xs md:text-sm text-gray-600 font-medium">Total Postings</p>
              <p class="text-xl md:text-2xl font-bold text-gray-800 mt-1"><?php echo $stats['total']; ?></p>
            </div>
            <i data-lucide="briefcase" class="w-6 h-6 md:w-8 md:h-8 text-blue-500 opacity-80"></i>
          </div>
        </div>
        
        <div class="stats-card bg-white p-4 md:p-6 rounded-xl shadow-sm border border-gray-100 transition hover:shadow-md">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-xs md:text-sm text-gray-600 font-medium">Active</p>
              <p class="text-xl md:text-2xl font-bold text-gray-800 mt-1"><?php echo $stats['active']; ?></p>
            </div>
            <i data-lucide="activity" class="w-6 h-6 md:w-8 md:h-8 text-green-500 opacity-80"></i>
          </div>
        </div>
        
        <div class="stats-card bg-white p-4 md:p-6 rounded-xl shadow-sm border border-gray-100 transition hover:shadow-md">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-xs md:text-sm text-gray-600 font-medium">Draft</p>
              <p class="text-xl md:text-2xl font-bold text-gray-800 mt-1"><?php echo $stats['draft']; ?></p>
            </div>
            <i data-lucide="edit" class="w-6 h-6 md:w-8 md:h-8 text-amber-500 opacity-80"></i>
          </div>
        </div>
        
        <div class="stats-card bg-white p-4 md:p-6 rounded-xl shadow-sm border border-gray-100 transition hover:shadow-md">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-xs md:text-sm text-gray-600 font-medium">Closed</p>
              <p class="text-xl md:text-2xl font-bold text-gray-800 mt-1"><?php echo $stats['closed']; ?></p>
            </div>
            <i data-lucide="archive" class="w-6 h-6 md:w-8 md:h-8 text-gray-500 opacity-80"></i>
          </div>
        </div>
      </div>

      <!-- Job Postings Card with Tabs and Table -->
      <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        
        <!-- Tabs - horizontally scrollable on mobile -->
        <div class="border-b border-gray-200 overflow-x-auto scrollbar-thin">
          <nav class="flex flex-nowrap whitespace-nowrap -mb-px min-w-full">
            <a href="?status=active" class="tab-btn py-3 md:py-4 px-4 md:px-6 border-b-2 font-medium text-sm transition duration-150 
              <?php echo $status == 'active' ? 'border-blue-600 text-blue-700 bg-blue-50/30' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'; ?>">
              Active <span class="ml-1 text-xs font-normal">(<?php echo $stats['active']; ?>)</span>
            </a>
            <a href="?status=draft" class="tab-btn py-3 md:py-4 px-4 md:px-6 border-b-2 font-medium text-sm transition duration-150 
              <?php echo $status == 'draft' ? 'border-blue-600 text-blue-700 bg-blue-50/30' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'; ?>">
              Draft <span class="ml-1 text-xs font-normal">(<?php echo $stats['draft']; ?>)</span>
            </a>
            <a href="?status=closed" class="tab-btn py-3 md:py-4 px-4 md:px-6 border-b-2 font-medium text-sm transition duration-150 
              <?php echo $status == 'closed' ? 'border-blue-600 text-blue-700 bg-blue-50/30' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'; ?>">
              Closed <span class="ml-1 text-xs font-normal">(<?php echo $stats['closed']; ?>)</span>
            </a>
            <a href="?status=all" class="tab-btn py-3 md:py-4 px-4 md:px-6 border-b-2 font-medium text-sm transition duration-150 
              <?php echo $status == 'all' ? 'border-blue-600 text-blue-700 bg-blue-50/30' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'; ?>">
              All
            </a>
          </nav>
        </div>

        <!-- Table container with horizontal scroll -->
        <div class="table-wrapper">
          <table class="min-w-[700px] md:min-w-full w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
              <tr>
                <th scope="col" class="px-4 py-3 md:px-6 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Job Title</th>
                <th scope="col" class="px-4 py-3 md:px-6 text-left text-xs font-medium text-gray-500 uppercase tracking-wider hidden sm:table-cell">Department</th>
                <th scope="col" class="px-4 py-3 md:px-6 text-left text-xs font-medium text-gray-500 uppercase tracking-wider hidden md:table-cell">Posted Date</th>
                <th scope="col" class="px-4 py-3 md:px-6 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Applications</th>
                <th scope="col" class="px-4 py-3 md:px-6 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th scope="col" class="px-4 py-3 md:px-6 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
              <?php foreach($job_postings as $posting): 
                // Get application count
                $app_stmt = $connections->prepare("SELECT COUNT(*) as count FROM applicants WHERE job_id = ?");
                $app_stmt->execute([$posting['id']]);
                $app_count = $app_stmt->fetch()['count'];
              ?>
              <tr class="hover:bg-gray-50 transition">
                <td class="px-4 py-3 md:px-6 align-top">
                  <div class="text-sm font-semibold text-gray-900"><?php echo htmlspecialchars($posting['job_title']); ?></div>
                  <div class="text-xs text-gray-500 mt-0.5">Ref: <?php echo htmlspecialchars($posting['job_code']); ?></div>
                  <!-- Show department and date on mobile for better context -->
                  <div class="text-xs text-gray-500 mt-1 sm:hidden">Dept: <?php echo htmlspecialchars($posting['department']); ?></div>
                  <div class="text-xs text-gray-400 mt-1 md:hidden">Posted: <?php echo date('M d, Y', strtotime($posting['created_at'])); ?></div>
                </td>
                <td class="px-4 py-3 md:px-6 text-sm text-gray-700 hidden sm:table-cell align-middle"><?php echo htmlspecialchars($posting['department']); ?></td>
                <td class="px-4 py-3 md:px-6 text-sm text-gray-500 whitespace-nowrap hidden md:table-cell align-middle"><?php echo date('M d, Y', strtotime($posting['created_at'])); ?></td>
                <td class="px-4 py-3 md:px-6 align-middle">
                  <span class="inline-flex items-center px-2.5 py-0.5 md:px-3 md:py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                    <?php echo $app_count; ?> applicant<?php echo $app_count != 1 ? 's' : ''; ?>
                  </span>
                </td>
                <td class="px-4 py-3 md:px-6 align-middle">
                  <span class="inline-flex px-2.5 py-0.5 md:px-3 md:py-1 text-xs font-semibold rounded-full 
                    <?php echo $posting['status'] == 'active' ? 'bg-green-100 text-green-800' : 
                           ($posting['status'] == 'draft' ? 'bg-yellow-100 text-yellow-800' : 
                           'bg-gray-100 text-gray-700'); ?>">
                    <?php echo ucfirst($posting['status']); ?>
                  </span>
                </td>
                <td class="px-4 py-3 md:px-6 align-middle">
                  <div class="flex items-center gap-2">
                    <a href="view_posting.php?id=<?php echo $posting['id']; ?>" 
                       class="action-btn inline-flex items-center justify-center p-1.5 md:p-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition active:scale-95" 
                       title="View details">
                      <i data-lucide="eye" class="w-4 h-4"></i>
                    </a>
                    <a href="edit_posting.php?id=<?php echo $posting['id']; ?>" 
                       class="action-btn inline-flex items-center justify-center p-1.5 md:p-2 bg-blue-50 text-blue-700 rounded-lg hover:bg-blue-100 transition active:scale-95" 
                       title="Edit posting">
                      <i data-lucide="edit" class="w-4 h-4"></i>
                    </a>
                    <?php if($posting['status'] == 'active'): ?>
                    <a href="close_posting.php?id=<?php echo $posting['id']; ?>" 
                       class="action-btn inline-flex items-center justify-center p-1.5 md:p-2 bg-red-50 text-red-700 rounded-lg hover:bg-red-100 transition active:scale-95" 
                       title="Close posting">
                      <i data-lucide="archive" class="w-4 h-4"></i>
                    </a>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
           </table>
          
          <?php if(empty($job_postings)): ?>
          <div class="text-center py-12 md:py-16 px-4">
            <i data-lucide="briefcase" class="w-12 h-12 md:w-16 md:h-16 text-gray-300 mx-auto mb-4"></i>
            <p class="text-gray-500 text-sm md:text-base">No job postings found</p>
            <a href="new_job_posting.php" class="mt-3 inline-flex items-center gap-1 text-blue-600 hover:text-blue-800 text-sm md:text-base font-medium">
              Create your first job posting <i data-lucide="arrow-right" class="w-4 h-4"></i>
            </a>
          </div>
          <?php endif; ?>
        </div>
        
        <!-- Mobile hint for horizontal scroll (only visible on small screens) -->
        <div class="text-center text-xs text-gray-400 py-2 md:hidden">
          ← Scroll table sideways →
        </div>
      </div>
    </main>
  </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
  // Initialize Lucide icons
  if (typeof lucide !== 'undefined') {
    lucide.createIcons();
  }
  
  // Optional: enhance touch feedback for action buttons
  const actionBtns = document.querySelectorAll('.action-btn');
  actionBtns.forEach(btn => {
    btn.addEventListener('touchstart', function() {
      this.style.transform = 'scale(0.96)';
    }, { passive: true });
    btn.addEventListener('touchend', function() {
      this.style.transform = '';
    });
    btn.addEventListener('touchcancel', function() {
      this.style.transform = '';
    });
  });
});
</script>
</body>
</html>