<?php
/* =========================
   HEADERS + PREFLIGHT
========================= */
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

/* =========================
   DATABASE (PDO)
========================= */
require_once __DIR__ . "/../connections.php";

if (!isset($connections) || !($connections instanceof PDO)) {
    http_response_code(500);
    echo json_encode(["error" => "PDO database connection not available"]);
    exit;
}

$db = $connections;
$method = $_SERVER['REQUEST_METHOD'];

/* =========================
   RESUME CONFIG
========================= */
$baseResumePath = "uploads/resumes/";

$resumeMap = [
    0 => "1768422300_VERGARA_Resume.pdf", // 1st
    1 => "COSTIBOLO_Resume.pdf",          // 2nd
    2 => "REVILLA_Resume.pdf"             // 3rd
];

$defaultResume = "1768422300_VERGARA_Resume.pdf";

/* =========================
   ROUTES
========================= */
switch ($method) {

    /* =========================
       GET (ALL / SINGLE)
    ========================== */
    case 'GET':

        // SINGLE RECORD
        if (!empty($_GET['id'])) {
            $stmt = $db->prepare("SELECT * FROM onboarding WHERE id = ? LIMIT 1");
            $stmt->execute([intval($_GET['id'])]);
            $onboarding = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$onboarding) {
                echo json_encode([]);
                exit;
            }

            $onboarding['resume'] = $baseResumePath . $defaultResume;

            echo json_encode([
                "onboarding" => $onboarding,
                "employee" => false,
                "employment_details" => [],
                "government_ids" => [],
                "dependents" => []
            ]);
            break;
        }

        // ALL RECORDS
        $stmt = $db->query("SELECT * FROM onboarding ORDER BY created_at DESC");
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $result = [];
        foreach ($rows as $index => $row) {
            $resumeFile = $resumeMap[$index] ?? $defaultResume;

            $row['resume'] = $baseResumePath . $resumeFile;

            $result[] = [
                "onboarding" => $row,
                "employee" => false,
                "employment_details" => [],
                "government_ids" => [],
                "dependents" => []
            ];
        }

        echo json_encode($result, JSON_PRETTY_PRINT);
        break;

    /* =========================
       POST (CREATE)
    ========================== */
    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);

        if (!$data) {
            http_response_code(400);
            echo json_encode(["error" => "Invalid JSON"]);
            exit;
        }

        $stmt = $db->prepare(
            "INSERT INTO onboarding (
                employee_id, job_position, first_name, middle_name, last_name,
                email, contact_number, address, date_of_birth, hire_date,
                status, resume, created_at, updated_at
            ) VALUES (
                :employee_id, :job_position, :first_name, :middle_name, :last_name,
                :email, :contact_number, :address, :date_of_birth, :hire_date,
                :status, :resume, NOW(), NOW()
            )"
        );

        $stmt->execute([
            ":employee_id"    => $data['employee_id'],
            ":job_position"   => $data['job_position'],
            ":first_name"     => $data['first_name'],
            ":middle_name"    => $data['middle_name'] ?? null,
            ":last_name"      => $data['last_name'],
            ":email"          => $data['email'],
            ":contact_number" => $data['contact_number'],
            ":address"        => $data['address'],
            ":date_of_birth"  => $data['date_of_birth'],
            ":hire_date"      => $data['hire_date'],
            ":status"         => $data['status'],
            ":resume"         => $defaultResume
        ]);

        echo json_encode([
            "success" => true,
            "id" => $db->lastInsertId()
        ]);
        break;

    /* =========================
       PUT (UPDATE)
    ========================== */
    case 'PUT':
        parse_str($_SERVER['QUERY_STRING'], $query);
        $id = intval($query['id'] ?? 0);
        $data = json_decode(file_get_contents("php://input"), true);

        if (!$id || !$data) {
            http_response_code(400);
            echo json_encode(["error" => "Missing id or data"]);
            exit;
        }

        $stmt = $db->prepare(
            "UPDATE onboarding SET
                employee_id = :employee_id,
                job_position = :job_position,
                first_name = :first_name,
                middle_name = :middle_name,
                last_name = :last_name,
                email = :email,
                contact_number = :contact_number,
                address = :address,
                date_of_birth = :date_of_birth,
                hire_date = :hire_date,
                status = :status,
                resume = :resume,
                updated_at = NOW()
            WHERE id = :id"
        );

        $stmt->execute([
            ":employee_id"    => $data['employee_id'],
            ":job_position"   => $data['job_position'],
            ":first_name"     => $data['first_name'],
            ":middle_name"    => $data['middle_name'] ?? null,
            ":last_name"      => $data['last_name'],
            ":email"          => $data['email'],
            ":contact_number" => $data['contact_number'],
            ":address"        => $data['address'],
            ":date_of_birth"  => $data['date_of_birth'],
            ":hire_date"      => $data['hire_date'],
            ":status"         => $data['status'],
            ":resume"         => $data['resume'] ?? $defaultResume,
            ":id"             => $id
        ]);

        echo json_encode(["success" => true]);
        break;

    /* =========================
       DELETE
    ========================== */
    case 'DELETE':
        parse_str($_SERVER['QUERY_STRING'], $query);
        $id = intval($query['id'] ?? 0);

        if (!$id) {
            http_response_code(400);
            echo json_encode(["error" => "Missing id"]);
            exit;
        }

        $stmt = $db->prepare("DELETE FROM onboarding WHERE id = ?");
        $stmt->execute([$id]);

        echo json_encode(["success" => true]);
        break;

    default:
        http_response_code(405);
        echo json_encode(["error" => "Method not allowed"]);
}
