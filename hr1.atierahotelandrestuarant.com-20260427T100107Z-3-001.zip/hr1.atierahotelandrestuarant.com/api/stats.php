<?php
require_once '../connections.php';

// recruitment_stats.php
header('Content-Type: application/json');

try {
    // Total job requests
    $stmt1 = $connections->prepare("
        SELECT COUNT(*) as total_requests,
               SUM(CASE WHEN overall_status = 'approved' THEN 1 ELSE 0 END) as approved_requests,
               SUM(CASE WHEN overall_status = 'pending' THEN 1 ELSE 0 END) as pending_requests,
               SUM(CASE WHEN overall_status = 'rejected' THEN 1 ELSE 0 END) as rejected_requests
        FROM job_requests
        WHERE is_active = TRUE
    ");
    $stmt1->execute();
    $requests = $stmt1->fetch();
    
    // Job postings
    $stmt2 = $connections->prepare("
        SELECT COUNT(*) as total_postings,
               SUM(CASE WHEN status = 'open' THEN 1 ELSE 0 END) as open_jobs,
               SUM(CASE WHEN status = 'closed' THEN 1 ELSE 0 END) as closed_jobs
        FROM job_postings
    ");
    $stmt2->execute();
    $postings = $stmt2->fetch();
    
    // Applicants
    $stmt3 = $connections->prepare("
        SELECT COUNT(*) as total_applicants,
               SUM(CASE WHEN application_status = 'new' THEN 1 ELSE 0 END) as new_applicants,
               SUM(CASE WHEN application_status = 'shortlisted' THEN 1 ELSE 0 END) as shortlisted,
               SUM(CASE WHEN application_status = 'hired' THEN 1 ELSE 0 END) as hired_applicants,
               SUM(CASE WHEN application_status = 'rejected' THEN 1 ELSE 0 END) as rejected_applicants
        FROM applicants
    ");
    $stmt3->execute();
    $applicants = $stmt3->fetch();
    
    // Pending actions
    $stmt4 = $connections->prepare("
        SELECT 
            (SELECT COUNT(*) FROM job_requests WHERE overall_status = 'pending') as pending_approvals,
            (SELECT COUNT(*) FROM applicants WHERE application_status IN ('new', 'qualified')) as pending_screening,
            (SELECT COUNT(*) FROM interviews WHERE status = 'scheduled' AND scheduled_date >= CURDATE()) as upcoming_interviews,
            (SELECT COUNT(*) FROM job_offers WHERE offer_status = 'pending') as pending_offers
    ");
    $stmt4->execute();
    $actions = $stmt4->fetch();
    
    // Time-based stats (last 30 days)
    $stmt5 = $connections->prepare("
        SELECT 
            DATE(created_at) as date,
            COUNT(*) as applications
        FROM applicants
        WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
        GROUP BY DATE(created_at)
        ORDER BY date
    ");
    $stmt5->execute();
    $trends = $stmt5->fetchAll();
    
    echo json_encode([
        'status' => 'success',
        'data' => [
            'requests' => $requests,
            'postings' => $postings,
            'applicants' => $applicants,
            'actions' => $actions,
            'trends' => $trends,
            'summary' => [
                'total_jobs' => $postings['total_postings'],
                'open_jobs' => $postings['open_jobs'],
                'closed_jobs' => $postings['closed_jobs'],
                'total_applications' => $applicants['total_applicants'],
                'hire_rate' => $applicants['total_applicants'] > 0 ? 
                    round(($applicants['hired_applicants'] / $applicants['total_applicants']) * 100, 2) : 0
            ]
        ]
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?>