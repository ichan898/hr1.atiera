<?php
/* =========================
   HEADERS & CORS
========================= */
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

/* =========================
   DATABASE (PDO)
========================= */
require_once __DIR__ . "/../connections.php";

if (!isset($connections) || !($connections instanceof PDO)) {
    http_response_code(500);
    echo json_encode(["error" => "PDO database connection not available"]);
    exit;
}

$db = $connections;
$method = $_SERVER['REQUEST_METHOD'];

/* =========================
   ROUTER
========================= */
switch ($method) {

    /* =========================
       GET (ALL / BY ID)
    ========================== */
    case 'GET':
        if (!empty($_GET['department_id'])) {
            $stmt = $db->prepare(
                "SELECT department_id, department_name
                 FROM job_departments
                 WHERE department_id = ?"
            );
            $stmt->execute([intval($_GET['department_id'])]);
            echo json_encode($stmt->fetch() ?: []);
        } else {
            $stmt = $db->query(
                "SELECT department_id, department_name
                 FROM job_departments
                 ORDER BY department_name ASC"
            );
            echo json_encode($stmt->fetchAll());
        }
        break;

    /* =========================
       POST (CREATE)
    ========================== */
    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);

        if (!$data || empty($data['department_name'])) {
            http_response_code(400);
            echo json_encode(["error" => "department_name is required"]);
            exit;
        }

        $stmt = $db->prepare(
            "INSERT INTO job_departments (department_name)
             VALUES (:department_name)"
        );

        $stmt->execute([
            ":department_name" => $data['department_name']
        ]);

        echo json_encode([
            "success" => true,
            "department_id" => $db->lastInsertId()
        ]);
        break;

    /* =========================
       PUT (UPDATE)
    ========================== */
    case 'PUT':
        parse_str($_SERVER['QUERY_STRING'], $query);
        $department_id = intval($query['department_id'] ?? 0);
        $data = json_decode(file_get_contents("php://input"), true);

        if (!$department_id || empty($data['department_name'])) {
            http_response_code(400);
            echo json_encode([
                "error" => "Missing department_id or department_name"
            ]);
            exit;
        }

        $stmt = $db->prepare(
            "UPDATE job_departments
             SET department_name = :department_name
             WHERE department_id = :department_id"
        );

        $stmt->execute([
            ":department_name" => $data['department_name'],
            ":department_id"   => $department_id
        ]);

        echo json_encode(["success" => true]);
        break;

    /* =========================
       DELETE
    ========================== */
    case 'DELETE':
        parse_str($_SERVER['QUERY_STRING'], $query);
        $department_id = intval($query['department_id'] ?? 0);

        if (!$department_id) {
            http_response_code(400);
            echo json_encode(["error" => "Missing department_id"]);
            exit;
        }

        $stmt = $db->prepare(
            "DELETE FROM job_departments WHERE department_id = ?"
        );
        $stmt->execute([$department_id]);

        echo json_encode(["success" => true]);
        break;

    default:
        http_response_code(405);
        echo json_encode(["error" => "Method not allowed"]);
}
