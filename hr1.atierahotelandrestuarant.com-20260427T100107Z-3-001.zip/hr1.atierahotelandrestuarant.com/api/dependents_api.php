<?php
/* =========================
   HEADERS + PREFLIGHT
========================= */
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

/* =========================
   DATABASE (PDO)
========================= */
require_once __DIR__ . "/../connections.php";

if (!isset($connections) || !($connections instanceof PDO)) {
    http_response_code(500);
    echo json_encode(["error" => "PDO database connection not available"]);
    exit;
}

$db = $connections;

/* =========================
   REQUEST METHOD
========================= */
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {

    /* =========================
       GET – ALL / BY ID / BY EMPLOYEE
    ========================== */
    case 'GET':
        if (!empty($_GET['id'])) {
            // Single dependent
            $stmt = $db->prepare(
                "SELECT * FROM dependents WHERE id = ?"
            );
            $stmt->execute([intval($_GET['id'])]);
            echo json_encode($stmt->fetch() ?: []);
        } elseif (!empty($_GET['employee_id'])) {
            // All dependents of an employee
            $stmt = $db->prepare(
                "SELECT * FROM dependents WHERE employee_id = ?"
            );
            $stmt->execute([$_GET['employee_id']]);
            echo json_encode($stmt->fetchAll());
        } else {
            // All dependents
            $stmt = $db->query(
                "SELECT * FROM dependents ORDER BY id DESC"
            );
            echo json_encode($stmt->fetchAll());
        }
        break;

    /* =========================
       POST – CREATE
    ========================== */
    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);

        if (!$data) {
            http_response_code(400);
            echo json_encode(["error" => "Invalid JSON"]);
            exit;
        }

        /* Optional rule:
           Allow only ONE beneficiary per employee
           Uncomment if needed
        */
        /*
        if (!empty($data['is_beneficiary'])) {
            $check = $db->prepare(
                "SELECT COUNT(*) FROM dependents
                 WHERE employee_id = ? AND is_beneficiary = 1"
            );
            $check->execute([$data['employee_id']]);
            if ($check->fetchColumn() > 0) {
                http_response_code(409);
                echo json_encode([
                    "error" => "Employee already has a beneficiary"
                ]);
                exit;
            }
        }
        */

        $stmt = $db->prepare(
            "INSERT INTO dependents (
                employee_id, full_name, relationship,
                date_of_birth, is_beneficiary
            ) VALUES (
                :employee_id, :full_name, :relationship,
                :date_of_birth, :is_beneficiary
            )"
        );

        $stmt->execute([
            ":employee_id"   => $data['employee_id'],
            ":full_name"     => $data['full_name'],
            ":relationship"  => $data['relationship'],
            ":date_of_birth" => $data['date_of_birth'],
            ":is_beneficiary"=> (int)$data['is_beneficiary']
        ]);

        echo json_encode([
            "success" => true,
            "id" => $db->lastInsertId()
        ]);
        break;

    /* =========================
       PUT – UPDATE
    ========================== */
    case 'PUT':
        parse_str($_SERVER['QUERY_STRING'], $query);
        $id = intval($query['id'] ?? 0);
        $data = json_decode(file_get_contents("php://input"), true);

        if (!$id || !$data) {
            http_response_code(400);
            echo json_encode(["error" => "Missing id or data"]);
            exit;
        }

        $stmt = $db->prepare(
            "UPDATE dependents SET
                employee_id = :employee_id,
                full_name = :full_name,
                relationship = :relationship,
                date_of_birth = :date_of_birth,
                is_beneficiary = :is_beneficiary
             WHERE id = :id"
        );

        $stmt->execute([
            ":employee_id"   => $data['employee_id'],
            ":full_name"     => $data['full_name'],
            ":relationship"  => $data['relationship'],
            ":date_of_birth" => $data['date_of_birth'],
            ":is_beneficiary"=> (int)$data['is_beneficiary'],
            ":id"            => $id
        ]);

        echo json_encode(["success" => true]);
        break;

    /* =========================
       DELETE
    ========================== */
    case 'DELETE':
        parse_str($_SERVER['QUERY_STRING'], $query);
        $id = intval($query['id'] ?? 0);

        if (!$id) {
            http_response_code(400);
            echo json_encode(["error" => "Missing id"]);
            exit;
        }

        $stmt = $db->prepare(
            "DELETE FROM dependents WHERE id = ?"
        );
        $stmt->execute([$id]);

        echo json_encode(["success" => true]);
        break;

    default:
        http_response_code(405);
        echo json_encode(["error" => "Method not allowed"]);
}
