<?php
/* =========================
   HEADERS & CORS
========================= */
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

/* =========================
   DATABASE (PDO)
========================= */
require_once __DIR__ . "/../connections.php";

if (!isset($connections) || !($connections instanceof PDO)) {
    http_response_code(500);
    echo json_encode(["error" => "PDO database connection not available"]);
    exit;
}

$db = $connections;
$method = $_SERVER['REQUEST_METHOD'];

/* =========================
   ROUTING
========================= */
$type = $_GET['type'] ?? 'employees';

switch ($type) {

    /* =====================================================
       EMPLOYEES + NESTED EMPLOYMENT DETAILS
    ===================================================== */
    case 'employees':
        switch ($method) {

            case 'GET':

                /* ===== BY INTERNAL ID ===== */
                if (!empty($_GET['id'])) {
                    $stmt = $db->prepare("
                        SELECT e.*, d.name AS department_name
                        FROM employees e
                        LEFT JOIN departments d ON e.department_id = d.id
                        WHERE e.id = ?
                    ");
                    $stmt->execute([intval($_GET['id'])]);
                    $employee = $stmt->fetch(PDO::FETCH_ASSOC);

                    if ($employee) {
                        $stmt2 = $db->prepare("
                            SELECT *
                            FROM employment_details
                            WHERE employee_id = ?
                        ");
                        $stmt2->execute([$employee['id']]);
                        $employee['employment_details'] = $stmt2->fetch(PDO::FETCH_ASSOC) ?: null;
                    }

                    echo json_encode($employee ?: []);
                    exit;
                }

                /* ===== BY PUBLIC EMPLOYEE ID (EMNxxxx) ===== */
                if (!empty($_GET['employee_id'])) {
                    $stmt = $db->prepare("
                        SELECT e.*, d.name AS department_name
                        FROM employees e
                        LEFT JOIN departments d ON e.department_id = d.id
                        WHERE e.employee_id = ?
                    ");
                    $stmt->execute([$_GET['employee_id']]);
                    $employee = $stmt->fetch(PDO::FETCH_ASSOC);

                    if ($employee) {
                        $stmt2 = $db->prepare("
                            SELECT *
                            FROM employment_details
                            WHERE employee_id = ?
                        ");
                        $stmt2->execute([$employee['id']]);
                        $employee['employment_details'] = $stmt2->fetch(PDO::FETCH_ASSOC) ?: null;
                    }

                    echo json_encode($employee ?: []);
                    exit;
                }

                /* ===== ALL EMPLOYEES ===== */
                $stmt = $db->query("
                    SELECT e.*, d.name AS department_name
                    FROM employees e
                    LEFT JOIN departments d ON e.department_id = d.id
                    ORDER BY e.created_at DESC
                ");

                $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);

                foreach ($employees as &$emp) {
                    $stmt2 = $db->prepare("
                        SELECT *
                        FROM employment_details
                        WHERE employee_id = ?
                    ");
                    $stmt2->execute([$emp['id']]);
                    $emp['employment_details'] = $stmt2->fetch(PDO::FETCH_ASSOC) ?: null;
                }

                echo json_encode($employees);
                break;

            case 'POST':
                $data = json_decode(file_get_contents("php://input"), true);
                if (!$data) {
                    http_response_code(400);
                    echo json_encode(["error" => "Invalid JSON"]);
                    exit;
                }

                $stmt = $db->prepare("
                    INSERT INTO employees (
                        employee_id, first_name, middle_name, last_name, gender,
                        department_id, email, contact_number, address,
                        date_of_birth, hire_date, status, created_at, updated_at
                    ) VALUES (
                        :employee_id, :first_name, :middle_name, :last_name, :gender,
                        :department_id, :email, :contact_number, :address,
                        :date_of_birth, :hire_date, :status, NOW(), NOW()
                    )
                ");

                $stmt->execute([
                    ":employee_id"    => $data['employee_id'],
                    ":first_name"     => $data['first_name'],
                    ":middle_name"    => $data['middle_name'] ?? null,
                    ":last_name"      => $data['last_name'],
                    ":gender"         => $data['gender'],
                    ":department_id"  => $data['department_id'],
                    ":email"          => $data['email'],
                    ":contact_number" => $data['contact_number'],
                    ":address"        => $data['address'],
                    ":date_of_birth"  => $data['date_of_birth'],
                    ":hire_date"      => $data['hire_date'],
                    ":status"         => $data['status']
                ]);

                echo json_encode(["success" => true, "id" => $db->lastInsertId()]);
                break;

            case 'PUT':
                parse_str($_SERVER['QUERY_STRING'], $query);
                $id = intval($query['id'] ?? 0);
                $data = json_decode(file_get_contents("php://input"), true);

                if (!$id || !$data) {
                    http_response_code(400);
                    echo json_encode(["error" => "Missing id or data"]);
                    exit;
                }

                $stmt = $db->prepare("
                    UPDATE employees SET
                        employee_id = :employee_id,
                        first_name = :first_name,
                        middle_name = :middle_name,
                        last_name = :last_name,
                        gender = :gender,
                        department_id = :department_id,
                        email = :email,
                        contact_number = :contact_number,
                        address = :address,
                        date_of_birth = :date_of_birth,
                        hire_date = :hire_date,
                        status = :status,
                        updated_at = NOW()
                    WHERE id = :id
                ");

                $stmt->execute([
                    ":employee_id"    => $data['employee_id'],
                    ":first_name"     => $data['first_name'],
                    ":middle_name"    => $data['middle_name'] ?? null,
                    ":last_name"      => $data['last_name'],
                    ":gender"         => $data['gender'],
                    ":department_id"  => $data['department_id'],
                    ":email"          => $data['email'],
                    ":contact_number" => $data['contact_number'],
                    ":address"        => $data['address'],
                    ":date_of_birth"  => $data['date_of_birth'],
                    ":hire_date"      => $data['hire_date'],
                    ":status"         => $data['status'],
                    ":id"             => $id
                ]);

                echo json_encode(["success" => true]);
                break;

            case 'DELETE':
                parse_str($_SERVER['QUERY_STRING'], $query);
                $id = intval($query['id'] ?? 0);

                if (!$id) {
                    http_response_code(400);
                    echo json_encode(["error" => "Missing id"]);
                    exit;
                }

                $stmt = $db->prepare("DELETE FROM employees WHERE id = ?");
                $stmt->execute([$id]);

                echo json_encode(["success" => true]);
                break;
        }
        break;

    /* =====================================================
       DEPARTMENTS (REPLACED job_departments)
    ===================================================== */
    case 'departments':
        if ($method === 'GET') {
            $stmt = $db->query("SELECT id, name FROM departments ORDER BY name ASC");
            echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
        }
        break;

    /* =====================================================
       EMPLOYMENT DETAILS
    ===================================================== */
    case 'employment_details':
        switch ($method) {

            case 'GET':
                if (!empty($_GET['employee_id'])) {
                    $stmt = $db->prepare("
                        SELECT *
                        FROM employment_details
                        WHERE employee_id = ?
                    ");
                    $stmt->execute([intval($_GET['employee_id'])]);
                    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
                    exit;
                }

                $stmt = $db->query("SELECT * FROM employment_details ORDER BY id DESC");
                echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
                break;

            case 'POST':
                $data = json_decode(file_get_contents("php://input"), true);
                if (!$data) {
                    http_response_code(400);
                    echo json_encode(["error" => "Invalid JSON"]);
                    exit;
                }

                $stmt = $db->prepare("
                    INSERT INTO employment_details (
                        employee_id, employment_type, job_title,
                        basic_salary, salary_type, probation_end
                    ) VALUES (
                        :employee_id, :employment_type, :job_title,
                        :basic_salary, :salary_type, :probation_end
                    )
                ");

                $stmt->execute([
                    ":employee_id"     => $data['employee_id'], // employees.id
                    ":employment_type" => $data['employment_type'],
                    ":job_title"       => $data['job_title'],
                    ":basic_salary"    => $data['basic_salary'],
                    ":salary_type"     => $data['salary_type'],
                    ":probation_end"   => $data['probation_end']
                ]);

                echo json_encode(["success" => true, "id" => $db->lastInsertId()]);
                break;

            case 'DELETE':
                parse_str($_SERVER['QUERY_STRING'], $query);
                $id = intval($query['id'] ?? 0);

                if (!$id) {
                    http_response_code(400);
                    echo json_encode(["error" => "Missing id"]);
                    exit;
                }

                $stmt = $db->prepare("DELETE FROM employment_details WHERE id = ?");
                $stmt->execute([$id]);

                echo json_encode(["success" => true]);
                break;
        }
        break;

    default:
        http_response_code(400);
        echo json_encode(["error" => "Invalid type parameter"]);
}
