<?php
require_once '../connections.php';

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'POST':
        requireAuth();
        
        $data = json_decode(file_get_contents('php://input'), true);
        
        try {
            // Verify job request is approved
            $checkStmt = $connections->prepare("
                SELECT id FROM job_requests 
                WHERE id = ? AND overall_status = 'approved'
            ");
            $checkStmt->execute([$data['job_request_id']]);
            
            if (!$checkStmt->fetch()) {
                throw new Exception('Job request not approved');
            }
            
            $connections->beginTransaction();
            
            // Create job posting
            $stmt = $connections->prepare("
                INSERT INTO job_postings (
                    job_request_id, job_title, description, employment_type,
                    vacancies, salary_per_hour, salary_weekly, salary_bi_monthly,
                    salary_monthly, possible_benefits, expected_hours_per_week,
                    status, posted_by, posted_on
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'draft', ?, ?)
            ");
            
            $stmt->execute([
                $data['job_request_id'],
                sanitizeInput($data['job_title']),
                sanitizeInput($data['description']),
                sanitizeInput($data['employment_type'] ?? 'Full-time'),
                (int)$data['vacancies'],
                $data['salary_per_hour'] ?? null,
                $data['salary_weekly'] ?? null,
                $data['salary_bi_monthly'] ?? null,
                $data['salary_monthly'] ?? null,
                sanitizeInput($data['possible_benefits'] ?? ''),
                (int)$data['expected_hours_per_week'] ?? 40,
                $_SESSION['user_name'],
                date('Y-m-d')
            ]);
            
            $postingId = $connections->lastInsertId();
            
            // Update job request step
            $updateStmt = $connections->prepare("
                UPDATE job_requests SET current_step = 4 WHERE id = ?
            ");
            $updateStmt->execute([$data['job_request_id']]);
            
            // Track process
            $trackStmt = $connections->prepare("
                INSERT INTO recruitment_process_tracking 
                (job_request_id, job_posting_id, step_number, step_name, status, performed_by)
                VALUES (?, ?, 4, 'Job Requisition Created', 'completed', ?)
            ");
            $trackStmt->execute([$data['job_request_id'], $postingId, $_SESSION['user_name']]);
            
            $connections->commit();
            
            echo json_encode([
                'status' => 'success',
                'message' => 'Job posting created',
                'posting_id' => $postingId
            ]);
            
        } catch (Exception $e) {
            $connections->rollBack();
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;
        
    case 'PUT':
        requireAuth();
        
        $id = $_GET['id'] ?? null;
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!$id) {
            http_response_code(400);
            echo json_encode(['error' => 'Posting ID required']);
            exit;
        }
        
        $updates = [];
        $params = [];
        
        if (isset($data['status'])) {
            $updates[] = "status = ?";
            $params[] = $data['status'];
            
            if ($data['status'] == 'open') {
                $updates[] = "posted_on = ?";
                $params[] = date('Y-m-d');
                
                // Update posting platforms
                if (isset($data['platforms'])) {
                    $platforms = $data['platforms'];
                    $updates[] = "posted_company_website = ?";
                    $params[] = in_array('website', $platforms) ? 1 : 0;
                    
                    $updates[] = "posted_job_portals = ?";
                    $params[] = in_array('portals', $platforms) ? 1 : 0;
                    
                    $updates[] = "posted_social_media = ?";
                    $params[] = in_array('social', $platforms) ? 1 : 0;
                    
                    $updates[] = "posted_internal = ?";
                    $params[] = in_array('internal', $platforms) ? 1 : 0;
                }
                
                // Get job request ID for tracking
                $getReqStmt = $connections->prepare("
                    SELECT job_request_id FROM job_postings WHERE id = ?
                ");
                $getReqStmt->execute([$id]);
                $result = $getReqStmt->fetch();
                
                if ($result) {
                    // Update job request step
                    $updateStepStmt = $connections->prepare("
                        UPDATE job_requests SET current_step = 5 WHERE id = ?
                    ");
                    $updateStepStmt->execute([$result['job_request_id']]);
                    
                    // Track process
                    $trackStmt = $connections->prepare("
                        INSERT INTO recruitment_process_tracking 
                        (job_request_id, job_posting_id, step_number, step_name, status, performed_by)
                        VALUES (?, ?, 5, 'Job Posted', 'completed', ?)
                    ");
                    $trackStmt->execute([$result['job_request_id'], $id, $_SESSION['user_name']]);
                }
            }
        }
        
        if (isset($data['filled_positions'])) {
            $updates[] = "filled_positions = ?";
            $params[] = (int)$data['filled_positions'];
        }
        
        if (empty($updates)) {
            http_response_code(400);
            echo json_encode(['error' => 'No updates provided']);
            exit;
        }
        
        $params[] = $id;
        $query = "UPDATE job_postings SET " . implode(', ', $updates) . " WHERE id = ?";
        
        $stmt = $connections->prepare($query);
        $stmt->execute($params);
        
        echo json_encode([
            'status' => 'success',
            'message' => 'Job posting updated'
        ]);
        break;
        
    case 'GET':
        // Public endpoint for landing page
        if (isset($_GET['public'])) {
            $stmt = $connections->prepare("
                SELECT * FROM v_public_job_postings 
                WHERE status = 'open'
                ORDER BY posted_on DESC
            ");
            $stmt->execute();
            $jobs = $stmt->fetchAll();
            
            echo json_encode(['data' => $jobs]);
            exit;
        }
        
        requireAuth();
        
        $status = $_GET['status'] ?? null;
        $query = "SELECT jp.*, jr.department, jr.position_title as requested_position 
                 FROM job_postings jp 
                 JOIN job_requests jr ON jp.job_request_id = jr.id";
        
        $params = [];
        if ($status) {
            $query .= " WHERE jp.status = ?";
            $params[] = $status;
        }
        
        $query .= " ORDER BY jp.created_at DESC";
        
        $stmt = $connections->prepare($query);
        $stmt->execute($params);
        $postings = $stmt->fetchAll();
        
        echo json_encode(['data' => $postings]);
        break;
}
?>