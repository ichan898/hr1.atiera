<?php
/* =========================
   HEADERS + CORS
========================= */
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

/* =========================
   DATABASE CONNECTION
========================= */
require_once __DIR__ . "/../connections.php";

if (!isset($connections) || !($connections instanceof PDO)) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed"]);
    exit;
}

$db = $connections;
$method = $_SERVER['REQUEST_METHOD'];

/* =========================
   ROUTER
========================= */
$type = $_GET['type'] ?? 'employees';

switch ($type) {

    /* =========================================================
       EMPLOYEES (GET ONLY)
    ========================================================= */
    case 'employees':

        if ($method !== 'GET') {
            http_response_code(405);
            echo json_encode(["error" => "Only GET method allowed"]);
            exit;
        }

        $employee_id = $_GET['employee_id'] ?? null;
        $id = $_GET['id'] ?? null;

        /* =========================
           MAIN EMPLOYEE QUERY
        ========================= */
        if ($employee_id) {

            $stmt = $db->prepare(
                "SELECT 
                    e.*,
                    d.name AS department_name
                 FROM employees e
                 LEFT JOIN departments d ON e.department_id = d.id
                 WHERE e.employee_id = ?"
            );
            $stmt->execute([$employee_id]);

        } elseif ($id) {

            $stmt = $db->prepare(
                "SELECT 
                    e.*,
                    d.name AS department_name
                 FROM employees e
                 LEFT JOIN departments d ON e.department_id = d.id
                 WHERE e.id = ?"
            );
            $stmt->execute([$id]);

        } else {

            $stmt = $db->query(
                "SELECT 
                    e.*,
                    d.name AS department_name
                 FROM employees e
                 LEFT JOIN departments d ON e.department_id = d.id
                 ORDER BY e.created_at DESC"
            );
        }

        $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (($employee_id || $id) && !empty($employees)) {
            $employees = [$employees[0]];
        }

        $result = [];

        foreach ($employees as $emp) {

            $employeeDbId = $emp['id']; // INTERNAL FK
            $employeePublicId = $emp['employee_id']; // EMNxxxx

            /* =========================
               EMPLOYMENT DETAILS
            ========================= */
            $stmt = $db->prepare(
                "SELECT 
                    ed.employment_type,
                    ed.job_title,
                    d.name AS department_name,
                    ed.basic_salary,
                    ed.salary_type,
                    ed.probation_end
                 FROM employment_details ed
                 JOIN employees e ON ed.employee_id = e.id
                 LEFT JOIN departments d ON e.department_id = d.id
                 WHERE e.id = ?"
            );
            $stmt->execute([$employeeDbId]);
            $employment = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;

            /* =========================
               GOVERNMENT IDS
            ========================= */
            $stmt = $db->prepare(
                "SELECT 
                    sss_number,
                    pagibig_number,
                    philhealth_number,
                    tin_number
                 FROM government_ids
                 WHERE employee_id = ?"
            );
            $stmt->execute([$employeeDbId]);
            $gov_ids = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;

            /* =========================
               DEPENDENTS
            ========================= */
            $stmt = $db->prepare(
                "SELECT 
                    id,
                    full_name,
                    relationship,
                    date_of_birth,
                    is_beneficiary
                 FROM dependents
                 WHERE employee_id = ?
                 ORDER BY id ASC"
            );
            $stmt->execute([$employeeDbId]);
            $dependents = $stmt->fetchAll(PDO::FETCH_ASSOC);

            /* =========================
               COMBINE RESPONSE
            ========================= */
            $emp['employment_details'] = $employment;
            $emp['government_ids'] = $gov_ids;
            $emp['dependents'] = $dependents;

            $result[] = $emp;
        }

        echo json_encode($result, JSON_PRETTY_PRINT);
        break;

    /* =========================================================
       INVALID TYPE
    ========================================================= */
    default:
        http_response_code(400);
        echo json_encode([
            "error" => "Invalid type parameter",
            "allowed" => ["employees"]
        ]);
        break;
}
