<?php
/* =========================
   HEADERS + PREFLIGHT
========================= */
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

/* =========================
   DATABASE (PDO)
========================= */
require_once __DIR__ . "/../connections.php";

if (!isset($connections) || !($connections instanceof PDO)) {
    http_response_code(500);
    echo json_encode(["error" => "PDO database connection not available"]);
    exit;
}

$db = $connections;

/* =========================
   REQUEST METHOD
========================= */
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {

    /* =========================
       GET – ALL / BY ID / BY EMPLOYEE
    ========================== */
    case 'GET':
        if (!empty($_GET['id'])) {
            $stmt = $db->prepare(
                "SELECT * FROM government_ids WHERE id = ?"
            );
            $stmt->execute([intval($_GET['id'])]);
            echo json_encode($stmt->fetch() ?: []);
        } elseif (!empty($_GET['employee_id'])) {
            $stmt = $db->prepare(
                "SELECT * FROM government_ids WHERE employee_id = ?"
            );
            $stmt->execute([$_GET['employee_id']]);
            echo json_encode($stmt->fetchAll());
        } else {
            $stmt = $db->query(
                "SELECT * FROM government_ids ORDER BY id DESC"
            );
            echo json_encode($stmt->fetchAll());
        }
        break;

    /* =========================
       POST – CREATE
    ========================== */
    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);

        if (!$data) {
            http_response_code(400);
            echo json_encode(["error" => "Invalid JSON"]);
            exit;
        }

        $stmt = $db->prepare(
            "INSERT INTO government_ids (
                employee_id, sss_number, pagibig_number, philhealth_number, tin_number, created_at
            ) VALUES (
                :employee_id, :sss_number, :pagibig_number, :philhealth_number, :tin_number, NOW()
            )"
        );

        $stmt->execute([
            ":employee_id"      => $data['employee_id'],
            ":sss_number"       => $data['sss_number'],
            ":pagibig_number"   => $data['pagibig_number'],
            ":philhealth_number"=> $data['philhealth_number'],
            ":tin_number"       => $data['tin_number']
        ]);

        echo json_encode([
            "success" => true,
            "id" => $db->lastInsertId()
        ]);
        break;

    /* =========================
       PUT – UPDATE
    ========================== */
    case 'PUT':
        parse_str($_SERVER['QUERY_STRING'], $query);
        $id = intval($query['id'] ?? 0);
        $data = json_decode(file_get_contents("php://input"), true);

        if (!$id || !$data) {
            http_response_code(400);
            echo json_encode(["error" => "Missing id or data"]);
            exit;
        }

        $stmt = $db->prepare(
            "UPDATE government_ids SET
                employee_id = :employee_id,
                sss_number = :sss_number,
                pagibig_number = :pagibig_number,
                philhealth_number = :philhealth_number,
                tin_number = :tin_number
             WHERE id = :id"
        );

        $stmt->execute([
            ":employee_id"      => $data['employee_id'],
            ":sss_number"       => $data['sss_number'],
            ":pagibig_number"   => $data['pagibig_number'],
            ":philhealth_number"=> $data['philhealth_number'],
            ":tin_number"       => $data['tin_number'],
            ":id"               => $id
        ]);

        echo json_encode(["success" => true]);
        break;

    /* =========================
       DELETE
    ========================== */
    case 'DELETE':
        parse_str($_SERVER['QUERY_STRING'], $query);
        $id = intval($query['id'] ?? 0);

        if (!$id) {
            http_response_code(400);
            echo json_encode(["error" => "Missing id"]);
            exit;
        }

        $stmt = $db->prepare(
            "DELETE FROM government_ids WHERE id = ?"
        );
        $stmt->execute([$id]);

        echo json_encode(["success" => true]);
        break;

    default:
        http_response_code(405);
        echo json_encode(["error" => "Method not allowed"]);
}
