<?php
require_once '../connections.php';

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'POST':
        requireAuth();
        $data = json_decode(file_get_contents('php://input'), true);
        
        try {
            $connections->beginTransaction();
            
            // STEP 10: Create job offer for selected candidate
            $stmt = $connections->prepare("
                INSERT INTO job_offers (
                    applicant_id, offer_date, salary_offer, benefits_offer,
                    start_date, expiration_date, offer_status
                ) VALUES (?, ?, ?, ?, ?, ?, 'pending')
            ");
            
            $offerDate = date('Y-m-d');
            $expirationDate = date('Y-m-d', strtotime('+7 days'));
            
            $stmt->execute([
                $data['applicant_id'],
                $offerDate,
                $data['salary_offer'],
                json_encode($data['benefits_offer'] ?? []),
                $data['start_date'],
                $expirationDate
            ]);
            
            $offerId = $connections->lastInsertId();
            
            // Update applicant status
            $updateApplicantStmt = $connections->prepare("
                UPDATE applicants SET application_status = 'for_offer'
                WHERE id = ?
            ");
            $updateApplicantStmt->execute([$data['applicant_id']]);
            
            // Get job info for tracking
            $getInfoStmt = $connections->prepare("
                SELECT a.job_posting_id, jp.job_request_id, 
                       jp.vacancies, jp.filled_positions
                FROM applicants a
                JOIN job_postings jp ON a.job_posting_id = jp.id
                WHERE a.id = ?
            ");
            $getInfoStmt->execute([$data['applicant_id']]);
            $info = $getInfoStmt->fetch();
            
            if ($info) {
                // Update job request step
                $updateStepStmt = $connections->prepare("
                    UPDATE job_requests SET current_step = 10 WHERE id = ?
                ");
                $updateStepStmt->execute([$info['job_request_id']]);
                
                // Track process
                $trackStmt = $connections->prepare("
                    INSERT INTO recruitment_process_tracking 
                    (job_request_id, job_posting_id, applicant_id, 
                     step_number, step_name, status, performed_by)
                    VALUES (?, ?, ?, 10, 'Job Offer Prepared', 'completed', ?)
                ");
                $trackStmt->execute([
                    $info['job_request_id'],
                    $info['job_posting_id'],
                    $data['applicant_id'],
                    $_SESSION['user_name']
                ]);
            }
            
            $connections->commit();
            
            echo json_encode([
                'status' => 'success',
                'message' => 'Job offer created successfully',
                'offer_id' => $offerId
            ]);
            
        } catch (Exception $e) {
            $connections->rollBack();
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;
        
    case 'PUT':
        requireAuth();
        
        $id = $_GET['id'] ?? null;
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!$id) {
            http_response_code(400);
            echo json_encode(['error' => 'Offer ID required']);
            exit;
        }
        
        try {
            $connections->beginTransaction();
            
            $updates = [];
            $params = [];
            
            if (isset($data['offer_status'])) {
                $updates[] = "offer_status = ?";
                $params[] = $data['offer_status'];
                
                if ($data['offer_status'] == 'sent') {
                    $updates[] = "sent_date = NOW()";
                    // Send offer letter email
                    sendOfferLetter($id);
                    
                    // Get applicant info for tracking
                    $getApplicantStmt = $connections->prepare("
                        SELECT jo.applicant_id, a.job_posting_id, jp.job_request_id
                        FROM job_offers jo
                        JOIN applicants a ON jo.applicant_id = a.id
                        JOIN job_postings jp ON a.job_posting_id = jp.id
                        WHERE jo.id = ?
                    ");
                    $getApplicantStmt->execute([$id]);
                    $appInfo = $getApplicantStmt->fetch();
                    
                    if ($appInfo) {
                        // Update job request step
                        $updateStepStmt = $connections->prepare("
                            UPDATE job_requests SET current_step = 11 WHERE id = ?
                        ");
                        $updateStepStmt->execute([$appInfo['job_request_id']]);
                        
                        // Track process
                        $trackStmt = $connections->prepare("
                            INSERT INTO recruitment_process_tracking 
                            (job_request_id, job_posting_id, applicant_id, 
                             step_number, step_name, status, performed_by)
                            VALUES (?, ?, ?, 11, 'Job Offer Sent', 'completed', ?)
                        ");
                        $trackStmt->execute([
                            $appInfo['job_request_id'],
                            $appInfo['job_posting_id'],
                            $appInfo['applicant_id'],
                            $_SESSION['user_name']
                        ]);
                    }
                }
                
                if ($data['offer_status'] == 'accepted') {
                    $updates[] = "accepted_date = NOW()";
                    
                    // Update applicant to hired
                    $updateAppStmt = $connections->prepare("
                        UPDATE applicants a
                        JOIN job_offers jo ON a.id = jo.applicant_id
                        SET a.application_status = 'hired'
                        WHERE jo.id = ?
                    ");
                    $updateAppStmt->execute([$id]);
                    
                    // Increment filled positions
                    $incFilledStmt = $connections->prepare("
                        UPDATE job_postings jp
                        JOIN applicants a ON jp.id = a.job_posting_id
                        JOIN job_offers jo ON a.id = jo.applicant_id
                        SET jp.filled_positions = jp.filled_positions + 1
                        WHERE jo.id = ?
                    ");
                    $incFilledStmt->execute([$id]);
                    
                    // Get job info for tracking
                    $getJobStmt = $connections->prepare("
                        SELECT jo.applicant_id, a.job_posting_id, jp.job_request_id
                        FROM job_offers jo
                        JOIN applicants a ON jo.applicant_id = a.id
                        JOIN job_postings jp ON a.job_posting_id = jp.id
                        WHERE jo.id = ?
                    ");
                    $getJobStmt->execute([$id]);
                    $jobInfo = $getJobStmt->fetch();
                    
                    if ($jobInfo) {
                        // Update job request step
                        $updateStepStmt = $connections->prepare("
                            UPDATE job_requests SET current_step = 12 WHERE id = ?
                        ");
                        $updateStepStmt->execute([$jobInfo['job_request_id']]);
                        
                        // Track process
                        $trackStmt = $connections->prepare("
                            INSERT INTO recruitment_process_tracking 
                            (job_request_id, job_posting_id, applicant_id, 
                             step_number, step_name, status, performed_by)
                            VALUES (?, ?, ?, 12, 'Candidate Hired', 'completed', ?)
                        ");
                        $trackStmt->execute([
                            $jobInfo['job_request_id'],
                            $jobInfo['job_posting_id'],
                            $jobInfo['applicant_id'],
                            $_SESSION['user_name']
                        ]);
                    }
                }
            }
            
            if (isset($data['medical_results_path'])) {
                $updates[] = "medical_results_path = ?";
                $params[] = $data['medical_results_path'];
            }
            
            if (isset($data['background_check_status'])) {
                $updates[] = "background_check_status = ?";
                $params[] = $data['background_check_status'];
            }
            
            if (isset($data['signed_offer_path'])) {
                $updates[] = "signed_offer_path = ?";
                $params[] = $data['signed_offer_path'];
            }
            
            if (isset($data['hired_date'])) {
                $updates[] = "hired_date = ?";
                $params[] = $data['hired_date'];
            }
            
            if (empty($updates)) {
                http_response_code(400);
                echo json_encode(['error' => 'No updates provided']);
                exit;
            }
            
            $params[] = $id;
            $query = "UPDATE job_offers SET " . implode(', ', $updates) . " WHERE id = ?";
            
            $stmt = $connections->prepare($query);
            $stmt->execute($params);
            
            $connections->commit();
            
            echo json_encode([
                'status' => 'success',
                'message' => 'Job offer updated'
            ]);
            
        } catch (Exception $e) {
            $connections->rollBack();
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;
        
    case 'GET':
        requireAuth();
        
        $applicantId = $_GET['applicant_id'] ?? null;
        $status = $_GET['status'] ?? null;
        
        $query = "
            SELECT jo.*, a.first_name, a.last_name, a.email, 
                   jp.job_title, jr.department
            FROM job_offers jo
            JOIN applicants a ON jo.applicant_id = a.id
            JOIN job_postings jp ON a.job_posting_id = jp.id
            JOIN job_requests jr ON jp.job_request_id = jr.id
        ";
        
        $params = [];
        $conditions = [];
        
        if ($applicantId) {
            $conditions[] = "jo.applicant_id = ?";
            $params[] = $applicantId;
        }
        
        if ($status) {
            $conditions[] = "jo.offer_status = ?";
            $params[] = $status;
        }
        
        if (!empty($conditions)) {
            $query .= " WHERE " . implode(' AND ', $conditions);
        }
        
        $query .= " ORDER BY jo.offer_date DESC";
        
        $stmt = $connections->prepare($query);
        $stmt->execute($params);
        $offers = $stmt->fetchAll();
        
        // Parse benefits from JSON
        foreach ($offers as &$offer) {
            $offer['benefits_offer'] = json_decode($offer['benefits_offer'], true) ?? [];
        }
        
        echo json_encode(['data' => $offers]);
        break;
}

function sendOfferLetter($offerId) {
    global $connections;
    
    $stmt = $connections->prepare("
        SELECT a.email, a.first_name, jo.salary_offer, jo.start_date,
               jo.expiration_date, jp.job_title, jr.department
        FROM job_offers jo
        JOIN applicants a ON jo.applicant_id = a.id
        JOIN job_postings jp ON a.job_posting_id = jp.id
        JOIN job_requests jr ON jp.job_request_id = jr.id
        WHERE jo.id = ?
    ");
    $stmt->execute([$offerId]);
    $data = $stmt->fetch();
    
    if (!$data) return;
    
    $salary = number_format($data['salary_offer'], 2);
    $startDate = date('F j, Y', strtotime($data['start_date']));
    $expirationDate = date('F j, Y', strtotime($data['expiration_date']));
    
    $subject = "Job Offer - {$data['job_title']} - Atiera Hotel & Restaurant";
    $message = "
    <html>
    <body>
        <h2>Congratulations!</h2>
        <p>Dear {$data['first_name']},</p>
        <p>We are pleased to offer you the position of <strong>{$data['job_title']}</strong> 
           in the {$data['department']} department at Atiera Hotel & Restaurant.</p>
        
        <h3>Offer Details:</h3>
        <ul>
            <li>Position: {$data['job_title']}</li>
            <li>Department: {$data['department']}</li>
            <li>Starting Salary: ₱$salary per month</li>
            <li>Start Date: $startDate</li>
        </ul>
        
        <p>Please review the attached offer letter for complete details including benefits 
           and terms of employment. You must accept this offer by $expirationDate.</p>
        
        <p>To accept this offer, please:</p>
        <ol>
            <li>Sign the attached offer letter</li>
            <li>Complete the pre-employment requirements</li>
            <li>Submit all documents to HR</li>
        </ol>
        
        <p>We look forward to welcoming you to the Atiera team!</p>
        <br>
        <p>Sincerely,<br>
        Atiera Human Resources</p>
    </body>
    </html>
    ";
    
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: hr@atiera.com" . "\r\n";
    
    // Note: In production, you would attach the offer letter PDF
    mail($data['email'], $subject, $message, $headers);
}
?>