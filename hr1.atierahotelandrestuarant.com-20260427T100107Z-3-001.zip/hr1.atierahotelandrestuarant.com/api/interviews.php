<?php
require_once '../connections.php';

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'POST':
        requireAuth();
        $data = json_decode(file_get_contents('php://input'), true);
        
        try {
            $connections->beginTransaction();
            
            // STEP 8: Schedule interview
            $stmt = $connections->prepare("
                INSERT INTO interviews (
                    applicant_id, interview_type, scheduled_date, 
                    duration_minutes, location, meeting_link,
                    interviewer_name, interviewer_role, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'scheduled')
            ");
            
            $stmt->execute([
                $data['applicant_id'],
                $data['interview_type'],
                $data['scheduled_date'],
                $data['duration_minutes'] ?? 60,
                $data['location'] ?? '',
                $data['meeting_link'] ?? '',
                $data['interviewer_name'],
                $data['interviewer_role'],
            ]);
            
            $interviewId = $connections->lastInsertId();
            
            // Update applicant status to shortlisted
            $updateApplicantStmt = $connections->prepare("
                UPDATE applicants SET application_status = 'shortlisted'
                WHERE id = ?
            ");
            $updateApplicantStmt->execute([$data['applicant_id']]);
            
            // Get job info for tracking
            $getInfoStmt = $connections->prepare("
                SELECT a.job_posting_id, jp.job_request_id
                FROM applicants a
                JOIN job_postings jp ON a.job_posting_id = jp.id
                WHERE a.id = ?
            ");
            $getInfoStmt->execute([$data['applicant_id']]);
            $info = $getInfoStmt->fetch();
            
            if ($info) {
                // Update job request step
                $updateStepStmt = $connections->prepare("
                    UPDATE job_requests SET current_step = 8 WHERE id = ?
                ");
                $updateStepStmt->execute([$info['job_request_id']]);
                
                // Track process
                $trackStmt = $connections->prepare("
                    INSERT INTO recruitment_process_tracking 
                    (job_request_id, job_posting_id, applicant_id, 
                     step_number, step_name, status, performed_by)
                    VALUES (?, ?, ?, 8, 'Interview Scheduled', 'completed', ?)
                ");
                $trackStmt->execute([
                    $info['job_request_id'],
                    $info['job_posting_id'],
                    $data['applicant_id'],
                    $_SESSION['user_name']
                ]);
            }
            
            // Send interview invitation email
            sendInterviewInvitation($data['applicant_id'], $interviewId);
            
            $connections->commit();
            
            echo json_encode([
                'status' => 'success',
                'message' => 'Interview scheduled successfully'
            ]);
            
        } catch (Exception $e) {
            $connections->rollBack();
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;
        
    case 'PUT':
        requireAuth();
        
        $id = $_GET['id'] ?? null;
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!$id) {
            http_response_code(400);
            echo json_encode(['error' => 'Interview ID required']);
            exit;
        }
        
        if (isset($data['evaluation'])) {
            // STEP 9: Submit evaluation
            try {
                $connections->beginTransaction();
                
                $eval = $data['evaluation'];
                
                // Calculate overall rating
                $commScore = (int)$eval['communication_score'];
                $techScore = (int)$eval['technical_score'];
                $cultureScore = (int)$eval['cultural_fit_score'];
                $overallRating = ($commScore + $techScore + $cultureScore) / 3;
                
                $stmt = $connections->prepare("
                    UPDATE interviews SET 
                        status = 'completed',
                        communication_score = ?,
                        technical_score = ?,
                        cultural_fit_score = ?,
                        overall_rating = ?,
                        feedback_notes = ?,
                        recommendation = ?,
                        evaluated_by = ?,
                        evaluated_date = NOW()
                    WHERE id = ?
                ");
                
                $stmt->execute([
                    $commScore,
                    $techScore,
                    $cultureScore,
                    $overallRating,
                    sanitizeInput($eval['feedback_notes']),
                    $eval['recommendation'],
                    $_SESSION['user_name'],
                    $id
                ]);
                
                // Get applicant and job info
                $getInfoStmt = $connections->prepare("
                    SELECT i.applicant_id, a.job_posting_id, jp.job_request_id
                    FROM interviews i
                    JOIN applicants a ON i.applicant_id = a.id
                    JOIN job_postings jp ON a.job_posting_id = jp.id
                    WHERE i.id = ?
                ");
                $getInfoStmt->execute([$id]);
                $info = $getInfoStmt->fetch();
                
                if ($info) {
                    // Update applicant status based on recommendation
                    $newStatus = $eval['recommendation'] == 'proceed' ? 'selected' : 'rejected';
                    
                    $updateApplicantStmt = $connections->prepare("
                        UPDATE applicants SET application_status = ?
                        WHERE id = ?
                    ");
                    $updateApplicantStmt->execute([$newStatus, $info['applicant_id']]);
                    
                    // Update job request step
                    $updateStepStmt = $connections->prepare("
                        UPDATE job_requests SET current_step = 9 WHERE id = ?
                    ");
                    $updateStepStmt->execute([$info['job_request_id']]);
                    
                    // Track process
                    $trackStmt = $connections->prepare("
                        INSERT INTO recruitment_process_tracking 
                        (job_request_id, job_posting_id, applicant_id, 
                         step_number, step_name, status, performed_by)
                        VALUES (?, ?, ?, 9, 'Interview Completed', 'completed', ?)
                    ");
                    $trackStmt->execute([
                        $info['job_request_id'],
                        $info['job_posting_id'],
                        $info['applicant_id'],
                        $_SESSION['user_name']
                    ]);
                }
                
                $connections->commit();
                
                echo json_encode([
                    'status' => 'success',
                    'message' => 'Evaluation submitted successfully'
                ]);
                
            } catch (Exception $e) {
                $connections->rollBack();
                http_response_code(500);
                echo json_encode(['error' => $e->getMessage()]);
            }
        } else {
            // Update interview details
            $updates = [];
            $params = [];
            
            $allowedFields = ['scheduled_date', 'location', 'meeting_link', 'status'];
            foreach ($allowedFields as $field) {
                if (isset($data[$field])) {
                    $updates[] = "$field = ?";
                    $params[] = $data[$field];
                }
            }
            
            if (empty($updates)) {
                http_response_code(400);
                echo json_encode(['error' => 'No updates provided']);
                exit;
            }
            
            $params[] = $id;
            $query = "UPDATE interviews SET " . implode(', ', $updates) . " WHERE id = ?";
            
            $stmt = $connections->prepare($query);
            $stmt->execute($params);
            
            echo json_encode([
                'status' => 'success',
                'message' => 'Interview updated'
            ]);
        }
        break;
        
    case 'GET':
        requireAuth();
        
        $applicantId = $_GET['applicant_id'] ?? null;
        $type = $_GET['type'] ?? null;
        
        $query = "SELECT i.*, a.first_name, a.last_name, a.email 
                 FROM interviews i
                 JOIN applicants a ON i.applicant_id = a.id";
        
        $params = [];
        if ($applicantId) {
            $query .= " WHERE i.applicant_id = ?";
            $params[] = $applicantId;
        }
        if ($type && $applicantId) {
            $query .= " AND i.interview_type = ?";
            $params[] = $type;
        }
        
        $query .= " ORDER BY i.scheduled_date";
        
        $stmt = $connections->prepare($query);
        $stmt->execute($params);
        $interviews = $stmt->fetchAll();
        
        echo json_encode(['data' => $interviews]);
        break;
}

function sendInterviewInvitation($applicantId, $interviewId) {
    global $connections;
    
    $stmt = $connections->prepare("
        SELECT a.email, a.first_name, i.scheduled_date, i.location, 
               i.meeting_link, i.interviewer_name, jp.job_title
        FROM interviews i
        JOIN applicants a ON i.applicant_id = a.id
        JOIN job_postings jp ON a.job_posting_id = jp.id
        WHERE i.id = ?
    ");
    $stmt->execute([$interviewId]);
    $data = $stmt->fetch();
    
    if (!$data) return;
    
    $date = date('F j, Y \a\t g:i A', strtotime($data['scheduled_date']));
    $location = $data['meeting_link'] ?: $data['location'];
    
    $subject = "Interview Invitation - {$data['job_title']}";
    $message = "
    <html>
    <body>
        <h2>Interview Invitation</h2>
        <p>Dear {$data['first_name']},</p>
        <p>Congratulations! You have been shortlisted for the position of {$data['job_title']}.</p>
        <p><strong>Interview Details:</strong></p>
        <ul>
            <li>Date & Time: $date</li>
            <li>Location: $location</li>
            <li>Interviewer: {$data['interviewer_name']}</li>
        </ul>
        <p>Please confirm your availability by replying to this email.</p>
        <br>
        <p>Best regards,<br>
        Atiera HR Team</p>
    </body>
    </html>
    ";
    
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: hr@atiera.com" . "\r\n";
    
    mail($data['email'], $subject, $message, $headers);
}
?>