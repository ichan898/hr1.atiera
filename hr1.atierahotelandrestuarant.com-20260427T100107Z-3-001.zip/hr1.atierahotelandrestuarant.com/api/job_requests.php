<?php
require_once '../connections.php';

$method = $_SERVER['REQUEST_METHOD'];
$data = json_decode(file_get_contents('php://input'), true) ?? $_POST;

switch ($method) {
    case 'POST':
        requireAuth();
        
        try {
            $connections->beginTransaction();
            
            // STEP 1: Create Job Request
            $stmt = $connections->prepare("
                INSERT INTO job_requests (
                    position_title, department, number_of_employees, reason,
                    qualifications, target_start_date, requested_by
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            
            $stmt->execute([
                sanitizeInput($data['position_title']),
                sanitizeInput($data['department']),
                (int)$data['number_of_employees'],
                sanitizeInput($data['reason']),
                json_encode($data['qualifications'] ?? []),
                sanitizeInput($data['target_start_date']),
                $_SESSION['user_name'] ?? 'System'
            ]);
            
            $jobRequestId = $connections->lastInsertId();
            
            // Create process tracking
            $trackStmt = $connections->prepare("
                INSERT INTO recruitment_process_tracking 
                (job_request_id, step_number, step_name, status, performed_by)
                VALUES (?, 1, 'Job Request Submission', 'completed', ?)
            ");
            $trackStmt->execute([$jobRequestId, $_SESSION['user_name'] ?? 'System']);
            
            $connections->commit();
            
            echo json_encode([
                'status' => 'success',
                'message' => 'Job request submitted successfully',
                'request_id' => $jobRequestId
            ]);
            
        } catch (Exception $e) {
            $connections->rollBack();
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;
        
    case 'GET':
        requireAuth();
        
        $status = $_GET['status'] ?? null;
        $department = $_GET['department'] ?? null;
        
        $query = "SELECT * FROM job_requests WHERE is_active = TRUE";
        $params = [];
        
        if ($status) {
            $query .= " AND overall_status = ?";
            $params[] = $status;
        }
        if ($department) {
            $query .= " AND department = ?";
            $params[] = $department;
        }
        
        $query .= " ORDER BY requested_date DESC";
        
        $stmt = $connections->prepare($query);
        $stmt->execute($params);
        $requests = $stmt->fetchAll();
        
        // Parse qualifications from JSON
        foreach ($requests as &$request) {
            $request['qualifications'] = json_decode($request['qualifications'], true) ?? [];
        }
        
        echo json_encode(['data' => $requests]);
        break;
        
    case 'PUT':
        requireAuth();
        
        $id = $_GET['id'] ?? $data['id'] ?? null;
        if (!$id) {
            http_response_code(400);
            echo json_encode(['error' => 'ID required']);
            exit;
        }
        
        $updates = [];
        $params = [];
        
        $allowedFields = [
            'completeness_check', 'job_necessity', 'alignment_with_plan',
            'hr_review_notes', 'needs_revision', 'immediate_supervisor_approval',
            'finance_approval', 'overall_status', 'job_description',
            'final_requirements', 'recruitment_priority'
        ];
        
        foreach ($allowedFields as $field) {
            if (isset($data[$field])) {
                $updates[] = "$field = ?";
                $params[] = is_array($data[$field]) ? json_encode($data[$field]) : $data[$field];
            }
        }
        
        if (empty($updates)) {
            http_response_code(400);
            echo json_encode(['error' => 'No valid fields to update']);
            exit;
        }
        
        // Update current step based on action
        if (isset($data['action'])) {
            switch ($data['action']) {
                case 'review':
                    $updates[] = "current_step = 2";
                    break;
                case 'approve':
                    $updates[] = "current_step = 3";
                    $updates[] = "requisition_number = ?";
                    $params[] = generateRequisitionNumber();
                    break;
            }
        }
        
        $params[] = $id;
        
        $query = "UPDATE job_requests SET " . implode(', ', $updates) . " WHERE id = ?";
        
        $stmt = $connections->prepare($query);
        $stmt->execute($params);
        
        // Record process tracking
        if (isset($data['action'])) {
            $stepName = ucfirst($data['action']) . ' Completed';
            $trackStmt = $connections->prepare("
                INSERT INTO recruitment_process_tracking 
                (job_request_id, step_number, step_name, status, performed_by)
                VALUES (?, ?, ?, 'completed', ?)
            ");
            
            $stepNumber = $data['action'] == 'review' ? 2 : 3;
            $trackStmt->execute([$id, $stepNumber, $stepName, $_SESSION['user_name']]);
        }
        
        echo json_encode([
            'status' => 'success',
            'message' => 'Job request updated'
        ]);
        break;
        
    default:
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
}
?>