<?php
require_once '../connections.php';

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'POST':
        // Public application submission (STEP 6)
        if (isset($_POST['submit_application'])) {
            try {
                $connections->beginTransaction();
                
                // Validate job posting
                $jobStmt = $connections->prepare("
                    SELECT id, vacancies, filled_positions 
                    FROM job_postings 
                    WHERE id = ? AND status = 'open'
                ");
                $jobStmt->execute([$_POST['job_id']]);
                $job = $jobStmt->fetch();
                
                if (!$job) {
                    throw new Exception('Job posting not found or closed');
                }
                
                if ($job['filled_positions'] >= $job['vacancies']) {
                    throw new Exception('No vacancies available');
                }
                
                // Handle file upload
                $resumePath = null;
                if (isset($_FILES['resume'])) {
                    $resumePath = uploadFile($_FILES['resume']);
                }
                
                // Save applicant (STEP 6)
                $stmt = $connections->prepare("
                    INSERT INTO applicants (
                        job_posting_id, first_name, middle_initial, last_name,
                        email, phone_number, address, gender, birthday,
                        contact_information, resume_path, application_status
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'new')
                ");
                
                $stmt->execute([
                    $_POST['job_id'],
                    sanitizeInput($_POST['First_Name']),
                    sanitizeInput($_POST['Middle_Initial'] ?? ''),
                    sanitizeInput($_POST['Last_Name']),
                    sanitizeInput($_POST['Email']),
                    sanitizeInput($_POST['Phone_Number']),
                    sanitizeInput($_POST['Address']),
                    $_POST['Gender'] ?? null,
                    $_POST['Birthday'] ?? null,
                    sanitizeInput($_POST['Contact_Information'] ?? ''),
                    $resumePath
                ]);
                
                $applicantId = $connections->lastInsertId();
                
                // Get job request ID for tracking
                $getReqStmt = $connections->prepare("
                    SELECT jp.job_request_id 
                    FROM job_postings jp 
                    WHERE jp.id = ?
                ");
                $getReqStmt->execute([$_POST['job_id']]);
                $result = $getReqStmt->fetch();
                
                if ($result) {
                    // Update job request step
                    $updateStepStmt = $connections->prepare("
                        UPDATE job_requests SET current_step = 6 WHERE id = ?
                    ");
                    $updateStepStmt->execute([$result['job_request_id']]);
                    
                    // Track process
                    $trackStmt = $connections->prepare("
                        INSERT INTO recruitment_process_tracking 
                        (job_request_id, job_posting_id, applicant_id, 
                         step_number, step_name, status, performed_by)
                        VALUES (?, ?, ?, 6, 'Application Received', 'completed', 'System')
                    ");
                    $trackStmt->execute([
                        $result['job_request_id'],
                        $_POST['job_id'],
                        $applicantId
                    ]);
                }
                
                $connections->commit();
                
                // Send confirmation email
                sendApplicationConfirmation($_POST['Email'], $_POST['First_Name']);
                
                echo json_encode([
                    'status' => 'success',
                    'message' => 'Application submitted successfully'
                ]);
                
            } catch (Exception $e) {
                $connections->rollBack();
                http_response_code(500);
                echo json_encode(['error' => $e->getMessage()]);
            }
            exit;
        }
        
        // HR screening (STEP 7)
        requireAuth();
        
        $data = json_decode(file_get_contents('php://input'), true);
        
        try {
            $connections->beginTransaction();
            
            // Update applicant status and scores
            $stmt = $connections->prepare("
                UPDATE applicants SET 
                    application_status = ?,
                    qualification_score = ?,
                    experience_score = ?,
                    skills_score = ?,
                    overall_score = ?,
                    screening_notes = ?,
                    screened_by = ?,
                    screened_date = NOW()
                WHERE id = ?
            ");
            
            // Calculate overall score
            $qualScore = (int)$data['qualification_score'];
            $expScore = (int)$data['experience_score'];
            $skillsScore = (int)$data['skills_score'];
            $overallScore = ($qualScore + $expScore + $skillsScore) / 3;
            
            // Determine status based on score
            $status = $overallScore >= 70 ? 'qualified' : 'not_qualified';
            if (isset($data['force_status'])) {
                $status = $data['force_status'];
            }
            
            $stmt->execute([
                $status,
                $qualScore,
                $expScore,
                $skillsScore,
                $overallScore,
                sanitizeInput($data['screening_notes'] ?? ''),
                $_SESSION['user_name'],
                $data['applicant_id']
            ]);
            
            // Get job info for tracking
            $getInfoStmt = $connections->prepare("
                SELECT a.job_posting_id, jp.job_request_id
                FROM applicants a
                JOIN job_postings jp ON a.job_posting_id = jp.id
                WHERE a.id = ?
            ");
            $getInfoStmt->execute([$data['applicant_id']]);
            $info = $getInfoStmt->fetch();
            
            if ($info) {
                // Update job request step for first screening
                $updateStepStmt = $connections->prepare("
                    UPDATE job_requests SET current_step = 7 WHERE id = ?
                ");
                $updateStepStmt->execute([$info['job_request_id']]);
                
                // Track process
                $trackStmt = $connections->prepare("
                    INSERT INTO recruitment_process_tracking 
                    (job_request_id, job_posting_id, applicant_id, 
                     step_number, step_name, status, performed_by)
                    VALUES (?, ?, ?, 7, 'Application Screened', 'completed', ?)
                ");
                $trackStmt->execute([
                    $info['job_request_id'],
                    $info['job_posting_id'],
                    $data['applicant_id'],
                    $_SESSION['user_name']
                ]);
            }
            
            $connections->commit();
            
            echo json_encode([
                'status' => 'success',
                'message' => 'Application screened successfully'
            ]);
            
        } catch (Exception $e) {
            $connections->rollBack();
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;
        
    case 'GET':
        requireAuth();
        
        $status = $_GET['status'] ?? null;
        $jobId = $_GET['job_id'] ?? null;
        
        $query = "
            SELECT a.*, jp.job_title, jr.department
            FROM applicants a
            JOIN job_postings jp ON a.job_posting_id = jp.id
            JOIN job_requests jr ON jp.job_request_id = jr.id
        ";
        
        $params = [];
        $conditions = [];
        
        if ($status) {
            $conditions[] = "a.application_status = ?";
            $params[] = $status;
        }
        
        if ($jobId) {
            $conditions[] = "a.job_posting_id = ?";
            $params[] = $jobId;
        }
        
        if (!empty($conditions)) {
            $query .= " WHERE " . implode(' AND ', $conditions);
        }
        
        $query .= " ORDER BY a.applied_date DESC";
        
        $stmt = $connections->prepare($query);
        $stmt->execute($params);
        $applicants = $stmt->fetchAll();
        
        echo json_encode(['data' => $applicants]);
        break;
}

function sendApplicationConfirmation($email, $name) {
    $subject = "Application Received - Atiera Hotel & Restaurant";
    $message = "
    <html>
    <body>
        <h2>Thank you for your application, $name!</h2>
        <p>We have received your application and will review it shortly.</p>
        <p>Our HR team will contact you if your qualifications match our requirements.</p>
        <br>
        <p>Best regards,<br>
        Atiera Recruitment Team</p>
    </body>
    </html>
    ";
    
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: careers@atiera.com" . "\r\n";
    
    mail($email, $subject, $message, $headers);
}
?>