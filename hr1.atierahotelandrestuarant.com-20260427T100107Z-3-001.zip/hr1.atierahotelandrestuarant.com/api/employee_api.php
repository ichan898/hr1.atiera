<?php
/* =========================
   HEADERS & CORS
========================= */
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

/* =========================
   DATABASE (PDO)
========================= */
require_once __DIR__ . "/../connections.php";

if (!isset($connections) || !($connections instanceof PDO)) {
    http_response_code(500);
    echo json_encode(["error" => "PDO database connection not available"]);
    exit;
}

$db = $connections;
$method = $_SERVER['REQUEST_METHOD'];

/* =========================
   ROUTER
========================= */
switch ($method) {

    /* =========================
       GET (ALL / BY ID / BY EMPLOYEE_ID / BY DEPARTMENT)
    ========================== */
    case 'GET':
        if (!empty($_GET['id'])) {
            $stmt = $db->prepare("SELECT * FROM employees WHERE id = ?");
            $stmt->execute([intval($_GET['id'])]);
            echo json_encode($stmt->fetch() ?: []);
        } elseif (!empty($_GET['employee_id'])) {
            $stmt = $db->prepare("SELECT * FROM employees WHERE employee_id = ?");
            $stmt->execute([$_GET['employee_id']]);
            echo json_encode($stmt->fetch() ?: []);
        } elseif (!empty($_GET['department_id'])) {
            $stmt = $db->prepare("SELECT * FROM employees WHERE department_id = ?");
            $stmt->execute([intval($_GET['department_id'])]);
            echo json_encode($stmt->fetchAll());
        } else {
            $stmt = $db->query("SELECT * FROM employees ORDER BY created_at DESC");
            echo json_encode($stmt->fetchAll());
        }
        break;

    /* =========================
       POST (CREATE)
    ========================== */
    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);

        if (!$data) {
            http_response_code(400);
            echo json_encode(["error" => "Invalid JSON"]);
            exit;
        }

        $stmt = $db->prepare(
            "INSERT INTO employees (
                employee_id, first_name, middle_name, last_name, gender,
                department_id, email, contact_number, address,
                date_of_birth, hire_date, status, created_at, updated_at
            ) VALUES (
                :employee_id, :first_name, :middle_name, :last_name, :gender,
                :department_id, :email, :contact_number, :address,
                :date_of_birth, :hire_date, :status, NOW(), NOW()
            )"
        );

        $stmt->execute([
            ":employee_id"    => $data['employee_id'],
            ":first_name"     => $data['first_name'],
            ":middle_name"    => $data['middle_name'] ?? null,
            ":last_name"      => $data['last_name'],
            ":gender"         => $data['gender'],
            ":department_id"  => $data['department_id'],
            ":email"          => $data['email'],
            ":contact_number" => $data['contact_number'],
            ":address"        => $data['address'],
            ":date_of_birth"  => $data['date_of_birth'],
            ":hire_date"      => $data['hire_date'],
            ":status"         => $data['status']
        ]);

        echo json_encode([
            "success" => true,
            "id" => $db->lastInsertId()
        ]);
        break;

    /* =========================
       PUT (UPDATE)
    ========================== */
    case 'PUT':
        parse_str($_SERVER['QUERY_STRING'], $query);
        $id = intval($query['id'] ?? 0);
        $data = json_decode(file_get_contents("php://input"), true);

        if (!$id || !$data) {
            http_response_code(400);
            echo json_encode(["error" => "Missing id or data"]);
            exit;
        }

        $stmt = $db->prepare(
            "UPDATE employees SET
                employee_id = :employee_id,
                first_name = :first_name,
                middle_name = :middle_name,
                last_name = :last_name,
                gender = :gender,
                department_id = :department_id,
                email = :email,
                contact_number = :contact_number,
                address = :address,
                date_of_birth = :date_of_birth,
                hire_date = :hire_date,
                status = :status,
                updated_at = NOW()
             WHERE id = :id"
        );

        $stmt->execute([
            ":employee_id"    => $data['employee_id'],
            ":first_name"     => $data['first_name'],
            ":middle_name"    => $data['middle_name'] ?? null,
            ":last_name"      => $data['last_name'],
            ":gender"         => $data['gender'],
            ":department_id"  => $data['department_id'],
            ":email"          => $data['email'],
            ":contact_number" => $data['contact_number'],
            ":address"        => $data['address'],
            ":date_of_birth"  => $data['date_of_birth'],
            ":hire_date"      => $data['hire_date'],
            ":status"         => $data['status'],
            ":id"             => $id
        ]);

        echo json_encode(["success" => true]);
        break;

    /* =========================
       DELETE
    ========================== */
    case 'DELETE':
        parse_str($_SERVER['QUERY_STRING'], $query);
        $id = intval($query['id'] ?? 0);

        if (!$id) {
            http_response_code(400);
            echo json_encode(["error" => "Missing id"]);
            exit;
        }

        $stmt = $db->prepare("DELETE FROM employees WHERE id = ?");
        $stmt->execute([$id]);

        echo json_encode(["success" => true]);
        break;

    default:
        http_response_code(405);
        echo json_encode(["error" => "Method not allowed"]);
}
