<?php
/* =========================
   HEADERS
========================= */
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");

require_once __DIR__ . "/../connections.php";

try {

    if (!isset($connections) || !($connections instanceof PDO)) {
        throw new Exception("Database connection not found.");
    }

    $stmt = $connections->prepare("
        SELECT 
            e.id,
            e.employee_id,
            CONCAT(e.first_name, ' ', e.middle_name, ' ', e.last_name) AS employee_name,
            e.first_name,
            e.middle_name,
            e.last_name,
            e.position,
            e.gender,
            e.email,
            e.contact_number,
            e.status,
            e.department_id,
            d.name AS department_name
        FROM employees e
        INNER JOIN departments d ON e.department_id = d.id
        WHERE e.department_id = :dept_id
    ");

    $stmt->execute([
        'dept_id' => 8   // Logistics 2
    ]);

    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($employees, JSON_PRETTY_PRINT);

} catch (PDOException $e) {

    http_response_code(500);
    echo json_encode([
        "error" => "Database error: " . $e->getMessage()
    ]);
}