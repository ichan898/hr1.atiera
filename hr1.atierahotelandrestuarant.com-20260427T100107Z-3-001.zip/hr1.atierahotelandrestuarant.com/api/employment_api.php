<?php
/* =========================
   HEADERS + PREFLIGHT
========================= */
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

/* =========================
   DATABASE (PDO)
========================= */
require_once __DIR__ . "/../connections.php";

if (!isset($connections) || !($connections instanceof PDO)) {
    http_response_code(500);
    echo json_encode(["error" => "PDO database connection not available"]);
    exit;
}

$db = $connections;

/* =========================
   REQUEST METHOD
========================= */
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {

    /* =========================
       GET – ALL / BY ID / BY EMPLOYEE
    ========================== */
    case 'GET':
        if (!empty($_GET['id'])) {
            $stmt = $db->prepare(
                "SELECT * FROM employment_details WHERE id = ?"
            );
            $stmt->execute([intval($_GET['id'])]);
            echo json_encode($stmt->fetch() ?: []);
        } elseif (!empty($_GET['employee_id'])) {
            $stmt = $db->prepare(
                "SELECT * FROM employment_details WHERE employee_id = ?"
            );
            $stmt->execute([$_GET['employee_id']]);
            echo json_encode($stmt->fetchAll());
        } else {
            $stmt = $db->query(
                "SELECT * FROM employment_details ORDER BY id DESC"
            );
            echo json_encode($stmt->fetchAll());
        }
        break;

    /* =========================
       POST – CREATE
    ========================== */
    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);

        if (!$data) {
            http_response_code(400);
            echo json_encode(["error" => "Invalid JSON"]);
            exit;
        }

        $stmt = $db->prepare(
            "INSERT INTO employment_details (
                employee_id, employment_type, job_title,
                department, basic_salary, salary_type, probation_end
            ) VALUES (
                :employee_id, :employment_type, :job_title,
                :department, :basic_salary, :salary_type, :probation_end
            )"
        );

        $stmt->execute([
            ":employee_id"     => $data['employee_id'],
            ":employment_type" => $data['employment_type'],
            ":job_title"       => $data['job_title'],
            ":department"      => $data['department'],
            ":basic_salary"    => $data['basic_salary'],
            ":salary_type"     => $data['salary_type'],
            ":probation_end"   => $data['probation_end']
        ]);

        echo json_encode([
            "success" => true,
            "id" => $db->lastInsertId()
        ]);
        break;

    /* =========================
       PUT – UPDATE
    ========================== */
    case 'PUT':
        parse_str($_SERVER['QUERY_STRING'], $query);
        $id = intval($query['id'] ?? 0);
        $data = json_decode(file_get_contents("php://input"), true);

        if (!$id || !$data) {
            http_response_code(400);
            echo json_encode(["error" => "Missing id or data"]);
            exit;
        }

        $stmt = $db->prepare(
            "UPDATE employment_details SET
                employee_id = :employee_id,
                employment_type = :employment_type,
                job_title = :job_title,
                department = :department,
                basic_salary = :basic_salary,
                salary_type = :salary_type,
                probation_end = :probation_end
             WHERE id = :id"
        );

        $stmt->execute([
            ":employee_id"     => $data['employee_id'],
            ":employment_type" => $data['employment_type'],
            ":job_title"       => $data['job_title'],
            ":department"      => $data['department'],
            ":basic_salary"    => $data['basic_salary'],
            ":salary_type"     => $data['salary_type'],
            ":probation_end"   => $data['probation_end'],
            ":id"              => $id
        ]);

        echo json_encode(["success" => true]);
        break;

    /* =========================
       DELETE
    ========================== */
    case 'DELETE':
        parse_str($_SERVER['QUERY_STRING'], $query);
        $id = intval($query['id'] ?? 0);

        if (!$id) {
            http_response_code(400);
            echo json_encode(["error" => "Missing id"]);
            exit;
        }

        $stmt = $db->prepare(
            "DELETE FROM employment_details WHERE id = ?"
        );
        $stmt->execute([$id]);

        echo json_encode(["success" => true]);
        break;

    default:
        http_response_code(405);
        echo json_encode(["error" => "Method not allowed"]);
}
