<?php
/* =========================
   HEADERS + PREFLIGHT
========================= */
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

/* =========================
   DATABASE (PDO)
========================= */
require_once __DIR__ . "/../connections.php";

if (!isset($connections) || !($connections instanceof PDO)) {
    http_response_code(500);
    echo json_encode(["error" => "PDO database connection not available"]);
    exit;
}

$db = $connections;
$db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
$method = $_SERVER['REQUEST_METHOD'];

/* =========================
   HELPER: READ JSON BODY
========================= */
function getJsonInput()
{
    $raw = file_get_contents("php://input");
    if (!$raw) return [];
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

/* =========================
   ROUTER
========================= */
try {

    switch ($method) {

        /* =========================
           GET (ALL / SINGLE)
        ========================== */
        case 'GET':
            if (!empty($_GET['id'])) {

                $stmt = $db->prepare(
                    "SELECT * FROM onboarding WHERE id = ?"
                );
                $stmt->execute([(int) $_GET['id']]);
                $row = $stmt->fetch();

                if (!$row) {
                    http_response_code(404);
                    echo json_encode(["error" => "Record not found"]);
                    exit;
                }

                echo json_encode($row);

            } else {

                $stmt = $db->query(
                    "SELECT * FROM onboarding ORDER BY created_at DESC"
                );
                echo json_encode($stmt->fetchAll());
            }
            break;

        /* =========================
           POST (CREATE)
        ========================== */
        case 'POST':
            $data = getJsonInput();

            $required = [
                'employee_id', 'job_position', 'first_name', 'last_name',
                'email', 'hire_date', 'status'
            ];

            foreach ($required as $field) {
                if (empty($data[$field])) {
                    http_response_code(400);
                    echo json_encode(["error" => "$field is required"]);
                    exit;
                }
            }

            $sql = "INSERT INTO onboarding (
                        employee_id, job_position, first_name, middle_name, last_name,
                        email, contact_number, address, date_of_birth, hire_date,
                        status, created_at, updated_at
                    ) VALUES (
                        :employee_id, :job_position, :first_name, :middle_name, :last_name,
                        :email, :contact_number, :address, :date_of_birth, :hire_date,
                        :status, NOW(), NOW()
                    )";

            $stmt = $db->prepare($sql);
            $stmt->execute([
                ":employee_id"    => trim($data['employee_id']),
                ":job_position"   => trim($data['job_position']),
                ":first_name"     => trim($data['first_name']),
                ":middle_name"    => trim($data['middle_name'] ?? ''),
                ":last_name"      => trim($data['last_name']),
                ":email"          => trim($data['email']),
                ":contact_number" => trim($data['contact_number'] ?? ''),
                ":address"        => trim($data['address'] ?? ''),
                ":date_of_birth"  => $data['date_of_birth'] ?? null,
                ":hire_date"      => $data['hire_date'],
                ":status"         => trim($data['status'])
            ]);

            http_response_code(201);
            echo json_encode([
                "success" => true,
                "id" => $db->lastInsertId()
            ]);
            break;

        /* =========================
           PUT (UPDATE)
        ========================== */
        case 'PUT':
            parse_str($_SERVER['QUERY_STRING'] ?? '', $query);
            $id = (int) ($query['id'] ?? 0);
            $data = getJsonInput();

            if (!$id || !$data) {
                http_response_code(400);
                echo json_encode(["error" => "id and data are required"]);
                exit;
            }

            $sql = "UPDATE onboarding SET
                        employee_id = :employee_id,
                        job_position = :job_position,
                        first_name = :first_name,
                        middle_name = :middle_name,
                        last_name = :last_name,
                        email = :email,
                        contact_number = :contact_number,
                        address = :address,
                        date_of_birth = :date_of_birth,
                        hire_date = :hire_date,
                        status = :status,
                        updated_at = NOW()
                    WHERE id = :id";

            $stmt = $db->prepare($sql);
            $stmt->execute([
                ":employee_id"    => trim($data['employee_id']),
                ":job_position"   => trim($data['job_position']),
                ":first_name"     => trim($data['first_name']),
                ":middle_name"    => trim($data['middle_name'] ?? ''),
                ":last_name"      => trim($data['last_name']),
                ":email"          => trim($data['email']),
                ":contact_number" => trim($data['contact_number'] ?? ''),
                ":address"        => trim($data['address'] ?? ''),
                ":date_of_birth"  => $data['date_of_birth'] ?? null,
                ":hire_date"      => $data['hire_date'],
                ":status"         => trim($data['status']),
                ":id"             => $id
            ]);

            if ($stmt->rowCount() === 0) {
                http_response_code(404);
                echo json_encode(["error" => "Record not found or no changes made"]);
                exit;
            }

            echo json_encode(["success" => true]);
            break;

        /* =========================
           DELETE
        ========================== */
        case 'DELETE':
            parse_str($_SERVER['QUERY_STRING'] ?? '', $query);
            $id = (int) ($query['id'] ?? 0);

            if (!$id) {
                http_response_code(400);
                echo json_encode(["error" => "id is required"]);
                exit;
            }

            $stmt = $db->prepare(
                "DELETE FROM onboarding WHERE id = ?"
            );
            $stmt->execute([$id]);

            if ($stmt->rowCount() === 0) {
                http_response_code(404);
                echo json_encode(["error" => "Record not found"]);
                exit;
            }

            echo json_encode(["success" => true]);
            break;

        default:
            http_response_code(405);
            echo json_encode(["error" => "Method not allowed"]);
    }

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        "error" => "Database error",
        "details" => $e->getMessage()
    ]);
}
