<?php
/* =========================
   HEADERS + PREFLIGHT
========================= */
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

/* =========================
   DATABASE (PDO)
========================= */
require_once __DIR__ . "/../connections.php";

if (!isset($connections) || !($connections instanceof PDO)) {
    http_response_code(500);
    echo json_encode(["error" => "PDO database connection not available"]);
    exit;
}

$db = $connections;
$db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

/* =========================
   ONLY ALLOW GET
========================= */
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

/* =========================
   BASE QUERY
========================= */
$baseSql = "
    SELECT
        pr.id,
        pr.employee_id,

        e.employee_id AS employee_code,
        CONCAT(
            e.first_name, ' ',
            IFNULL(e.middle_name, ''), ' ',
            e.last_name
        ) AS employee_name,

        e.first_name,
        e.middle_name,
        e.last_name,
        e.gender,
        e.department_id,
        e.email,
        e.contact_number,
        e.address,
        e.hire_date,
        e.status AS employee_status,

        pr.reviewer_id,
        pr.review_date,
        pr.due_date,
        pr.rating,
        pr.summary,
        pr.status,
        pr.created_at,
        pr.updated_at
    FROM performance_reviews pr
    INNER JOIN employees e ON pr.employee_id = e.id
";

/* =========================
   FILTERS (OPTIONAL)
========================= */
$where = [];
$params = [];

/* Single review */
if (!empty($_GET['id'])) {
    $where[] = "pr.id = ?";
    $params[] = (int) $_GET['id'];
}

/* Filter by employee */
if (!empty($_GET['employee_id'])) {
    $where[] = "pr.employee_id = ?";
    $params[] = (int) $_GET['employee_id'];
}

/* Filter by status */
if (!empty($_GET['status'])) {
    $where[] = "pr.status = ?";
    $params[] = trim($_GET['status']);
}

if ($where) {
    $baseSql .= " WHERE " . implode(" AND ", $where);
}

$baseSql .= " ORDER BY pr.created_at DESC";

/* =========================
   EXECUTE
========================= */
$stmt = $db->prepare($baseSql);
$stmt->execute($params);

$results = $stmt->fetchAll();

/* =========================
   RESPONSE
========================= */
if (!empty($_GET['id']) && empty($results)) {
    http_response_code(404);
    echo json_encode(["error" => "Record not found"]);
    exit;
}

echo json_encode($results, JSON_PRETTY_PRINT);
