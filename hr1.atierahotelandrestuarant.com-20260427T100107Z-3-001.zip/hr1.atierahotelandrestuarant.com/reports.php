<?php
// File: reports.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

// Get date filters
$start_date = $_GET['start_date'] ?? date('Y-m-01'); // First day of current month
$end_date = $_GET['end_date'] ?? date('Y-m-d'); // Today
$report_type = $_GET['type'] ?? 'overview';

// Function to get employee statistics from your database
function getEmployeeDashboardStats($connections) {
    $query = "
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status = 'Active' THEN 1 ELSE 0 END) as active_count,
            SUM(CASE WHEN status = 'Inactive' THEN 1 ELSE 0 END) as inactive_count,
            SUM(CASE WHEN status = 'On Leave' THEN 1 ELSE 0 END) as on_leave_count,
            SUM(CASE WHEN status = 'Terminated' THEN 1 ELSE 0 END) as terminated_count
        FROM employees
    ";
    try {
        $stmt = $connections->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result ?: ['total' => 0, 'active_count' => 0, 'inactive_count' => 0, 'on_leave_count' => 0, 'terminated_count' => 0];
    } catch (Exception $e) {
        error_log("Error in getEmployeeDashboardStats: " . $e->getMessage());
        return ['total' => 0, 'active_count' => 0, 'inactive_count' => 0, 'on_leave_count' => 0, 'terminated_count' => 0];
    }
}

// Function to get recruitment stats from your applicants table
function getRecruitmentDashboardStats($connections, $start_date, $end_date) {
    $query = "
        SELECT 
            COUNT(*) as total_applicants,
            SUM(CASE WHEN application_status = 'new' THEN 1 ELSE 0 END) as new_applicants,
            SUM(CASE WHEN application_status = 'hired' THEN 1 ELSE 0 END) as hired,
            SUM(CASE WHEN application_status = 'rejected' THEN 1 ELSE 0 END) as rejected,
            SUM(CASE WHEN application_status = 'shortlisted' THEN 1 ELSE 0 END) as shortlisted
        FROM applicants
        WHERE DATE(applied_at) BETWEEN ? AND ? 
        AND is_active = 1
    ";
    try {
        $stmt = $connections->prepare($query);
        $stmt->execute([$start_date, $end_date]);
        $result = $stmt->fetch();
        return $result ?: ['total_applicants' => 0, 'new_applicants' => 0, 'hired' => 0, 'rejected' => 0, 'shortlisted' => 0];
    } catch (Exception $e) {
        error_log("Error in getRecruitmentDashboardStats: " . $e->getMessage());
        return ['total_applicants' => 0, 'new_applicants' => 0, 'hired' => 0, 'rejected' => 0, 'shortlisted' => 0];
    }
}

// Function to get department breakdown from your database
function getDepartmentBreakdownDashboard($connections) {
    $query = "
        SELECT 
            d.name as department,
            COUNT(e.id) as employee_count,
            SUM(CASE WHEN e.status = 'Active' THEN 1 ELSE 0 END) as active,
            COALESCE(AVG(ed.basic_salary), 0) as avg_salary
        FROM departments d
        LEFT JOIN employees e ON d.id = e.department_id
        LEFT JOIN employment_details ed ON e.id = ed.employee_id
        GROUP BY d.id, d.name
        ORDER BY employee_count DESC
    ";
    try {
        $stmt = $connections->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    } catch (Exception $e) {
        error_log("Error in getDepartmentBreakdownDashboard: " . $e->getMessage());
        return [];
    }
}

// Function to get onboarding status from your onboarding table
function getOnboardingDashboardStats($connections) {
    $query = "
        SELECT 
            status,
            COUNT(*) as count,
            CASE status
                WHEN 'pending' THEN 'bg-yellow-100 text-yellow-800'
                WHEN 'onboarding' THEN 'bg-blue-100 text-blue-800'
                WHEN 'completed' THEN 'bg-green-100 text-green-800'
                WHEN 'cancelled' THEN 'bg-red-100 text-red-800'
                ELSE 'bg-gray-100 text-gray-800'
            END as badge_class
        FROM onboarding
        WHERE status IS NOT NULL
        GROUP BY status
        ORDER BY FIELD(status, 'onboarding', 'pending', 'completed', 'cancelled')
    ";
    try {
        $stmt = $connections->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    } catch (Exception $e) {
        error_log("Error in getOnboardingDashboardStats: " . $e->getMessage());
        return [];
    }
}

// Function to get monthly hires from your database
function getMonthlyHiresDashboard($connections) {
    $query = "
        SELECT 
            DATE_FORMAT(hire_date, '%Y-%m') as month,
            COUNT(*) as hire_count
        FROM employees
        WHERE hire_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
        AND status IN ('Active', 'On Leave')
        GROUP BY DATE_FORMAT(hire_date, '%Y-%m')
        ORDER BY month
    ";
    try {
        $stmt = $connections->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    } catch (Exception $e) {
        error_log("Error in getMonthlyHiresDashboard: " . $e->getMessage());
        return [];
    }
}

// Function to get job posting stats from your database
function getJobPostingDashboardStats($connections) {
    $query = "
        SELECT 
            status,
            COUNT(*) as count,
            SUM(vacancies) as total_vacancies,
            SUM(filled_positions) as filled_positions,
            SUM(applications_count) as total_applications
        FROM job_postings
        WHERE status IN ('active', 'draft', 'closed')
        GROUP BY status
    ";
    try {
        $stmt = $connections->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    } catch (Exception $e) {
        error_log("Error in getJobPostingDashboardStats: " . $e->getMessage());
        return [];
    }
}

// Function to get recent activity from your activity_logs table
function getRecentActivityDashboard($connections) {
    $query = "
        SELECT 
            al.description,
            al.action,
            al.created_at,
            u.full_name
        FROM activity_logs al
        LEFT JOIN users u ON al.user_id = u.id
        WHERE al.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
        ORDER BY al.created_at DESC
        LIMIT 10
    ";
    try {
        $stmt = $connections->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    } catch (Exception $e) {
        error_log("Error in getRecentActivityDashboard: " . $e->getMessage());
        return [];
    }
}

// Function to get turnover rate from your database
function getTurnoverDashboardStats($connections, $start_date, $end_date) {
    $query = "
        SELECT 
            (SELECT COUNT(*) FROM employees WHERE status = 'Terminated' AND DATE(updated_at) BETWEEN ? AND ?) as terminated_count,
            (SELECT COUNT(*) FROM employees WHERE status = 'Active') as active_count,
            (SELECT COUNT(*) FROM employees WHERE hire_date BETWEEN ? AND ?) as hired_count
    ";
    try {
        $stmt = $connections->prepare($query);
        $stmt->execute([$start_date, $end_date, $start_date, $end_date]);
        $result = $stmt->fetch();
        return $result ?: ['terminated_count' => 0, 'active_count' => 0, 'hired_count' => 0];
    } catch (Exception $e) {
        error_log("Error in getTurnoverDashboardStats: " . $e->getMessage());
        return ['terminated_count' => 0, 'active_count' => 0, 'hired_count' => 0];
    }
}

// Function to get employee status distribution for chart
function getEmployeeStatusDistribution($connections) {
    $query = "
        SELECT 
            status,
            COUNT(*) as count
        FROM employees
        WHERE status IN ('Active', 'Inactive', 'On Leave', 'Terminated')
        GROUP BY status
    ";
    try {
        $stmt = $connections->prepare($query);
        $stmt->execute();
        $result = $stmt->fetchAll();
        
        // Format for Chart.js
        $data = [
            'labels' => [],
            'data' => [],
            'colors' => []
        ];
        
        foreach ($result as $row) {
            $data['labels'][] = $row['status'];
            $data['data'][] = $row['count'];
            
            // Assign colors based on status
            switch ($row['status']) {
                case 'Active':
                    $data['colors'][] = '#10b981'; // green
                    break;
                case 'On Leave':
                    $data['colors'][] = '#3b82f6'; // blue
                    break;
                case 'Inactive':
                    $data['colors'][] = '#f59e0b'; // yellow
                    break;
                case 'Terminated':
                    $data['colors'][] = '#ef4444'; // red
                    break;
                default:
                    $data['colors'][] = '#6b7280'; // gray
            }
        }
        
        return $data;
    } catch (Exception $e) {
        error_log("Error in getEmployeeStatusDistribution: " . $e->getMessage());
        return ['labels' => [], 'data' => [], 'colors' => []];
    }
}

// Function to get recent hires (last 30 days) - KEEP THIS ONE (not in functions.php)
function getRecentHires($connections) {
    $query = "
        SELECT 
            e.employee_id,
            CONCAT(e.first_name, ' ', e.last_name) as full_name,
            d.name as department,
            ed.job_title,
            e.hire_date
        FROM employees e
        LEFT JOIN departments d ON e.department_id = d.id
        LEFT JOIN employment_details ed ON e.id = ed.employee_id
        WHERE e.hire_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
        AND e.status = 'Active'
        ORDER BY e.hire_date DESC
        LIMIT 10
    ";
    try {
        $stmt = $connections->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    } catch (Exception $e) {
        error_log("Error in getRecentHires: " . $e->getMessage());
        return [];
    }
}

// Function to get employee count by employment type - KEEP THIS ONE (not in functions.php)
function getEmploymentTypeStats($connections) {
    $query = "
        SELECT 
            ed.employment_type,
            COUNT(*) as count
        FROM employees e
        INNER JOIN employment_details ed ON e.id = ed.employee_id
        WHERE e.status = 'Active'
        GROUP BY ed.employment_type
    ";
    try {
        $stmt = $connections->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    } catch (Exception $e) {
        error_log("Error in getEmploymentTypeStats: " . $e->getMessage());
        return [];
    }
}

// Fallback functions if they don't exist in functions.php
if (!function_exists('getGenderDistribution')) {
    function getGenderDistribution($connections) {
        $query = "
            SELECT 
                gender,
                COUNT(*) as count
            FROM employees
            WHERE status = 'Active'
            GROUP BY gender
        ";
        try {
            $stmt = $connections->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error in getGenderDistribution: " . $e->getMessage());
            return [];
        }
    }
}

if (!function_exists('getJobRequestStats')) {
    function getJobRequestStats($status, $connections) {
        $query = "
            SELECT 
                overall_status as status,
                COUNT(*) as count
            FROM job_requests
            WHERE overall_status IN ('approved', 'pending', 'rejected')
            GROUP BY overall_status
        ";
        try {
            $stmt = $connections->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error in getJobRequestStats: " . $e->getMessage());
            return [];
        }
    }
}

if (!function_exists('getUpcomingBirthdays')) {
    function getUpcomingBirthdays($connections, $limit = 10) {
        $query = "
            SELECT 
                CONCAT(e.first_name, ' ', e.last_name) as full_name,
                e.date_of_birth,
                d.name as department
            FROM employees e
            LEFT JOIN departments d ON e.department_id = d.id
            WHERE e.status = 'Active'
            AND DAYOFYEAR(e.date_of_birth) >= DAYOFYEAR(CURDATE())
            AND DAYOFYEAR(e.date_of_birth) <= DAYOFYEAR(DATE_ADD(CURDATE(), INTERVAL 30 DAY))
            ORDER BY DAYOFYEAR(e.date_of_birth)
            LIMIT ?
        ";
        try {
            $stmt = $connections->prepare($query);
            $stmt->execute([$limit]);
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error in getUpcomingBirthdays: " . $e->getMessage());
            return [];
        }
    }
}

// Fetch all statistics
try {
    $employee_stats = getEmployeeDashboardStats($connections);
    $recruitment_stats = getRecruitmentDashboardStats($connections, $start_date, $end_date);
    $department_breakdown = getDepartmentBreakdownDashboard($connections);
    $onboarding_stats = getOnboardingDashboardStats($connections);
    $monthly_hires = getMonthlyHiresDashboard($connections);
    $job_posting_stats = getJobPostingDashboardStats($connections);
    $recent_activity = getRecentActivityDashboard($connections);
    $turnover_stats = getTurnoverDashboardStats($connections, $start_date, $end_date);
    $employee_status_dist = getEmployeeStatusDistribution($connections);
    
    // Use functions
    $gender_dist = getGenderDistribution($connections);
    $job_request_stats = getJobRequestStats(null, $connections);
    $recent_hires = getRecentHires($connections);
    $upcoming_birthdays = getUpcomingBirthdays($connections, 10);
    $employment_type_stats = getEmploymentTypeStats($connections);
    
    // Calculate totals
    $total_onboarding = 0;
    $onboarding_in_progress = 0;
    if (!empty($onboarding_stats)) {
        foreach ($onboarding_stats as $stat) {
            $total_onboarding += $stat['count'];
            if ($stat['status'] == 'onboarding') {
                $onboarding_in_progress = $stat['count'];
            }
        }
    }
    
    // Calculate turnover rate
    $turnover_rate = 0;
    if (isset($turnover_stats['active_count']) && $turnover_stats['active_count'] > 0) {
        $turnover_rate = ($turnover_stats['terminated_count'] / $turnover_stats['active_count']) * 100;
    }
    
    // Calculate recruitment totals
    $total_recruitment = $recruitment_stats['total_applicants'] ?? 0;
    $total_hired = $recruitment_stats['hired'] ?? 0;
    
    // Debug: Check if data is being fetched
    error_log("Employee Stats: " . print_r($employee_stats, true));
    error_log("Recruitment Stats: " . print_r($recruitment_stats, true));
    error_log("Recruitment Stats is array: " . (is_array($recruitment_stats) ? 'yes' : 'no'));
    error_log("Recruitment Stats type: " . gettype($recruitment_stats));
    
} catch (Exception $e) {
    error_log("Error fetching dashboard stats: " . $e->getMessage());
    error_log("Error trace: " . $e->getTraceAsString());
    // Set default values if there's an error
    $employee_stats = ['total' => 0, 'active_count' => 0, 'inactive_count' => 0, 'on_leave_count' => 0, 'terminated_count' => 0];
    $recruitment_stats = ['total_applicants' => 0, 'new_applicants' => 0, 'hired' => 0, 'rejected' => 0, 'shortlisted' => 0];
    $department_breakdown = [];
    $onboarding_stats = [];
    $monthly_hires = [];
    $job_posting_stats = [];
    $recent_activity = [];
    $turnover_stats = ['terminated_count' => 0, 'active_count' => 0, 'hired_count' => 0];
    $employee_status_dist = ['labels' => [], 'data' => [], 'colors' => []];
    $gender_dist = [];
    $job_request_stats = [];
    $recent_hires = [];
    $upcoming_birthdays = [];
    $employment_type_stats = [];
    $total_onboarding = 0;
    $onboarding_in_progress = 0;
    $turnover_rate = 0;
    $total_recruitment = 0;
    $total_hired = 0;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>HR1 - Reports Dashboard</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
    .progress-bar {
        transition: width 0.5s ease-in-out;
    }
    .chart-container {
        position: relative;
        height: 300px;
    }
    .stat-card:hover {
        transform: translateY(-2px);
        transition: transform 0.2s ease-in-out;
    }
</style>
</head>

<body class="h-screen bg-gray-100 font-sans">
<div class="flex h-full">
  
  <!-- Sidebar -->
  <?php include 'sidebar.php'; ?>
  
  <!-- Main Content -->
  <div class="flex-1 flex flex-col overflow-y-auto">
    <main class="p-6 space-y-6">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-gray-300 pb-4">
        <div>
          <h2 class="text-2xl font-bold text-gray-800">HR Analytics Dashboard</h2>
          <p class="text-sm text-gray-600">Real-time HR metrics and reports</p>
        </div>
        <div class="flex items-center space-x-4">
          <div class="flex items-center space-x-2">
            <button onclick="exportToExcel()" class="flex items-center space-x-2 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
              <i data-lucide="download" class="w-4 h-4"></i>
              <span>Export</span>
            </button>
          </div>
          <?php include 'profile_dropdown.php'; ?>
        </div>
      </div>

      <!-- Date Filter -->
      <div class="bg-white p-4 rounded-lg shadow border">
        <form method="GET" class="flex items-center space-x-4">
          <div>
            <label class="block text-sm font-medium text-gray-700">Start Date</label>
            <input type="date" name="start_date" value="<?php echo htmlspecialchars($start_date); ?>" 
                   class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700">End Date</label>
            <input type="date" name="end_date" value="<?php echo htmlspecialchars($end_date); ?>" 
                   class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700">Report Type</label>
            <select name="type" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
              <option value="overview" <?php echo $report_type == 'overview' ? 'selected' : ''; ?>>Overview</option>
              <option value="recruitment" <?php echo $report_type == 'recruitment' ? 'selected' : ''; ?>>Recruitment</option>
              <option value="employee" <?php echo $report_type == 'employee' ? 'selected' : ''; ?>>Employee Analytics</option>
              <option value="onboarding" <?php echo $report_type == 'onboarding' ? 'selected' : ''; ?>>Onboarding</option>
            </select>
          </div>
          <div class="pt-5">
            <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
              Apply Filters
            </button>
          </div>
          <div class="pt-5">
            <a href="reports.php" class="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300">
              Reset
            </a>
          </div>
        </form>
      </div>

      <!-- Overview Stats -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div class="bg-white p-6 rounded-lg shadow border stat-card">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-600">Total Employees</p>
              <p class="text-2xl font-bold text-gray-800"><?php echo is_array($employee_stats) ? ($employee_stats['total'] ?? 0) : 0; ?></p>
              <p class="text-xs text-green-600 mt-1">
                <i data-lucide="trending-up" class="w-3 h-3 inline"></i>
                <?php echo is_array($employee_stats) ? ($employee_stats['active_count'] ?? 0) : 0; ?> active
              </p>
            </div>
            <i data-lucide="users" class="w-8 h-8 text-blue-500"></i>
          </div>
        </div>
        
        <div class="bg-white p-6 rounded-lg shadow border stat-card">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-600">Job Applications</p>
              <p class="text-2xl font-bold text-gray-800"><?php echo $total_recruitment; ?></p>
              <p class="text-xs text-blue-600 mt-1">
                <i data-lucide="user-plus" class="w-3 h-3 inline"></i>
                <?php echo $total_hired; ?> hired
              </p>
            </div>
            <i data-lucide="user-check" class="w-8 h-8 text-green-500"></i>
          </div>
        </div>
        
        <div class="bg-white p-6 rounded-lg shadow border stat-card">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-600">Onboarding</p>
              <p class="text-2xl font-bold text-gray-800"><?php echo $total_onboarding; ?></p>
              <p class="text-xs text-yellow-600 mt-1">
                <i data-lucide="clock" class="w-3 h-3 inline"></i>
                <?php echo $onboarding_in_progress; ?> in progress
              </p>
            </div>
            <i data-lucide="clipboard-check" class="w-8 h-8 text-yellow-500"></i>
          </div>
        </div>
        
        <div class="bg-white p-6 rounded-lg shadow border stat-card">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-600">Turnover Rate</p>
              <p class="text-2xl font-bold text-gray-800"><?php echo number_format($turnover_rate, 1); ?>%</p>
              <p class="text-xs <?php echo $turnover_rate > 10 ? 'text-red-600' : 'text-green-600'; ?> mt-1">
                <?php echo is_array($turnover_stats) ? ($turnover_stats['terminated_count'] ?? 0) : 0; ?> terminated
              </p>
            </div>
            <i data-lucide="refresh-cw" class="w-8 h-8 <?php echo $turnover_rate > 10 ? 'text-red-500' : 'text-green-500'; ?>"></i>
          </div>
        </div>
      </div>

      <!-- Tabs -->
      <div class="bg-white rounded-lg shadow">
        <div class="border-b">
          <nav class="flex -mb-px">
            <a href="?type=overview&start_date=<?php echo $start_date; ?>&end_date=<?php echo $end_date; ?>" 
               class="py-4 px-6 border-b-2 font-medium text-sm 
               <?php echo $report_type == 'overview' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'; ?>">
              Overview
            </a>
            <a href="?type=recruitment&start_date=<?php echo $start_date; ?>&end_date=<?php echo $end_date; ?>" 
               class="py-4 px-6 border-b-2 font-medium text-sm 
               <?php echo $report_type == 'recruitment' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'; ?>">
              Recruitment
            </a>
            <a href="?type=employee&start_date=<?php echo $start_date; ?>&end_date=<?php echo $end_date; ?>" 
               class="py-4 px-6 border-b-2 font-medium text-sm 
               <?php echo $report_type == 'employee' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'; ?>">
              Employee Analytics
            </a>
            <a href="?type=onboarding&start_date=<?php echo $start_date; ?>&end_date=<?php echo $end_date; ?>" 
               class="py-4 px-6 border-b-2 font-medium text-sm 
               <?php echo $report_type == 'onboarding' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'; ?>">
              Onboarding
            </a>
          </nav>
        </div>

        <!-- Report Content -->
        <div class="p-6">
          <?php if ($report_type == 'overview'): ?>
            <!-- Overview Tab -->
            <div class="space-y-6">
              <!-- Charts Row -->
              <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <!-- Employee Status Chart -->
                <div class="bg-white p-6 rounded-lg shadow border">
                  <h3 class="text-lg font-semibold text-gray-800 mb-4">Employee Status Distribution</h3>
                  <div class="chart-container">
                    <canvas id="employeeStatusChart"></canvas>
                  </div>
                </div>
                
                <!-- Gender Distribution Chart -->
                <div class="bg-white p-6 rounded-lg shadow border">
                  <h3 class="text-lg font-semibold text-gray-800 mb-4">Gender Distribution (Active)</h3>
                  <div class="chart-container">
                    <canvas id="genderDistributionChart"></canvas>
                  </div>
                </div>
              </div>
              
              <!-- Department Breakdown -->
              <div class="bg-white p-6 rounded-lg shadow border">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Department Overview</h3>
                <div class="overflow-x-auto">
                  <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                      <tr>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Department</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Total Employees</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Active</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">On Leave</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Avg Salary</th>
                      </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                      <?php if (!empty($department_breakdown)): ?>
                        <?php foreach ($department_breakdown as $dept): ?>
                          <?php 
                            // Get on leave count for this department
                            $on_leave_count = 0;
                            if (isset($dept['department'])) {
                              try {
                                $leave_stmt = $connections->prepare("
                                  SELECT COUNT(*) as on_leave_count 
                                  FROM employees 
                                  WHERE department_id = (SELECT id FROM departments WHERE name = ?) 
                                  AND status = 'On Leave'
                                ");
                                $leave_stmt->execute([$dept['department']]);
                                $leave_data = $leave_stmt->fetch();
                                $on_leave_count = $leave_data['on_leave_count'] ?? 0;
                              } catch (Exception $e) {
                                error_log("Error getting leave count: " . $e->getMessage());
                              }
                            }
                          ?>
                          <tr>
                            <td class="px-4 py-3 text-sm font-medium text-gray-900"><?php echo htmlspecialchars($dept['department'] ?? 'N/A'); ?></td>
                            <td class="px-4 py-3 text-sm text-gray-500"><?php echo $dept['employee_count'] ?? 0; ?></td>
                            <td class="px-4 py-3">
                              <span class="px-2 py-1 text-xs rounded-full bg-green-100 text-green-800">
                                <?php echo $dept['active'] ?? 0; ?>
                              </span>
                            </td>
                            <td class="px-4 py-3">
                              <span class="px-2 py-1 text-xs rounded-full bg-blue-100 text-blue-800">
                                <?php echo $on_leave_count; ?>
                              </span>
                            </td>
                            <td class="px-4 py-3 text-sm text-gray-900">
                              ₱<?php echo number_format($dept['avg_salary'] ?? 0, 2); ?>
                            </td>
                          </tr>
                        <?php endforeach; ?>
                      <?php else: ?>
                        <tr>
                          <td colspan="5" class="px-4 py-3 text-center text-gray-500">No department data available</td>
                        </tr>
                      <?php endif; ?>
                    </tbody>
                  </table>
                </div>
              </div>
              
              <!-- Monthly Hires & Recent Activity -->
              <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <!-- Monthly Hires -->
                <div class="bg-white p-6 rounded-lg shadow border">
                  <h3 class="text-lg font-semibold text-gray-800 mb-4">Monthly Hires (Last 6 Months)</h3>
                  <div class="chart-container">
                    <canvas id="monthlyHiresChart"></canvas>
                  </div>
                </div>
                
                <!-- Recent Hires -->
                <div class="bg-white p-6 rounded-lg shadow border">
                  <h3 class="text-lg font-semibold text-gray-800 mb-4">Recent Hires (Last 30 Days)</h3>
                  <div class="space-y-3">
                    <?php if (!empty($recent_hires)): ?>
                      <?php foreach ($recent_hires as $hire): ?>
                        <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div>
                            <p class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($hire['full_name'] ?? ''); ?></p>
                            <p class="text-xs text-gray-500"><?php echo htmlspecialchars($hire['job_title'] ?? ''); ?> • <?php echo htmlspecialchars($hire['department'] ?? ''); ?></p>
                          </div>
                          <div class="text-right">
                            <p class="text-sm text-gray-900"><?php echo isset($hire['hire_date']) ? date('M d', strtotime($hire['hire_date'])) : ''; ?></p>
                            <p class="text-xs text-gray-500">Hired</p>
                          </div>
                        </div>
                      <?php endforeach; ?>
                    <?php else: ?>
                      <p class="text-center text-gray-500 py-4">No recent hires</p>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
            </div>

          <?php elseif ($report_type == 'recruitment'): ?>
            <!-- Recruitment Tab -->
            <div class="space-y-6">
              <!-- Recruitment Stats -->
              <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <?php 
                // Ensure $recruitment_stats is an array
                if (!is_array($recruitment_stats)) {
                  $recruitment_stats = [];
                }
                
                $recruitment_metrics = [
                  ['title' => 'Total Applicants', 'value' => $recruitment_stats['total_applicants'] ?? 0, 'icon' => 'users', 'color' => 'blue'],
                  ['title' => 'New Applicants', 'value' => $recruitment_stats['new_applicants'] ?? 0, 'icon' => 'user-plus', 'color' => 'green'],
                  ['title' => 'Hired', 'value' => $recruitment_stats['hired'] ?? 0, 'icon' => 'user-check', 'color' => 'purple'],
                  ['title' => 'Shortlisted', 'value' => $recruitment_stats['shortlisted'] ?? 0, 'icon' => 'clipboard-check', 'color' => 'yellow'],
                ];
                foreach ($recruitment_metrics as $metric): ?>
                  <div class="bg-white p-6 rounded-lg shadow border">
                    <div class="flex items-center justify-between">
                      <div>
                        <p class="text-sm text-gray-600"><?php echo $metric['title']; ?></p>
                        <p class="text-2xl font-bold text-gray-800"><?php echo $metric['value']; ?></p>
                      </div>
                      <i data-lucide="<?php echo $metric['icon']; ?>" class="w-8 h-8 text-<?php echo $metric['color']; ?>-500"></i>
                    </div>
                  </div>
                <?php endforeach; ?>
              </div>
              
              <!-- Job Posting Stats -->
              <div class="bg-white p-6 rounded-lg shadow border">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Job Posting Status</h3>
                <div class="overflow-x-auto">
                  <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                      <tr>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Postings</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Total Vacancies</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Filled Positions</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Applications</th>
                      </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                      <?php if (!empty($job_posting_stats)): ?>
                        <?php foreach ($job_posting_stats as $job_stat): ?>
                          <tr>
                            <td class="px-4 py-3">
                              <span class="px-3 py-1 text-xs rounded-full 
                                <?php echo ($job_stat['status'] ?? '') == 'active' ? 'bg-green-100 text-green-800' : 
                                       (($job_stat['status'] ?? '') == 'draft' ? 'bg-yellow-100 text-yellow-800' : 
                                       'bg-gray-100 text-gray-800'); ?>">
                                <?php echo ucfirst($job_stat['status'] ?? ''); ?>
                              </span>
                            </td>
                            <td class="px-4 py-3 text-sm text-gray-900"><?php echo $job_stat['count'] ?? 0; ?></td>
                            <td class="px-4 py-3 text-sm text-gray-900"><?php echo $job_stat['total_vacancies'] ?? 0; ?></td>
                            <td class="px-4 py-3 text-sm text-gray-900"><?php echo $job_stat['filled_positions'] ?? 0; ?></td>
                            <td class="px-4 py-3 text-sm text-gray-900"><?php echo $job_stat['total_applications'] ?? 0; ?></td>
                          </tr>
                        <?php endforeach; ?>
                      <?php else: ?>
                        <tr>
                          <td colspan="5" class="px-4 py-3 text-center text-gray-500">No job posting data available</td>
                        </tr>
                      <?php endif; ?>
                    </tbody>
                  </table>
                </div>
              </div>
              
              <!-- Job Request Stats -->
              <div class="bg-white p-6 rounded-lg shadow border">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Job Request Status</h3>
                <div class="overflow-x-auto">
                  <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                      <tr>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Count</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Percentage</th>
                      </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                      <?php if (!empty($job_request_stats)): ?>
                        <?php 
                        $total_requests = 0;
                        foreach ($job_request_stats as $stat) {
                          $total_requests += $stat['count'] ?? 0;
                        }
                        foreach ($job_request_stats as $stat): 
                          $percentage = $total_requests > 0 ? (($stat['count'] ?? 0) / $total_requests) * 100 : 0;
                        ?>
                          <tr>
                            <td class="px-4 py-3">
                              <span class="px-3 py-1 text-xs rounded-full 
                                <?php echo ($stat['status'] ?? '') == 'approved' ? 'bg-green-100 text-green-800' : 
                                       (($stat['status'] ?? '') == 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                                       (($stat['status'] ?? '') == 'rejected' ? 'bg-red-100 text-red-800' : 
                                       'bg-gray-100 text-gray-800')); ?>">
                                <?php echo ucfirst($stat['status'] ?? ''); ?>
                              </span>
                            </td>
                            <td class="px-4 py-3 text-sm text-gray-900"><?php echo $stat['count'] ?? 0; ?></td>
                            <td class="px-4 py-3 text-sm text-gray-900"><?php echo number_format($percentage, 1); ?>%</td>
                          </tr>
                        <?php endforeach; ?>
                      <?php else: ?>
                        <tr>
                          <td colspan="3" class="px-4 py-3 text-center text-gray-500">No job request data available</td>
                        </tr>
                      <?php endif; ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

          <?php elseif ($report_type == 'employee'): ?>
            <!-- Employee Analytics Tab -->
            <div class="space-y-6">
              <!-- Employment Type Distribution -->
              <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Employee Status Details -->
                <div class="bg-white p-6 rounded-lg shadow border">
                  <h3 class="text-lg font-semibold text-gray-800 mb-4">Employee Status</h3>
                  <div class="space-y-4">
                    <?php 
                    // Ensure $employee_stats is an array
                    if (!is_array($employee_stats)) {
                      $employee_stats = ['total' => 0, 'active_count' => 0, 'inactive_count' => 0, 'on_leave_count' => 0, 'terminated_count' => 0];
                    }
                    
                    $status_data = [
                      ['status' => 'Active', 'count' => $employee_stats['active_count'] ?? 0, 'color' => 'green'],
                      ['status' => 'On Leave', 'count' => $employee_stats['on_leave_count'] ?? 0, 'color' => 'blue'],
                      ['status' => 'Inactive', 'count' => $employee_stats['inactive_count'] ?? 0, 'color' => 'yellow'],
                      ['status' => 'Terminated', 'count' => $employee_stats['terminated_count'] ?? 0, 'color' => 'red'],
                    ];
                    $total_employees = $employee_stats['total'] ?? 1;
                    foreach ($status_data as $status): 
                      $percentage = $total_employees > 0 ? ($status['count'] / $total_employees) * 100 : 0;
                    ?>
                      <div>
                        <div class="flex justify-between mb-1">
                          <span class="text-sm font-medium text-gray-700"><?php echo $status['status']; ?></span>
                          <span class="text-sm font-medium text-gray-900"><?php echo $status['count']; ?> (<?php echo number_format($percentage, 1); ?>%)</span>
                        </div>
                        <div class="w-full bg-gray-200 rounded-full h-2">
                          <div class="bg-<?php echo $status['color']; ?>-500 h-2 rounded-full progress-bar" 
                               style="width: <?php echo $percentage; ?>%"></div>
                        </div>
                      </div>
                    <?php endforeach; ?>
                  </div>
                </div>
                
                <!-- Employment Type Distribution -->
                <div class="bg-white p-6 rounded-lg shadow border">
                  <h3 class="text-lg font-semibold text-gray-800 mb-4">Employment Type Distribution</h3>
                  <div class="space-y-4">
                    <?php if (!empty($employment_type_stats)): ?>
                      <?php 
                      $total_employment = 0;
                      foreach ($employment_type_stats as $stat) {
                        $total_employment += $stat['count'] ?? 0;
                      }
                      foreach ($employment_type_stats as $stat): 
                        $percentage = $total_employment > 0 ? (($stat['count'] ?? 0) / $total_employment) * 100 : 0;
                      ?>
                        <div>
                          <div class="flex justify-between mb-1">
                            <span class="text-sm font-medium text-gray-700"><?php echo $stat['employment_type'] ?? ''; ?></span>
                            <span class="text-sm font-medium text-gray-900"><?php echo $stat['count'] ?? 0; ?> (<?php echo number_format($percentage, 1); ?>%)</span>
                          </div>
                          <div class="w-full bg-gray-200 rounded-full h-2">
                            <div class="bg-blue-500 h-2 rounded-full progress-bar" 
                                 style="width: <?php echo $percentage; ?>%"></div>
                          </div>
                        </div>
                      <?php endforeach; ?>
                    <?php else: ?>
                      <p class="text-center text-gray-500">No employment type data available</p>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
              
              <!-- Recent Activity -->
              <div class="bg-white p-6 rounded-lg shadow border">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Recent Activity</h3>
                <div class="space-y-4">
                  <?php if (!empty($recent_activity)): ?>
                    <?php foreach ($recent_activity as $activity): ?>
                      <div class="flex items-start space-x-3">
                        <div class="flex-shrink-0">
                          <div class="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                            <i data-lucide="activity" class="w-4 h-4 text-blue-600"></i>
                          </div>
                        </div>
                        <div class="flex-1">
                          <p class="text-sm text-gray-900"><?php echo htmlspecialchars($activity['description'] ?? 'No description'); ?></p>
                          <p class="text-xs text-gray-500">
                            <?php echo htmlspecialchars($activity['full_name'] ?? 'System'); ?> • 
                            <?php echo isset($activity['created_at']) ? date('M d, Y H:i', strtotime($activity['created_at'])) : ''; ?>
                          </p>
                        </div>
                      </div>
                    <?php endforeach; ?>
                  <?php else: ?>
                    <p class="text-sm text-gray-500 text-center">No recent activity</p>
                  <?php endif; ?>
                </div>
              </div>
              
              <!-- Upcoming Birthdays -->
              <div class="bg-white p-6 rounded-lg shadow border">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Upcoming Birthdays (Next 30 Days)</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <?php if (!empty($upcoming_birthdays)): ?>
                    <?php foreach ($upcoming_birthdays as $birthday): 
                      if (isset($birthday['date_of_birth'])) {
                        $birthday_date = new DateTime($birthday['date_of_birth']);
                        $today = new DateTime();
                        $birthday_this_year = new DateTime($today->format('Y') . '-' . $birthday_date->format('m-d'));
                        if ($birthday_this_year < $today) {
                          $birthday_this_year->modify('+1 year');
                        }
                        $days_until = $today->diff($birthday_this_year)->days;
                      } else {
                        $days_until = 0;
                      }
                    ?>
                      <div class="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                        <div class="flex-shrink-0">
                          <div class="w-10 h-10 rounded-full bg-pink-100 flex items-center justify-center">
                            <i data-lucide="cake" class="w-5 h-5 text-pink-600"></i>
                          </div>
                        </div>
                        <div class="flex-1">
                          <p class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($birthday['full_name'] ?? ''); ?></p>
                          <p class="text-xs text-gray-500"><?php echo htmlspecialchars($birthday['department'] ?? ''); ?></p>
                        </div>
                        <div class="text-right">
                          <p class="text-sm font-medium text-gray-900"><?php echo isset($birthday['date_of_birth']) ? date('M d', strtotime($birthday['date_of_birth'])) : ''; ?></p>
                          <p class="text-xs text-gray-500"><?php echo $days_until; ?> days</p>
                        </div>
                      </div>
                    <?php endforeach; ?>
                  <?php else: ?>
                    <div class="col-span-3 text-center py-4 text-gray-500">
                      No upcoming birthdays in the next 30 days
                    </div>
                  <?php endif; ?>
                </div>
              </div>
            </div>

          <?php elseif ($report_type == 'onboarding'): ?>
            <!-- Onboarding Tab -->
            <div class="space-y-6">
              <!-- Onboarding Stats -->
              <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <?php if (!empty($onboarding_stats)): ?>
                  <?php foreach ($onboarding_stats as $stat): ?>
                    <div class="bg-white p-6 rounded-lg shadow border">
                      <div class="flex items-center justify-between">
                        <div>
                          <p class="text-sm text-gray-600"><?php echo ucfirst($stat['status'] ?? ''); ?></p>
                          <p class="text-2xl font-bold text-gray-800"><?php echo $stat['count'] ?? 0; ?></p>
                        </div>
                        <span class="px-3 py-1 text-xs rounded-full <?php echo $stat['badge_class'] ?? 'bg-gray-100 text-gray-800'; ?>">
                          <?php 
                            $total_onboarding = 0;
                            foreach ($onboarding_stats as $s) {
                              $total_onboarding += $s['count'] ?? 0;
                            }
                            $percentage = $total_onboarding > 0 ? (($stat['count'] ?? 0) / $total_onboarding) * 100 : 0;
                            echo number_format($percentage, 0) . '%';
                          ?>
                        </span>
                      </div>
                    </div>
                  <?php endforeach; ?>
                <?php else: ?>
                  <div class="col-span-4 text-center py-6 text-gray-500">
                    No onboarding data available
                  </div>
                <?php endif; ?>
              </div>
              
              <!-- Onboarding Progress -->
              <div class="bg-white p-6 rounded-lg shadow border">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Onboarding Progress</h3>
                <div class="overflow-x-auto">
                  <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                      <tr>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Employee</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Position</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Start Date</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Progress</th>
                      </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                      <?php 
                      // Get onboarding list with more details
                      try {
                        $onboarding_list = $connections->query("
                          SELECT 
                            o.employee_id,
                            o.first_name,
                            o.last_name,
                            o.job_position,
                            o.hire_date,
                            o.status,
                            o.contract_status,
                            o.created_at
                          FROM onboarding o
                          WHERE o.status IS NOT NULL
                          ORDER BY o.created_at DESC 
                          LIMIT 15
                        ")->fetchAll();
                        
                        if (!empty($onboarding_list)) {
                          foreach ($onboarding_list as $onboard): 
                            // Calculate progress based on status
                            if (($onboard['status'] ?? '') == 'completed') {
                              $progress = 100;
                            } elseif (($onboard['status'] ?? '') == 'onboarding') {
                              $progress = 60;
                            } elseif (($onboard['status'] ?? '') == 'pending') {
                              $progress = 20;
                            } else {
                              $progress = 0;
                            }
                          ?>
                            <tr>
                              <td class="px-4 py-3">
                                <div class="text-sm font-medium text-gray-900">
                                  <?php echo htmlspecialchars(($onboard['first_name'] ?? '') . ' ' . ($onboard['last_name'] ?? '')); ?>
                                </div>
                                <div class="text-sm text-gray-500"><?php echo $onboard['employee_id'] ?? ''; ?></div>
                              </td>
                              <td class="px-4 py-3 text-sm text-gray-900"><?php echo htmlspecialchars($onboard['job_position'] ?? ''); ?></td>
                              <td class="px-4 py-3 text-sm text-gray-500">
                                <?php echo isset($onboard['hire_date']) ? date('M d, Y', strtotime($onboard['hire_date'])) : ''; ?>
                              </td>
                              <td class="px-4 py-3">
                                <span class="px-3 py-1 text-xs rounded-full 
                                  <?php echo ($onboard['status'] ?? '') == 'onboarding' ? 'bg-blue-100 text-blue-800' : 
                                         (($onboard['status'] ?? '') == 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                                         (($onboard['status'] ?? '') == 'completed' ? 'bg-green-100 text-green-800' : 
                                         'bg-gray-100 text-gray-800')); ?>">
                                  <?php echo ucfirst($onboard['status'] ?? ''); ?>
                                </span>
                              </td>
                              <td class="px-4 py-3">
                                <div class="flex items-center">
                                  <div class="w-full bg-gray-200 rounded-full h-2 mr-2">
                                    <div class="bg-blue-500 h-2 rounded-full progress-bar" style="width: <?php echo $progress; ?>%"></div>
                                  </div>
                                  <span class="text-xs text-gray-600"><?php echo $progress; ?>%</span>
                                </div>
                              </td>
                            </tr>
                          <?php endforeach; 
                        } else { ?>
                          <tr>
                            <td colspan="5" class="px-4 py-3 text-center text-gray-500">No onboarding records found</td>
                          </tr>
                        <?php }
                      } catch (Exception $e) { ?>
                        <tr>
                          <td colspan="5" class="px-4 py-3 text-center text-gray-500">Error loading onboarding data</td>
                        </tr>
                      <?php } ?>
                    </tbody>
                  </table>
                </div>
              </div>
              
              <!-- Contract Status -->
              <div class="bg-white p-6 rounded-lg shadow border">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Contract Status</h3>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <?php 
                  // Get contract status distribution
                  try {
                    $contract_status_stmt = $connections->prepare("
                      SELECT 
                        contract_status,
                        COUNT(*) as count
                      FROM onboarding
                      WHERE contract_status IS NOT NULL
                      GROUP BY contract_status
                      ORDER BY FIELD(contract_status, 'Pending HR', 'HR Approved', 'Manager Approved', 'Completed', 'Rejected')
                    ");
                    $contract_status_stmt->execute();
                    $contract_statuses = $contract_status_stmt->fetchAll();
                    
                    $contract_colors = [
                      'Pending HR' => 'bg-yellow-100 text-yellow-800',
                      'HR Approved' => 'bg-blue-100 text-blue-800',
                      'Manager Approved' => 'bg-indigo-100 text-indigo-800',
                      'Completed' => 'bg-green-100 text-green-800',
                      'Rejected' => 'bg-red-100 text-red-800'
                    ];
                    
                    foreach ($contract_statuses as $contract): ?>
                      <div class="text-center p-4 bg-gray-50 rounded-lg">
                        <p class="text-sm text-gray-600"><?php echo $contract['contract_status'] ?? ''; ?></p>
                        <p class="text-2xl font-bold text-gray-800 mt-2"><?php echo $contract['count'] ?? 0; ?></p>
                        <span class="inline-block mt-2 px-3 py-1 text-xs rounded-full <?php echo isset($contract['contract_status']) ? ($contract_colors[$contract['contract_status']] ?? 'bg-gray-100 text-gray-800') : 'bg-gray-100 text-gray-800'; ?>">
                          Contracts
                        </span>
                      </div>
                    <?php endforeach;
                    
                    if (empty($contract_statuses)): ?>
                      <div class="col-span-3 text-center py-4 text-gray-500">
                        No contract status data available
                      </div>
                    <?php endif;
                    
                  } catch (Exception $e) { ?>
                    <div class="col-span-3 text-center py-4 text-gray-500">
                      Error loading contract status data
                    </div>
                  <?php } ?>
                </div>
              </div>
            </div>
          <?php endif; ?>
        </div>
      </div>

      <!-- Summary -->
      <div class="bg-white p-6 rounded-lg shadow border">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">Report Summary</h3>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <h4 class="font-medium text-gray-700 mb-2">Period</h4>
            <p class="text-gray-900"><?php echo date('F d, Y', strtotime($start_date)); ?> to <?php echo date('F d, Y', strtotime($end_date)); ?></p>
          </div>
          <div>
            <h4 class="font-medium text-gray-700 mb-2">Report Generated</h4>
            <p class="text-gray-900"><?php echo date('F d, Y H:i:s'); ?></p>
          </div>
          <div>
            <h4 class="font-medium text-gray-700 mb-2">Generated By</h4>
            <p class="text-gray-900"><?php echo htmlspecialchars($_SESSION['user_name'] ?? 'System'); ?></p>
          </div>
        </div>
      </div>
    </main>
  </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
  lucide.createIcons();
  
  // Initialize charts
  initializeCharts();
  
  // Add hover effects to progress bars
  document.querySelectorAll('.progress-bar').forEach(bar => {
    bar.addEventListener('mouseenter', function() {
      this.style.transform = 'scaleY(1.2)';
    });
    bar.addEventListener('mouseleave', function() {
      this.style.transform = 'scaleY(1)';
    });
  });
});

function initializeCharts() {
  // Employee Status Chart
  const employeeStatusCtx = document.getElementById('employeeStatusChart')?.getContext('2d');
  if (employeeStatusCtx) {
    const labels = <?php echo json_encode($employee_status_dist['labels'] ?? []); ?>;
    const data = <?php echo json_encode($employee_status_dist['data'] ?? []); ?>;
    const colors = <?php echo json_encode($employee_status_dist['colors'] ?? []); ?>;
    
    if (labels && labels.length > 0 && data && data.length > 0) {
      new Chart(employeeStatusCtx, {
        type: 'doughnut',
        data: {
          labels: labels,
          datasets: [{
            data: data,
            backgroundColor: colors,
            borderWidth: 1
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: 'bottom'
            }
          }
        }
      });
    } else {
      employeeStatusCtx.font = '16px Arial';
      employeeStatusCtx.fillText('No data available', 10, 50);
    }
  }
  
  // Gender Distribution Chart
  const genderDistributionCtx = document.getElementById('genderDistributionChart')?.getContext('2d');
  if (genderDistributionCtx) {
    const genderData = <?php echo json_encode($gender_dist); ?>;
    if (genderData && genderData.length > 0) {
      const genderLabels = genderData.map(item => item.gender || '');
      const genderCounts = genderData.map(item => item.count || 0);
      
      new Chart(genderDistributionCtx, {
        type: 'pie',
        data: {
          labels: genderLabels,
          datasets: [{
            data: genderCounts,
            backgroundColor: ['#3b82f6', '#ec4899', '#8b5cf6'], // blue, pink, purple
            borderWidth: 1
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: 'bottom'
            }
          }
        }
      });
    } else {
      genderDistributionCtx.font = '16px Arial';
      genderDistributionCtx.fillText('No data available', 10, 50);
    }
  }
  
  // Monthly Hires Chart
  const monthlyHiresCtx = document.getElementById('monthlyHiresChart')?.getContext('2d');
  if (monthlyHiresCtx) {
    const months = <?php echo json_encode(array_column($monthly_hires ?? [], 'month')); ?>;
    const hires = <?php echo json_encode(array_column($monthly_hires ?? [], 'hire_count')); ?>;
    
    if (months && months.length > 0 && hires && hires.length > 0) {
      // Format months for display
      const formattedMonths = months.map(month => {
        if (month) {
          const date = new Date(month + '-01');
          return date.toLocaleDateString('en-US', { month: 'short', year: '2-digit' });
        }
        return '';
      });
      
      new Chart(monthlyHiresCtx, {
        type: 'bar',
        data: {
          labels: formattedMonths,
          datasets: [{
            label: 'Hires',
            data: hires,
            backgroundColor: '#3b82f6',
            borderColor: '#2563eb',
            borderWidth: 1
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            y: {
              beginAtZero: true,
              ticks: {
                stepSize: 1
              }
            }
          },
          plugins: {
            legend: {
              display: false
            }
          }
        }
      });
    } else {
      monthlyHiresCtx.font = '16px Arial';
      monthlyHiresCtx.fillText('No data available', 10, 50);
    }
  }
}

function exportToExcel() {
  // In a real application, this would generate an Excel file
  // For now, we'll show a confirmation and redirect to a download page
  if (confirm('Export this report to Excel? The export will include all visible data.')) {
    // Create form and submit to generate Excel
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = 'export_report.php';
    
    const startDate = document.createElement('input');
    startDate.type = 'hidden';
    startDate.name = 'start_date';
    startDate.value = '<?php echo $start_date; ?>';
    
    const endDate = document.createElement('input');
    endDate.type = 'hidden';
    endDate.name = 'end_date';
    endDate.value = '<?php echo $end_date; ?>';
    
    const reportType = document.createElement('input');
    reportType.type = 'hidden';
    reportType.name = 'report_type';
    reportType.value = '<?php echo $report_type; ?>';
    
    form.appendChild(startDate);
    form.appendChild(endDate);
    form.appendChild(reportType);
    document.body.appendChild(form);
    form.submit();
  }
}
</script>
</body>
</html>