<?php
// File: provide_equipment.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: onboarding.php');
    exit();
}

$id = $_GET['id'];

$query = "SELECT o.*, d.name as department_name 
          FROM onboarding o 
          LEFT JOIN departments d ON o.department = d.id 
          WHERE o.id = ?";
$stmt = $connections->prepare($query);
$stmt->execute([$id]);
$onboarding = $stmt->fetch();

if (!$onboarding) {
    header('Location: onboarding.php');
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_equipment'])) {
        $equipment_provided = isset($_POST['equipment_provided']) ? 1 : 0;
        $equipment_laptop = $_POST['equipment_laptop'] ?? '';
        $equipment_phone = $_POST['equipment_phone'] ?? '';
        $equipment_accessories = $_POST['equipment_accessories'] ?? '';
        $uniform_size = $_POST['uniform_size'] ?? '';
        $uniform_issued = $_POST['uniform_issued'] ?? '';
        $access_card = $_POST['access_card'] ?? '';
        $equipment_notes = $_POST['equipment_notes'] ?? '';
        
        // Handle equipment photo upload
        $equipment_photo = $onboarding['equipment_photo'] ?? null;
        if (isset($_FILES['equipment_photo']) && $_FILES['equipment_photo']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = 'uploads/equipment/' . $onboarding['employee_id'] . '/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }
            
            $fileName = 'equipment_' . time() . '_' . basename($_FILES['equipment_photo']['name']);
            $targetFile = $uploadDir . $fileName;
            
            if (move_uploaded_file($_FILES['equipment_photo']['tmp_name'], $targetFile)) {
                $equipment_photo = $targetFile;
            }
        }
        
        // Handle signature upload
        $equipment_signature = $onboarding['equipment_signature'] ?? null;
        if (isset($_FILES['equipment_signature']) && $_FILES['equipment_signature']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = 'uploads/signatures/' . $onboarding['employee_id'] . '/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }
            
            $fileName = 'equipment_receipt_' . time() . '_' . basename($_FILES['equipment_signature']['name']);
            $targetFile = $uploadDir . $fileName;
            
            if (move_uploaded_file($_FILES['equipment_signature']['tmp_name'], $targetFile)) {
                $equipment_signature = $targetFile;
            }
        }
        
        $update_query = "UPDATE onboarding SET 
            equipment_provided = ?,
            equipment_laptop = ?,
            equipment_phone = ?,
            equipment_accessories = ?,
            uniform_size = ?,
            uniform_issued = ?,
            access_card = ?,
            equipment_photo = ?,
            equipment_signature = ?,
            equipment_provided_at = ?,
            equipment_notes = ?,
            notes = CONCAT(COALESCE(notes, ''), ?),
            updated_at = NOW()
            WHERE id = ?";
        
        $equipment_provided_at = $equipment_provided ? date('Y-m-d H:i:s') : null;
        $update_notes = "\n\nEquipment updated on " . date('Y-m-d H:i:s') . ": " . $equipment_notes;
        
        $update_stmt = $connections->prepare($update_query);
        $update_stmt->execute([
            $equipment_provided,
            $equipment_laptop,
            $equipment_phone,
            $equipment_accessories,
            $uniform_size,
            $uniform_issued,
            $access_card,
            $equipment_photo,
            $equipment_signature,
            $equipment_provided_at,
            $equipment_notes,
            $update_notes,
            $id
        ]);
        
        $_SESSION['success'] = "Equipment details updated!";
        header("Location: view_onboarding.php?id=$id");
        exit();
    }
}

// Decode equipment data
$equipment_accessories = !empty($onboarding['equipment_accessories']) ? json_decode($onboarding['equipment_accessories'], true) : [];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HR1 - Equipment Provision</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="bg-gray-50 min-h-screen">
    <div class="flex">
        <?php include 'sidebar.php'; ?>
        
        <div class="flex-1 p-6">
            <!-- Header -->
            <div class="flex justify-between items-center mb-6">
                <div>
                    <h1 class="text-2xl font-bold text-gray-800">Equipment Provision</h1>
                    <p class="text-gray-600">
                        <?php echo htmlspecialchars($onboarding['first_name'] . ' ' . $onboarding['last_name']); ?> - 
                        <?php echo htmlspecialchars($onboarding['job_position']); ?>
                    </p>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="view_onboarding.php?id=<?php echo $id; ?>" 
                       class="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 flex items-center">
                        <i data-lucide="arrow-left" class="w-4 h-4 mr-2"></i>
                        Back to Onboarding
                    </a>
                    <?php include 'profile_dropdown.php'; ?>
                </div>
            </div>

            <?php if (isset($_SESSION['success'])): ?>
            <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-6">
                <div class="flex items-center">
                    <i data-lucide="check-circle" class="w-5 h-5 mr-2"></i>
                    <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                </div>
            </div>
            <?php endif; ?>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <!-- Main Form -->
                <div class="lg:col-span-2">
                    <form method="POST" enctype="multipart/form-data">
                        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
                            <h2 class="text-xl font-bold text-gray-800 mb-6">IT Equipment</h2>
                            
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Laptop/Computer</label>
                                    <input type="text" name="equipment_laptop" 
                                           class="w-full border border-gray-300 rounded-lg p-2"
                                           value="<?php echo htmlspecialchars($onboarding['equipment_laptop'] ?? ''); ?>"
                                           placeholder="e.g., Dell Latitude 5420 - SN: ABC123">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Phone/Device</label>
                                    <input type="text" name="equipment_phone" 
                                           class="w-full border border-gray-300 rounded-lg p-2"
                                           value="<?php echo htmlspecialchars($onboarding['equipment_phone'] ?? ''); ?>"
                                           placeholder="e.g., iPhone 13 - 09171234567">
                                </div>
                            </div>

                            <div class="mb-6">
                                <label class="block text-sm font-medium text-gray-700 mb-2">Accessories</label>
                                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                                    <?php 
                                    $accessories_list = [
                                        'laptop_charger' => 'Laptop Charger',
                                        'mouse' => 'Mouse',
                                        'keyboard' => 'Keyboard',
                                        'headset' => 'Headset',
                                        'monitor' => 'Monitor',
                                        'docking_station' => 'Docking Station',
                                        'usb_hub' => 'USB Hub',
                                        'bag' => 'Laptop Bag',
                                        'cables' => 'Various Cables'
                                    ];
                                    
                                    foreach ($accessories_list as $key => $label):
                                        $checked = in_array($key, $equipment_accessories) ? 'checked' : '';
                                    ?>
                                    <div class="flex items-center">
                                        <input type="checkbox" name="equipment_accessories[]" value="<?php echo $key; ?>" 
                                               id="accessory_<?php echo $key; ?>"
                                               class="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                                               <?php echo $checked; ?>>
                                        <label for="accessory_<?php echo $key; ?>" class="ml-2 text-sm text-gray-700">
                                            <?php echo $label; ?>
                                        </label>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>

                        <!-- Uniform & Access -->
                        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
                            <h2 class="text-xl font-bold text-gray-800 mb-6">Uniform & Access</h2>
                            
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Uniform Size</label>
                                    <select name="uniform_size" class="w-full border border-gray-300 rounded-lg p-2">
                                        <option value="">Select Size</option>
                                        <option value="XS" <?php echo ($onboarding['uniform_size'] ?? '') == 'XS' ? 'selected' : ''; ?>>XS</option>
                                        <option value="S" <?php echo ($onboarding['uniform_size'] ?? '') == 'S' ? 'selected' : ''; ?>>S</option>
                                        <option value="M" <?php echo ($onboarding['uniform_size'] ?? '') == 'M' ? 'selected' : ''; ?>>M</option>
                                        <option value="L" <?php echo ($onboarding['uniform_size'] ?? '') == 'L' ? 'selected' : ''; ?>>L</option>
                                        <option value="XL" <?php echo ($onboarding['uniform_size'] ?? '') == 'XL' ? 'selected' : ''; ?>>XL</option>
                                        <option value="XXL" <?php echo ($onboarding['uniform_size'] ?? '') == 'XXL' ? 'selected' : ''; ?>>XXL</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Uniform Issued</label>
                                    <div class="flex items-center">
                                        <input type="radio" name="uniform_issued" id="uniform_yes" value="1" 
                                               class="w-4 h-4 text-blue-600 border-gray-300 focus:ring-blue-500"
                                               <?php echo ($onboarding['uniform_issued'] ?? '') == '1' ? 'checked' : ''; ?>>
                                        <label for="uniform_yes" class="ml-2 mr-4 text-sm text-gray-700">Yes</label>
                                        
                                        <input type="radio" name="uniform_issued" id="uniform_no" value="0" 
                                               class="w-4 h-4 text-blue-600 border-gray-300 focus:ring-blue-500"
                                               <?php echo ($onboarding['uniform_issued'] ?? '') == '0' ? 'checked' : ''; ?>>
                                        <label for="uniform_no" class="ml-2 text-sm text-gray-700">No</label>
                                    </div>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Access Card Number</label>
                                    <input type="text" name="access_card" 
                                           class="w-full border border-gray-300 rounded-lg p-2"
                                           value="<?php echo htmlspecialchars($onboarding['access_card'] ?? ''); ?>"
                                           placeholder="e.g., AC-2024-00123">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Card Activation Date</label>
                                    <input type="date" class="w-full border border-gray-300 rounded-lg p-2"
                                           value="<?php echo date('Y-m-d'); ?>"
                                           disabled>
                                </div>
                            </div>
                        </div>

                        <!-- Documentation -->
                        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
                            <h2 class="text-xl font-bold text-gray-800 mb-6">Documentation</h2>
                            
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Equipment Photo</label>
                                    <input type="file" name="equipment_photo" 
                                           class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-gray-50 file:text-gray-700 hover:file:bg-gray-100"
                                           accept="image/*">
                                    <?php if (!empty($onboarding['equipment_photo'])): ?>
                                    <p class="mt-2 text-sm text-gray-500">
                                        <a href="<?php echo htmlspecialchars($onboarding['equipment_photo']); ?>" 
                                           target="_blank" class="text-blue-600 hover:underline">
                                            View Current Photo
                                        </a>
                                    </p>
                                    <?php endif; ?>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Receipt Signature</label>
                                    <input type="file" name="equipment_signature" 
                                           class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-gray-50 file:text-gray-700 hover:file:bg-gray-100"
                                           accept="image/*,.pdf">
                                    <?php if (!empty($onboarding['equipment_signature'])): ?>
                                    <p class="mt-2 text-sm text-gray-500">
                                        <a href="<?php echo htmlspecialchars($onboarding['equipment_signature']); ?>" 
                                           target="_blank" class="text-blue-600 hover:underline">
                                            View Current Receipt
                                        </a>
                                    </p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="border border-gray-300 rounded-lg p-4 bg-gray-50">
                                <div class="flex items-center">
                                    <i data-lucide="alert-triangle" class="w-5 h-5 text-yellow-500 mr-3"></i>
                                    <div>
                                        <p class="text-sm text-gray-700">
                                            <strong>Important:</strong> All equipment issued to employees must be documented 
                                            with photos and signed receipts. Employees are responsible for the care and 
                                            return of all company property upon separation.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Notes and Submit -->
                        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                            <div class="flex items-center mb-4">
                                <input type="checkbox" name="equipment_provided" id="equipment_provided" value="1" 
                                       class="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                                       <?php echo !empty($onboarding['equipment_provided']) ? 'checked' : ''; ?>>
                                <label for="equipment_provided" class="ml-2 block text-sm font-medium text-gray-700">
                                    Mark equipment as provided and complete
                                </label>
                            </div>
                            
                            <div class="mb-4">
                                <label class="block text-sm font-medium text-gray-700 mb-2">Equipment Notes</label>
                                <textarea name="equipment_notes" rows="3" 
                                          class="w-full border border-gray-300 rounded-lg p-2"
                                          placeholder="Add any notes about equipment..."><?php echo htmlspecialchars($onboarding['equipment_notes'] ?? ''); ?></textarea>
                            </div>
                            
                            <button type="submit" name="update_equipment"
                                    class="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 font-medium">
                                <i data-lucide="save" class="w-5 h-5 inline mr-2"></i>
                                Update Equipment Details
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Right Column -->
                <div class="space-y-6">
                    <!-- Status -->
                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                        <h3 class="text-lg font-semibold mb-4">Equipment Status</h3>
                        <div class="space-y-4">
                            <div class="flex justify-between items-center">
                                <span class="text-gray-600">Provision Status</span>
                                <span class="px-3 py-1 rounded-full text-sm font-medium 
                                    <?php echo !empty($onboarding['equipment_provided']) ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'; ?>">
                                    <?php echo !empty($onboarding['equipment_provided']) ? 'Complete' : 'Pending'; ?>
                                </span>
                            </div>
                            
                            <?php if (!empty($onboarding['equipment_provided_at'])): ?>
                            <div class="border-t pt-4">
                                <p class="text-sm text-gray-500">Issued Date</p>
                                <p class="font-medium"><?php echo date('M d, Y', strtotime($onboarding['equipment_provided_at'])); ?></p>
                            </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($onboarding['equipment_laptop'])): ?>
                            <div class="border-t pt-4">
                                <p class="text-sm text-gray-500">Laptop/Computer</p>
                                <p class="font-medium"><?php echo htmlspecialchars($onboarding['equipment_laptop']); ?></p>
                            </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($onboarding['access_card'])): ?>
                            <div class="border-t pt-4">
                                <p class="text-sm text-gray-500">Access Card</p>
                                <p class="font-medium"><?php echo htmlspecialchars($onboarding['access_card']); ?></p>
                            </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($onboarding['equipment_photo'])): ?>
                            <div class="border-t pt-4">
                                <p class="text-sm text-gray-500 mb-2">Equipment Photo</p>
                                <img src="<?php echo htmlspecialchars($onboarding['equipment_photo']); ?>" 
                                     alt="Equipment Photo" class="w-full h-32 object-cover rounded-lg">
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Quick Actions -->
                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                        <h3 class="text-lg font-semibold mb-4">Quick Actions</h3>
                        <div class="space-y-3">
                            <?php if (empty($onboarding['equipment_provided'])): ?>
                            <button type="button" onclick="markAsProvided()"
                                    class="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700">
                                <i data-lucide="check-circle" class="w-4 h-4 inline mr-2"></i>
                                Mark as Provided
                            </button>
                            <?php endif; ?>
                            
                            <a href="#" onclick="printEquipmentReceipt()"
                               class="block w-full text-center border border-blue-600 text-blue-600 py-2 rounded-lg hover:bg-blue-50">
                                <i data-lucide="printer" class="w-4 h-4 inline mr-2"></i>
                                Print Receipt
                            </a>
                            
                            <a href="view_onboarding.php?id=<?php echo $id; ?>"
                               class="block w-full text-center border border-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-50">
                                <i data-lucide="eye" class="w-4 h-4 inline mr-2"></i>
                                View Onboarding
                            </a>
                        </div>
                    </div>

                    <!-- Equipment Checklist -->
                    <div class="bg-blue-50 border border-blue-200 rounded-xl p-6">
                        <h3 class="text-lg font-semibold mb-2 text-blue-800">Equipment Checklist</h3>
                        <ul class="space-y-2 text-blue-700 text-sm">
                            <li class="flex items-start">
                                <i data-lucide="check-circle" class="w-4 h-4 mr-2 mt-0.5 text-blue-600"></i>
                                <span>Laptop/Computer with charger</span>
                            </li>
                            <li class="flex items-start">
                                <i data-lucide="check-circle" class="w-4 h-4 mr-2 mt-0.5 text-blue-600"></i>
                                <span>Phone/communication device</span>
                            </li>
                            <li class="flex items-start">
                                <i data-lucide="check-circle" class="w-4 h-4 mr-2 mt-0.5 text-blue-600"></i>
                                <span>Required accessories (mouse, headset, etc.)</span>
                            </li>
                            <li class="flex items-start">
                                <i data-lucide="check-circle" class="w-4 h-4 mr-2 mt-0.5 text-blue-600"></i>
                                <span>Company uniform (size appropriate)</span>
                            </li>
                            <li class="flex items-start">
                                <i data-lucide="check-circle" class="w-4 h-4 mr-2 mt-0.5 text-blue-600"></i>
                                <span>Access card/security pass</span>
                            </li>
                            <li class="flex items-start">
                                <i data-lucide="check-circle" class="w-4 h-4 mr-2 mt-0.5 text-blue-600"></i>
                                <span>Documentation and signed receipt</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener("DOMContentLoaded", () => {
        lucide.createIcons();
    });

    function markAsProvided() {
        if (confirm('Mark equipment as provided and complete?')) {
            document.querySelector('#equipment_provided').checked = true;
            document.querySelector('form').submit();
        }
    }

    function printEquipmentReceipt() {
        // Create printable receipt
        const receiptContent = `
            <html>
            <head>
                <title>Equipment Receipt - <?php echo $onboarding['first_name'] . ' ' . $onboarding['last_name']; ?></title>
                <style>
                    body { font-family: Arial, sans-serif; padding: 20px; }
                    .receipt { border: 2px solid #000; padding: 20px; max-width: 500px; margin: 0 auto; }
                    .header { text-align: center; margin-bottom: 20px; }
                    .details { margin-bottom: 20px; }
                    .signature { margin-top: 50px; }
                    .footer { margin-top: 30px; font-size: 12px; }
                </style>
            </head>
            <body>
                <div class="receipt">
                    <div class="header">
                        <h2>LUXURY HOTEL MANILA</h2>
                        <h3>EQUIPMENT ISSUANCE RECEIPT</h3>
                        <p>Date: ${new Date().toLocaleDateString()}</p>
                    </div>
                    
                    <div class="details">
                        <p><strong>Employee:</strong> <?php echo $onboarding['first_name'] . ' ' . $onboarding['last_name']; ?></p>
                        <p><strong>Employee ID:</strong> <?php echo $onboarding['employee_id']; ?></p>
                        <p><strong>Position:</strong> <?php echo $onboarding['job_position']; ?></p>
                        <p><strong>Department:</strong> <?php echo $onboarding['department_name']; ?></p>
                        
                        <hr style="margin: 15px 0;">
                        
                        <h4>Equipment Issued:</h4>
                        <p>Laptop: <?php echo htmlspecialchars($onboarding['equipment_laptop'] ?? 'N/A'); ?></p>
                        <p>Phone: <?php echo htmlspecialchars($onboarding['equipment_phone'] ?? 'N/A'); ?></p>
                        <p>Access Card: <?php echo htmlspecialchars($onboarding['access_card'] ?? 'N/A'); ?></p>
                        <p>Uniform Size: <?php echo htmlspecialchars($onboarding['uniform_size'] ?? 'N/A'); ?></p>
                        
                        <hr style="margin: 15px 0;">
                        
                        <p><strong>I acknowledge receipt of the above company property and agree to:</strong></p>
                        <ol style="margin-left: 20px; font-size: 12px;">
                            <li>Use equipment only for company business</li>
                            <li>Maintain equipment in good condition</li>
                            <li>Report any loss or damage immediately</li>
                            <li>Return all equipment upon separation</li>
                        </ol>
                    </div>
                    
                    <div class="signature">
                        <p>Employee Signature: _________________________</p>
                        <p>Date: _________________________</p>
                        
                        <p style="margin-top: 30px;">Issued By: _________________________</p>
                        <p>HR Department</p>
                    </div>
                    
                    <div class="footer">
                        <p><em>This receipt must be signed and returned to HR Department</em></p>
                    </div>
                </div>
            </body>
            </html>
        `;
        
        const printWindow = window.open('', '_blank');
        printWindow.document.write(receiptContent);
        printWindow.document.close();
        printWindow.print();
    }
    </script>
</body>
</html>