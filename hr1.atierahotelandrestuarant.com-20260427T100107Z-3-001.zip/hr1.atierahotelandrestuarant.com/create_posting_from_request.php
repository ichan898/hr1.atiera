<?php
// File: create_posting_from_request.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

// Check if user has permission
if (!in_array($_SESSION['user_role'], ['admin', 'hr_manager', 'hr_officer'])) {
    $_SESSION['flash_message'] = [
        'type' => 'error',
        'message' => 'You do not have permission to create job postings.'
    ];
    header('Location: job_requests.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $requestId = $_POST['request_id'] ?? 0;
    
    // Get the job request
    $request = getJobRequest($requestId, $connections);
    
    if (!$request) {
        $_SESSION['flash_message'] = [
            'type' => 'error',
            'message' => 'Job request not found.'
        ];
        header('Location: job_requests.php');
        exit();
    }
    
    // Check if request is approved
    if ($request['overall_status'] !== 'approved') {
        $_SESSION['flash_message'] = [
            'type' => 'error',
            'message' => 'Only approved job requests can be converted to postings.'
        ];
        header('Location: job_requests.php');
        exit();
    }
    
    // Check if posting already exists
    if (hasJobPosting($requestId, $connections)) {
        $_SESSION['flash_message'] = [
            'type' => 'warning',
            'message' => 'A job posting already exists for this request.'
        ];
        header('Location: job_requests.php');
        exit();
    }
    
    // Create job posting from request
    $result = autoCreateJobPostingFromRequest($requestId, $connections);
    
    if ($result['success']) {
        $_SESSION['flash_message'] = [
            'type' => 'success',
            'message' => "Job posting created successfully! You can now edit and publish it."
        ];
        header('Location: edit_posting.php?id=' . $result['posting_id']);
        exit();
    } else {
        $_SESSION['flash_message'] = [
            'type' => 'error',
            'message' => 'Failed to create job posting: ' . ($result['error'] ?? 'Please try again.')
        ];
        header('Location: job_requests.php');
        exit();
    }
} else {
    // If not POST request, redirect to job requests
    header('Location: job_requests.php');
    exit();
}
?>