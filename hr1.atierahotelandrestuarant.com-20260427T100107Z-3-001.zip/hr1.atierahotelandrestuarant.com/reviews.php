<?php
// File: reviews.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

// Get filter parameters
$status = $_GET['status'] ?? 'all';
$department = $_GET['department'] ?? 'all';
$year = $_GET['year'] ?? date('Y');

// Get reviews
$reviews = [];
try {
    // Build query with PDO
    $sql = "SELECT 
            pr.id,
            CONCAT(e.first_name, ' ', e.last_name) as employee_name,
            ed.job_title as position,
            d.name as department,
            pr.overall_rating as rating,
            pr.summary,
            u.full_name as reviewer_name,
            pr.review_date,
            pr.due_date,
            pr.status
            FROM performance_reviews pr
            JOIN employees e ON pr.employee_id = e.id
            JOIN employment_details ed ON e.id = ed.employee_id
            JOIN departments d ON e.department_id = d.id
            JOIN users u ON pr.reviewer_id = u.id";
    
    $conditions = [];
    $params = [];
    
    if ($status != 'all') {
        $conditions[] = "pr.status = ?";
        $params[] = $status;
    }
    
    if ($department != 'all') {
        $conditions[] = "e.department_id = ?";
        $params[] = $department;
    }
    
    if (!empty($year)) {
        $conditions[] = "YEAR(pr.due_date) = ?";
        $params[] = $year;
    }
    
    if (!empty($conditions)) {
        $sql .= " WHERE " . implode(" AND ", $conditions);
    }
    
    $sql .= " ORDER BY pr.due_date DESC";
    
    $stmt = $connections->prepare($sql);
    $stmt->execute($params);
    $reviews = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    error_log("Error getting reviews: " . $e->getMessage());
    // Fallback to sample data if table doesn't exist
    if (strpos($e->getMessage(), "performance_reviews") !== false) {
        $reviews = [
            [
                'id' => 1,
                'employee_name' => 'John Smith',
                'position' => 'Senior Developer',
                'department' => 'IT',
                'rating' => 4.5,
                'summary' => 'Excellent performance this quarter',
                'reviewer_name' => 'Jane Doe',
                'review_date' => date('Y-m-d', strtotime('-30 days')),
                'due_date' => date('Y-m-d', strtotime('-30 days')),
                'status' => 'completed'
            ],
            [
                'id' => 2,
                'employee_name' => 'Maria Garcia',
                'position' => 'HR Manager',
                'department' => 'Human Resources',
                'rating' => 4.2,
                'summary' => 'Great leadership skills',
                'reviewer_name' => 'Robert Johnson',
                'review_date' => date('Y-m-d', strtotime('-45 days')),
                'due_date' => date('Y-m-d', strtotime('-45 days')),
                'status' => 'completed'
            ]
        ];
    }
}

// Get departments for filter
$departments = [];
try {
    $stmt = $connections->query("SELECT id, name FROM departments ORDER BY name");
    $departments = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error getting departments: " . $e->getMessage());
    // Fallback sample departments
    $departments = [
        ['id' => 1, 'name' => 'IT'],
        ['id' => 2, 'name' => 'Sales'],
        ['id' => 3, 'name' => 'Marketing'],
        ['id' => 4, 'name' => 'HR'],
        ['id' => 5, 'name' => 'Finance']
    ];
}

// Get years for filter
$years = [];
try {
    // First check if table exists
    $tableCheck = $connections->query("SHOW TABLES LIKE 'performance_reviews'");
    $tableExists = $tableCheck->fetch(PDO::FETCH_ASSOC);
    
    if ($tableExists) {
        $stmt = $connections->query("SELECT DISTINCT YEAR(due_date) as year FROM performance_reviews ORDER BY year DESC");
        $yearsData = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($yearsData as $row) {
            if ($row['year']) {
                $years[] = $row['year'];
            }
        }
    }
    
    // If no years found or table doesn't exist, add current year
    if (empty($years)) {
        $years = [date('Y'), date('Y')-1, date('Y')-2];
    }
} catch (PDOException $e) {
    error_log("Error getting years: " . $e->getMessage());
    $years = [date('Y'), date('Y')-1, date('Y')-2];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>HR1 - All Performance Reviews</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
</head>

<body class="h-screen bg-gray-100 font-sans">
<div class="flex h-full">
  <?php include 'sidebar.php'; ?>
  
  <div class="flex-1 flex flex-col overflow-y-auto">
    <main class="p-6">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-gray-300 pb-4 mb-6">
        <div>
          <h2 class="text-2xl font-bold text-gray-800">All Performance Reviews</h2>
          <p class="text-sm text-gray-600">View and manage all performance reviews</p>
        </div>
        <div class="flex space-x-3">
          <?php if(checkUserRole($_SESSION['user_id'], ['manager', 'admin', 'hr_manager', 'department_head'], $connections)): ?>
          <a href="add_review.php" 
             class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center">
            <i data-lucide="plus" class="w-4 h-4 mr-2"></i>
            New Review
          </a>
          <?php endif; ?>
          <a href="performance.php" class="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 flex items-center">
            <i data-lucide="arrow-left" class="w-4 h-4 mr-2"></i>
            Back to Dashboard
          </a>
        </div>
      </div>

      <!-- Filters -->
      <div class="bg-white rounded-lg shadow border p-4 mb-6">
        <form method="GET" action="" class="grid grid-cols-1 md:grid-cols-4 gap-4">
          <!-- Status Filter -->
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Status</label>
            <select name="status" 
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="all" <?php echo $status == 'all' ? 'selected' : ''; ?>>All Statuses</option>
              <option value="draft" <?php echo $status == 'draft' ? 'selected' : ''; ?>>Draft</option>
              <option value="scheduled" <?php echo $status == 'scheduled' ? 'selected' : ''; ?>>Scheduled</option>
              <option value="in_progress" <?php echo $status == 'in_progress' ? 'selected' : ''; ?>>In Progress</option>
              <option value="completed" <?php echo $status == 'completed' ? 'selected' : ''; ?>>Completed</option>
              <option value="cancelled" <?php echo $status == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
            </select>
          </div>

          <!-- Department Filter -->
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Department</label>
            <select name="department" 
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="all" <?php echo $department == 'all' ? 'selected' : ''; ?>>All Departments</option>
              <?php foreach ($departments as $dept): ?>
                <option value="<?php echo htmlspecialchars($dept['id']); ?>" 
                        <?php echo $department == $dept['id'] ? 'selected' : ''; ?>>
                  <?php echo htmlspecialchars($dept['name']); ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <!-- Year Filter -->
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Year</label>
            <select name="year" 
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
              <?php foreach ($years as $y): ?>
                <option value="<?php echo htmlspecialchars($y); ?>" <?php echo $year == $y ? 'selected' : ''; ?>>
                  <?php echo htmlspecialchars($y); ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <!-- Filter Button -->
          <div class="flex items-end">
            <button type="submit" 
                    class="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center justify-center">
              <i data-lucide="filter" class="w-4 h-4 mr-2"></i>
              Apply Filters
            </button>
          </div>
        </form>
      </div>

      <!-- Reviews Table -->
      <div class="bg-white rounded-lg shadow border overflow-hidden">
        <div class="overflow-x-auto">
          <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
              <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Employee</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Department</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Rating</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Review Date</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Due Date</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
              <?php foreach ($reviews as $review): ?>
                <tr class="hover:bg-gray-50">
                  <td class="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div class="font-medium text-gray-900"><?php echo htmlspecialchars($review['employee_name']); ?></div>
                      <div class="text-sm text-gray-500"><?php echo htmlspecialchars($review['position']); ?></div>
                    </div>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap">
                    <span class="px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800">
                      <?php echo htmlspecialchars($review['department']); ?>
                    </span>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap">
                    <?php 
                    $rating = $review['rating'] ?? 0;
                    $ratingClass = getRatingBadgeClass($rating);
                    ?>
                    <span class="px-2 py-1 text-xs font-medium rounded-full <?php echo $ratingClass; ?>">
                      <?php echo htmlspecialchars($rating); ?>/5
                    </span>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <?php echo !empty($review['review_date']) && $review['review_date'] != '0000-00-00' ? formatDate($review['review_date']) : 'Not reviewed'; ?>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <?php echo formatDate($review['due_date']); ?>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap">
                    <?php 
                    $statusColor = getReviewStatusColor($review['status']);
                    ?>
                    <span class="px-2 py-1 text-xs font-medium rounded-full <?php echo $statusColor; ?>">
                      <?php echo ucfirst(htmlspecialchars($review['status'])); ?>
                    </span>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div class="flex space-x-2">
                      <a href="view_review.php?id=<?php echo $review['id']; ?>" 
                         class="text-blue-600 hover:text-blue-900" title="View">
                        <i data-lucide="eye" class="w-4 h-4"></i>
                      </a>
                      <?php if(checkUserRole($_SESSION['user_id'], ['manager', 'admin', 'hr_manager', 'department_head'], $connections)): ?>
                      <a href="edit_review.php?id=<?php echo $review['id']; ?>" 
                         class="text-yellow-600 hover:text-yellow-900" title="Edit">
                        <i data-lucide="edit" class="w-4 h-4"></i>
                      </a>
                      <a href="delete_review.php?id=<?php echo $review['id']; ?>" 
                         onclick="return confirm('Are you sure you want to delete this review?')"
                         class="text-red-600 hover:text-red-900" title="Delete">
                        <i data-lucide="trash" class="w-4 h-4"></i>
                      </a>
                      <?php endif; ?>
                    </div>
                  </td>
                </tr>
              <?php endforeach; ?>
              
              <?php if (empty($reviews)): ?>
                <tr>
                  <td colspan="7" class="px-6 py-8 text-center text-gray-500">
                    <i data-lucide="file-text" class="w-12 h-12 mx-auto text-gray-300 mb-3"></i>
                    <p>No performance reviews found</p>
                    <p class="text-sm mt-2">Try adjusting your filters or create a new review.</p>
                  </td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
        
        <!-- Statistics -->
        <div class="border-t border-gray-200 px-6 py-4 bg-gray-50">
          <div class="flex items-center justify-between">
            <div class="text-sm text-gray-600">
              Total: <span class="font-medium"><?php echo count($reviews); ?></span> reviews
              <?php 
              $completed = array_filter($reviews, function($r) { return $r['status'] == 'completed'; });
              $pending = array_filter($reviews, function($r) { return $r['status'] == 'scheduled' || $r['status'] == 'in_progress'; });
              ?>
              • Completed: <span class="font-medium text-green-600"><?php echo count($completed); ?></span>
              • Pending: <span class="font-medium text-yellow-600"><?php echo count($pending); ?></span>
            </div>
            <div class="flex space-x-2">
              <a href="export_reviews.php?<?php echo http_build_query($_GET); ?>" 
                 class="px-3 py-1 text-sm border border-gray-300 rounded-lg hover:bg-gray-50 flex items-center">
                <i data-lucide="download" class="w-4 h-4 mr-1"></i>
                Export CSV
              </a>
            </div>
          </div>
        </div>
      </div>
    </main>
  </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
  lucide.createIcons();
});
</script>
</body>
</html>