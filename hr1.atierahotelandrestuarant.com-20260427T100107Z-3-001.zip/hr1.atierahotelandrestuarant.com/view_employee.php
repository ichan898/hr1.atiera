<?php
// File: view_employee.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

$id = intval($_GET['id'] ?? 0);

try {
    $sql = "SELECT e.*, d.name as department_name 
            FROM employees e 
            LEFT JOIN departments d ON e.department_id = d.id 
            WHERE e.id = ?";
    $stmt = $connections->prepare($sql);
    $stmt->execute([$id]);
    $employee = $stmt->fetch();
    
    if (!$employee) {
        $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Employee not found'];
        header('Location: employee_list.php');
        exit;
    }
} catch(PDOException $e) {
    error_log("View employee error: " . $e->getMessage());
    $_SESSION['flash_message'] = ['type' => 'error', 'message' => 'Error loading employee'];
    header('Location: employee_list.php');
    exit;
}

$age = getAge($employee['date_of_birth']);
$years_service = getYearsOfService($employee['hire_date']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>View Employee: <?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?></title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="bg-gray-50">
<div class="min-h-screen flex">
    <?php include 'sidebar.php'; ?>
    <div class="flex-1 p-6">
        <div class="max-w-4xl mx-auto">
            <div class="mb-6 flex justify-between items-center">
                <div>
                    <h1 class="text-2xl font-bold">Employee Details</h1>
                    <a href="employee_list.php" class="text-blue-600 hover:text-blue-800">← Back to Employee List</a>
                </div>
                <div class="flex space-x-2">
                    <a href="edit_employee.php?id=<?php echo $employee['id']; ?>" 
                       class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Edit</a>
                    <a href="employee_list.php?delete_id=<?php echo $employee['id']; ?>" 
                       onclick="return confirm('Are you sure you want to delete this employee?')"
                       class="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700">Delete</a>
                </div>
            </div>
            
            <?php if (isset($_SESSION['flash_message'])): ?>
                <div class="mb-4 p-4 bg-green-50 border border-green-200 rounded">
                    <?php echo $_SESSION['flash_message']['message']; ?>
                    <?php unset($_SESSION['flash_message']); ?>
                </div>
            <?php endif; ?>
            
            <div class="bg-white rounded-lg shadow">
                <div class="p-6 border-b">
                    <div class="flex items-center space-x-4">
                        <div class="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center text-2xl">
                            <?php echo strtoupper(substr($employee['first_name'], 0, 1) . substr($employee['last_name'], 0, 1)); ?>
                        </div>
                        <div>
                            <h2 class="text-xl font-bold"><?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?></h2>
                            <div class="flex items-center space-x-4 mt-2">
                                <span class="px-3 py-1 text-sm rounded-full <?php echo getEmployeeStatusColor($employee['status']); ?>">
                                    <?php echo $employee['status']; ?>
                                </span>
                                <span class="text-gray-600">ID: <?php echo $employee['employee_id']; ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="p-6 grid md:grid-cols-2 gap-6">
                    <div class="space-y-4">
                        <div>
                            <h3 class="text-sm text-gray-500">Personal Information</h3>
                            <div class="mt-2 space-y-2">
                                <p><span class="font-medium">Gender:</span> <?php echo $employee['gender']; ?></p>
                                <p><span class="font-medium">Date of Birth:</span> <?php echo date('F d, Y', strtotime($employee['date_of_birth'])); ?> (<?php echo $age; ?> years)</p>
                                <p><span class="font-medium">Email:</span> <?php echo htmlspecialchars($employee['email']); ?></p>
                                <?php if ($employee['contact_number']): ?>
                                <p><span class="font-medium">Phone:</span> <?php echo htmlspecialchars($employee['contact_number']); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div>
                            <h3 class="text-sm text-gray-500">Employment Information</h3>
                            <div class="mt-2 space-y-2">
                                <p><span class="font-medium">Department:</span> <?php echo htmlspecialchars($employee['department_name'] ?? 'N/A'); ?></p>
                                <p><span class="font-medium">Hire Date:</span> <?php echo date('F d, Y', strtotime($employee['hire_date'])); ?></p>
                                <p><span class="font-medium">Years of Service:</span> <?php echo $years_service; ?> years</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="space-y-4">
                        <div>
                            <h3 class="text-sm text-gray-500">System Information</h3>
                            <div class="mt-2 space-y-2">
                                <p><span class="font-medium">Created:</span> <?php echo date('F d, Y H:i', strtotime($employee['created_at'])); ?></p>
                                <p><span class="font-medium">Last Updated:</span> <?php echo date('F d, Y H:i', strtotime($employee['updated_at'])); ?></p>
                            </div>
                        </div>
                        
                        <?php if ($employee['address']): ?>
                        <div>
                            <h3 class="text-sm text-gray-500">Address</h3>
                            <p class="mt-2"><?php echo htmlspecialchars($employee['address']); ?></p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>lucide.createIcons();</script>
</body>
</html>