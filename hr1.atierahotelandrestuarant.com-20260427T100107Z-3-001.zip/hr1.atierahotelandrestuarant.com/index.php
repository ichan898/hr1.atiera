<?php
// index.php (or upload.php)
require_once 'connections.php';
use Smalot\PdfParser\Parser;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['resume'])) {
    $uploadedFile = $_FILES['resume']['tmp_name'];
    
    // Validate that it's a PDF
    if ($_FILES['resume']['type'] !== 'application/pdf') {
        die('Please upload a PDF file.');
    }
    
    // Use the temporary file path
    $resumePath = $uploadedFile;
    
    // Check if file exists and is readable
    if (!file_exists($resumePath) || !is_readable($resumePath)) {
        die('Uploaded file cannot be read.');
    }
    
    try {
        $parser = new Parser();
        $pdf = $parser->parseFile($resumePath);
        $text = $pdf->getText();
        
        // Now you can process $text (e.g., extract candidate info)
        echo "PDF parsed successfully!";
    } catch (Exception $e) {
        die('Error parsing PDF: ' . $e->getMessage());
    }
} else {
    // Show upload form
?>
<form method="post" enctype="multipart/form-data">
    <input type="file" name="resume" accept=".pdf" required>
    <button type="submit">Upload</button>
</form>
<?php
}
require_once "email_functions.php";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['submit_application'])) {
        $result = handleApplicationSubmission();
        if ($result['status'] === 'success') {
            echo "<script>alert('" . addslashes($result['message']) . "');</script>";
            echo "<script>window.location.href = 'index.php?success=1';</script>";
        } else {
            $error = $result['message'];
            echo "<script>alert('" . addslashes($error) . "');</script>";
        }
    }
    // Handle OTP verification for applicants (optional feature)
    elseif (isset($_POST['verify_applicant_otp'])) {
        $result = verifyApplicantOTP();
        if ($result['status'] === 'success') {
            echo "<script>alert('" . addslashes($result['message']) . "');</script>";
            echo "<script>window.location.href = 'index.php?verified=1';</script>";
        } else {
            echo "<script>alert('" . addslashes($result['message']) . "');</script>";
        }
    }
}

function handleApplicationSubmission() {
    global $connections;
    
    try {
        $connections->beginTransaction();
        
        // Validate required fields
        $required = ['First_Name', 'Last_Name', 'Email', 'Phone_Number', 'Address', 'Gender', 'Birthday', 'job_id'];
        foreach ($required as $field) {
            if (empty($_POST[$field])) {
                throw new Exception("Please fill in all required fields");
            }
        }
        
        $job_id = (int)$_POST['job_id'];
        
        // Check if job exists and is active
        $stmt = $connections->prepare("
            SELECT id, job_title, status, requirements
            FROM job_postings 
            WHERE id = ? AND status = 'active'
        ");
        $stmt->execute([$job_id]);
        $job = $stmt->fetch();
        
        if (!$job) {
            throw new Exception('This position is no longer available');
        }
        
        // Check if already applied
        $checkStmt = $connections->prepare("
            SELECT id FROM applicants 
            WHERE job_id = ? AND email = ?
        ");
        $checkStmt->execute([$job_id, $_POST['Email']]);
        if ($checkStmt->fetch()) {
            throw new Exception('You have already applied for this position');
        }
        
        // Validate age
        $birthday = new DateTime($_POST['Birthday']);
        $today = new DateTime();
        $age = $today->diff($birthday)->y;
        if ($age < 18) {
            throw new Exception('You must be at least 18 years old to apply');
        }
        
        // Handle file upload
        $resumePath = null;
        if (isset($_FILES['resume']) && $_FILES['resume']['error'] === UPLOAD_ERR_OK) {
            $resumePath = uploadResume($_FILES['resume']);
        } else {
            throw new Exception('Please upload your resume (PDF only, max 5MB)');
        }
        
        // Parse resume for qualifications
        $qualifications = parseResumeQualifications($resumePath);
        $qualificationsJson = json_encode($qualifications);
        
        // Check if applicant is qualified (with new lenient scoring)
        $qualificationCheck = checkApplicantQualifications($qualifications, $job['requirements'] ?? '');
        $isQualified = $qualificationCheck['qualified'] ? 1 : 0;
        $qualificationScore = $qualificationCheck['score'];
        
        // Save applicant with qualifications
        $stmt = $connections->prepare("
            INSERT INTO applicants (
                job_id, first_name, last_name, email, 
                phone, address, gender, birthday,
                application_status, resume_path, qualifications,
                qualification_score, is_qualified, applied_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'new', ?, ?, ?, ?, NOW())
        ");
        
        $stmt->execute([
            $job_id,
            sanitizeInput($_POST['First_Name']),
            sanitizeInput($_POST['Last_Name']),
            filter_var($_POST['Email'], FILTER_SANITIZE_EMAIL),
            sanitizeInput($_POST['Phone_Number']),
            sanitizeInput($_POST['Address']),
            $_POST['Gender'],
            $_POST['Birthday'],
            $resumePath,
            $qualificationsJson,
            $qualificationScore,
            $isQualified
        ]);
        
        $applicantId = $connections->lastInsertId();
        
        // Update applications count
        $updateStmt = $connections->prepare("
            UPDATE job_postings 
            SET applications_count = applications_count + 1 
            WHERE id = ?
        ");
        $updateStmt->execute([$job_id]);
        
        // Generate and send OTP for email verification (optional)
        $otp = generateOTP();
        storeOTP($_POST['Email'], $otp, $connections);
        sendOTPEmail($_POST['Email'], $_POST['First_Name'] . ' ' . $_POST['Last_Name'], $otp);
        
        // Send application confirmation
        sendApplicationConfirmation(
            $_POST['Email'],
            $_POST['First_Name'] . ' ' . $_POST['Last_Name'],
            $job['job_title'],
            $applicantId
        );
        
        $connections->commit();
        
        return [
            'status' => 'success',
            'message' => 'Application submitted successfully! Please check your email for verification OTP.',
            'applicant_id' => $applicantId,
            'qualified' => $isQualified,
            'qualification_score' => $qualificationScore
        ];
        
    } catch (Exception $e) {
        if ($connections->inTransaction()) {
            $connections->rollBack();
        }
        return [
            'status' => 'error',
            'message' => $e->getMessage()
        ];
    }
}

function uploadResume($file) {
    $targetDir = "uploads/resumes/";
    
    if (!file_exists($targetDir)) {
        mkdir($targetDir, 0777, true);
    }
    
    $allowedExtensions = ['pdf'];
    $fileName = basename($file['name']);
    $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    
    if (!in_array($fileExtension, $allowedExtensions)) {
        throw new Exception('Only PDF files are allowed');
    }
    
    $allowedMimeTypes = ['application/pdf'];
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $fileMimeType = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    if (!in_array($fileMimeType, $allowedMimeTypes)) {
        throw new Exception('Invalid file type. Only PDF files are allowed');
    }
    
    if ($file['size'] > 5 * 1024 * 1024) {
        throw new Exception('File size must be less than 5MB');
    }
    
    $fileName = uniqid() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '_', $fileName);
    $targetFile = $targetDir . $fileName;
    
    if (move_uploaded_file($file['tmp_name'], $targetFile)) {
        return $targetFile;
    } else {
        throw new Exception('Failed to upload resume. Please try again.');
    }
}

// ==================== IMPROVED PARSING FUNCTIONS START ====================
function parseResumeQualifications($resumePath) {
    try {
        if (!file_exists($resumePath)) {
            throw new Exception('Resume file not found');
        }

        $text = '';
        $fileExt = strtolower(pathinfo($resumePath, PATHINFO_EXTENSION));

        if ($fileExt === 'pdf') {
            // Try using pdftotext if available (recommended: install poppler-utils on server)
            if (function_exists('shell_exec') && !in_array('shell_exec', explode(',', ini_get('disable_functions')))) {
                $command = "pdftotext " . escapeshellarg($resumePath) . " - 2>&1";
                $text = @shell_exec($command);
                if ($text === null || trim($text) === '') {
                    error_log("pdftotext returned empty or null for: $resumePath");
                    $text = '';
                }
            } else {
                error_log("shell_exec is disabled; cannot use pdftotext.");
                $text = '';
            }

            // Optional: Add fallback PHP PDF parser here (e.g., Smalot\PdfParser) if installed via Composer.
            // For now, we rely on pdftotext.

            if (empty(trim($text))) {
                error_log("No text could be extracted from PDF: $resumePath");
            }
        } else {
            // For non-PDF files (should not happen, but just in case)
            $text = file_get_contents($resumePath);
        }

        // Extract qualifications from text if we have any
        if (!empty(trim($text))) {
            $qualifications = extractQualificationsFromText($text);
        } else {
            // No text – return neutral values
            $qualifications = [
                'education'          => 'Not specified',
                'experience_years'   => 0,
                'skills'             => [],
                'certifications'     => []
            ];
        }

        return $qualifications;

    } catch (Exception $e) {
        error_log("Error parsing resume: " . $e->getMessage());
        // On error, return neutral values
        return [
            'education'          => 'Not specified',
            'experience_years'   => 0,
            'skills'             => [],
            'certifications'     => []
        ];
    }
}

function extractQualificationsFromText($text) {
    $qualifications = [];
    $lowerText = strtolower($text);

    // --- Education (expanded patterns) ---
    if (preg_match('/\b(?:bachelor(?:\'s)?|bs\b|ba\b|b\.?a\.?|b\.?s\.?|b\.?s\.?c\.?|bachelor of (?:science|arts|business)|undergraduate|college degree)/i', $text)) {
        $qualifications['education'] = 'Bachelor\'s Degree';
    } elseif (preg_match('/\b(?:master(?:\'s)?|ms\b|ma\b|m\.?a\.?|m\.?s\.?|mba|master of (?:science|arts|business|administration)|graduate degree)/i', $text)) {
        $qualifications['education'] = 'Master\'s Degree';
    } elseif (preg_match('/\b(?:phd|doctorate|doctoral|ph\.?d|dba)/i', $text)) {
        $qualifications['education'] = 'Doctorate';
    } elseif (preg_match('/\b(?:high school|secondary|diploma|ged)/i', $text)) {
        $qualifications['education'] = 'High School Diploma';
    } else {
        $qualifications['education'] = 'Not specified';
    }

    // --- Experience Years (more patterns) ---
    $exp = 0;
    // Standard patterns
    if (preg_match('/(\d+)\+?\s*(?:year|yr)s?\s+of\s+experience/i', $lowerText, $matches)) {
        $exp = (int)$matches[1];
    } elseif (preg_match('/experience\s+(?:of\s+)?(\d+)\+?\s*(?:year|yr)s?/i', $lowerText, $matches)) {
        $exp = (int)$matches[1];
    } elseif (preg_match('/with\s+(\d+)\+?\s*(?:year|yr)s?\s+experience/i', $lowerText, $matches)) {
        $exp = (int)$matches[1];
    } elseif (preg_match('/(\d+)\+?\s*(?:year|yr)s?\s+in\s+the\s+(?:industry|field)/i', $lowerText, $matches)) {
        $exp = (int)$matches[1];
    }
    // Additional patterns
    elseif (preg_match('/worked\s+(?:for\s+)?(\d+)\+?\s*(?:year|yr)s?/i', $lowerText, $matches)) {
        $exp = (int)$matches[1];
    } elseif (preg_match('/total\s+experience.*?(\d+)\+?\s*(?:year|yr)s?/i', $lowerText, $matches)) {
        $exp = (int)$matches[1];
    } elseif (preg_match('/over\s+(\d+)\+?\s*(?:year|yr)s?/i', $lowerText, $matches)) {
        $exp = (int)$matches[1];
    } elseif (preg_match('/(\d+)\+?\s*(?:year|yr)s?\s+(?:as|in)/i', $lowerText, $matches)) {
        $exp = (int)$matches[1];
    }
    $qualifications['experience_years'] = $exp;

    // --- Skills (greatly expanded list) ---
    $commonSkills = [
        // Core hospitality
        'management', 'leadership', 'communication', 'teamwork', 'customer service',
        'hospitality', 'restaurant', 'hotel', 'cooking', 'chef', 'server', 'front desk',
        'accounting', 'finance', 'marketing', 'sales', 'administration', 'food safety',
        'menu planning', 'inventory', 'budgeting', 'supervision', 'training', 'scheduling',
        'microsoft office', 'excel', 'word', 'powerpoint', 'outlook', 'quickbooks',
        'pos', 'reservation', 'event planning', 'bartending', 'wine knowledge', 'culinary',
        // Additional common terms
        'guest service', 'concierge', 'housekeeping', 'laundry', 'sanitation',
        'banquet', 'catering', 'barista', 'mixology', 'food preparation', 'pastry',
        'baking', 'grill', 'saute', 'expediting', 'purchasing', 'receiving',
        'cost control', 'profit loss', 'p&l', 'revenue management', 'yield management',
        'human resources', 'recruiting', 'onboarding', 'payroll', 'benefits administration',
        'employee relations', 'performance review', 'conflict resolution',
        'maintenance', 'engineering', 'hvac', 'plumbing', 'electrical',
        'security', 'safety', 'emergency response', 'first aid', 'cpr',
        'computer skills', 'data entry', 'typing', 'spreadsheets', 'database',
        'social media', 'digital marketing', 'advertising', 'public relations',
        'project management', 'time management', 'problem solving', 'critical thinking',
        'multitasking', 'detail oriented', 'organizational skills',
        'bilingual', 'spanish', 'english', 'filipino', 'tagalog',
        // Hotel-specific
        'opera', 'microsoft dynamics', 'oracle', 'salesforce', 'sabre',
        'hotel software', 'property management system', 'pms', 'channel manager',
        'booking engine', 'online travel agency', 'ota', 'expedia', 'booking.com',
        'airbnb', 'vrbo', 'tripadvisor', 'review management', 'reputation management'
    ];
    $foundSkills = [];
    foreach ($commonSkills as $skill) {
        if (strpos($lowerText, $skill) !== false) {
            $foundSkills[] = ucwords($skill);
        }
    }
    $qualifications['skills'] = !empty($foundSkills) ? array_slice($foundSkills, 0, 30) : [];

    // --- Certifications (more specific) ---
    $foundCerts = [];
    $certKeywords = ['certification', 'certified', 'certificate', 'license', 'licensed', 'training'];
    foreach ($certKeywords as $keyword) {
        if (preg_match("/\b{$keyword}\b/i", $text)) {
            $foundCerts[] = ucfirst($keyword) . ' (found)';
            break;
        }
    }
    // Specific certifications
    if (preg_match('/food\s+(?:safety|handler|protection)/i', $text)) {
        $foundCerts[] = 'Food Safety Certification';
    }
    if (preg_match('/first\s*aid|cpr|aed/i', $text)) {
        $foundCerts[] = 'First Aid/CPR Certified';
    }
    if (preg_match('/servsafe/i', $text)) {
        $foundCerts[] = 'ServSafe Certified';
    }
    if (preg_match('/tips|alcohol\s+serv/i', $text)) {
        $foundCerts[] = 'TIPS Alcohol Certification';
    }
    if (preg_match('/haccp/i', $text)) {
        $foundCerts[] = 'HACCP Certified';
    }
    if (preg_match('/cph(?:r)?|phr|shrm|professional in human resources/i', $text)) {
        $foundCerts[] = 'HR Certification';
    }
    if (preg_match('/cma|cpa|cfm|financial/i', $text)) {
        $foundCerts[] = 'Finance Certification';
    }
    $qualifications['certifications'] = array_unique($foundCerts);

    return $qualifications;
}
// ==================== IMPROVED PARSING FUNCTIONS END ====================

// ==================== MODIFIED SCORING FUNCTION (MORE LENIENT) ====================
function checkApplicantQualifications($qualifications, $jobRequirements) {
    $score = 0;
    $maxScore = 100;
    
    // Ensure skills is an array
    if (!isset($qualifications['skills']) || !is_array($qualifications['skills'])) {
        $qualifications['skills'] = [];
    }
    
    // Ensure certifications is an array
    if (!isset($qualifications['certifications']) || !is_array($qualifications['certifications'])) {
        $qualifications['certifications'] = [];
    }
    
    // Parse job requirements (simple keyword matching)
    $requirementsText = strtolower($jobRequirements);
    
    // --- EDUCATION SCORING (more generous) ---
    $education = strtolower($qualifications['education'] ?? '');
    if ($education !== 'not specified') {
        // Any education mentioned gets 20 base points
        $score += 20;
        // Extra points if it matches the requirement specifically
        if (strpos($requirementsText, 'bachelor') !== false && strpos($education, 'bachelor') !== false) {
            $score += 10; // total 30
        } elseif (strpos($requirementsText, 'master') !== false && strpos($education, 'master') !== false) {
            $score += 15; // total 35
        } elseif (strpos($requirementsText, 'high school') !== false && strpos($education, 'high school') !== false) {
            $score += 5;  // total 25
        }
    } else {
        // No education detected – still give some points
        $score += 10;
    }
    
    // --- EXPERIENCE SCORING (6 points per year, capped at 40) ---
    $expYears = $qualifications['experience_years'] ?? 0;
    // If job specifies required experience, we compare; otherwise just give points per year
    if (preg_match('/(\d+)\s*(year|yr)s?.{0,50}experience/i', $jobRequirements, $matches)) {
        $requiredExp = intval($matches[1]);
        if ($expYears >= $requiredExp) {
            $score += min(40, $expYears * 6); // 6 points per year, max 40
        } else {
            $score += min(25, $expYears * 4); // reduced points but still some
        }
    } else {
        // No specific requirement – just give points per year (capped at 40)
        $score += min(40, $expYears * 6);
    }
    
    // --- SKILLS SCORING (7 points per matching skill) ---
    $skills = $qualifications['skills'] ?? [];
    $skillMatchCount = 0;
    foreach ($skills as $skill) {
        if (strpos($requirementsText, strtolower($skill)) !== false) {
            $score += 7;
            $skillMatchCount++;
        }
    }
    
    // --- CERTIFICATIONS SCORING (5 points per certification, max 20) ---
    $certs = $qualifications['certifications'] ?? [];
    $certPoints = 0;
    foreach ($certs as $cert) {
        // Just having any certification adds points (we don't check against requirements)
        $certPoints += 5;
    }
    $score += min(20, $certPoints);
    
    // Cap the score at maxScore
    $score = min($score, $maxScore);
    
    // Determine if qualified (threshold still 50)
    $qualified = $score >= 50;
    
    return [
        'qualified' => $qualified,
        'score' => $score,
        'max_score' => $maxScore,
        'education_match' => $qualifications['education'],
        'experience_years' => $expYears,
        'matched_skills' => $skills,
        'skill_match_count' => $skillMatchCount,
        'certifications' => $certs
    ];
}
// ==================== END MODIFIED SCORING ====================

function generateOTP() {
    // Generate a 6-digit OTP
    return str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
}

function storeOTP($email, $otp, $connections) {
    try {
        $stmt = $connections->prepare("
            INSERT INTO otp_verification (email, otp, expires_at, created_at) 
            VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 10 MINUTE), NOW())
        ");
        $stmt->execute([$email, $otp]);
        return true;
    } catch (Exception $e) {
        error_log("Error storing OTP: " . $e->getMessage());
        return false;
    }
}

function verifyOTP($email, $otp, $connections) {
    try {
        $stmt = $connections->prepare("
            SELECT id FROM otp_verification 
            WHERE email = ? AND otp = ? AND expires_at > NOW() AND used = 0
            ORDER BY created_at DESC LIMIT 1
        ");
        $stmt->execute([$email, $otp]);
        $result = $stmt->fetch();
        
        if ($result) {
            // Mark OTP as used
            $updateStmt = $connections->prepare("UPDATE otp_verification SET used = 1 WHERE id = ?");
            $updateStmt->execute([$result['id']]);
            return true;
        }
        return false;
    } catch (Exception $e) {
        error_log("Error verifying OTP: " . $e->getMessage());
        return false;
    }
}

function sendOTPEmail($email, $name, $otp) {
    $subject = "Email Verification OTP - Atiera Hotel & Restaurant";
    
    $message = '
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background-color: #004AAD; color: white; padding: 20px; text-align: center; }
            .content { padding: 30px; background-color: #f9f9f9; }
            .otp-box { 
                background-color: #fff; 
                border: 2px dashed #004AAD; 
                padding: 20px; 
                text-align: center; 
                font-size: 32px; 
                font-weight: bold; 
                color: #004AAD;
                margin: 20px 0;
                letter-spacing: 5px;
            }
            .footer { background-color: #f1f1f1; padding: 20px; text-align: center; font-size: 12px; color: #666; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>Atiera Hotel & Restaurant</h1>
                <h2>Email Verification</h2>
            </div>
            <div class="content">
                <h3>Dear ' . htmlspecialchars($name) . ',</h3>
                <p>Thank you for submitting your application. Please use the following One-Time Password (OTP) to verify your email address:</p>
                
                <div class="otp-box">' . $otp . '</div>
                
                <p><strong>Important:</strong></p>
                <ul>
                    <li>This OTP is valid for 10 minutes only</li>
                    <li>Do not share this OTP with anyone</li>
                    <li>If you didn\'t request this OTP, please ignore this email</li>
                </ul>
                
                <p>Enter this OTP on the verification page to complete your application process.</p>
                
                <br>
                <p>Best regards,<br>
                <strong>Atiera Recruitment Team</strong><br>
                📧 careers@atiera.com<br>
                📞 +1 (555) 123-4567</p>
            </div>
            <div class="footer">
                <p>&copy; ' . date('Y') . ' Atiera Hotel & Restaurant Management. All rights reserved.</p>
                <p>This is an automated email, please do not reply.</p>
            </div>
        </div>
    </body>
    </html>';
    
    // Use the existing sendEmailViaSMTP function from email_functions.php
    return sendEmailViaSMTP($email, $subject, $message, true, 'careers@atiera.com', 'Atiera Careers');
}

function sanitizeInput($data) {
    // Remove whitespace and HTML tags, but keep raw text (no encoding)
    return strip_tags(trim($data));
}

function sendApplicationConfirmation($email, $name, $position, $applicationId) {
    $subject = "Application Received - " . $position . " - Atiera Hotel & Restaurant";
    
    $message = '
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background-color: #004AAD; color: white; padding: 20px; text-align: center; }
            .content { padding: 30px; background-color: #f9f9f9; }
            .footer { background-color: #f1f1f1; padding: 20px; text-align: center; font-size: 12px; color: #666; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>Atiera Hotel & Restaurant</h1>
                <h2>Application Received</h2>
            </div>
            <div class="content">
                <h3>Dear ' . htmlspecialchars($name) . ',</h3>
                <p>Thank you for applying for the <strong>' . htmlspecialchars($position) . '</strong> position at Atiera Hotel & Restaurant.</p>
                
                <p><strong>Application Details:</strong></p>
                <ul>
                    <li>Application ID: APP-' . str_pad($applicationId, 6, '0', STR_PAD_LEFT) . '</li>
                    <li>Position: ' . htmlspecialchars($position) . '</li>
                    <li>Date: ' . date('F j, Y') . '</li>
                </ul>
                
                <p>We have received your application and our HR team will review it shortly. 
                You will be contacted if your qualifications match our requirements.</p>
                
                <p><strong>Next Steps:</strong></p>
                <ol>
                    <li>Our HR team will review your application (2-3 business days)</li>
                    <li>If shortlisted, we will contact you for an interview</li>
                    <li>Interview process may include multiple rounds</li>
                    <li>Final decision and job offer</li>
                </ol>
                
                <p>You can check your application status by contacting our HR department.</p>
                
                <br>
                <p>Best regards,<br>
                <strong>Atiera Recruitment Team</strong><br>
                📧 careers@atiera.com<br>
                📞 +1 (555) 123-4567</p>
            </div>
            <div class="footer">
                <p>&copy; ' . date('Y') . ' Atiera Hotel & Restaurant Management. All rights reserved.</p>
                <p>123 Luxury Avenue, Metro City</p>
            </div>
        </div>
    </body>
    </html>';
    
    return sendEmailViaSMTP($email, $subject, $message, true, 'careers@atiera.com', 'Atiera Careers');
}

function verifyApplicantOTP() {
    global $connections;
    
    try {
        if (empty($_POST['email']) || empty($_POST['otp'])) {
            throw new Exception('Email and OTP are required');
        }
        
        $email = $_POST['email'];
        $otp = $_POST['otp'];
        
        if (verifyOTP($email, $otp, $connections)) {
            return [
                'status' => 'success',
                'message' => 'Email verified successfully!'
            ];
        } else {
            throw new Exception('Invalid or expired OTP');
        }
    } catch (Exception $e) {
        return [
            'status' => 'error',
            'message' => $e->getMessage()
        ];
    }
}

/* Fetch ACTIVE jobs from job_postings table */
$jobs = [];

try {
    $stmt = $connections->prepare("
        SELECT DISTINCT
            id,
            job_title,
            job_code,
            department,
            location,
            employment_type,
            salary_range,
            description,
            requirements,
            responsibilities,
            status,
            posting_date,
            closing_date,
            views,
            applications_count
        FROM job_postings 
        WHERE status = 'active' 
        AND (closing_date IS NULL OR closing_date >= CURDATE())
        ORDER BY posting_date DESC, id DESC
    ");

    if ($stmt) {
        $stmt->execute();
        $jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $jobIds = [];
        $duplicateCount = 0;
        foreach ($jobs as $job) {
            if (in_array($job['id'], $jobIds)) {
                $duplicateCount++;
                error_log("Duplicate job found: ID " . $job['id'] . " - " . $job['job_title']);
            }
            $jobIds[] = $job['id'];
        }
        
        if ($duplicateCount > 0) {
            error_log("Found $duplicateCount duplicate jobs in the result set");
            $uniqueJobs = [];
            foreach ($jobs as $job) {
                $uniqueJobs[$job['id']] = $job;
            }
            $jobs = array_values($uniqueJobs);
        }
    }
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atiera: Hotel and Restaurant Careers | Join Our Luxury Team</title>
    <!-- AOS Library -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --blue: #004AAD;
            --light-blue: #e6f0ff;
            --dark-blue: #003680;
            --green: #16a34a;
            --light-green: #dcfce7;
            --orange: #f59e0b;
            --red: #dc2626;
            --white: #ffffff;
            --light-gray: #f8fafc;
            --gray: #64748b;
            --dark-gray: #334155;
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            line-height: 1.6;
            color: var(--dark-gray);
            background-color: var(--white);
            position: relative;
        }

        /* ---- Full page background image with 20% opacity ---- */
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=2000&q=80');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            opacity: 0.2;
            z-index: -1;
            pointer-events: none;
        }

        h1, h2, h3, h4 {
            font-family: 'Playfair Display', serif;
            font-weight: 600;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        /* Navigation */
        .navbar {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            background-color: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            z-index: 1000;
            transition: var(--transition);
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .navbar.scrolled {
            background-color: var(--white);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        .nav-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 0;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            text-decoration: none;
            color: var(--dark-blue);
        }

        .logo-icon {
            width: 40px;
            height: 40px;
            background-color: var(--blue);
            color: var(--white);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 18px;
        }

        .logo-text {
            font-family: 'Playfair Display', serif;
            font-size: 24px;
            font-weight: 700;
            line-height: 1;
        }

        .logo-subtext {
            font-size: 11px;
            color: var(--gray);
            letter-spacing: 1px;
            text-transform: uppercase;
        }

        .nav-links {
            display: flex;
            list-style: none;
            gap: 30px;
            align-items: center;
        }

        .nav-links a {
            text-decoration: none;
            color: var(--dark-gray);
            font-weight: 500;
            transition: var(--transition);
            position: relative;
        }

        .nav-links a:hover {
            color: var(--blue);
        }

        .nav-links a::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 0;
            height: 2px;
            background-color: var(--blue);
            transition: var(--transition);
        }

        .nav-links a:hover::after {
            width: 100%;
        }

        .signup-btn {
            background-color: var(--blue);
            color: var(--white) !important;
            padding: 10px 24px;
            border-radius: 6px;
            transition: var(--transition);
        }

        .signup-btn:hover {
            background-color: var(--dark-blue);
            transform: translateY(-2px);
        }

        .signup-btn::after {
            display: none;
        }

        .mobile-toggle {
            display: none;
            font-size: 24px;
            cursor: pointer;
            color: var(--dark-gray);
        }

        /* Hero Section */
        .hero {
            min-height: 100vh;
            background: linear-gradient(135deg, rgba(0, 74, 173, 0.05) 0%, rgba(255, 255, 255, 1) 100%);
            display: grid;
            grid-template-columns: 1fr 1fr;
            align-items: center;
            padding: 100px 0 60px;
        }

        .hero-content {
            padding-right: 40px;
        }

        .hiring-badge {
            display: inline-block;
            background-color: var(--light-green);
            color: var(--green);
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 500;
            margin-bottom: 20px;
        }

        .hero h1 {
            font-size: 3.5rem;
            line-height: 1.1;
            margin-bottom: 20px;
            color: var(--dark-blue);
        }

        .hero h1 span {
            color: var(--blue);
        }

        .hero p {
            font-size: 1.1rem;
            color: var(--gray);
            margin-bottom: 20px;
            max-width: 500px;
        }

        .hero-buttons {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }

        .explore-btn {
            display: inline-block;
            background-color: var(--blue);
            color: var(--white);
            padding: 15px 30px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            transition: var(--transition);
            border: 2px solid var(--blue);
        }

        .explore-btn:hover {
            background-color: var(--dark-blue);
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(0, 74, 173, 0.2);
        }

        .why-work-btn {
            display: inline-block;
            background-color: transparent;
            color: var(--blue);
            padding: 15px 30px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            transition: var(--transition);
            border: 2px solid var(--blue);
        }

        .why-work-btn:hover {
            background-color: var(--light-blue);
            transform: translateY(-3px);
        }

        .hero-image {
            position: relative;
        }

        .image-container {
            position: relative;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            height: 500px;
            background-color: var(--dark-blue);
        }

        .image-container img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }

        .apply-overlay {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            background: linear-gradient(transparent, rgba(0, 0, 0, 0.8));
            padding: 30px;
            text-align: center;
        }

        .apply-button {
            display: inline-block;
            background-color: var(--white);
            color: var(--blue);
            padding: 15px 30px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            transition: var(--transition);
        }

        .apply-button:hover {
            background-color: var(--light-blue);
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(255, 255, 255, 0.2);
        }

        /* Section Styles */
        section {
            padding: 80px 0;
        }

        .section-title {
            text-align: center;
            margin-bottom: 50px;
        }

        .section-title h2 {
            font-size: 2.5rem;
            color: var(--dark-blue);
            margin-bottom: 15px;
        }

        /* Jobs Section */
        .jobs-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 30px;
            margin-top: 30px;
        }

        .job-card {
            background-color: var(--white);
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            transition: var(--transition);
            border: 1px solid #e2e8f0;
        }

        .job-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.12);
        }

        .card-header {
            background-color: var(--light-blue);
            padding: 25px;
            border-bottom: 1px solid #e2e8f0;
        }

        .card-header h3 {
            font-size: 1.5rem;
            color: var(--dark-blue);
            margin-bottom: 8px;
        }

        .department {
            display: inline-block;
            background-color: var(--blue);
            color: var(--white);
            padding: 5px 12px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .card-body {
            padding: 25px;
        }

        .card-body p {
            margin-bottom: 15px;
            color: var(--gray);
        }

        .job-card-buttons {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }

        .btn {
            padding: 12px 24px;
            border-radius: 6px;
            border: none;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            font-family: 'Poppins', sans-serif;
        }

        .apply-now-btn {
            background-color: var(--blue);
            color: var(--white);
            flex: 1;
        }

        .apply-now-btn:hover:not(:disabled) {
            background-color: var(--dark-blue);
            transform: translateY(-2px);
        }

        .apply-now-btn:disabled {
            background-color: var(--gray);
            cursor: not-allowed;
        }

        .view-more-btn {
            background-color: transparent;
            color: var(--blue);
            border: 1px solid var(--blue);
        }

        .view-more-btn:hover {
            background-color: var(--light-blue);
        }

        /* Benefits Section */
        .benefits-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
            margin-top: 50px;
        }

        .benefit-item {
            text-align: center;
            padding: 30px;
            background-color: var(--white);
            border-radius: 12px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            transition: var(--transition);
        }

        .benefit-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
        }

        .benefit-icon {
            width: 70px;
            height: 70px;
            background-color: var(--light-blue);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 30px;
            color: var(--blue);
        }

        .benefit-item h3 {
            font-size: 1.3rem;
            margin-bottom: 15px;
            color: var(--dark-blue);
        }

        /* Testimonials */
        .testimonials-container {
            max-width: 800px;
            margin: 0 auto;
        }

        .testimonial {
            background-color: var(--white);
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            margin-top: 30px;
        }

        .testimonial-text {
            font-size: 1.2rem;
            font-style: italic;
            color: var(--dark-gray);
            margin-bottom: 30px;
            line-height: 1.8;
        }

        .testimonial-author {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .author-img {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            object-fit: cover;
            background-color: var(--blue);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }

        .author-info h4 {
            font-size: 1.2rem;
            color: var(--dark-blue);
            margin-bottom: 5px;
        }

        .author-info p {
            color: var(--gray);
        }

        /* Footer */
        .footer {
            background-color: var(--dark-blue);
            color: var(--white);
            padding: 60px 0 20px;
        }

        .footer-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 40px;
            margin-bottom: 40px;
        }

        .footer-col h3 {
            font-size: 1.5rem;
            margin-bottom: 20px;
            color: var(--white);
        }

        .footer-col a {
            display: block;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            margin-bottom: 10px;
            transition: var(--transition);
        }

        .footer-col a:hover {
            color: var(--white);
            padding-left: 5px;
        }

        .footer-col p {
            margin-bottom: 15px;
            color: rgba(255, 255, 255, 0.8);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .social-links {
            display: flex;
            gap: 15px;
            margin-top: 20px;
        }

        .social-links a {
            width: 40px;
            height: 40px;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--white);
            transition: var(--transition);
        }

        .social-links a:hover {
            background-color: var(--blue);
            transform: translateY(-3px);
        }

        .copyright {
            text-align: center;
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            color: rgba(255, 255, 255, 0.6);
            font-size: 14px;
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 2000;
            overflow-y: auto;
            padding: 20px;
        }

        .modal-content {
            background-color: var(--white);
            border-radius: 12px;
            max-width: 800px;
            margin: 50px auto;
            padding: 40px;
            position: relative;
            animation: modalFadeIn 0.3s ease;
        }

        @keyframes modalFadeIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .close-btn {
            position: absolute;
            top: 20px;
            right: 20px;
            background: none;
            border: none;
            font-size: 28px;
            color: var(--gray);
            cursor: pointer;
            transition: var(--transition);
        }

        .close-btn:hover {
            color: var(--dark-blue);
        }

        /* Form Styles */
        input, select, textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-family: 'Poppins', sans-serif;
            font-size: 16px;
            transition: var(--transition);
        }

        input:focus, select:focus, textarea:focus {
            outline: none;
            border-color: var(--blue);
            box-shadow: 0 0 0 3px rgba(0, 74, 173, 0.1);
        }

        /* Success Message */
        .success-message {
            position: fixed;
            top: 80px;
            left: 20px;
            right: 20px;
            background-color: var(--light-green);
            color: var(--green);
            padding: 15px;
            border-radius: 6px;
            text-align: center;
            z-index: 1001;
            animation: slideIn 0.3s ease;
            display: none;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Chatbot Styles - START */
        .chatbot-container {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 9999;
            font-family: 'Poppins', sans-serif;
        }

        .chatbot-toggle {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--blue), var(--dark-blue));
            border: none;
            color: white;
            font-size: 24px;
            cursor: pointer;
            box-shadow: 0 4px 20px rgba(0, 74, 173, 0.3);
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }

        .chatbot-toggle:hover {
            transform: scale(1.1);
            box-shadow: 0 6px 25px rgba(0, 74, 173, 0.4);
        }

        .chatbot-toggle:active {
            transform: scale(0.95);
        }

        .chatbot-notification {
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--red);
            color: white;
            font-size: 12px;
            width: 22px;
            height: 22px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }

        .chatbot-window {
            position: absolute;
            bottom: 80px;
            right: 0;
            width: 380px;
            height: 600px;
            background: white;
            border-radius: 16px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15);
            display: none;
            flex-direction: column;
            overflow: hidden;
            animation: slideInUp 0.3s ease;
        }

        @keyframes slideInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .chatbot-window.active {
            display: flex;
        }

        .chat-header {
            background: linear-gradient(135deg, var(--blue), var(--dark-blue));
            color: white;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .chat-header-content {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .chat-avatar {
            width: 40px;
            height: 40px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }

        .chat-info h3 {
            margin: 0;
            font-size: 16px;
            font-weight: 600;
        }

        .chat-info p {
            margin: 4px 0 0;
            font-size: 12px;
            opacity: 0.9;
        }

        .chat-close {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: white;
            width: 32px;
            height: 32px;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.3s ease;
        }

        .chat-close:hover {
            background: rgba(255, 255, 255, 0.3);
        }

        .chat-messages {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
            background: #f8fafc;
            display: flex;
            flex-direction: column;
            gap: 16px;
        }

        .message {
            max-width: 85%;
            display: flex;
            animation: fadeIn 0.3s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .bot-message {
            align-self: flex-start;
        }

        .user-message {
            align-self: flex-end;
            flex-direction: row-reverse;
        }

        .message-content {
            background: white;
            padding: 12px 16px;
            border-radius: 18px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            position: relative;
        }

        .bot-message .message-content {
            background: white;
            border-bottom-left-radius: 4px;
        }

        .user-message .message-content {
            background: var(--blue);
            color: white;
            border-bottom-right-radius: 4px;
        }

        .message-text {
            line-height: 1.4;
            margin-bottom: 8px;
        }

        .message-time {
            font-size: 11px;
            opacity: 0.7;
            text-align: right;
        }

        .user-message .message-time {
            color: rgba(255, 255, 255, 0.8);
        }

        .quick-replies {
            display: flex;
            flex-direction: column;
            gap: 8px;
            margin-top: 12px;
        }

        .quick-reply {
            background: var(--light-blue);
            border: 1px solid rgba(0, 74, 173, 0.2);
            border-radius: 20px;
            padding: 8px 16px;
            font-size: 14px;
            text-align: left;
            cursor: pointer;
            transition: all 0.3s ease;
            color: var(--dark-blue);
            font-family: 'Poppins', sans-serif;
        }

        .quick-reply:hover {
            background: var(--blue);
            color: white;
            transform: translateY(-2px);
        }

        .chat-input-container {
            border-top: 1px solid #e2e8f0;
            background: white;
            padding: 16px;
        }

        .typing-indicator {
            display: none;
            align-items: center;
            gap: 8px;
            padding: 8px 16px;
            background: #f1f5f9;
            border-radius: 20px;
            margin-bottom: 12px;
            font-size: 14px;
            color: var(--gray);
        }

        .typing-indicator span {
            width: 8px;
            height: 8px;
            background: var(--blue);
            border-radius: 50%;
            animation: typing 1.4s infinite;
        }

        .typing-indicator span:nth-child(1) { animation-delay: 0s; }
        .typing-indicator span:nth-child(2) { animation-delay: 0.2s; }
        .typing-indicator span:nth-child(3) { animation-delay: 0.4s; }

        @keyframes typing {
            0%, 60%, 100% { transform: translateY(0); }
            30% { transform: translateY(-4px); }
        }

        .chat-form {
            display: flex;
            gap: 8px;
        }

        .chat-input {
            flex: 1;
            padding: 12px 16px;
            border: 2px solid #e2e8f0;
            border-radius: 24px;
            font-family: 'Poppins', sans-serif;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .chat-input:focus {
            outline: none;
            border-color: var(--blue);
            box-shadow: 0 0 0 3px rgba(0, 74, 173, 0.1);
        }

        .chat-send {
            width: 44px;
            height: 44px;
            border-radius: 50%;
            background: var(--blue);
            color: white;
            border: none;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }

        .chat-send:hover {
            background: var(--dark-blue);
            transform: rotate(15deg);
        }

        .chat-send:active {
            transform: scale(0.95) rotate(15deg);
        }

        .chat-suggestions {
            display: flex;
            gap: 8px;
            margin-top: 12px;
            flex-wrap: wrap;
        }

        .suggestion-btn {
            padding: 6px 12px;
            background: var(--light-gray);
            border: 1px solid #e2e8f0;
            border-radius: 16px;
            font-size: 12px;
            color: var(--gray);
            cursor: pointer;
            transition: all 0.3s ease;
            font-family: 'Poppins', sans-serif;
        }

        .suggestion-btn:hover {
            background: var(--light-blue);
            color: var(--blue);
            transform: translateY(-1px);
        }

        @media (max-width: 480px) {
            .chatbot-container {
                bottom: 10px;
                right: 10px;
            }
            
            .chatbot-window {
                width: calc(100vw - 40px);
                height: 70vh;
                right: -10px;
            }
            
            .chatbot-toggle {
                width: 50px;
                height: 50px;
                font-size: 20px;
            }
        }

        .chat-messages::-webkit-scrollbar {
            width: 6px;
        }

        .chat-messages::-webkit-scrollbar-track {
            background: #f1f5f9;
        }

        .chat-messages::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 3px;
        }

        .chat-messages::-webkit-scrollbar-thumb:hover {
            background: #94a3b8;
        }
        /* Chatbot Styles - END */

        /* Responsive Design */
        @media (max-width: 992px) {
            .hero {
                grid-template-columns: 1fr;
                text-align: center;
                padding: 120px 0 60px;
            }

            .hero-content {
                padding-right: 0;
                margin-bottom: 50px;
            }

            .hero h1 {
                font-size: 2.8rem;
            }

            .hero-buttons {
                justify-content: center;
            }

            .jobs-container {
                grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            }
        }

        @media (max-width: 768px) {
            .nav-links {
                position: fixed;
                top: 70px;
                left: 0;
                right: 0;
                background-color: var(--white);
                flex-direction: column;
                padding: 20px;
                box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
                transform: translateY(-100%);
                opacity: 0;
                visibility: hidden;
                transition: var(--transition);
                z-index: 999;
            }

            .nav-links.active {
                transform: translateY(0);
                opacity: 1;
                visibility: visible;
            }

            .mobile-toggle {
                display: block;
            }

            .hero h1 {
                font-size: 2.3rem;
            }

            .section-title h2 {
                font-size: 2rem;
            }

            .modal-content {
                padding: 20px;
                margin: 20px auto;
            }
        }

        @media (max-width: 576px) {
            .hero-buttons {
                flex-direction: column;
            }

            .job-card-buttons {
                flex-direction: column;
            }

            .benefits-container {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Success Message -->
    <?php if (isset($_GET['success'])): ?>
        <div class="success-message" id="successMessage">
            Application submitted successfully! We will contact you soon.
        </div>
    <?php endif; ?>

    <!-- Navigation -->
    <nav class="navbar">
        <div class="container nav-container">
            <a href="#" class="logo">
                <div class="logo-icon">HR</div>
                <div>
                    <div class="logo-text">Atiera</div>
                    <div class="logo-subtext">Hotel & Restaurant Management</div>
                </div>
            </a>
            <div class="mobile-toggle" id="mobileToggle" aria-label="Toggle navigation menu">
                <i class="fas fa-bars"></i>
            </div>
            <ul class="nav-links" id="navLinks">
                <li><a href="#home">Home</a></li>
                <li><a href="#" id="aboutLink">About</a></li>
                <li><a href="#careers">Careers</a></li>
                <li><a href="#contact">Contact</a></li>
                <li><a href="admin_dashboard.php" class="signup-btn">HR Login</a></li>            
            </ul>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero" id="home">
        <div class="hero-content" data-aos="fade-right" data-aos-duration="1000">
            <div class="hiring-badge">We're hiring — Front & Back of House</div>
            <h1>Join Our Team at <span>Atiera</span></h1>
            <p>Hospitality careers that grow with you</p>
            <p>Atiera connects talented individuals with great opportunities in hotels and restaurants. Apply online — fast application, interview scheduling, and easy onboarding.</p>
            <div class="hero-buttons">
                <a href="#careers" class="explore-btn">Explore Openings</a>
                <a href="#" class="why-work-btn">Why Work With Us</a>
            </div>
        </div>
        <div class="hero-image" data-aos="fade-left" data-aos-duration="1000">
            <div class="image-container">
                <img src="https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1000&q=80"
                     alt="Atiera Hotel & Restaurant luxury dining and lobby"
                     loading="lazy">
                <div class="apply-overlay">
                    <a href="#careers" class="apply-button">Apply — Open Positions</a>
                </div>
            </div>
        </div>  
    </section>

    <!-- Why Work With Us Modal -->
    <div id="whyWorkModal" class="modal" aria-hidden="true" role="dialog" aria-labelledby="whyWorkModalTitle">
        <div class="modal-content" data-aos="fade-up" data-aos-duration="800">
            <button class="close-btn" aria-label="Close modal">&times;</button>
            <div class="section-title">
                <h2 id="whyWorkModalTitle">Why Work With Us</h2>
                <p style="color:#666; margin-top:10px;">
                    Discover what makes Atiera one of the most rewarding places to build a career in hospitality.
                </p>
            </div>
            <div class="about-content" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 40px; align-items: center;">
                <div data-aos="fade-right" data-aos-duration="1000">
                    <img src="https://images.unsplash.com/photo-1600880292089-90a7e086ee0c?auto=format&fit=crop&w=1000&q=80"
                         alt="Atiera Team working together"
                         style="width:100%; border-radius:15px; box-shadow:0 8px 25px rgba(0,0,0,0.1);">
                </div>
                <div data-aos="fade-left" data-aos-duration="1000">
                    <h3 style="color:var(--blue); margin-bottom:15px;">Culture of Excellence</h3>
                    <p style="margin-bottom:20px; color:#555;">
                        At Atiera Hotel and Restaurant, we believe in empowering our people. Every team member — from kitchen to concierge — plays
                        an essential role in delivering exceptional guest experiences. We cultivate a culture where your
                        ideas matter, growth is celebrated, and hospitality is a shared passion.
                    </p>
                    <h3 style="color:var(--blue); margin-bottom:15px;">Growth and Opportunities</h3>
                    <p style="margin-bottom:20px; color:#555;">
                        We invest in your development with hands-on training, leadership programs, and international placements.
                        Many of our leaders started their journey as entry-level staff and grew into department heads and managers.
                    </p>
                    <h3 style="color:var(--blue); margin-bottom:15px;">Work-Life Harmony</h3>
                    <p style="color:#555;">
                        Enjoy a supportive work environment that values your well-being, with competitive benefits, flexible
                        schedules, and access to Atiera-exclusive employee perks.
                    </p>
                    <a href="#careers" class="explore-btn" style="margin-top:25px; display:inline-block;">
                        View Job Openings
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Featured Jobs -->
    <section id="careers">
        <div class="container">
            <div class="section-title" data-aos="fade-up" data-aos-duration="800">
                <h2>Featured Opportunities</h2>
            </div>

            <div class="jobs-container">
                <?php if (empty($jobs)): ?>
                    <p style="text-align:center; color:#666; padding: 2rem;">
                        No open positions available at the moment. Please check back later or <a href="#contact">contact us</a> for inquiries.
                    </p>
                <?php else: ?>
                    <?php foreach ($jobs as $index => $job): ?>
                        <?php
                            // Calculate if job is still open
                            $isAvailable = true;
                            if ($job['closing_date']) {
                                $closingDate = new DateTime($job['closing_date']);
                                $today = new DateTime();
                                $isAvailable = $closingDate >= $today;
                            }
                        ?>
                        <div class="job-card"
                             data-job-id="<?= htmlspecialchars($job['id'], ENT_QUOTES, 'UTF-8') ?>"
                             data-aos="zoom-in"
                             data-aos-duration="800"
                             data-aos-delay="<?= min(($index + 1) * 100, 500) ?>"
                             role="article">

                            <div class="card-header">
                                <h3><?= htmlspecialchars($job['job_title'], ENT_QUOTES, 'UTF-8') ?></h3>
                                <span class="department"><?= htmlspecialchars($job['department'], ENT_QUOTES, 'UTF-8') ?></span>
                            </div>

                            <div class="card-body">
                                <!-- REMOVED THE DESCRIPTION LINE -->
                                
                                <p style="margin-top:8px; font-weight:600; color:#16a34a;">
                                    <i class="fas fa-briefcase"></i> <?= htmlspecialchars($job['employment_type'], ENT_QUOTES, 'UTF-8') ?>
                                </p>
                                
                                <p><strong>Location:</strong> <?= htmlspecialchars($job['location'] ?? 'Not specified', ENT_QUOTES, 'UTF-8') ?></p>
                                <p><strong>Salary:</strong> <?= htmlspecialchars($job['salary_range'] ?? 'Negotiable', ENT_QUOTES, 'UTF-8') ?></p>
                                
                                <?php if ($job['applications_count'] > 0): ?>
                                    <p style="margin-top:8px; font-weight:600; color:#3b82f6;">
                                        <i class="fas fa-users"></i> <?= $job['applications_count'] ?> applicants
                                    </p>
                                <?php endif; ?>
                                
                                <?php if (!$isAvailable): ?>
                                    <p style="margin-top:8px; font-weight:600; color:#dc2626;">
                                        <i class="fas fa-calendar-times"></i> Application closed
                                    </p>
                                <?php endif; ?>

                                <div class="job-card-buttons">
                                    <button class="btn apply-now-btn" 
                                            <?= !$isAvailable ? 'disabled style="opacity:0.5; cursor:not-allowed;"' : '' ?>
                                            data-job-title="<?= htmlspecialchars($job['job_title'], ENT_QUOTES, 'UTF-8') ?>"
                                            data-job-id="<?= htmlspecialchars($job['id'], ENT_QUOTES, 'UTF-8') ?>">
                                        <?= $isAvailable ? 'Apply Now' : 'Position Closed' ?>
                                    </button>
                                    <button class="btn view-more-btn" 
                                            data-job-id="<?= htmlspecialchars($job['id'], ENT_QUOTES, 'UTF-8') ?>">
                                        View Details
                                    </button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Benefits Section -->
    <section style="background-color: var(--light-gray);">
        <div class="container">
            <div class="section-title" data-aos="fade-up" data-aos-duration="800">
                <h2>Why Join Atiera Team?</h2>
            </div>
            <div class="benefits-container">
                <div class="benefit-item" data-aos="fade-up" data-aos-duration="800" data-aos-delay="100">
                    <div class="benefit-icon"><i class="fas fa-utensils"></i></div>
                    <h3>Industry Excellence</h3>
                    <p>Work with world-class chefs and hospitality professionals in award-winning establishments.</p>
                </div>
                <div class="benefit-item" data-aos="fade-up" data-aos-duration="800" data-aos-delay="200">
                    <div class="benefit-icon"><i class="fas fa-globe"></i></div>
                    <h3>Global Opportunities</h3>
                    <p>Career advancement across our international portfolio of luxury hotels and restaurants.</p>
                </div>
                <div class="benefit-item" data-aos="fade-up" data-aos-duration="800" data-aos-delay="300">
                    <div class="benefit-icon"><i class="fas fa-graduation-cap"></i></div>
                    <h3>Professional Growth</h3>
                    <p>Comprehensive training programs and mentorship to develop your hospitality expertise.</p>
                </div>
                <div class="benefit-item" data-aos="fade-up" data-aos-duration="800" data-aos-delay="400">
                    <div class="benefit-icon"><i class="fas fa-heart"></i></div>
                    <h3>Employee Benefits</h3>
                    <p>Competitive compensation, health coverage, and exclusive discounts across our properties.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials -->
    <section>
        <div class="container">
            <div class="section-title" data-aos="fade-up" data-aos-duration="800">
                <h2>Employee Stories</h2>
            </div>
            <div class="testimonials-container">
                <div class="testimonial" data-aos="fade-up" data-aos-duration="800" data-aos-delay="200">
                    <p class="testimonial-text">"Starting as a line cook at Atiera, I've grown into an Executive Chef role through their mentorship program. The culture of excellence pushes you to become your best self every day."</p>
                    <div class="testimonial-author">
                        <div class="author-img">
                            JK
                        </div>
                        <div class="author-info">
                            <h4>Sabandal, James Kneechtel DL.</h4>
                            <p>Executive Chef, Grand Plaza Hotel</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer" id="contact">
        <div class="container">
            <div class="footer-container">
                <div class="footer-col" data-aos="fade-right" data-aos-duration="800">
                    <h3>Atiera Careers</h3>
                    <p>Join our team of hospitality professionals dedicated to creating unforgettable guest experiences in luxury settings.</p>
                    <div class="social-links">
                        <a href="#" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
                        <a href="#" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                        <a href="#" aria-label="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
                <div class="footer-col" data-aos="fade-up" data-aos-duration="800">
                    <h3>Quick Links</h3>
                    <a href="#home">Home</a>
                    <a href="#" id="aboutLinkFooter">About Us</a>
                    <a href="#careers">Career Opportunities</a>
                    <a href="#" class="benefits-link">Employee Benefits</a>
                </div>
                <div class="footer-col" data-aos="fade-left" data-aos-duration="800">
                    <h3>Contact Us</h3>
                    <p><i class="fas fa-map-marker-alt"></i> 123 Luxury Avenue, Metro City</p>
                    <p><i class="fas fa-phone"></i> +1 (555) 123-4567</p>
                    <p><i class="fas fa-envelope"></i> atierahotelandrestaurant@gmail.com</p>
                </div>
            </div>
            <div class="copyright" data-aos="fade-up" data-aos-duration="800">
                <p>&copy; <?= date('Y') ?> ATIERA:Hotel & Restaurant Management. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Employee Benefits Modal -->
    <div id="benefitsModal" class="modal" aria-hidden="true" role="dialog" aria-labelledby="benefitsModalTitle">
        <div class="modal-content" data-aos="fade-up" data-aos-duration="800">
            <button class="close-btn close-benefits" aria-label="Close modal">&times;</button>
            <div class="section-title">
                <h2 id="benefitsModalTitle">Employee Benefits</h2>
                <p style="color:#666; margin-top:10px;">
                    Atiera Hotel and Restaurant values its people — here are the benefits we provide to support your growth and well-being.
                </p>
            </div>
            <div class="benefits-content" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 30px; margin-top: 30px;">
                <div data-aos="fade-up" data-aos-duration="900" style="text-align:center;">
                    <div style="width: 100px; height: 100px; background-color: var(--light-blue); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px;">
                        <i class="fas fa-money-bill-alt" style="font-size: 40px; color: var(--blue);"></i>
                    </div>
                    <h3 style="color:var(--blue); margin-top:10px;">Competitive Salary</h3>
                    <p style="color:#555;">We offer industry-leading compensation to reward your hard work and dedication.</p>
                </div>
                <div data-aos="fade-up" data-aos-duration="1100" style="text-align:center;">
                    <div style="width: 100px; height: 100px; background-color: var(--light-blue); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px;">
                        <i class="fas fa-heartbeat" style="font-size: 40px; color: var(--blue);"></i>
                    </div>
                    <h3 style="color:var(--blue); margin-top:10px;">Health & Wellness</h3>
                    <p style="color:#555;">Comprehensive medical, dental, and wellness programs for you and your family.</p>
                </div>
                <div data-aos="fade-up" data-aos-duration="1300" style="text-align:center;">
                    <div style="width: 100px; height: 100px; background-color: var(--light-blue); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px;">
                        <i class="fas fa-graduation-cap" style="font-size: 40px; color: var(--blue);"></i>
                    </div>
                    <h3 style="color:var(--blue); margin-top:10px;">Training & Development</h3>
                    <p style="color:#555;">We support your professional growth through workshops and leadership programs.</p>
                </div>
                <div data-aos="fade-up" data-aos-duration="1500" style="text-align:center;">
                    <div style="width: 100px; height: 100px; background-color: var(--light-blue); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px;">
                        <i class="fas fa-plane" style="font-size: 40px; color: var(--blue);"></i>
                    </div>
                    <h3 style="color:var(--blue); margin-top:10px;">Travel Perks</h3>
                    <p style="color:#555;">Enjoy exclusive discounts on hotel stays, dining, and partner establishments.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- About Us Modal -->
    <div id="aboutModal" class="modal" aria-hidden="true" role="dialog" aria-labelledby="aboutModalTitle">
        <div class="modal-content" data-aos="fade-up" data-aos-duration="800">
            <button class="close-btn close-about" aria-label="Close modal">&times;</button>
            <div class="section-title">
                <h2 id="aboutModalTitle">About Atiera</h2>
                <p style="color:#666; margin-top:10px;">
                    Learn more about Atiera Hotel and Restaurant commitment to luxury, hospitality, and people-first service.
                </p>
            </div>
            <div class="about-content" style="display:grid; grid-template-columns:repeat(auto-fit,minmax(300px,1fr)); gap:40px; align-items:center;">
                <div data-aos="fade-right" data-aos-duration="1000">
                    <img src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1000&q=80"
                         alt="Luxury Hotel Lobby"
                         style="width:100%; border-radius:15px; box-shadow:0 8px 25px rgba(0,0,0,0.1);">
                </div>
                <div data-aos="fade-left" data-aos-duration="1000">
                    <h3 style="color:var(--blue); margin-bottom:15px;">Our Mission</h3>
                    <p style="margin-bottom:20px; color:#555;">
                        Atiera exists to redefine hospitality recruitment — connecting passionate individuals with top-tier hotels and restaurants across the country. We empower every applicant to grow, lead, and succeed.
                    </p>
                    <h3 style="color:var(--blue); margin-bottom:15px;">Our Vision</h3>
                    <p style="margin-bottom:20px; color:#555;">
                        To be the Philippines' most trusted name in hospitality talent solutions — where careers flourish and service excellence thrives.
                    </p>
                    <h3 style="color:var(--blue); margin-bottom:15px;">Our Core Values</h3>
                    <ul style="color:#555; margin-left:20px; margin-bottom:20px;">
                        <li>Integrity in every interaction</li>
                        <li>Respect for people and culture</li>
                        <li>Commitment to growth and learning</li>
                        <li>Passion for hospitality and service</li>
                    </ul>
                    <a href="#careers" class="explore-btn" style="margin-top:25px; display:inline-block;">
                        Explore Careers
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Apply Now Modal -->
    <div id="applyNowModal" class="modal" aria-hidden="true" role="dialog" aria-labelledby="applyNowModalTitle">
        <div class="modal-content" data-aos="fade-up" data-aos-duration="800">
            <button class="close-btn close-apply" aria-label="Close modal">&times;</button>
            <div class="section-title">
                <h2 id="applyNowModalTitle">Apply for This Position</h2>
                <p style="color:#666; margin-top:10px;">Please fill out the form below to submit your application.</p>
            </div>
            <form id="applicationForm" method="POST" enctype="multipart/form-data" style="display: grid; gap: 20px; margin-top: 20px;">
                <input type="hidden" name="submit_application" value="1">
                <input type="hidden" id="appJobId" name="job_id">

                <!-- Name Fields -->
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 15px;">
                    <div>
                        <label for="appFirstName" style="display:block; margin-bottom:6px; font-weight:500; color:var(--dark-blue);">
                            First Name <span style="color:red">*</span>
                        </label>
                        <input type="text" id="appFirstName" name="First_Name" required 
                               style="width:100%; padding:12px; border:1px solid #ddd; border-radius:8px; font-size:16px; font-family:'Poppins', sans-serif;">
                    </div>
                    <!-- <div>
                        <label for="appMiddleInitial" style="display:block; margin-bottom:6px; font-weight:500; color:var(--dark-blue);">Middle Initial</label>
                        <input type="text" id="appMiddleInitial" name="Middle_Initial" maxlength="1" 
                               style="width:100%; padding:12px; border:1px solid #ddd; border-radius:8px; font-size:16px; font-family:'Poppins', sans-serif; text-transform: uppercase;">
                    </div> -->
                    <div>
                        <label for="appLastName" style="display:block; margin-bottom:6px; font-weight:500; color:var(--dark-blue);">
                            Last Name <span style="color:red">*</span>
                        </label>
                        <input type="text" id="appLastName" name="Last_Name" required 
                               style="width:100%; padding:12px; border:1px solid #ddd; border-radius:8px; font-size:16px; font-family:'Poppins', sans-serif;">
                    </div>
                </div>
                
                <!-- Job Position, Gender, Birthday -->
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
                    <div>
                        <label for="appJobPosition" style="display:block; margin-bottom:6px; font-weight:500; color:var(--dark-blue);">
                            Job Position <span style="color:red">*</span>
                        </label>
                        <input type="text" id="appJobPosition" name="Job_Position" readonly required
                               style="width:100%; padding:12px; border:1px solid #ddd; border-radius:8px; font-size:16px; font-family:'Poppins', sans-serif; background-color:#f5f5f5;">
                    </div>
                    <div>
                        <label for="appGender" style="display:block; margin-bottom:6px; font-weight:500; color:var(--dark-blue);">
                            Gender <span style="color:red">*</span>
                        </label>
                        <select id="appGender" name="Gender" required 
                                style="width:100%; padding:12px; border:1px solid #ddd; border-radius:8px; font-size:16px; font-family:'Poppins', sans-serif;">
                            <option value="">Select...</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    <div>
                        <label for="appBirthday" style="display:block; margin-bottom:6px; font-weight:500; color:var(--dark-blue);">
                            Birthday <span style="color:red">*</span>
                        </label>
                        <input type="date" id="appBirthday" name="Birthday" required 
                               style="width:100%; padding:12px; border:1px solid #ddd; border-radius:8px; font-size:16px; font-family:'Poppins', sans-serif;"
                               max="<?= date('Y-m-d', strtotime('-18 years')) ?>">
                    </div>
                </div>

                <!-- Email and Contact -->
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
                    <div>
                        <label for="appEmail" style="display:block; margin-bottom:6px; font-weight:500; color:var(--dark-blue);">
                            Email <span style="color:red">*</span>
                        </label>
                        <input type="email" id="appEmail" name="Email" required 
                               style="width:100%; padding:12px; border:1px solid #ddd; border-radius:8px; font-size:16px; font-family:'Poppins', sans-serif;">
                    </div>
                    <div>
                        <label for="appPhone" style="display:block; margin-bottom:6px; font-weight:500; color:var(--dark-blue);">
                            Phone Number <span style="color:red">*</span>
                        </label>
                        <input type="tel" id="appPhone" name="Phone_Number" required 
                               pattern="[0-9]{10,15}"
                               style="width:100%; padding:12px; border:1px solid #ddd; border-radius:8px; font-size:16px; font-family:'Poppins', sans-serif;"
                               placeholder="09123456789">
                    </div>
                </div>

                <!-- Contact Information -->
                <div>
                    <label for="appContactInfo" style="display:block; margin-bottom:6px; font-weight:500; color:var(--dark-blue);">
                        Additional Contact Information
                    </label>
                    <input type="text" id="appContactInfo" name="Contact_Information" 
                           placeholder="e.g., Messenger, Viber, Telegram username"
                           style="width:100%; padding:12px; border:1px solid #ddd; border-radius:8px; font-size:16px; font-family:'Poppins', sans-serif;">
                </div>

                <!-- Address -->
                <div>
                    <label for="appAddress" style="display:block; margin-bottom:6px; font-weight:500; color:var(--dark-blue);">
                        Address <span style="color:red">*</span>
                    </label>
                    <textarea id="appAddress" name="Address" rows="2" required 
                              style="width:100%; padding:12px; border:1px solid #ddd; border-radius:8px; font-size:16px; font-family:'Poppins', sans-serif;"
                              placeholder="Full address including city and postal code"></textarea>
                </div>

                <!-- Resume Upload -->
                <div>
                    <label for="appResume" style="display:block; margin-bottom:6px; font-weight:500; color:var(--dark-blue);">
                        Upload Resume (PDF only, max 5MB) <span style="color:red">*</span>
                    </label>
                    <input type="file" id="appResume" name="resume" accept=".pdf" required 
                           style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px; font-size:16px; font-family:'Poppins', sans-serif;">
                    <p style="font-size:13px; color:#666; margin-top:5px;">Only PDF files up to 5MB are accepted.</p>
                </div>

                <!-- Consent Checkbox -->
                <div>
                    <input type="checkbox" id="appConsent" name="Consent" required 
                           style="margin-right:8px;">
                    <label for="appConsent" style="color:#555;">
                        I consent to the processing and storage of my personal data and agree to the 
                        <a href="privacy-policy.html" target="_blank" rel="noopener noreferrer">Privacy Policy</a> and 
                        <a href="terms.html" target="_blank" rel="noopener noreferrer">Terms & Conditions</a> 
                        <span style="color:red">*</span>
                    </label>
                </div>

                <!-- Submit Button -->
                <button type="submit" class="btn" 
                        style="background:var(--blue); color:var(--white); padding:14px; border:none; border-radius:8px; font-size:16px; font-weight:600; cursor:pointer; font-family:'Poppins', sans-serif;"
                        id="submitApplicationBtn">
                    Submit Application
                </button>
            </form>
        </div>
    </div>

    <!-- View More Modal -->
    <div id="viewMoreModal" class="modal" aria-hidden="true" role="dialog" aria-labelledby="viewJobTitle">
        <div class="modal-content">
            <button class="close-btn close-view" aria-label="Close modal">&times;</button>
            <div class="section-title">
                <h2 id="viewJobTitle">Job Title</h2>
            </div>
            <div class="job-details-content" style="margin-top:20px; line-height:1.6;">
                <p><strong>Job Code:</strong> <span id="viewJobCode"></span></p>
                <p><strong>Department:</strong> <span id="viewJobDepartment"></span></p>
                <p><strong>Location:</strong> <span id="viewJobLocation"></span></p>
                <p><strong>Employment Type:</strong> <span id="viewJobEmployment"></span></p>
                <p><strong>Salary Range:</strong> <span id="viewJobSalary"></span></p>
                <p><strong>Posted Date:</strong> <span id="viewJobPosted"></span></p>
                <p><strong>Closing Date:</strong> <span id="viewJobClosing"></span></p>
                <p><strong>Applications Received:</strong> <span id="viewJobApplications"></span></p>
                <p><strong>Description:</strong></p>
                <p id="viewJobDescription" style="white-space: pre-line;"></p>
                <p><strong>Requirements:</strong></p>
                <p id="viewJobRequirements" style="white-space: pre-line;"></p>
                <p><strong>Responsibilities:</strong></p>
                <p id="viewJobResponsibilities" style="white-space: pre-line;"></p>
            </div>
            <div style="margin-top:20px; text-align:right;">
                <button class="btn apply-now-btn-modal" style="background:var(--blue); color:white; padding:10px 20px; border:none; border-radius:5px; cursor:pointer;">Apply Now</button>
            </div>
        </div>
    </div>

    <!-- Chatbot Widget - START -->
    <div id="chatbotContainer" class="chatbot-container">
        <!-- Chatbot Toggle Button -->
        <button id="chatbotToggle" class="chatbot-toggle" aria-label="Open chatbot">
            <i class="fas fa-comments"></i>
            <span class="chatbot-notification" id="chatbotNotification">1</span>
        </button>

        <!-- Chatbot Window -->
        <div id="chatbotWindow" class="chatbot-window">
            <!-- Chat Header -->
            <div class="chat-header">
                <div class="chat-header-content">
                    <div class="chat-avatar">
                        <i class="fas fa-robot"></i>
                    </div>
                    <div class="chat-info">
                        <h3>Atiera HR Assistant</h3>
                        <p>Online • Ready to help</p>
                    </div>
                </div>
                <button class="chat-close" id="chatClose" aria-label="Close chat">
                    <i class="fas fa-times"></i>
                </button>
            </div>

            <!-- Chat Messages Container -->
            <div class="chat-messages" id="chatMessages">
                <!-- Welcome message -->
                <div class="message bot-message">
                    <div class="message-content">
                        <div class="message-text">
                            Hi there! 👋 I'm Atiera's HR Assistant. I can help you with:
                        </div>
                        <div class="quick-replies">
                            <button class="quick-reply" data-question="job-openings">🔍 Current Job Openings</button>
                            <button class="quick-reply" data-question="application-status">📋 Application Status</button>
                            <button class="quick-reply" data-question="interview-process">🎯 Interview Process</button>
                            <button class="quick-reply" data-question="benefits">💰 Employee Benefits</button>
                            <button class="quick-reply" data-question="contact-hr">📞 Contact HR Team</button>
                        </div>
                        <div class="message-time">Just now</div>
                    </div>
                </div>
            </div>

            <!-- Chat Input -->
            <div class="chat-input-container">
                <div class="typing-indicator" id="typingIndicator">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span>HR Assistant is typing...</span>
                </div>
                <form id="chatForm" class="chat-form">
                    <input type="text" id="chatInput" class="chat-input" 
                           placeholder="Type your message here..." 
                           autocomplete="off"
                           aria-label="Type your message">
                    <button type="submit" class="chat-send" aria-label="Send message">
                        <i class="fas fa-paper-plane"></i>
                    </button>
                </form>
                <div class="chat-suggestions">
                    <button class="suggestion-btn" data-suggestion="How do I apply?">How do I apply?</button>
                    <button class="suggestion-btn" data-suggestion="What documents do I need?">Required documents</button>
                    <button class="suggestion-btn" data-suggestion="When will I hear back?">Response time</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Chatbot Widget - END -->

    <!-- Scripts -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        // Initialize AOS
        AOS.init({
            duration: 800,
            once: true,
            easing: 'ease-out-cubic',
            disable: window.innerWidth < 768
        });

        // Utility Functions
        const ModalManager = {
            currentModal: null,
            
            openModal(modal) {
                if (this.currentModal) {
                    this.closeModal(this.currentModal);
                }
                modal.style.display = 'block';
                document.body.style.overflow = 'hidden';
                this.currentModal = modal;
                modal.setAttribute('aria-hidden', 'false');
            },
            
            closeModal(modal) {
                modal.style.display = 'none';
                document.body.style.overflow = '';
                if (this.currentModal === modal) {
                    this.currentModal = null;
                }
                modal.setAttribute('aria-hidden', 'true');
            }
        };

        // Initialize modals
        const modals = {
            whyWork: document.getElementById('whyWorkModal'),
            benefits: document.getElementById('benefitsModal'),
            about: document.getElementById('aboutModal'),
            applyNow: document.getElementById('applyNowModal'),
            viewMore: document.getElementById('viewMoreModal')
        };

        // Job data for JavaScript
        const jobDetails = <?= json_encode(array_map(function($job) {
            // Strip HTML tags from description, requirements, responsibilities
            $description = strip_tags($job['description'] ?? '');
            $requirements = strip_tags($job['requirements'] ?? '');
            $responsibilities = strip_tags($job['responsibilities'] ?? '');
            
            return [
                'id' => $job['id'],
                'title' => htmlspecialchars($job['job_title'], ENT_QUOTES, 'UTF-8'),
                'code' => htmlspecialchars($job['job_code'] ?? '', ENT_QUOTES, 'UTF-8'),
                'department' => htmlspecialchars($job['department'], ENT_QUOTES, 'UTF-8'),
                'location' => htmlspecialchars($job['location'] ?? '', ENT_QUOTES, 'UTF-8'),
                'employment_type' => htmlspecialchars($job['employment_type'], ENT_QUOTES, 'UTF-8'),
                'salary_range' => htmlspecialchars($job['salary_range'] ?? '', ENT_QUOTES, 'UTF-8'),
                'description' => htmlspecialchars($description, ENT_QUOTES, 'UTF-8'),
                'requirements' => htmlspecialchars($requirements, ENT_QUOTES, 'UTF-8'),
                'responsibilities' => htmlspecialchars($responsibilities, ENT_QUOTES, 'UTF-8'),
                'posting_date' => htmlspecialchars($job['posting_date'] ?? '', ENT_QUOTES, 'UTF-8'),
                'closing_date' => htmlspecialchars($job['closing_date'] ?? '', ENT_QUOTES, 'UTF-8'),
                'applications_count' => $job['applications_count'] ?? 0
            ];
        }, $jobs), JSON_HEX_QUOT | JSON_HEX_TAG) ?>;

        // Mobile Navigation Toggle
        const mobileToggle = document.getElementById('mobileToggle');
        const navLinks = document.getElementById('navLinks');
        
        if (mobileToggle && navLinks) {
            mobileToggle.addEventListener('click', () => {
                navLinks.classList.toggle('active');
                const icon = mobileToggle.querySelector('i');
                icon.classList.toggle('fa-bars');
                icon.classList.toggle('fa-times');
                const isExpanded = navLinks.classList.contains('active');
                mobileToggle.setAttribute('aria-expanded', isExpanded);
            });
        }

        // Navbar scroll effect
        window.addEventListener('scroll', () => {
            const navbar = document.querySelector('.navbar');
            if (navbar) {
                navbar.classList.toggle('scrolled', window.scrollY > 50);
            }
        });

        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                const href = this.getAttribute('href');
                if (href === '#') {
                    e.preventDefault();
                    return;
                }
                
                e.preventDefault();
                const target = document.querySelector(href);
                if (target) {
                    const navbarHeight = document.querySelector('.navbar').offsetHeight;
                    window.scrollTo({
                        top: target.offsetTop - navbarHeight,
                        behavior: 'smooth'
                    });
                    // Close mobile menu if open
                    if (navLinks.classList.contains('active')) {
                        navLinks.classList.remove('active');
                        const icon = mobileToggle.querySelector('i');
                        icon.classList.add('fa-bars');
                        icon.classList.remove('fa-times');
                        mobileToggle.setAttribute('aria-expanded', 'false');
                    }
                }
            });
        });

        // Why Work Modal
        const whyWorkBtn = document.querySelector('.why-work-btn');
        if (whyWorkBtn && modals.whyWork) {
            whyWorkBtn.addEventListener('click', e => {
                e.preventDefault();
                ModalManager.openModal(modals.whyWork);
            });
        }

        // Benefits Modal
        const benefitsBtn = document.querySelector('.benefits-link');
        if (benefitsBtn && modals.benefits) {
            benefitsBtn.addEventListener('click', e => {
                e.preventDefault();
                ModalManager.openModal(modals.benefits);
            });
        }

        // About Modal
        const aboutLink = document.getElementById('aboutLink');
        const aboutLinkFooter = document.getElementById('aboutLinkFooter');
        
        const openAboutModal = e => {
            e.preventDefault();
            ModalManager.openModal(modals.about);
        };

        if (aboutLink && modals.about) {
            aboutLink.addEventListener('click', openAboutModal);
        }
        if (aboutLinkFooter && modals.about) {
            aboutLinkFooter.addEventListener('click', openAboutModal);
        }

        // Apply Now Buttons
        const applyNowButtons = document.querySelectorAll('.apply-now-btn');
        const jobPositionInput = document.getElementById('appJobPosition');
        const jobIdInput = document.getElementById('appJobId');
        
        applyNowButtons.forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                
                if (this.disabled) return;
                
                const jobTitle = this.getAttribute('data-job-title');
                const jobId = this.getAttribute('data-job-id');
                
                if (jobPositionInput) {
                    jobPositionInput.value = jobTitle || '';
                }
                if (jobIdInput) {
                    jobIdInput.value = jobId || '';
                }
                
                ModalManager.openModal(modals.applyNow);
            });
        });

        // View More Buttons
        const viewMoreButtons = document.querySelectorAll('.view-more-btn');
        
        viewMoreButtons.forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                const jobId = this.getAttribute('data-job-id');
                const job = jobDetails.find(j => j.id == jobId);
                
                if (job) {
                    document.getElementById('viewJobTitle').textContent = job.title;
                    document.getElementById('viewJobCode').textContent = job.code || 'N/A';
                    document.getElementById('viewJobDepartment').textContent = job.department;
                    document.getElementById('viewJobLocation').textContent = job.location || 'Not specified';
                    document.getElementById('viewJobEmployment').textContent = job.employment_type;
                    document.getElementById('viewJobSalary').textContent = job.salary_range || 'Negotiable';
                    document.getElementById('viewJobPosted').textContent = job.posting_date ? new Date(job.posting_date).toLocaleDateString() : 'N/A';
                    document.getElementById('viewJobClosing').textContent = job.closing_date ? new Date(job.closing_date).toLocaleDateString() : 'Open until filled';
                    document.getElementById('viewJobApplications').textContent = job.applications_count;
                    document.getElementById('viewJobDescription').textContent = job.description || 'No description provided';
                    document.getElementById('viewJobRequirements').textContent = job.requirements || 'No specific requirements listed';
                    document.getElementById('viewJobResponsibilities').textContent = job.responsibilities || 'No specific responsibilities listed';
                    
                    ModalManager.openModal(modals.viewMore);
                }
            });
        });

        // Apply from View More modal
        const applyNowFromView = document.querySelector('.apply-now-btn-modal');
        if (applyNowFromView && modals.viewMore && modals.applyNow) {
            applyNowFromView.addEventListener('click', e => {
                e.preventDefault();
                const jobTitle = document.getElementById('viewJobTitle').textContent;
                const jobId = jobDetails.find(j => j.title === jobTitle)?.id;
                
                if (jobPositionInput) {
                    jobPositionInput.value = jobTitle;
                }
                if (jobIdInput && jobId) {
                    jobIdInput.value = jobId;
                }
                
                ModalManager.closeModal(modals.viewMore);
                ModalManager.openModal(modals.applyNow);
            });
        }

        // Close buttons for all modals
        document.querySelectorAll('.close-btn').forEach(closeBtn => {
            closeBtn.addEventListener('click', function() {
                const modal = this.closest('.modal');
                if (modal) {
                    ModalManager.closeModal(modal);
                }
            });
        });

        // Close modals when clicking outside
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('click', function(e) {
                if (e.target === this) {
                    ModalManager.closeModal(this);
                }
            });
        });

        // Close modals with Escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && ModalManager.currentModal) {
                ModalManager.closeModal(ModalManager.currentModal);
            }
        });

        // Form validation
        const applicationForm = document.getElementById('applicationForm');
        if (applicationForm) {
            const consentCheckbox = document.getElementById('appConsent');
            const submitButton = document.getElementById('submitApplicationBtn');
            
            // Age validation
            const birthdayInput = document.getElementById('appBirthday');
            if (birthdayInput) {
                const maxDate = new Date();
                maxDate.setFullYear(maxDate.getFullYear() - 18);
                birthdayInput.max = maxDate.toISOString().split('T')[0];
                
                birthdayInput.addEventListener('change', function() {
                    const selectedDate = new Date(this.value);
                    const today = new Date();
                    let age = today.getFullYear() - selectedDate.getFullYear();
                    const monthDiff = today.getMonth() - selectedDate.getMonth();
                    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < selectedDate.getDate())) {
                        age--;
                    }
                    
                    if (age < 18) {
                        alert('You must be at least 18 years old to apply.');
                        this.value = '';
                    }
                });
            }
            
            // Resume validation
            const resumeInput = document.getElementById('appResume');
            if (resumeInput) {
                resumeInput.addEventListener('change', function() {
                    const file = this.files[0];
                    if (file) {
                        if (file.size > 5 * 1024 * 1024) {
                            alert('File size must be less than 5MB.');
                            this.value = '';
                            return;
                        }
                        
                        if (file.type !== 'application/pdf') {
                            alert('Only PDF files are accepted.');
                            this.value = '';
                        }
                    }
                });
            }
            
            // Enable submit only when consent is checked
            if (consentCheckbox && submitButton) {
                consentCheckbox.addEventListener('change', function() {
                    submitButton.disabled = !this.checked;
                    submitButton.style.opacity = this.checked ? '1' : '0.5';
                    submitButton.style.cursor = this.checked ? 'pointer' : 'not-allowed';
                });
                
                // Initial state
                submitButton.disabled = true;
                submitButton.style.opacity = '0.5';
                submitButton.style.cursor = 'not-allowed';
            }
        }

        // Auto-hide success message
        const successMessage = document.getElementById('successMessage');
        if (successMessage) {
            successMessage.style.display = 'block';
            setTimeout(() => {
                successMessage.style.display = 'none';
            }, 5000);
        }

        // Show success message from URL parameter
        if (window.location.search.includes('success=1')) {
            const successDiv = document.createElement('div');
            successDiv.className = 'success-message';
            successDiv.textContent = 'Application submitted successfully! We will contact you soon.';
            document.body.appendChild(successDiv);
            successDiv.style.display = 'block';
            
            setTimeout(() => {
                successDiv.style.display = 'none';
                // Remove success parameter from URL without refresh
                const url = new URL(window.location);
                url.searchParams.delete('success');
                window.history.replaceState({}, document.title, url.toString());
            }, 5000);
        }

        // Chatbot functionality - START
        document.addEventListener('DOMContentLoaded', function() {
            const chatbotContainer = document.getElementById('chatbotContainer');
            const chatbotToggle = document.getElementById('chatbotToggle');
            const chatbotWindow = document.getElementById('chatbotWindow');
            const chatClose = document.getElementById('chatClose');
            const chatMessages = document.getElementById('chatMessages');
            const chatForm = document.getElementById('chatForm');
            const chatInput = document.getElementById('chatInput');
            const typingIndicator = document.getElementById('typingIndicator');
            const chatbotNotification = document.getElementById('chatbotNotification');
            
            let isChatOpen = false;
            let unreadMessages = 1;
            
            // Initialize chat with welcome message if no previous state
            if (!localStorage.getItem('chatHistory')) {
                addWelcomeMessage();
            } else {
                loadChatHistory();
            }
            
            // Toggle chat window
            chatbotToggle.addEventListener('click', function() {
                isChatOpen = !isChatOpen;
                chatbotWindow.classList.toggle('active', isChatOpen);
                
                if (isChatOpen) {
                    resetNotification();
                    chatInput.focus();
                    scrollToBottom();
                }
            });
            
            // Close chat
            chatClose.addEventListener('click', function() {
                isChatOpen = false;
                chatbotWindow.classList.remove('active');
            });
            
            // Send message on form submit
            chatForm.addEventListener('submit', function(e) {
                e.preventDefault();
                const message = chatInput.value.trim();
                
                if (message) {
                    addUserMessage(message);
                    chatInput.value = '';
                    simulateBotResponse(message);
                    saveChatHistory();
                }
            });
            
            // Quick reply buttons
            document.querySelectorAll('.quick-reply').forEach(button => {
                button.addEventListener('click', function() {
                    const question = this.getAttribute('data-question');
                    addUserMessage(this.textContent);
                    simulateBotResponse(question);
                    saveChatHistory();
                });
            });
            
            // Suggestion buttons
            document.querySelectorAll('.suggestion-btn').forEach(button => {
                button.addEventListener('click', function() {
                    const suggestion = this.getAttribute('data-suggestion');
                    chatInput.value = suggestion;
                    chatInput.focus();
                });
            });
            
            // Auto-open chat if there's an unread notification
            function checkAutoOpen() {
                const hasNotification = localStorage.getItem('chatNotification');
                if (hasNotification === 'true' && !isChatOpen) {
                    setTimeout(() => {
                        isChatOpen = true;
                        chatbotWindow.classList.add('active');
                        resetNotification();
                        scrollToBottom();
                    }, 2000);
                }
            }
            
            // Add user message to chat
            function addUserMessage(text) {
                const messageDiv = document.createElement('div');
                messageDiv.className = 'message user-message';
                messageDiv.innerHTML = `
                    <div class="message-content">
                        <div class="message-text">${escapeHtml(text)}</div>
                        <div class="message-time">${getCurrentTime()}</div>
                    </div>
                `;
                chatMessages.appendChild(messageDiv);
                scrollToBottom();
            }
            
            // Add bot message to chat
            function addBotMessage(text, options = []) {
                const messageDiv = document.createElement('div');
                messageDiv.className = 'message bot-message';
                
                let quickRepliesHtml = '';
                if (options.length > 0) {
                    quickRepliesHtml = `
                        <div class="quick-replies">
                            ${options.map(option => 
                                `<button class="quick-reply" data-question="${option.value}">${option.text}</button>`
                            ).join('')}
                        </div>
                    `;
                }
                
                messageDiv.innerHTML = `
                    <div class="message-content">
                        <div class="message-text">${text}</div>
                        ${quickRepliesHtml}
                        <div class="message-time">${getCurrentTime()}</div>
                    </div>
                `;
                chatMessages.appendChild(messageDiv);
                
                // Re-attach event listeners to new quick replies
                messageDiv.querySelectorAll('.quick-reply').forEach(button => {
                    button.addEventListener('click', function() {
                        const question = this.getAttribute('data-question');
                        addUserMessage(this.textContent);
                        simulateBotResponse(question);
                        saveChatHistory();
                    });
                });
                
                scrollToBottom();
            }
            
            // Simulate bot response
            function simulateBotResponse(userMessage) {
                // Show typing indicator
                typingIndicator.style.display = 'flex';
                
                // Hide typing indicator after delay and show response
                setTimeout(() => {
                    typingIndicator.style.display = 'none';
                    
                    const response = getBotResponse(userMessage.toLowerCase());
                    addBotMessage(response.text, response.options || []);
                    saveChatHistory();
                    
                    // Show notification if chat is closed
                    if (!isChatOpen) {
                        showNotification();
                    }
                }, 1500 + Math.random() * 1000);
            }
            
            // Bot response logic
            function getBotResponse(message) {
                const responses = {
                    // Job openings
                    'job-openings': {
                        text: `🔍 We currently have ${jobDetails.length} open positions across various departments. Here are some highlights:\n\n${jobDetails.slice(0, 3).map(job => `• ${job.title} (${job.department})`).join('\n')}\n\nYou can view all positions in the "Featured Opportunities" section above. Would you like me to help you apply for a specific position?`,
                        options: [
                            { text: 'Yes, help me apply', value: 'apply-help' },
                            { text: 'View more details', value: 'more-details' },
                            { text: 'Different question', value: 'other' }
                        ]
                    },
                    
                    // Application process
                    'how do i apply?': {
                        text: `📋 Here's our application process:\n\n1. Browse open positions above\n2. Click "Apply Now" on your desired job\n3. Fill out the application form\n4. Upload your resume (PDF format)\n5. Submit and wait for HR review\n\nOur typical response time is 3-5 business days. Need help with a specific application?`,
                        options: [
                            { text: 'What documents do I need?', value: 'application-documents' },
                            { text: 'Check application status', value: 'application-status' },
                            { text: 'Interview preparation', value: 'interview-prep' }
                        ]
                    },
                    
                    // Application status
                    'application-status': {
                        text: `📊 To check your application status:\n\n1. Contact our HR team at careers@atiera.com\n2. Provide your full name and application ID\n3. Allow 3-5 business days for response\n\nYou'll receive email updates at every stage. Need to update your application?`,
                        options: [
                            { text: 'Update application', value: 'update-application' },
                            { text: 'Withdraw application', value: 'withdraw-application' },
                            { text: 'Contact HR', value: 'contact-hr' }
                        ]
                    },
                    
                    // Interview process
                    'interview-process': {
                        text: `🎯 Our interview process typically includes:\n\n• Phone screening (15-20 minutes)\n• Technical/role-specific assessment\n• In-person interview (1-2 rounds)\n• Final offer discussion\n\nWe recommend preparing by:\n1. Researching Atiera\n2. Reviewing the job description\n3. Preparing examples of your work\n\nNeed interview tips?`,
                        options: [
                            { text: 'Interview tips', value: 'interview-tips' },
                            { text: 'Dress code', value: 'dress-code' },
                            { text: 'Interview schedule', value: 'interview-schedule' }
                        ]
                    },
                    
                    // Benefits
                    'benefits': {
                        text: `💰 Atiera offers comprehensive benefits:\n\n• Competitive salary packages\n• Health & dental insurance\n• Professional development\n• Flexible work arrangements\n• Employee discounts\n• Paid time off\n• Retirement plans\n\nWant more details about specific benefits?`,
                        options: [
                            { text: 'Health insurance details', value: 'health-insurance' },
                            { text: 'Professional development', value: 'professional-dev' },
                            { text: 'Employee discounts', value: 'discounts' }
                        ]
                    },
                    
                    // Contact HR
                    'contact-hr': {
                        text: `📞 Contact our HR team:\n\n• Email: careers@atiera.com\n• Phone: +1 (555) 123-4567\n• Hours: Mon-Fri, 9AM-5PM\n• Address: 123 Luxury Avenue, Metro City\n\nFor application status inquiries, please include your application ID. Need immediate assistance?`,
                        options: [
                            { text: 'Application status check', value: 'application-status' },
                            { text: 'Schedule a call', value: 'schedule-call' },
                            { text: 'Different question', value: 'other' }
                        ]
                    },
                    
                    // Required documents
                    'what documents do i need?': {
                        text: `📄 Required documents for application:\n\n• Updated resume/CV (PDF format)\n• Cover letter (optional but recommended)\n• Valid ID/Passport\n• Professional references (2-3)\n• Portfolio (for creative roles)\n\nMake sure your resume highlights relevant experience for the position. Need resume tips?`,
                        options: [
                            { text: 'Resume tips', value: 'resume-tips' },
                            { text: 'Cover letter help', value: 'cover-letter' },
                            { text: 'Portfolio requirements', value: 'portfolio' }
                        ]
                    },
                    
                    // Response time
                    'when will i hear back?': {
                        text: `⏰ Typical response times:\n\n• Application review: 3-5 business days\n• Interview scheduling: Within 1 week of review\n• Final decision: 1-2 weeks after final interview\n\nYou'll receive email updates at each stage. Can check application status after 5 business days.`,
                        options: [
                            { text: 'Check status', value: 'application-status' },
                            { text: 'Update contact info', value: 'update-contact' },
                            { text: 'Withdraw application', value: 'withdraw-application' }
                        ]
                    },
                    
                    // Default response
                    'default': {
                        text: `I'm here to help with your Atiera career questions! You can ask me about:\n\n• Current job openings\n• Application process\n• Interview preparation\n• Employee benefits\n• Contacting HR\n\nWhat would you like to know?`,
                        options: [
                            { text: '🔍 Job Openings', value: 'job-openings' },
                            { text: '📋 How to Apply', value: 'how do i apply?' },
                            { text: '📞 Contact HR', value: 'contact-hr' },
                            { text: '💰 Benefits', value: 'benefits' }
                        ]
                    }
                };
                
                // Check for exact matches
                if (responses[message]) {
                    return responses[message];
                }
                
                // Check for keywords
                const keywords = {
                    'job': 'job-openings',
                    'apply': 'how do i apply?',
                    'status': 'application-status',
                    'interview': 'interview-process',
                    'benefit': 'benefits',
                    'contact': 'contact-hr',
                    'document': 'what documents do i need?',
                    'resume': 'what documents do i need?',
                    'time': 'when will i hear back?',
                    'when': 'when will i hear back?',
                    'salary': 'benefits',
                    'hr': 'contact-hr'
                };
                
                for (const [keyword, responseKey] of Object.entries(keywords)) {
                    if (message.includes(keyword)) {
                        return responses[responseKey];
                    }
                }
                
                // Default response
                return responses['default'];
            }
            
            // Helper functions
            function getCurrentTime() {
                const now = new Date();
                return now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            }
            
            function scrollToBottom() {
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }
            
            function escapeHtml(text) {
                const div = document.createElement('div');
                div.textContent = text;
                return div.innerHTML;
            }
            
            function showNotification() {
                unreadMessages++;
                chatbotNotification.textContent = unreadMessages;
                chatbotNotification.style.display = 'flex';
                localStorage.setItem('chatNotification', 'true');
            }
            
            function resetNotification() {
                unreadMessages = 0;
                chatbotNotification.style.display = 'none';
                localStorage.setItem('chatNotification', 'false');
            }
            
            function saveChatHistory() {
                const messages = Array.from(chatMessages.querySelectorAll('.message')).map(msg => ({
                    html: msg.outerHTML,
                    isBot: msg.classList.contains('bot-message')
                }));
                localStorage.setItem('chatHistory', JSON.stringify(messages));
            }
            
            function loadChatHistory() {
                const history = JSON.parse(localStorage.getItem('chatHistory') || '[]');
                chatMessages.innerHTML = '';
                history.forEach(msg => {
                    const div = document.createElement('div');
                    div.innerHTML = msg.html;
                    chatMessages.appendChild(div.firstChild);
                });
                
                // Re-attach event listeners to quick replies
                document.querySelectorAll('.quick-reply').forEach(button => {
                    button.addEventListener('click', function() {
                        const question = this.getAttribute('data-question');
                        addUserMessage(this.textContent);
                        simulateBotResponse(question);
                        saveChatHistory();
                    });
                });
            }
            
            function addWelcomeMessage() {
                chatMessages.innerHTML = `
                    <div class="message bot-message">
                        <div class="message-content">
                            <div class="message-text">
                                Hi there! 👋 I'm Atiera's HR Assistant. I can help you with:
                            </div>
                            <div class="quick-replies">
                                <button class="quick-reply" data-question="job-openings">🔍 Current Job Openings</button>
                                <button class="quick-reply" data-question="application-status">📋 Application Status</button>
                                <button class="quick-reply" data-question="interview-process">🎯 Interview Process</button>
                                <button class="quick-reply" data-question="benefits">💰 Employee Benefits</button>
                                <button class="quick-reply" data-question="contact-hr">📞 Contact HR Team</button>
                            </div>
                            <div class="message-time">Just now</div>
                        </div>
                    </div>
                `;
            }
            
            // Auto-open after page load if there's a notification
            setTimeout(checkAutoOpen, 1000);
            
            // Close chat when clicking outside
            document.addEventListener('click', function(event) {
                if (isChatOpen && 
                    !chatbotContainer.contains(event.target) && 
                    !chatbotToggle.contains(event.target)) {
                    isChatOpen = false;
                    chatbotWindow.classList.remove('active');
                }
            });
            
            // Keyboard shortcuts
            document.addEventListener('keydown', function(e) {
                if (e.ctrlKey && e.key === '/') {
                    e.preventDefault();
                    chatbotToggle.click();
                }
                
                if (e.key === 'Escape' && isChatOpen) {
                    chatbotWindow.classList.remove('active');
                    isChatOpen = false;
                }
            });
            
            // Initialize notification from localStorage
            const hasNotification = localStorage.getItem('chatNotification') === 'true';
            if (hasNotification) {
                showNotification();
            }
        });
        // Chatbot functionality - END
    </script>
</body>
</html>