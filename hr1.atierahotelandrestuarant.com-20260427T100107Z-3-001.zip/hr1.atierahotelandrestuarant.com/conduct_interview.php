<?php
// File: conduct_interview.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

// Get interview ID
if (!isset($_GET['id'])) {
    header('Location: interviews.php');
    exit();
}

$interview_id = $_GET['id'];

// Fetch interview details with all required information
$query = "SELECT i.*, a.first_name, a.last_name, a.email, a.phone, a.resume_path, 
                 a.job_id, j.job_title, j.department, j.salary_range,
                 u.full_name as scheduled_by
          FROM interviews i
          JOIN applicants a ON i.applicant_id = a.id
          LEFT JOIN job_postings j ON a.job_id = j.id
          LEFT JOIN users u ON i.scheduled_by = u.id
          WHERE i.id = :id";

$stmt = $connections->prepare($query);
$stmt->bindParam(':id', $interview_id, PDO::PARAM_INT);
$stmt->execute();
$interview = $stmt->fetch();

if (!$interview) {
    $_SESSION['error'] = "Interview not found";
    header('Location: interviews.php');
    exit();
}

// Check if interview can be conducted
if ($interview['status'] != 'scheduled') {
    $_SESSION['error'] = "This interview cannot be conducted (already completed or cancelled)";
    header('Location: view_interview.php?id=' . $interview_id);
    exit();
}

// Check if evaluation already exists
$eval_stmt = $connections->prepare("SELECT * FROM interview_evaluations WHERE interview_id = :id");
$eval_stmt->bindParam(':id', $interview_id, PDO::PARAM_INT);
$eval_stmt->execute();
$existing_evaluation = $eval_stmt->fetch();

// Check if applicant is already in onboarding
$onboarding_check = $connections->prepare("
    SELECT id FROM onboarding 
    WHERE applicant_id = :applicant_id 
    AND interview_id = :interview_id
");
$onboarding_check->bindParam(':applicant_id', $interview['applicant_id'], PDO::PARAM_INT);
$onboarding_check->bindParam(':interview_id', $interview_id, PDO::PARAM_INT);
$onboarding_check->execute();
$already_onboarding = $onboarding_check->fetch();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $connections->beginTransaction();
        
        // Get form data
        $technical_skills = $_POST['technical_skills'] ?? 0;
        $communication = $_POST['communication'] ?? 0;
        $cultural_fit = $_POST['cultural_fit'] ?? 0;
        $problem_solving = $_POST['problem_solving'] ?? 0;
        $overall_rating = $_POST['overall_rating'] ?? 0;
        $strengths = $_POST['strengths'] ?? '';
        $weaknesses = $_POST['weaknesses'] ?? '';
        $notes = $_POST['notes'] ?? '';
        $recommendation = $_POST['recommendation'] ?? '';
        $next_steps = $_POST['next_steps'] ?? '';
        
        // Validate required fields
        if (empty($recommendation)) {
            throw new Exception("Please select a recommendation (Hire, Maybe, or Reject)");
        }
        
        // Calculate overall rating if not provided
        if ($overall_rating == 0) {
            $overall_rating = round(($technical_skills + $communication + $cultural_fit + $problem_solving) / 4, 1);
        }
        
        // Insert or update evaluation
        if ($existing_evaluation) {
            $update_query = "UPDATE interview_evaluations SET 
                             technical_skills = :technical_skills,
                             communication = :communication,
                             cultural_fit = :cultural_fit,
                             problem_solving = :problem_solving,
                             overall_rating = :overall_rating,
                             strengths = :strengths,
                             weaknesses = :weaknesses,
                             notes = :notes,
                             recommendation = :recommendation,
                             next_steps = :next_steps,
                             evaluated_by = :user_id,
                             evaluated_at = NOW()
                             WHERE interview_id = :interview_id";
        } else {
            $update_query = "INSERT INTO interview_evaluations 
                             (interview_id, technical_skills, communication, cultural_fit, 
                              problem_solving, overall_rating, strengths, weaknesses, 
                              notes, recommendation, next_steps, evaluated_by, evaluated_at)
                             VALUES 
                             (:interview_id, :technical_skills, :communication, :cultural_fit,
                              :problem_solving, :overall_rating, :strengths, :weaknesses,
                              :notes, :recommendation, :next_steps, :user_id, NOW())";
        }
        
        $update_stmt = $connections->prepare($update_query);
        $update_stmt->bindParam(':interview_id', $interview_id, PDO::PARAM_INT);
        $update_stmt->bindParam(':technical_skills', $technical_skills, PDO::PARAM_STR);
        $update_stmt->bindParam(':communication', $communication, PDO::PARAM_STR);
        $update_stmt->bindParam(':cultural_fit', $cultural_fit, PDO::PARAM_STR);
        $update_stmt->bindParam(':problem_solving', $problem_solving, PDO::PARAM_STR);
        $update_stmt->bindParam(':overall_rating', $overall_rating, PDO::PARAM_STR);
        $update_stmt->bindParam(':strengths', $strengths, PDO::PARAM_STR);
        $update_stmt->bindParam(':weaknesses', $weaknesses, PDO::PARAM_STR);
        $update_stmt->bindParam(':notes', $notes, PDO::PARAM_STR);
        $update_stmt->bindParam(':recommendation', $recommendation, PDO::PARAM_STR);
        $update_stmt->bindParam(':next_steps', $next_steps, PDO::PARAM_STR);
        $update_stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
        $update_stmt->execute();
        
        // Update interview status to completed
        $status_query = "UPDATE interviews SET status = 'completed', updated_at = NOW() WHERE id = :id";
        $status_stmt = $connections->prepare($status_query);
        $status_stmt->bindParam(':id', $interview_id, PDO::PARAM_INT);
        $status_stmt->execute();
        
        // If recommendation is 'hire', add to onboarding
        if ($recommendation == 'hire' && !$already_onboarding) {
            // Generate employee ID
            $prefix = 'EMP';
            $year = date('Y');
            $month = date('m');
            
            // Get the next sequence number
            $seq_query = "SELECT COUNT(*) + 1 as next_seq FROM onboarding WHERE YEAR(created_at) = YEAR(NOW())";
            $seq_stmt = $connections->query($seq_query);
            $seq_result = $seq_stmt->fetch();
            $sequence = str_pad($seq_result['next_seq'], 4, '0', STR_PAD_LEFT);
            
            $employee_id = $prefix . $year . $month . $sequence;
            
            // Insert into onboarding table
            $onboarding_query = "INSERT INTO onboarding 
                                (applicant_id, interview_id, first_name, last_name, email, phone,
                                 job_position, department, salary_range, employee_id, hire_date,
                                 status, contract_signed, documents_complete, orientation_complete,
                                 created_at, updated_at)
                                VALUES 
                                (:applicant_id, :interview_id, :first_name, :last_name, :email, :phone,
                                 :job_position, :department, :salary_range, :employee_id, :hire_date,
                                 'onboarding', 0, 0, 0, NOW(), NOW())";
            
            $onboarding_stmt = $connections->prepare($onboarding_query);
            $onboarding_stmt->bindParam(':applicant_id', $interview['applicant_id'], PDO::PARAM_INT);
            $onboarding_stmt->bindParam(':interview_id', $interview_id, PDO::PARAM_INT);
            $onboarding_stmt->bindParam(':first_name', $interview['first_name']);
            $onboarding_stmt->bindParam(':last_name', $interview['last_name']);
            $onboarding_stmt->bindParam(':email', $interview['email']);
            $onboarding_stmt->bindParam(':phone', $interview['phone']);
            $onboarding_stmt->bindParam(':job_position', $interview['job_title']);
            $onboarding_stmt->bindParam(':department', $interview['department']);
            $onboarding_stmt->bindParam(':salary_range', $interview['salary_range']);
            $onboarding_stmt->bindParam(':employee_id', $employee_id);
            
            // Set hire date to 2 weeks from now (typical onboarding period)
            $hire_date = date('Y-m-d', strtotime('+2 weeks'));
            $onboarding_stmt->bindParam(':hire_date', $hire_date);
            
            $onboarding_stmt->execute();
            
            $onboarding_id = $connections->lastInsertId();
            
            // Log the onboarding creation
            $log_query = "INSERT INTO activity_logs 
                         (user_id, action, details, created_at)
                         VALUES 
                         (:user_id, 'onboarding_created', :details, NOW())";
            
            $log_details = json_encode([
                'applicant_id' => $interview['applicant_id'],
                'interview_id' => $interview_id,
                'onboarding_id' => $onboarding_id,
                'employee_id' => $employee_id,
                'position' => $interview['job_title']
            ]);
            
            $log_stmt = $connections->prepare($log_query);
            $log_stmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
            $log_stmt->bindParam(':details', $log_details);
            $log_stmt->execute();
            
            $_SESSION['success'] = "Interview evaluation submitted successfully! Candidate has been added to Onboarding.";
            $_SESSION['employee_id'] = $employee_id;
            $_SESSION['onboarding_created'] = true;
            
            $connections->commit();
            
            // Clear output buffer and redirect
            if (ob_get_length()) ob_clean();
            header("Location: onboarding.php");
            exit();
            
        } else {
            // If not hired, redirect to view interview
            $_SESSION['success'] = "Interview evaluation submitted successfully!";
            $connections->commit();
            
            // Clear output buffer and redirect
            if (ob_get_length()) ob_clean();
            header("Location: view_interview.php?id=" . $interview_id);
            exit();
        }
        
    } catch (Exception $e) {
        $connections->rollBack();
        $_SESSION['error'] = "Failed to submit evaluation: " . $e->getMessage();
    }
}

// Parse scheduled datetime
$scheduled_date = new DateTime($interview['scheduled_date']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>HR1 - Conduct Interview</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        .rating-stars label {
            transition: all 0.2s ease;
        }
        .rating-stars label:hover i {
            transform: scale(1.2);
        }
        .recommendation-option {
            transition: all 0.2s ease;
        }
        .recommendation-option:hover {
            transform: translateY(-2px);
        }
        .animate-spin {
            animation: spin 1s linear infinite;
        }
        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
    </style>
</head>
<body class="h-screen bg-gray-100 font-sans">
<div class="flex h-full">
    
    <!-- Sidebar -->
    <?php include 'sidebar.php'; ?>
    
    <!-- Main Content -->
    <div class="flex-1 flex flex-col overflow-y-auto">
        <main class="p-6">
            <!-- Header -->
            <div class="flex items-center justify-between border-b border-gray-300 pb-4 mb-6">
                <div>
                    <div class="flex items-center space-x-3">
                        <a href="view_interview.php?id=<?php echo $interview['id']; ?>" class="text-blue-600 hover:text-blue-800">
                            <i data-lucide="arrow-left" class="w-5 h-5"></i>
                        </a>
                        <h2 class="text-2xl font-bold text-gray-800">Conduct Interview</h2>
                    </div>
                    <p class="text-sm text-gray-600">Evaluate candidate performance</p>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="view_interview.php?id=<?php echo $interview['id']; ?>" 
                       class="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                        Cancel
                    </a>
                    <?php include 'profile_dropdown.php'; ?>
                </div>
            </div>

            <!-- Messages -->
            <?php if(isset($_SESSION['error'])): ?>
                <div class="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
                    <div class="flex items-center">
                        <i data-lucide="alert-circle" class="w-5 h-5 text-red-600 mr-2"></i>
                        <p class="text-red-700"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></p>
                    </div>
                </div>
            <?php endif; ?>

            <?php if(isset($_SESSION['onboarding_created'])): ?>
                <div class="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg">
                    <div class="flex items-center">
                        <i data-lucide="check-circle" class="w-5 h-5 text-green-600 mr-2"></i>
                        <div>
                            <p class="text-green-700 font-medium">Candidate added to Onboarding!</p>
                            <p class="text-green-600 text-sm mt-1">
                                Employee ID: <strong><?php echo $_SESSION['employee_id']; ?></strong> | 
                                <a href="onboarding.php" class="underline hover:text-green-800">View Onboarding Dashboard</a>
                            </p>
                        </div>
                    </div>
                </div>
                <?php unset($_SESSION['onboarding_created'], $_SESSION['employee_id']); ?>
            <?php endif; ?>

            <!-- Main Content -->
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <!-- Left Column - Form -->
                <div class="lg:col-span-2">
                    <form method="POST" action="" class="space-y-6" id="evaluationForm">
                        <div class="bg-white rounded-lg shadow border">
                            <div class="p-6 border-b border-gray-200">
                                <h3 class="text-lg font-semibold text-gray-800">Candidate Evaluation</h3>
                            </div>
                            <div class="p-6">
                                <!-- Ratings Grid -->
                                <div class="mb-8">
                                    <h4 class="text-md font-medium text-gray-700 mb-4">Rating Categories</h4>
                                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <!-- Technical Skills -->
                                        <div>
                                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                                Technical Skills
                                            </label>
                                            <div class="flex space-x-1 rating-stars">
                                                <?php for($i = 1; $i <= 5; $i++): ?>
                                                    <label class="cursor-pointer">
                                                        <input type="radio" name="technical_skills" value="<?php echo $i; ?>" 
                                                               class="hidden" 
                                                               <?php echo ($existing_evaluation['technical_skills'] ?? 0) == $i ? 'checked' : ''; ?>>
                                                        <i data-lucide="star" class="w-8 h-8 
                                                            <?php echo ($existing_evaluation['technical_skills'] ?? 0) >= $i ? 'text-yellow-500 fill-yellow-500' : 'text-gray-300'; ?>
                                                            hover:text-yellow-400 hover:fill-yellow-400"></i>
                                                    </label>
                                                <?php endfor; ?>
                                            </div>
                                        </div>

                                        <!-- Communication Skills -->
                                        <div>
                                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                                Communication
                                            </label>
                                            <div class="flex space-x-1 rating-stars">
                                                <?php for($i = 1; $i <= 5; $i++): ?>
                                                    <label class="cursor-pointer">
                                                        <input type="radio" name="communication" value="<?php echo $i; ?>" 
                                                               class="hidden"
                                                               <?php echo ($existing_evaluation['communication'] ?? 0) == $i ? 'checked' : ''; ?>>
                                                        <i data-lucide="star" class="w-8 h-8 
                                                            <?php echo ($existing_evaluation['communication'] ?? 0) >= $i ? 'text-yellow-500 fill-yellow-500' : 'text-gray-300'; ?>
                                                            hover:text-yellow-400 hover:fill-yellow-400"></i>
                                                    </label>
                                                <?php endfor; ?>
                                            </div>
                                        </div>

                                        <!-- Cultural Fit -->
                                        <div>
                                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                                Cultural Fit
                                            </label>
                                            <div class="flex space-x-1 rating-stars">
                                                <?php for($i = 1; $i <= 5; $i++): ?>
                                                    <label class="cursor-pointer">
                                                        <input type="radio" name="cultural_fit" value="<?php echo $i; ?>" 
                                                               class="hidden"
                                                               <?php echo ($existing_evaluation['cultural_fit'] ?? 0) == $i ? 'checked' : ''; ?>>
                                                        <i data-lucide="star" class="w-8 h-8 
                                                            <?php echo ($existing_evaluation['cultural_fit'] ?? 0) >= $i ? 'text-yellow-500 fill-yellow-500' : 'text-gray-300'; ?>
                                                            hover:text-yellow-400 hover:fill-yellow-400"></i>
                                                    </label>
                                                <?php endfor; ?>
                                            </div>
                                        </div>

                                        <!-- Problem Solving -->
                                        <div>
                                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                                Problem Solving
                                            </label>
                                            <div class="flex space-x-1 rating-stars">
                                                <?php for($i = 1; $i <= 5; $i++): ?>
                                                    <label class="cursor-pointer">
                                                        <input type="radio" name="problem_solving" value="<?php echo $i; ?>" 
                                                               class="hidden"
                                                               <?php echo ($existing_evaluation['problem_solving'] ?? 0) == $i ? 'checked' : ''; ?>>
                                                        <i data-lucide="star" class="w-8 h-8 
                                                            <?php echo ($existing_evaluation['problem_solving'] ?? 0) >= $i ? 'text-yellow-500 fill-yellow-500' : 'text-gray-300'; ?>
                                                            hover:text-yellow-400 hover:fill-yellow-400"></i>
                                                    </label>
                                                <?php endfor; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Overall Rating -->
                                <div class="mb-6">
                                    <label class="block text-sm font-medium text-gray-700 mb-2">
                                        Overall Rating
                                    </label>
                                    <div class="flex space-x-1 rating-stars">
                                        <?php for($i = 1; $i <= 5; $i++): ?>
                                            <label class="cursor-pointer">
                                                <input type="radio" name="overall_rating" value="<?php echo $i; ?>" 
                                                       class="hidden"
                                                       <?php echo ($existing_evaluation['overall_rating'] ?? 0) == $i ? 'checked' : ''; ?>>
                                                <i data-lucide="star" class="w-10 h-10 
                                                    <?php echo ($existing_evaluation['overall_rating'] ?? 0) >= $i ? 'text-yellow-500 fill-yellow-500' : 'text-gray-300'; ?>
                                                    hover:text-yellow-400 hover:fill-yellow-400"></i>
                                            </label>
                                        <?php endfor; ?>
                                    </div>
                                </div>

                                <!-- Strengths & Weaknesses -->
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">
                                            Strengths
                                        </label>
                                        <textarea name="strengths" rows="4" 
                                                  class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                                  placeholder="List the candidate's key strengths..."><?php echo htmlspecialchars($existing_evaluation['strengths'] ?? ''); ?></textarea>
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">
                                            Areas for Improvement
                                        </label>
                                        <textarea name="weaknesses" rows="4" 
                                                  class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                                  placeholder="Areas where the candidate can improve..."><?php echo htmlspecialchars($existing_evaluation['weaknesses'] ?? ''); ?></textarea>
                                    </div>
                                </div>

                                <!-- Recommendation -->
                                <div class="mb-6">
                                    <label class="block text-sm font-medium text-gray-700 mb-2">
                                        Recommendation *
                                    </label>
                                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                        <label class="recommendation-option flex items-center p-4 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50 
                                            <?php echo ($existing_evaluation['recommendation'] ?? '') == 'hire' ? 'border-green-500 bg-green-50' : ''; ?>">
                                            <input type="radio" name="recommendation" value="hire" 
                                                   class="h-4 w-4 text-green-600 focus:ring-green-500"
                                                   <?php echo ($existing_evaluation['recommendation'] ?? '') == 'hire' ? 'checked' : ''; ?>
                                                   required>
                                            <div class="ml-3">
                                                <span class="block text-sm font-medium text-gray-900">Hire</span>
                                                <span class="block text-sm text-gray-500">Strong candidate for the role</span>
                                                <?php if($already_onboarding): ?>
                                                <span class="block text-xs text-yellow-600 mt-1">
                                                    <i data-lucide="info" class="w-3 h-3 inline"></i> Already in onboarding
                                                </span>
                                                <?php endif; ?>
                                            </div>
                                        </label>
                                        <label class="recommendation-option flex items-center p-4 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50 
                                            <?php echo ($existing_evaluation['recommendation'] ?? '') == 'maybe' ? 'border-yellow-500 bg-yellow-50' : ''; ?>">
                                            <input type="radio" name="recommendation" value="maybe" 
                                                   class="h-4 w-4 text-yellow-600 focus:ring-yellow-500"
                                                   <?php echo ($existing_evaluation['recommendation'] ?? '') == 'maybe' ? 'checked' : ''; ?>
                                                   required>
                                            <div class="ml-3">
                                                <span class="block text-sm font-medium text-gray-900">Maybe</span>
                                                <span class="block text-sm text-gray-500">Consider other candidates first</span>
                                            </div>
                                        </label>
                                        <label class="recommendation-option flex items-center p-4 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50 
                                            <?php echo ($existing_evaluation['recommendation'] ?? '') == 'reject' ? 'border-red-500 bg-red-50' : ''; ?>">
                                            <input type="radio" name="recommendation" value="reject" 
                                                   class="h-4 w-4 text-red-600 focus:ring-red-500"
                                                   <?php echo ($existing_evaluation['recommendation'] ?? '') == 'reject' ? 'checked' : ''; ?>
                                                   required>
                                            <div class="ml-3">
                                                <span class="block text-sm font-medium text-gray-900">Reject</span>
                                                <span class="block text-sm text-gray-500">Not suitable for this role</span>
                                            </div>
                                        </label>
                                    </div>
                                </div>

                                <!-- Additional Notes -->
                                <div class="mb-6">
                                    <label class="block text-sm font-medium text-gray-700 mb-2">
                                        Detailed Notes
                                    </label>
                                    <textarea name="notes" rows="6" 
                                              class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                              placeholder="Detailed feedback, specific examples from the interview, observations..."><?php echo htmlspecialchars($existing_evaluation['notes'] ?? ''); ?></textarea>
                                </div>

                                <!-- Next Steps -->
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">
                                        Next Steps
                                    </label>
                                    <textarea name="next_steps" rows="3" 
                                              class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                              placeholder="e.g., Schedule second interview, Technical assessment, Reference checks..."><?php echo htmlspecialchars($existing_evaluation['next_steps'] ?? ''); ?></textarea>
                                </div>
                            </div>
                        </div>

                        <!-- Form Actions -->
                        <div class="flex items-center justify-between">
                            <a href="view_interview.php?id=<?php echo $interview['id']; ?>" 
                               class="px-6 py-3 border border-gray-300 rounded-lg hover:bg-gray-50">
                                Cancel
                            </a>
                            <div class="flex space-x-3">
                                <button type="submit" name="submit" 
                                        class="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 flex items-center space-x-2">
                                    <i data-lucide="check-circle" class="w-5 h-5"></i>
                                    <span>Complete Interview</span>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>

                <!-- Right Column - Interview Info -->
                <div class="space-y-6">
                    <!-- Interview Details -->
                    <div class="bg-white rounded-lg shadow border">
                        <div class="p-6 border-b border-gray-200">
                            <h3 class="text-lg font-semibold text-gray-800">Interview Details</h3>
                        </div>
                        <div class="p-6">
                            <div class="space-y-4">
                                <div>
                                    <p class="text-sm text-gray-600">Candidate</p>
                                    <p class="font-medium text-gray-900">
                                        <?php echo htmlspecialchars($interview['first_name'] . ' ' . $interview['last_name']); ?>
                                    </p>
                                    <p class="text-sm text-gray-600"><?php echo htmlspecialchars($interview['email']); ?></p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-600">Position</p>
                                    <p class="font-medium text-gray-900">
                                        <?php echo htmlspecialchars($interview['job_title'] ?? 'N/A'); ?>
                                    </p>
                                    <?php if(!empty($interview['department'])): ?>
                                    <p class="text-sm text-gray-600"><?php echo htmlspecialchars($interview['department']); ?></p>
                                    <?php endif; ?>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-600">Scheduled Time</p>
                                    <p class="font-medium text-gray-900">
                                        <?php echo $scheduled_date->format('F j, Y'); ?>
                                    </p>
                                    <p class="text-gray-700">
                                        <?php echo $scheduled_date->format('h:i A'); ?>
                                    </p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-600">Interview Type</p>
                                    <p class="font-medium text-gray-900">
                                        <?php echo ucfirst($interview['interview_type'] ?? 'Not specified'); ?>
                                    </p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-600">Interviewers</p>
                                    <p class="font-medium text-gray-900">
                                        <?php echo htmlspecialchars($interview['interviewers']); ?>
                                    </p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-600">Location/Platform</p>
                                    <p class="font-medium text-gray-900">
                                        <?php echo htmlspecialchars($interview['location'] ?? 'Not specified'); ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Onboarding Preview -->
                    <div id="onboardingPreview" class="hidden bg-gradient-to-r from-green-50 to-blue-50 border border-green-200 rounded-lg p-6">
                        <h4 class="text-md font-semibold text-green-800 mb-3 flex items-center">
                            <i data-lucide="user-check" class="w-5 h-5 mr-2"></i>
                            Onboarding Preview
                        </h4>
                        <div class="space-y-3 text-sm text-green-800">
                            <div class="flex items-center justify-between">
                                <span>Employee ID:</span>
                                <span class="font-mono font-bold" id="previewEmpId">EMP<?php echo date('Ym'); ?>0001</span>
                            </div>
                            <div class="flex items-center justify-between">
                                <span>Hire Date:</span>
                                <span><?php echo date('M d, Y', strtotime('+2 weeks')); ?></span>
                            </div>
                            <div class="flex items-center justify-between">
                                <span>Initial Status:</span>
                                <span class="px-2 py-1 bg-yellow-100 text-yellow-800 text-xs rounded-full">Onboarding</span>
                            </div>
                            <div class="mt-4 pt-3 border-t border-green-200">
                                <p class="text-green-700 text-xs">
                                    <i data-lucide="info" class="w-3 h-3 inline mr-1"></i>
                                    Selecting "Hire" will automatically create an onboarding record
                                </p>
                            </div>
                        </div>
                    </div>

                    <!-- Evaluation Tips -->
                    <div class="bg-blue-50 border border-blue-200 rounded-lg p-6">
                        <h4 class="text-md font-semibold text-blue-800 mb-3 flex items-center">
                            <i data-lucide="lightbulb" class="w-5 h-5 mr-2"></i>
                            Evaluation Tips
                        </h4>
                        <ul class="space-y-2 text-sm text-blue-700">
                            <li class="flex items-start">
                                <i data-lucide="check-circle" class="w-4 h-4 mr-2 mt-0.5 flex-shrink-0"></i>
                                <span>Be specific with examples from the interview</span>
                            </li>
                            <li class="flex items-start">
                                <i data-lucide="check-circle" class="w-4 h-4 mr-2 mt-0.5 flex-shrink-0"></i>
                                <span>Focus on job-relevant skills and behaviors</span>
                            </li>
                            <li class="flex items-start">
                                <i data-lucide="check-circle" class="w-4 h-4 mr-2 mt-0.5 flex-shrink-0"></i>
                                <span>Provide constructive feedback for improvement</span>
                            </li>
                            <li class="flex items-start">
                                <i data-lucide="check-circle" class="w-4 h-4 mr-2 mt-0.5 flex-shrink-0"></i>
                                <span>Consider both technical and cultural fit</span>
                            </li>
                            <li class="flex items-start">
                                <i data-lucide="check-circle" class="w-4 h-4 mr-2 mt-0.5 flex-shrink-0"></i>
                                <span class="font-medium">"Hire" recommendation triggers automatic onboarding</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
    lucide.createIcons();
    
    // Handle star rating interactions
    const ratingGroups = ['technical_skills', 'communication', 'cultural_fit', 'problem_solving', 'overall_rating'];
    
    ratingGroups.forEach(groupName => {
        const radios = document.querySelectorAll(`input[name="${groupName}"]`);
        radios.forEach(radio => {
            radio.addEventListener('change', function() {
                const value = parseInt(this.value);
                
                // Update all stars for this rating group
                document.querySelectorAll(`input[name="${groupName}"]`).forEach((star, index) => {
                    const icon = star.nextElementSibling;
                    if (index < value) {
                        icon.classList.remove('text-gray-300');
                        icon.classList.add('text-yellow-500', 'fill-yellow-500');
                    } else {
                        icon.classList.remove('text-yellow-500', 'fill-yellow-500');
                        icon.classList.add('text-gray-300');
                    }
                });
            });
        });
    });
    
    // Handle recommendation selection
    const recommendationRadios = document.querySelectorAll('input[name="recommendation"]');
    const onboardingPreview = document.getElementById('onboardingPreview');
    
    recommendationRadios.forEach(radio => {
        radio.addEventListener('change', function() {
            // Remove all selection styles
            document.querySelectorAll('.recommendation-option').forEach(option => {
                option.classList.remove('border-green-500', 'bg-green-50', 
                                       'border-yellow-500', 'bg-yellow-50',
                                       'border-red-500', 'bg-red-50');
            });
            
            // Add style to selected option
            const parent = this.closest('.recommendation-option');
            if (this.value === 'hire') {
                parent.classList.add('border-green-500', 'bg-green-50');
                onboardingPreview.classList.remove('hidden');
            } else if (this.value === 'maybe') {
                parent.classList.add('border-yellow-500', 'bg-yellow-50');
                onboardingPreview.classList.add('hidden');
            } else if (this.value === 'reject') {
                parent.classList.add('border-red-500', 'bg-red-50');
                onboardingPreview.classList.add('hidden');
            }
            
            // Update onboarding preview if hire is selected
            if (this.value === 'hire') {
                const now = new Date();
                const year = now.getFullYear();
                const month = String(now.getMonth() + 1).padStart(2, '0');
                // Generate a random sequence for demo
                const sequence = String(Math.floor(Math.random() * 9999) + 1).padStart(4, '0');
                document.getElementById('previewEmpId').textContent = `EMP${year}${month}${sequence}`;
            }
        });
    });
    
    // Trigger change event for any pre-selected ratings and recommendations
    document.querySelectorAll('input[type="radio"]:checked').forEach(radio => {
        radio.dispatchEvent(new Event('change'));
    });
    
    // Form validation
    const form = document.getElementById('evaluationForm');
    form.addEventListener('submit', function(e) {
        const recommendation = document.querySelector('input[name="recommendation"]:checked');
        if (!recommendation) {
            e.preventDefault();
            alert('Please select a recommendation (Hire, Maybe, or Reject)');
            return;
        }
        
        // Confirm if selecting "Hire"
        if (recommendation.value === 'hire') {
            const confirmMessage = `Are you sure you want to recommend this candidate for hiring?\n\n` +
                                  `This will:\n` +
                                  `1. Mark the interview as completed\n` +
                                  `2. Create an onboarding record\n` +
                                  `3. Send the candidate to the onboarding dashboard\n\n` +
                                  `Click OK to confirm or Cancel to review.`;
            
            if (!confirm(confirmMessage)) {
                e.preventDefault();
            } else {
                // Show loading indicator
                const submitBtn = form.querySelector('button[type="submit"]');
                submitBtn.innerHTML = '<i data-lucide="loader-2" class="w-5 h-5 animate-spin"></i><span>Processing...</span>';
                submitBtn.disabled = true;
                
                // Add a small delay to show the loading state
                setTimeout(() => {
                    // Allow form to submit normally
                }, 500);
            }
        }
    });
});
</script>
</body>
</html>