<?php
// File: delete_request.php
session_start();
require_once 'connections.php';
require_once 'functions.php';

// Ensure user is authenticated
requireAuth();

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['flash_message'] = [
        'type' => 'error',
        'message' => 'Invalid request method.'
    ];
    header('Location: user_job_requests.php');
    exit;
}

// Check if ID is provided
if (!isset($_POST['id']) || empty($_POST['id'])) {
    $_SESSION['flash_message'] = [
        'type' => 'error',
        'message' => 'No job request specified.'
    ];
    header('Location: user_job_requests.php');
    exit;
}

$request_id = (int)$_POST['id'];

// Verify user has permission to delete (must be admin, hr_manager, or hr_officer)
if (!in_array($_SESSION['user_role'], ['admin', 'hr_manager', 'hr_officer'])) {
    $_SESSION['flash_message'] = [
        'type' => 'error',
        'message' => 'You do not have permission to delete job requests.'
    ];
    header('Location: job_requests.php');
    exit;
}

try {
    // Begin transaction
    $connections->beginTransaction();

    // Check if the job request exists
    $checkStmt = $connections->prepare("SELECT id FROM job_requests WHERE id = ?");
    $checkStmt->execute([$request_id]);
    if (!$checkStmt->fetch()) {
        $_SESSION['flash_message'] = [
            'type' => 'error',
            'message' => 'Job request not found.'
        ];
        header('Location: job_requests.php');
        exit;
    }

    // Check for any associated job postings
    $postingStmt = $connections->prepare("SELECT id FROM job_postings WHERE job_request_id = ? LIMIT 1");
    $postingStmt->execute([$request_id]);
    if ($postingStmt->fetch()) {
        // There is a job posting linked to this request – prevent deletion
        $connections->rollBack();
        $_SESSION['flash_message'] = [
            'type' => 'warning',
            'message' => 'Cannot delete this request because it has an associated job posting. Remove the posting first.'
        ];
        header('Location: job_requests.php');
        exit;
    }

    // Optionally, check for other dependencies (e.g., applicants, interviews) – add similar checks here if needed.

    // Perform deletion
    $deleteStmt = $connections->prepare("DELETE FROM job_requests WHERE id = ?");
    $deleteStmt->execute([$request_id]);

    // Commit transaction
    $connections->commit();

    // Set success message
    $_SESSION['flash_message'] = [
        'type' => 'success',
        'message' => 'Job request deleted successfully.'
    ];

} catch (Exception $e) {
    // Rollback on error
    $connections->rollBack();
    error_log("Error deleting job request: " . $e->getMessage());
    $_SESSION['flash_message'] = [
        'type' => 'error',
        'message' => 'An error occurred while deleting the request. Please try again.'
    ];
}

// Redirect back to the job requests page
header('Location: job_requests.php');
exit;