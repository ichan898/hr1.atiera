<?php
// File: job_requests.php - FULLY RESPONSIVE (Sidebar Unaffected)
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

// Get filters
$status = $_GET['status'] ?? '';
$department = $_GET['department'] ?? '';
$urgency = $_GET['urgency'] ?? '';
$search = $_GET['search'] ?? '';
$sort_by = $_GET['sort_by'] ?? 'created_at';
$sort_order = $_GET['sort_order'] ?? 'DESC';

// Build filters array
$filters = [
    'status' => $status,
    'department' => $department,
    'urgency' => $urgency,
    'search' => $search,
    'sort_by' => $sort_by,
    'sort_order' => $sort_order
];

// Get job requests
$job_requests = getJobRequests($filters, $connections);

// Get statistics
$stats = getJobRequestStats(null, $connections);

// Get departments for filter
$departments = getDepartments($connections);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
<title>HR1 - Job Requests</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<style>
  /* Responsive customizations - only for main content, sidebar untouched */
  @media (max-width: 640px) {
    .stats-card {
      padding: 1rem !important;
    }
    .stats-card i {
      width: 1.5rem !important;
      height: 1.5rem !important;
    }
    .stats-card p.text-2xl {
      font-size: 1.25rem !important;
    }
    .tab-link {
      padding: 0.75rem 1rem !important;
      font-size: 0.75rem !important;
    }
    .action-buttons-container {
      gap: 0.5rem !important;
    }
    .action-btn {
      padding: 0.25rem 0.5rem !important;
    }
    .action-btn i {
      width: 1rem !important;
      height: 1rem !important;
    }
    /* Better touch targets */
    button, a, .clickable {
      min-height: 44px;
    }
    td, th {
      padding-left: 0.75rem !important;
      padding-right: 0.75rem !important;
    }
  }
  
  @media (max-width: 768px) {
    .filter-grid {
      gap: 0.75rem !important;
    }
    .sort-controls {
      flex-direction: column;
      align-items: stretch !important;
      gap: 0.75rem;
    }
    .sort-controls > div {
      width: 100%;
      justify-content: space-between;
    }
    .filter-actions {
      flex-direction: column;
      width: 100%;
    }
    .filter-actions button, .filter-actions a {
      width: 100%;
      text-align: center;
      justify-content: center;
    }
  }
  
  /* Table horizontal scroll for mobile - smooth */
  .table-wrapper {
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
    scrollbar-width: thin;
  }
  
  .actions-cell {
    min-width: 140px;
  }
  
  /* Prevent zoom on iOS for form elements */
  select, input, button {
    font-size: 16px;
  }
</style>
</head>

<body class="h-screen bg-gray-100 font-sans">
<div class="flex h-full">
  
  <!-- Sidebar - untouched, original structure preserved -->
  <?php include 'sidebar.php'; ?>
  
  <!-- Main Content - fully responsive, independent of sidebar -->
  <div class="flex-1 flex flex-col overflow-y-auto">
    <main class="p-4 md:p-6 space-y-4 md:space-y-6">
      <!-- Header with responsive stacking -->
      <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between border-b border-gray-300 pb-4 gap-3">
        <div>
          <h2 class="text-xl md:text-2xl font-bold text-gray-800">Job Requests</h2>
          <p class="text-xs md:text-sm text-gray-600">Manage and track all job requisition requests</p>
        </div>
        <div class="flex flex-wrap items-center gap-2 md:gap-4">
          <a href="job_request_form.php" class="inline-flex items-center justify-center gap-2 px-3 py-2 md:px-4 md:py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm md:text-base">
            <i data-lucide="plus" class="w-4 h-4"></i>
            <span>New Request</span>
          </a>
          <a href="job_postings.php" class="inline-flex items-center justify-center gap-2 px-3 py-2 md:px-4 md:py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 text-sm md:text-base">
            <i data-lucide="briefcase" class="w-4 h-4"></i>
            <span>View Postings</span>
          </a>
          
          <?php include 'profile_dropdown.php'; ?>
        </div>
      </div>

      <!-- Flash Messages -->
      <?php if (isset($_SESSION['flash_message'])): ?>
        <div class="bg-<?php echo $_SESSION['flash_message']['type'] == 'success' ? 'green' : ($_SESSION['flash_message']['type'] == 'warning' ? 'yellow' : 'red'); ?>-50 border border-<?php echo $_SESSION['flash_message']['type'] == 'success' ? 'green' : ($_SESSION['flash_message']['type'] == 'warning' ? 'yellow' : 'red'); ?>-400 text-<?php echo $_SESSION['flash_message']['type'] == 'success' ? 'green' : ($_SESSION['flash_message']['type'] == 'warning' ? 'yellow' : 'red'); ?>-700 px-4 py-3 rounded-lg">
          <div class="flex items-center">
            <i data-lucide="<?php echo $_SESSION['flash_message']['type'] == 'success' ? 'check-circle' : ($_SESSION['flash_message']['type'] == 'warning' ? 'alert-triangle' : 'alert-circle'); ?>" class="w-5 h-5 mr-2"></i>
            <span><?php echo $_SESSION['flash_message']['message']; ?></span>
          </div>
        </div>
        <?php unset($_SESSION['flash_message']); ?>
      <?php endif; ?>

      <!-- Stats Cards - Responsive Grid -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
        <div class="stats-card bg-white p-4 md:p-6 rounded-lg shadow border">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-xs md:text-sm text-gray-600">Total Requests</p>
              <p class="text-xl md:text-2xl font-bold text-gray-800"><?php echo $stats['total']; ?></p>
            </div>
            <i data-lucide="inbox" class="w-6 h-6 md:w-8 md:h-8 text-blue-500"></i>
          </div>
        </div>
        
        <div class="stats-card bg-white p-4 md:p-6 rounded-lg shadow border">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-xs md:text-sm text-gray-600">Pending Review</p>
              <p class="text-xl md:text-2xl font-bold text-gray-800"><?php echo $stats['pending']; ?></p>
            </div>
            <i data-lucide="clock" class="w-6 h-6 md:w-8 md:h-8 text-yellow-500"></i>
          </div>
        </div>
        
        <div class="stats-card bg-white p-4 md:p-6 rounded-lg shadow border">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-xs md:text-sm text-gray-600">Approved</p>
              <p class="text-xl md:text-2xl font-bold text-gray-800"><?php echo $stats['approved']; ?></p>
            </div>
            <i data-lucide="check-circle" class="w-6 h-6 md:w-8 md:h-8 text-green-500"></i>
          </div>
        </div>
        
        <div class="stats-card bg-white p-4 md:p-6 rounded-lg shadow border">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-xs md:text-sm text-gray-600">Rejected</p>
              <p class="text-xl md:text-2xl font-bold text-gray-800"><?php echo $stats['rejected']; ?></p>
            </div>
            <i data-lucide="x-circle" class="w-6 h-6 md:w-8 md:h-8 text-red-500"></i>
          </div>
        </div>
      </div>

      <!-- Tabs & Filters Container -->
      <div class="bg-white rounded-lg shadow">
        <!-- Responsive Tabs with horizontal scroll on mobile -->
        <div class="border-b overflow-x-auto">
          <nav class="flex min-w-max md:min-w-0">
            <a href="?status=pending" class="tab-link py-3 md:py-4 px-4 md:px-6 border-b-2 font-medium text-xs md:text-sm whitespace-nowrap 
              <?php echo $status == 'pending' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'; ?>">
              Pending (<?php echo $stats['pending']; ?>)
            </a>
            <a href="?status=approved" class="tab-link py-3 md:py-4 px-4 md:px-6 border-b-2 font-medium text-xs md:text-sm whitespace-nowrap 
              <?php echo $status == 'approved' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'; ?>">
              Approved (<?php echo $stats['approved']; ?>)
            </a>
            <a href="?status=rejected" class="tab-link py-3 md:py-4 px-4 md:px-6 border-b-2 font-medium text-xs md:text-sm whitespace-nowrap 
              <?php echo $status == 'rejected' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'; ?>">
              Rejected (<?php echo $stats['rejected']; ?>)
            </a>
            <a href="?status=draft" class="tab-link py-3 md:py-4 px-4 md:px-6 border-b-2 font-medium text-xs md:text-sm whitespace-nowrap 
              <?php echo $status == 'draft' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'; ?>">
              Draft (<?php echo $stats['draft']; ?>)
            </a>
            <a href="job_requests.php" class="tab-link py-3 md:py-4 px-4 md:px-6 border-b-2 font-medium text-xs md:text-sm whitespace-nowrap 
              <?php echo empty($status) ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'; ?>">
              All
            </a>
          </nav>
        </div>

        <!-- Filters - Fully Responsive -->
        <div class="p-4 md:p-6 border-b">
          <form method="GET" class="space-y-4">
            <div class="filter-grid grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
              <!-- Status Filter -->
              <div>
                <label class="block text-xs md:text-sm font-medium text-gray-700 mb-1 md:mb-2">Status</label>
                <select name="status" 
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm md:text-base">
                  <option value="">All Status</option>
                  <option value="pending" <?php echo $status == 'pending' ? 'selected' : ''; ?>>Pending</option>
                  <option value="approved" <?php echo $status == 'approved' ? 'selected' : ''; ?>>Approved</option>
                  <option value="rejected" <?php echo $status == 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                  <option value="draft" <?php echo $status == 'draft' ? 'selected' : ''; ?>>Draft</option>
                </select>
              </div>
              
              <!-- Department Filter -->
              <div>
                <label class="block text-xs md:text-sm font-medium text-gray-700 mb-1 md:mb-2">Department</label>
                <select name="department" 
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm md:text-base">
                  <option value="">All Departments</option>
                  <?php foreach ($departments as $dept): ?>
                    <option value="<?php echo htmlspecialchars($dept['name']); ?>"
                      <?php echo $department == $dept['name'] ? 'selected' : ''; ?>>
                      <?php echo htmlspecialchars($dept['name']); ?>
                    </option>
                  <?php endforeach; ?>
                </select>
              </div>
              
              <!-- Urgency Filter -->
              <div>
                <label class="block text-xs md:text-sm font-medium text-gray-700 mb-1 md:mb-2">Urgency</label>
                <select name="urgency" 
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm md:text-base">
                  <option value="">All Urgency</option>
                  <option value="critical" <?php echo $urgency == 'critical' ? 'selected' : ''; ?>>Critical</option>
                  <option value="high" <?php echo $urgency == 'high' ? 'selected' : ''; ?>>High</option>
                  <option value="medium" <?php echo $urgency == 'medium' ? 'selected' : ''; ?>>Medium</option>
                  <option value="low" <?php echo $urgency == 'low' ? 'selected' : ''; ?>>Low</option>
                </select>
              </div>
              
              <!-- Search -->
              <div>
                <label class="block text-xs md:text-sm font-medium text-gray-700 mb-1 md:mb-2">Search</label>
                <div class="relative">
                  <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>"
                         placeholder="Search requests..."
                         class="w-full px-3 py-2 border border-gray-300 rounded-lg pl-9 md:pl-10 text-sm md:text-base">
                  <i data-lucide="search" class="absolute left-3 top-2.5 w-4 h-4 text-gray-400"></i>
                </div>
              </div>
            </div>
            
            <!-- Sort Options & Buttons - Responsive stacking -->
            <div class="sort-controls flex flex-col md:flex-row justify-between items-stretch md:items-center gap-3 md:gap-4">
              <div class="flex flex-col sm:flex-row gap-3">
                <select name="sort_by" 
                        class="px-3 py-2 border border-gray-300 rounded-lg text-sm md:text-base">
                  <option value="created_at" <?php echo $sort_by == 'created_at' ? 'selected' : ''; ?>>Sort by Date</option>
                  <option value="urgency_level" <?php echo $sort_by == 'urgency_level' ? 'selected' : ''; ?>>Sort by Urgency</option>
                  <option value="target_start_date" <?php echo $sort_by == 'target_start_date' ? 'selected' : ''; ?>>Sort by Start Date</option>
                  <option value="position_title" <?php echo $sort_by == 'position_title' ? 'selected' : ''; ?>>Sort by Job Title</option>
                </select>
                
                <select name="sort_order" 
                        class="px-3 py-2 border border-gray-300 rounded-lg text-sm md:text-base">
                  <option value="DESC" <?php echo $sort_order == 'DESC' ? 'selected' : ''; ?>>Newest First</option>
                  <option value="ASC" <?php echo $sort_order == 'ASC' ? 'selected' : ''; ?>>Oldest First</option>
                </select>
              </div>
              
              <div class="filter-actions flex flex-col sm:flex-row gap-3">
                <button type="submit"
                        class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm md:text-base flex items-center justify-center gap-2">
                  <i data-lucide="filter" class="w-4 h-4"></i> Apply Filters
                </button>
                <a href="job_requests.php"
                   class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 text-center text-sm md:text-base flex items-center justify-center gap-2">
                  <i data-lucide="x" class="w-4 h-4"></i> Clear All
                </a>
              </div>
            </div>
          </form>
        </div>

        <!-- Job Requests Table - Horizontally Scrollable on Mobile -->
        <div class="table-wrapper overflow-x-auto">
          <table class="min-w-[800px] md:min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
              <tr>
                <th class="px-4 md:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Request ID</th>
                <th class="px-4 md:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Job Title</th>
                <th class="px-4 md:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Department</th>
                <th class="px-4 md:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Requester</th>
                <th class="px-4 md:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Urgency</th>
                <th class="px-4 md:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th class="px-4 md:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Created Date</th>
                <th class="px-4 md:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
              <?php if(empty($job_requests)): ?>
                <tr>
                  <td colspan="8" class="px-4 md:px-6 py-12 text-center text-gray-500">
                    <i data-lucide="inbox" class="w-10 h-10 md:w-12 md:h-12 mx-auto text-gray-400 mb-4"></i>
                    <p>No job requests found</p>
                    <a href="job_request_form.php" class="mt-2 inline-block text-blue-600 hover:underline text-sm">
                      Create your first job request
                    </a>
                  </td>
                </tr>
              <?php else: ?>
                <?php foreach($job_requests as $request): 
                  // Check if posting exists for this request
                  $hasPosting = hasJobPosting($request['id'], $connections);
                ?>
                <tr class="hover:bg-gray-50">
                  <td class="px-4 md:px-6 py-3 md:py-4">
                    <div class="text-xs md:text-sm font-medium text-gray-900"><?php echo htmlspecialchars($request['job_code'] ?? 'N/A'); ?></div>
                  </td>
                  <td class="px-4 md:px-6 py-3 md:py-4">
                    <div class="text-xs md:text-sm font-medium text-gray-900"><?php echo htmlspecialchars($request['position_title']); ?></div>
                    <div class="text-xs text-gray-500">
                      Budget: &#8369;<?php echo number_format($request['salary_budget'] ?? 0); ?>
                      <?php if($request['number_needed'] > 1): ?>
                        | Positions: <?php echo $request['number_needed']; ?>
                      <?php endif; ?>
                    </div>
                  </td>
                  <td class="px-4 md:px-6 py-3 md:py-4 text-xs md:text-sm text-gray-900"><?php echo htmlspecialchars($request['department']); ?></td>
                  <td class="px-4 md:px-6 py-3 md:py-4">
                    <div class="text-xs md:text-sm text-gray-900"><?php echo htmlspecialchars($request['requester_name'] ?? $request['requested_by']); ?></div>
                    <div class="text-xs text-gray-500">
                      <?php echo htmlspecialchars($request['hiring_manager_name'] ?? $request['requested_by']); ?>
                    </div>
                  </td>
                  <td class="px-4 md:px-6 py-3 md:py-4">
                    <span class="px-2 md:px-3 py-1 text-[10px] md:text-xs rounded-full <?php echo getUrgencyColor($request['urgency_level'] ?? 'medium'); ?>">
                      <?php echo strtoupper($request['urgency_level'] ?? 'MEDIUM'); ?>
                    </span>
                  </td>
                  <td class="px-4 md:px-6 py-3 md:py-4">
                    <span class="px-2 md:px-3 py-1 text-[10px] md:text-xs rounded-full <?php echo getJobRequestStatusColor($request['overall_status']); ?> whitespace-nowrap">
                      <?php echo ucfirst($request['overall_status']); ?>
                      <?php if($hasPosting && $request['overall_status'] == 'approved'): ?>
                        <i data-lucide="check" class="w-3 h-3 inline ml-1"></i>
                      <?php endif; ?>
                    </span>
                  </td>
                  <td class="px-4 md:px-6 py-3 md:py-4 text-xs md:text-sm text-gray-500">
                    <?php echo date('M d, Y', strtotime($request['created_at'])); ?>
                  </td>
                  <td class="px-4 md:px-6 py-3 md:py-4 actions-cell">
                    <div class="flex flex-wrap gap-1 md:gap-2 action-buttons-container">
                      <a href="view_request.php?id=<?php echo $request['id']; ?>" 
                         class="action-btn inline-flex items-center justify-center p-1.5 md:p-2 text-sm bg-gray-100 rounded hover:bg-gray-200" title="View">
                        <i data-lucide="eye" class="w-3.5 h-3.5 md:w-4 md:h-4"></i>
                      </a>
                      <?php if(canEditJobRequest($request['id'], $_SESSION['user_id'], $_SESSION['user_role'], $connections)): ?>
                        <a href="edit_request.php?id=<?php echo $request['id']; ?>" 
                           class="action-btn inline-flex items-center justify-center p-1.5 md:p-2 text-sm bg-blue-100 text-blue-700 rounded hover:bg-blue-200" title="Edit">
                          <i data-lucide="edit" class="w-3.5 h-3.5 md:w-4 md:h-4"></i>
                        </a>
                      <?php endif; ?>
                      
                      <!-- Create Posting button for approved requests without posting -->
                      <?php if($request['overall_status'] == 'approved' && !$hasPosting): ?>
                        <form method="POST" action="create_posting_from_request.php" 
                              class="inline" 
                              onsubmit="return confirm('Create job posting from this approved request?');">
                          <input type="hidden" name="request_id" value="<?php echo $request['id']; ?>">
                          <button type="submit" class="action-btn inline-flex items-center justify-center p-1.5 md:p-2 text-sm bg-green-100 text-green-700 rounded hover:bg-green-200" title="Create Job Posting">
                            <i data-lucide="file-text" class="w-3.5 h-3.5 md:w-4 md:h-4"></i>
                          </button>
                        </form>
                      <?php endif; ?>
                      
                      <!-- View Posting button for approved requests with posting -->
                      <?php if($hasPosting && $request['overall_status'] == 'approved'): ?>
                        <?php 
                          // Get posting ID
                          $postingStmt = $connections->prepare("SELECT id FROM job_postings WHERE job_request_id = ?");
                          $postingStmt->execute([$request['id']]);
                          $posting = $postingStmt->fetch();
                        ?>
                        <a href="view_posting.php?id=<?php echo $posting['id']; ?>" 
                           class="action-btn inline-flex items-center justify-center p-1.5 md:p-2 text-sm bg-green-100 text-green-700 rounded hover:bg-green-200" title="View Job Posting">
                          <i data-lucide="external-link" class="w-3.5 h-3.5 md:w-4 md:h-4"></i>
                        </a>
                      <?php endif; ?>
                      
                      <?php if(in_array($_SESSION['user_role'], ['admin', 'hr_manager', 'hr_officer'])): ?>
                        <form method="POST" action="delete_request.php" 
                              class="inline" 
                              onsubmit="return confirm('Are you sure you want to delete this request?');">
                          <input type="hidden" name="id" value="<?php echo $request['id']; ?>">
                          <button type="submit" class="action-btn inline-flex items-center justify-center p-1.5 md:p-2 text-sm bg-red-100 text-red-700 rounded hover:bg-red-200" title="Delete">
                            <i data-lucide="trash-2" class="w-3.5 h-3.5 md:w-4 md:h-4"></i>
                          </button>
                        </form>
                      <?php endif; ?>
                    </div>
                  </td>
                </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
          
          <!-- Pagination - Responsive -->
          <?php if(!empty($job_requests)): ?>
          <div class="px-4 md:px-6 py-4 border-t border-gray-200">
            <div class="flex flex-col sm:flex-row justify-between items-center gap-3">
              <div class="text-xs md:text-sm text-gray-700">
                Showing <span class="font-medium">1</span> to 
                <span class="font-medium"><?php echo count($job_requests); ?></span> of 
                <span class="font-medium"><?php echo $stats['total']; ?></span> results
              </div>
              <div class="flex flex-wrap justify-center gap-2">
                <button class="px-3 py-1 border border-gray-300 rounded text-sm hover:bg-gray-50">
                  Previous
                </button>
                <button class="px-3 py-1 border border-gray-300 rounded text-sm bg-blue-50 text-blue-600">
                  1
                </button>
                <button class="px-3 py-1 border border-gray-300 rounded text-sm hover:bg-gray-50">
                  Next
                </button>
              </div>
            </div>
          </div>
          <?php endif; ?>
        </div>
      </div>
    </main>
  </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
  lucide.createIcons();
});
</script>
</body>
</html>