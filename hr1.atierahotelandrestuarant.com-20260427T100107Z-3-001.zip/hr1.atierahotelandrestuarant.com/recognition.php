<?php
// File: recognition.php - Enhanced Employee Recognition Dashboard with Milestones
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

// Get filters
$status = $_GET['status'] ?? '';
$category = $_GET['category'] ?? '';
$employee_id = $_GET['employee_id'] ?? '';
$start_date = $_GET['start_date'] ?? '';
$end_date = $_GET['end_date'] ?? '';
$search = $_GET['search'] ?? '';
$sort_by = $_GET['sort_by'] ?? 'created_at';
$sort_order = $_GET['sort_order'] ?? 'DESC';

// Build filters array
$filters = [
    'status' => $status,
    'category' => $category,
    'employee_id' => $employee_id,
    'start_date' => $start_date,
    'end_date' => $end_date,
    'search' => $search,
    'sort_by' => $sort_by,
    'sort_order' => $sort_order
];

// Get recognitions
$recognitions = getRecognitions($filters, $connections);

// Get statistics
$stats = getRecognitionStats($connections);

// Get employees for filter
$employees = getEmployees($connections);

// Get categories
$categories = getRecognitionCategories();

// Get recent recognitions for sidebar
$recent_recognitions = getRecentRecognitions(5, $connections);

// Get top recognized employees
$top_employees = getTopRecognizedEmployees(5, $connections);

// Get recognitions by category for chart
$recognitions_by_category = getRecognitionsByCategory($connections);

// --- NEW: Milestone Data ---
$total_milestones = 0;
$recent_milestones = [];
if (function_exists('getTotalMilestones')) {
    $total_milestones = getTotalMilestones($connections);
}
if (function_exists('getRecentMilestones')) {
    $recent_milestones = getRecentMilestones(5, $connections);
}
// ---------------------------
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>HR1 - Employee Recognition & Milestones</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body class="h-screen bg-gray-100 font-sans">
<div class="flex h-full">
  
  <!-- Sidebar -->
  <?php include 'sidebar.php'; ?>
  
  <!-- Main Content -->
  <div class="flex-1 flex flex-col overflow-y-auto">
    <main class="p-6 space-y-6">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-gray-300 pb-4">
        <div>
          <h2 class="text-2xl font-bold text-gray-800">Employee Recognition & Milestones</h2>
          <p class="text-sm text-gray-600">Recognize achievements and track performance milestones</p>
        </div>
        <div class="flex items-center space-x-4">
          <a href="recognition_form.php" class="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            <i data-lucide="award" class="w-4 h-4"></i>
            <span>New Recognition</span>
          </a>
          <!-- NEW: Configuration / Settings Button -->
          <a href="recognition_settings.php" class="flex items-center space-x-2 px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300">
            <i data-lucide="settings" class="w-4 h-4"></i>
            <span>Configure</span>
          </a>
          <?php include 'profile_dropdown.php'; ?>
        </div>
      </div>

      <!-- Flash Messages -->
      <?php if (isset($_SESSION['flash_message'])): ?>
        <div class="bg-<?php echo $_SESSION['flash_message']['type'] == 'success' ? 'green' : ($_SESSION['flash_message']['type'] == 'warning' ? 'yellow' : 'red'); ?>-50 border border-<?php echo $_SESSION['flash_message']['type'] == 'success' ? 'green' : ($_SESSION['flash_message']['type'] == 'warning' ? 'yellow' : 'red'); ?>-400 text-<?php echo $_SESSION['flash_message']['type'] == 'success' ? 'green' : ($_SESSION['flash_message']['type'] == 'warning' ? 'yellow' : 'red'); ?>-700 px-4 py-3 rounded-lg">
          <div class="flex items-center">
            <i data-lucide="<?php echo $_SESSION['flash_message']['type'] == 'success' ? 'check-circle' : ($_SESSION['flash_message']['type'] == 'warning' ? 'alert-triangle' : 'alert-circle'); ?>" class="w-5 h-5 mr-2"></i>
            <span><?php echo $_SESSION['flash_message']['message']; ?></span>
          </div>
        </div>
        <?php unset($_SESSION['flash_message']); ?>
      <?php endif; ?>

      <!-- Stats Row (now 5 cards) -->
      <div class="grid grid-cols-1 md:grid-cols-5 gap-6">
        <div class="bg-white p-6 rounded-lg shadow border">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-600">Total Recognitions</p>
              <p class="text-2xl font-bold text-gray-800"><?php echo $stats['total']; ?></p>
            </div>
            <i data-lucide="award" class="w-8 h-8 text-blue-500"></i>
          </div>
        </div>
        
        <div class="bg-white p-6 rounded-lg shadow border">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-600">This Month</p>
              <p class="text-2xl font-bold text-gray-800"><?php echo $stats['this_month']; ?></p>
            </div>
            <i data-lucide="calendar" class="w-8 h-8 text-green-500"></i>
          </div>
        </div>
        
        <div class="bg-white p-6 rounded-lg shadow border">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-600">Total Points</p>
              <p class="text-2xl font-bold text-gray-800"><?php echo number_format($stats['total_points']); ?></p>
            </div>
            <i data-lucide="star" class="w-8 h-8 text-yellow-500"></i>
          </div>
        </div>
        
        <div class="bg-white p-6 rounded-lg shadow border">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-600">Top Employee</p>
              <p class="text-lg font-bold text-gray-800"><?php echo htmlspecialchars($stats['top_employee']); ?></p>
              <p class="text-xs text-gray-500"><?php echo $stats['top_employee_count']; ?> recognitions</p>
            </div>
            <i data-lucide="trophy" class="w-8 h-8 text-purple-500"></i>
          </div>
        </div>

        <!-- NEW: Milestones Achieved Card -->
        <div class="bg-white p-6 rounded-lg shadow border">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-600">Milestones Achieved</p>
              <p class="text-2xl font-bold text-gray-800"><?php echo $total_milestones; ?></p>
            </div>
            <i data-lucide="flag" class="w-8 h-8 text-indigo-500"></i>
          </div>
        </div>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Main Content (Recognition Table) -->
        <div class="lg:col-span-2">
          <!-- Tabs (unchanged) -->
          <div class="bg-white rounded-lg shadow mb-6">
            <div class="border-b">
              <nav class="flex -mb-px">
                <a href="?status=published" class="py-4 px-6 border-b-2 font-medium text-sm 
                  <?php echo $status == 'published' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'; ?>">
                  Published (<?php echo $stats['total']; ?>)
                </a>
                <a href="?status=draft" class="py-4 px-6 border-b-2 font-medium text-sm 
                  <?php echo $status == 'draft' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'; ?>">
                  Draft
                </a>
                <a href="?status=archived" class="py-4 px-6 border-b-2 font-medium text-sm 
                  <?php echo $status == 'archived' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'; ?>">
                  Archived
                </a>
                <a href="recognition.php" class="py-4 px-6 border-b-2 font-medium text-sm 
                  <?php echo empty($status) ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'; ?>">
                  All
                </a>
              </nav>
            </div>

            <!-- Filters (unchanged) -->
            <div class="p-6 border-b">
              <form method="GET" class="space-y-4">
                <div class="grid md:grid-cols-2 gap-4">
                  <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Employee</label>
                    <select name="employee_id" class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                      <option value="">All Employees</option>
                      <?php foreach ($employees as $employee): ?>
                        <option value="<?php echo $employee['id']; ?>" <?php echo $employee_id == $employee['id'] ? 'selected' : ''; ?>>
                          <?php echo htmlspecialchars($employee['full_name']); ?> (<?php echo htmlspecialchars($employee['department']); ?>)
                        </option>
                      <?php endforeach; ?>
                    </select>
                  </div>
                  <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Category</label>
                    <select name="category" class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                      <option value="">All Categories</option>
                      <?php foreach ($categories as $key => $label): ?>
                        <option value="<?php echo htmlspecialchars($key); ?>" <?php echo $category == $key ? 'selected' : ''; ?>>
                          <?php echo htmlspecialchars($label); ?>
                        </option>
                      <?php endforeach; ?>
                    </select>
                  </div>
                </div>
                <div class="grid md:grid-cols-3 gap-4">
                  <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">From Date</label>
                    <input type="date" name="start_date" value="<?php echo htmlspecialchars($start_date); ?>" class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                  </div>
                  <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">To Date</label>
                    <input type="date" name="end_date" value="<?php echo htmlspecialchars($end_date); ?>" class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                  </div>
                  <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Search</label>
                    <div class="relative">
                      <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search recognitions..." class="w-full px-3 py-2 border border-gray-300 rounded-lg pl-10">
                      <i data-lucide="search" class="absolute left-3 top-2.5 w-4 h-4 text-gray-400"></i>
                    </div>
                  </div>
                </div>
                <div class="flex justify-between items-center">
                  <div class="flex space-x-4">
                    <select name="sort_by" class="px-3 py-2 border border-gray-300 rounded-lg text-sm">
                      <option value="created_at" <?php echo $sort_by == 'created_at' ? 'selected' : ''; ?>>Sort by Date Created</option>
                      <option value="recognition_date" <?php echo $sort_by == 'recognition_date' ? 'selected' : ''; ?>>Sort by Recognition Date</option>
                      <option value="points_awarded" <?php echo $sort_by == 'points_awarded' ? 'selected' : ''; ?>>Sort by Points</option>
                    </select>
                    <select name="sort_order" class="px-3 py-2 border border-gray-300 rounded-lg text-sm">
                      <option value="DESC" <?php echo $sort_order == 'DESC' ? 'selected' : ''; ?>>Newest First</option>
                      <option value="ASC" <?php echo $sort_order == 'ASC' ? 'selected' : ''; ?>>Oldest First</option>
                    </select>
                  </div>
                  <div class="flex space-x-3">
                    <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">Apply Filters</button>
                    <a href="recognition.php" class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">Clear All</a>
                  </div>
                </div>
              </form>
            </div>

            <!-- Recognitions Table (unchanged) -->
            <div class="overflow-x-auto">
              <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                  <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Employee</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Category</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Description</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Points</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                  </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                  <?php if(empty($recognitions)): ?>
                    <tr><td colspan="7" class="px-6 py-12 text-center text-gray-500"><i data-lucide="award" class="w-12 h-12 mx-auto text-gray-400 mb-4"></i><p>No recognitions found</p><a href="recognition_form.php" class="mt-2 inline-block text-blue-600 hover:underline">Create your first recognition</a></td></tr>
                  <?php else: ?>
                    <?php foreach($recognitions as $recognition): ?>
                    <tr class="hover:bg-gray-50">
                      <td class="px-6 py-4">
                        <div class="flex items-center">
                          <div class="flex-shrink-0 h-10 w-10 bg-blue-100 rounded-full flex items-center justify-center"><span class="text-blue-600 font-bold"><?php echo strtoupper(substr($recognition['employee_name'], 0, 1)); ?></span></div>
                          <div class="ml-4"><div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($recognition['employee_name']); ?></div><div class="text-sm text-gray-500"><?php echo htmlspecialchars($recognition['employee_position']); ?></div></div>
                        </div>
                      </td>
                      <td class="px-6 py-4"><span class="px-3 py-1 text-xs rounded-full <?php echo getRecognitionCategoryColor($recognition['category']); ?>"><?php $category_labels = getRecognitionCategories(); echo htmlspecialchars($category_labels[$recognition['category']] ?? $recognition['category']); ?></span></td>
                      <td class="px-6 py-4"><div class="text-sm text-gray-900 line-clamp-2"><?php echo htmlspecialchars($recognition['description']); ?></div><div class="text-xs text-gray-500 mt-1">By: <?php echo htmlspecialchars($recognition['recognizer_name']); ?></div></td>
                      <td class="px-6 py-4"><div class="text-sm font-bold text-gray-900"><?php echo number_format($recognition['points_awarded']); ?></div></td>
                      <td class="px-6 py-4 text-sm text-gray-500"><?php echo date('M d, Y', strtotime($recognition['recognition_date'])); ?></td>
                      <td class="px-6 py-4"><span class="px-3 py-1 text-xs rounded-full <?php echo getRecognitionStatusColor($recognition['status']); ?>"><?php echo ucfirst($recognition['status']); ?></span></td>
                      <td class="px-6 py-4">
                        <div class="flex space-x-2">
                          <a href="view_recognition.php?id=<?php echo $recognition['id']; ?>" class="px-3 py-1 text-sm bg-gray-100 rounded hover:bg-gray-200" title="View"><i data-lucide="eye" class="w-4 h-4"></i></a>
                          <?php if(canEditRecognition($recognition, $_SESSION['user_id'], $_SESSION['user_role'])): ?>
                            <a href="edit_recognition.php?id=<?php echo $recognition['id']; ?>" class="px-3 py-1 text-sm bg-blue-100 text-blue-700 rounded hover:bg-blue-200" title="Edit"><i data-lucide="edit" class="w-4 h-4"></i></a>
                          <?php endif; ?>
                          <?php if(in_array($_SESSION['user_role'], ['admin', 'hr_manager', 'hr_officer'])): ?>
                            <form method="POST" action="delete_recognition.php" class="inline" onsubmit="return confirm('Are you sure you want to delete this recognition?');"><input type="hidden" name="id" value="<?php echo $recognition['id']; ?>"><button type="submit" class="px-3 py-1 text-sm bg-red-100 text-red-700 rounded hover:bg-red-200" title="Delete"><i data-lucide="trash-2" class="w-4 h-4"></i></button></form>
                          <?php endif; ?>
                        </div>
                      </td>
                    </tr>
                    <?php endforeach; ?>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <!-- Sidebar (Enhanced) -->
        <div class="space-y-6">
          <!-- Top Employees (unchanged) -->
          <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Top Recognized Employees</h3>
            <div class="space-y-4">
              <?php if(empty($top_employees)): ?>
                <p class="text-sm text-gray-500 text-center py-4">No recognition data yet</p>
              <?php else: ?>
                <?php foreach($top_employees as $index => $employee): ?>
                <div class="flex items-center justify-between">
                  <div class="flex items-center">
                    <div class="flex-shrink-0 h-8 w-8 bg-blue-100 rounded-full flex items-center justify-center mr-3"><span class="text-blue-600 text-sm font-bold"><?php echo $index + 1; ?></span></div>
                    <div><p class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($employee['full_name']); ?></p><p class="text-xs text-gray-500"><?php echo htmlspecialchars($employee['department']); ?></p></div>
                  </div>
                  <div class="text-right"><p class="text-sm font-bold text-gray-900"><?php echo $employee['recognition_count']; ?></p><p class="text-xs text-gray-500"><?php echo $employee['total_points']; ?> pts</p></div>
                </div>
                <?php endforeach; ?>
              <?php endif; ?>
            </div>
          </div>

          <!-- NEW: Recent Milestones Section -->
          <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">🏆 Recent Milestones</h3>
            <div class="space-y-4">
              <?php if(empty($recent_milestones)): ?>
                <p class="text-sm text-gray-500 text-center py-4">No milestones achieved yet</p>
              <?php else: ?>
                <?php foreach($recent_milestones as $milestone): ?>
                <div class="border-l-4 border-indigo-500 pl-4 py-2">
                  <p class="text-sm text-gray-900">
                    <span class="font-medium"><?php echo htmlspecialchars($milestone['full_name']); ?></span>
                    reached
                    <span class="font-medium"><?php echo htmlspecialchars($milestone['milestone_name']); ?></span>
                  </p>
                  <p class="text-xs text-gray-500 mt-1">
                    <?php echo date('M d, Y', strtotime($milestone['achieved_at'])); ?>
                    <?php if(!empty($milestone['badge_name'])): ?> • 🏅 <?php echo htmlspecialchars($milestone['badge_name']); ?><?php endif; ?>
                  </p>
                </div>
                <?php endforeach; ?>
              <?php endif; ?>
            </div>
          </div>

          <!-- Recognition by Category Chart (unchanged) -->
          <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Recognition by Category</h3>
            <div class="h-64"><canvas id="categoryChart"></canvas></div>
          </div>

          <!-- Recent Recognitions (unchanged) -->
          <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Recent Recognitions</h3>
            <div class="space-y-4">
              <?php if(empty($recent_recognitions)): ?>
                <p class="text-sm text-gray-500 text-center py-4">No recent recognitions</p>
              <?php else: ?>
                <?php foreach($recent_recognitions as $recognition): ?>
                <div class="border-l-4 border-blue-500 pl-4 py-2">
                  <p class="text-sm text-gray-900"><span class="font-medium"><?php echo htmlspecialchars($recognition['employee_name']); ?></span> was recognized for <span class="font-medium"><?php echo htmlspecialchars($category_labels[$recognition['category']] ?? $recognition['category']); ?></span></p>
                  <p class="text-xs text-gray-500 mt-1">By <?php echo htmlspecialchars($recognition['recognizer_name']); ?> • <?php echo date('M d', strtotime($recognition['recognition_date'])); ?></p>
                </div>
                <?php endforeach; ?>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </main>
  </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
  lucide.createIcons();
  
  // Initialize category chart (unchanged)
  const categoryCtx = document.getElementById('categoryChart');
  if (categoryCtx) {
    const categoryData = <?php echo json_encode($recognitions_by_category); ?>;
    const labels = categoryData.map(item => {
      const categories = <?php echo json_encode(getRecognitionCategories()); ?>;
      return categories[item.category] || item.category;
    });
    const counts = categoryData.map(item => item.count);
    new Chart(categoryCtx, {
      type: 'doughnut',
      data: {
        labels: labels,
        datasets: [{
          data: counts,
          backgroundColor: ['#3b82f6','#8b5cf6','#6366f1','#0ea5e9','#10b981','#f59e0b','#ef4444','#84cc16','#f97316','#ec4899'],
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { position: 'bottom', labels: { boxWidth: 12, padding: 15 } } }
      }
    });
  }
});
</script>
</body>
</html>