<?php
// test_otp_email.php - Direct test of the OTP email function
require_once 'connections.php';
require_once 'email_functions.php';

$recipient = 'vergarajamesryan47@gmail.com';  // your Gmail address
$name = 'System Administrator';
$otp = generateOtp();  // generates a fresh 6-digit OTP

echo "Testing sendOtpEmail()...<br>";
echo "Recipient: $recipient<br>";
echo "Name: $name<br>";
echo "OTP: $otp<br><br>";

$result = sendOtpEmail($recipient, $name, $otp);

if ($result) {
    echo "<span style='color:green; font-weight:bold;'>✅ OTP email sent successfully! Check your inbox/spam.</span>";
    echo "<br>OTP code: $otp (use this to log in)";
} else {
    echo "<span style='color:red; font-weight:bold;'>❌ OTP email sending failed.</span>";
    echo "<br>Check the PHP error log for details.";
}
?>