<?php
// File: edit_request.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

$requestId = $_GET['id'] ?? 0;
$request = getJobRequest($requestId, $connections);

if (!$request) {
    header('Location: job_requests.php');
    exit();
}

// Check permission
if (!canEditJobRequest($requestId, $_SESSION['user_id'], $_SESSION['user_role'], $connections)) {
    header('Location: view_request.php?id=' . $requestId);
    exit();
}

// Get departments list
$departments = getDepartmentsList($connections);
$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data - MATCHING YOUR ACTUAL DATABASE COLUMNS
    $data = [
        'id' => $requestId,
        'position_title' => $_POST['position_title'] ?? '',
        'department' => $_POST['department'] ?? '',
        'number_needed' => $_POST['number_needed'] ?? 1,
        'reason' => $_POST['reason'] ?? 'new_position',
        'qualifications' => $_POST['qualifications'] ?? '',
        'target_start_date' => $_POST['target_start_date'] ?? '',
        'requested_by' => $_POST['requested_by'] ?? '',
        'requested_by_email' => $_POST['requested_by_email'] ?? '',
        'justification' => $_POST['justification'] ?? '',
        'budget_approved' => isset($_POST['budget_approved']) ? 1 : 0,
        'position_type' => $_POST['position_type'] ?? 'new_position',
        'required_skills' => $_POST['required_skills'] ?? '',
        'experience_level' => $_POST['experience_level'] ?? 'mid',
        'education_level' => $_POST['education_level'] ?? 'bachelor',
        'responsibilities' => $_POST['responsibilities'] ?? '',
        'reporting_to' => $_POST['reporting_to'] ?? '',
        'salary_budget' => $_POST['salary_budget'] ?? 0,
        'urgency_level' => $_POST['urgency_level'] ?? 'medium'
    ];
    
    // Validate required fields
    if (empty($data['position_title'])) {
        $errors[] = 'Position title is required';
    }
    if (empty($data['department'])) {
        $errors[] = 'Department is required';
    }
    if (empty($data['qualifications'])) {
        $errors[] = 'Qualifications are required';
    }
    if (empty($data['target_start_date'])) {
        $errors[] = 'Target start date is required';
    }
    if (empty($data['requested_by'])) {
        $errors[] = 'Requested by is required';
    }
    if (empty($data['requested_by_email'])) {
        $errors[] = 'Requested by email is required';
    } elseif (!filter_var($data['requested_by_email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Invalid email format';
    }
    if (empty($data['justification'])) {
        $errors[] = 'Justification is required';
    }
    
    // If no errors, update the request
    if (empty($errors)) {
        $success = updateJobRequest($data, $connections);
        
        if ($success) {
            // If saving as draft
            if (isset($_POST['save_draft'])) {
                // Update status to draft
                updateJobRequestStatus($requestId, 'draft', 'Saved as draft', $connections);
                header('Location: edit_request.php?id=' . $requestId . '&success=1&type=draft');
                exit();
            } else {
                // Submit for review (update status to pending)
                updateJobRequestStatus($requestId, 'pending', 'Submitted for review', $connections);
                header('Location: view_request.php?id=' . $requestId . '&success=1');
                exit();
            }
        } else {
            $errors[] = 'Failed to update job request. Please try again.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>HR1 - Edit Job Request</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
</head>

<body class="h-screen bg-gray-100 font-sans">
<div class="flex h-full">
  
  <!-- Sidebar -->
  <?php include 'user_sidebar.php'; ?>
  
  <!-- Main Content -->
  <div class="flex-1 flex flex-col overflow-y-auto">
    <main class="p-6 space-y-6">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-gray-300 pb-4">
        <div>
          <h2 class="text-2xl font-bold text-gray-800">Edit Job Request</h2>
          <p class="text-sm text-gray-600">Update job requisition details</p>
          <?php if (!empty($request['job_code'])): ?>
            <p class="text-sm text-gray-500">Request ID: <?php echo htmlspecialchars($request['job_code']); ?></p>
          <?php endif; ?>
        </div>
        <div class="flex items-center space-x-4">
          <a href="user_job_requests.php" class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
            Back to List
          </a>
          <a href="view_request.php?id=<?php echo $requestId; ?>" 
             class="px-4 py-2 bg-gray-100 rounded-lg text-gray-700 hover:bg-gray-200">
            View Request
          </a>
          <?php include 'user_profile_dropdown.php'; ?>
        </div>
      </div>

      <!-- Success/Error Messages -->
      <?php if (!empty($errors)): ?>
        <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
          <p class="font-bold">Please fix the following errors:</p>
          <ul class="list-disc list-inside mt-2">
            <?php foreach ($errors as $error): ?>
              <li><?php echo htmlspecialchars($error); ?></li>
            <?php endforeach; ?>
          </ul>
        </div>
      <?php endif; ?>

      <?php if (isset($_GET['success']) && $_GET['success'] == 1): ?>
        <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg">
          <div class="flex items-center">
            <i data-lucide="check-circle" class="w-5 h-5 mr-2"></i>
            <span>
              <?php if (isset($_GET['type']) && $_GET['type'] == 'draft'): ?>
                Job request saved as draft successfully!
              <?php else: ?>
                Job request updated successfully!
              <?php endif; ?>
            </span>
          </div>
        </div>
      <?php endif; ?>

      <!-- Edit Form -->
      <form method="POST" class="space-y-8">
        <!-- Basic Information Card -->
        <div class="bg-white rounded-lg shadow border">
          <div class="border-b px-6 py-4">
            <h3 class="text-lg font-semibold text-gray-800">Basic Information</h3>
            <p class="text-sm text-gray-600 mt-1">Status: 
              <span class="px-2 py-1 text-xs rounded-full <?php echo getJobRequestStatusColor($request['overall_status']); ?>">
                <?php echo ucfirst($request['overall_status']); ?>
              </span>
            </p>
          </div>
          <div class="p-6 space-y-6">
            <div class="grid md:grid-cols-2 gap-6">
              <!-- Position Title -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                  Position Title <span class="text-red-500">*</span>
                </label>
                <input type="text" 
                       name="position_title" 
                       value="<?php echo htmlspecialchars($request['position_title']); ?>"
                       required
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
              </div>
              
              <!-- Department -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                  Department <span class="text-red-500">*</span>
                </label>
                <select name="department" 
                        required
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                  <option value="">Select Department</option>
                  <?php foreach ($departments as $dept): ?>
                    <option value="<?php echo htmlspecialchars($dept['name']); ?>"
                      <?php echo $request['department'] == $dept['name'] ? 'selected' : ''; ?>>
                      <?php echo htmlspecialchars($dept['name']); ?>
                    </option>
                  <?php endforeach; ?>
                </select>
              </div>
              
              <!-- Number Needed -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Number of Positions Needed</label>
                <input type="number" 
                       name="number_needed" 
                       value="<?php echo htmlspecialchars($request['number_needed'] ?? 1); ?>"
                       min="1"
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
              </div>
              
              <!-- Position Type -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Position Type</label>
                <select name="position_type" 
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                  <option value="new_position" <?php echo ($request['position_type'] ?? 'new_position') == 'new_position' ? 'selected' : ''; ?>>New Position</option>
                  <option value="replacement" <?php echo ($request['position_type'] ?? '') == 'replacement' ? 'selected' : ''; ?>>Replacement</option>
                  <option value="temporary" <?php echo ($request['position_type'] ?? '') == 'temporary' ? 'selected' : ''; ?>>Temporary</option>
                  <option value="contract" <?php echo ($request['position_type'] ?? '') == 'contract' ? 'selected' : ''; ?>>Contract</option>
                </select>
              </div>
              
              <!-- Reason for Request -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Reason for Request</label>
                <select name="reason" 
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                  <?php foreach (getRequestReasons() as $key => $label): ?>
                    <option value="<?php echo $key; ?>" <?php echo ($request['reason'] ?? 'new') == $key ? 'selected' : ''; ?>>
                      <?php echo $label; ?>
                    </option>
                  <?php endforeach; ?>
                </select>
              </div>
              
              <!-- Urgency Level -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Urgency Level</label>
                <select name="urgency_level" 
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                  <?php foreach (getUrgencyLevels() as $key => $label): ?>
                    <option value="<?php echo $key; ?>" <?php echo ($request['urgency_level'] ?? 'medium') == $key ? 'selected' : ''; ?>>
                      <?php echo $label; ?>
                    </option>
                  <?php endforeach; ?>
                </select>
              </div>
            </div>
            
            <div class="grid md:grid-cols-2 gap-6">
              <!-- Target Start Date -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                  Target Start Date <span class="text-red-500">*</span>
                </label>
                <input type="date" 
                       name="target_start_date" 
                       value="<?php echo htmlspecialchars($request['target_start_date']); ?>"
                       required
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg">
              </div>
              
              <!-- Salary Budget -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Salary Budget</label>
                <div class="relative">
                  <span class="absolute left-3 top-2 text-gray-500">&#8369;</span>
                  <input type="number" 
                         name="salary_budget" 
                         value="<?php echo htmlspecialchars($request['salary_budget'] ?? 0); ?>"
                         step="0.01"
                         min="0"
                         class="w-full px-3 py-2 border border-gray-300 rounded-lg pl-8 focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
              </div>
            </div>
            
            <!-- Reporting To -->
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-2">Reporting To</label>
              <input type="text" 
                     name="reporting_to" 
                     value="<?php echo htmlspecialchars($request['reporting_to'] ?? ''); ?>"
                     class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
          </div>
        </div>

        <!-- Position Details Card -->
        <div class="bg-white rounded-lg shadow border">
          <div class="border-b px-6 py-4">
            <h3 class="text-lg font-semibold text-gray-800">Position Details</h3>
          </div>
          <div class="p-6 space-y-6">
            <!-- Qualifications -->
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-2">
                Qualifications & Requirements <span class="text-red-500">*</span>
              </label>
              <textarea name="qualifications" 
                        rows="4"
                        required
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo htmlspecialchars($request['qualifications']); ?></textarea>
            </div>
            
            <!-- Required Skills -->
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-2">Required Skills</label>
              <textarea name="required_skills" 
                        rows="3"
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo htmlspecialchars($request['required_skills'] ?? ''); ?></textarea>
            </div>
            
            <!-- Responsibilities -->
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-2">Responsibilities</label>
              <textarea name="responsibilities" 
                        rows="4"
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo htmlspecialchars($request['responsibilities'] ?? ''); ?></textarea>
            </div>
            
            <div class="grid md:grid-cols-2 gap-6">
              <!-- Experience Level -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Experience Level</label>
                <select name="experience_level" 
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                  <?php foreach (getExperienceLevels() as $key => $label): ?>
                    <option value="<?php echo $key; ?>" <?php echo ($request['experience_level'] ?? 'mid') == $key ? 'selected' : ''; ?>>
                      <?php echo $label; ?>
                    </option>
                  <?php endforeach; ?>
                </select>
              </div>
              
              <!-- Education Level -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Education Level</label>
                <select name="education_level" 
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                  <?php foreach (getEducationLevels() as $key => $label): ?>
                    <option value="<?php echo $key; ?>" <?php echo ($request['education_level'] ?? 'bachelor') == $key ? 'selected' : ''; ?>>
                      <?php echo $label; ?>
                    </option>
                  <?php endforeach; ?>
                </select>
              </div>
            </div>
          </div>
        </div>

        <!-- Requester Information Card -->
        <div class="bg-white rounded-lg shadow border">
          <div class="border-b px-6 py-4">
            <h3 class="text-lg font-semibold text-gray-800">Requester Information</h3>
          </div>
          <div class="p-6 space-y-6">
            <div class="grid md:grid-cols-2 gap-6">
              <!-- Requested By -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                  Requested By <span class="text-red-500">*</span>
                </label>
                <input type="text" 
                       name="requested_by" 
                       value="<?php echo htmlspecialchars($request['requested_by']); ?>"
                       required
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
              </div>
              
              <!-- Requested By Email -->
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                  Requested By Email <span class="text-red-500">*</span>
                </label>
                <input type="email" 
                       name="requested_by_email" 
                       value="<?php echo htmlspecialchars($request['requested_by_email']); ?>"
                       required
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
              </div>
            </div>
            
            <!-- Justification -->
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-2">
                Justification / Business Case <span class="text-red-500">*</span>
              </label>
              <textarea name="justification" 
                        rows="4"
                        required
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo htmlspecialchars($request['justification']); ?></textarea>
            </div>
            
            <!-- Budget Approval -->
            <div class="flex items-center space-x-3">
              <input type="checkbox" 
                     name="budget_approved" 
                     id="budget_approved"
                     value="1"
                     <?php echo ($request['budget_approved'] ?? 0) ? 'checked' : ''; ?>
                     class="w-4 h-4 text-blue-600 border-gray-300 rounded">
              <label for="budget_approved" class="text-sm text-gray-700">
                Budget has been approved
              </label>
            </div>
          </div>
        </div>

        <!-- Form Actions -->
        <div class="flex justify-between items-center pt-6 border-t border-gray-200">
          <div class="text-sm text-gray-500">
            Created: <?php echo date('M d, Y', strtotime($request['created_at'])); ?> 
            by <?php echo htmlspecialchars($request['requester_name'] ?? 'System'); ?>
          </div>
          <div class="flex space-x-4">
            <?php if (in_array($request['overall_status'], ['draft', 'pending'])): ?>
              <button type="submit" 
                      name="save_draft"
                      class="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50">
                Save as Draft
              </button>
            <?php endif; ?>
            <button type="submit" 
                    class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
              Update Request
            </button>
          </div>
        </div>
      </form>
    </main>
  </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
  lucide.createIcons();
  
  // Set minimum date for target start date to today
  const today = new Date().toISOString().split('T')[0];
  const dateInput = document.querySelector('input[name="target_start_date"]');
  if (dateInput) {
    dateInput.min = today;
  }
});
</script>
</body>
</html>