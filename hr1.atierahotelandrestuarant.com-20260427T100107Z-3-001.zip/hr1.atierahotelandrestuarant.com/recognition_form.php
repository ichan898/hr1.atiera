<?php
// File: recognition_form.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

// Fetch employees from database
$employees = [];
try {
    $sql = "SELECT 
                e.id,
                e.employee_id,
                CONCAT(e.first_name, ' ', 
                       IFNULL(CONCAT(LEFT(e.middle_name, 1), '. '), ''), 
                       e.last_name) as full_name,
                e.first_name,
                e.middle_name,
                e.last_name,
                e.gender,
                e.department_id,
                d.name as department_name,
                e.email,
                e.contact_number,
                e.address,
                e.date_of_birth,
                e.hire_date,
                e.status
            FROM employees e
            LEFT JOIN departments d ON e.department_id = d.id
            WHERE e.status IN ('Active', 'On Leave')
            ORDER BY e.first_name, e.last_name";
    
    $stmt = $connections->prepare($sql);
    $stmt->execute();
    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
}

$categories = getRecognitionCategories();
$types = getRecognitionTypes();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'employee_id' => $_POST['employee_id'],
        'recognition_type' => $_POST['recognition_type'],
        'category' => $_POST['category'],
        'points_awarded' => $_POST['points_awarded'] ?? 0,
        'description' => $_POST['description'],
        'recognition_date' => $_POST['recognition_date'],
        'status' => $_POST['status'] ?? 'draft'
    ];
    
    // Validate
    $errors = validateRecognition($data);
    
    if (empty($errors)) {
        $result = createRecognition($data, $_SESSION['user_id'], $connections);
        
        if ($result['success']) {
            $_SESSION['flash_message'] = [
                'type' => 'success',
                'message' => 'Recognition created successfully!'
            ];
            header('Location: recognition.php');
            exit;
        } else {
            $error = $result['error'];
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>HR1 - New Recognition</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css">
</head>

<body class="h-screen bg-gray-100 font-sans">
<div class="flex h-full">
  
  <!-- Sidebar -->
  <?php include 'sidebar.php'; ?>
  
  <!-- Main Content -->
  <div class="flex-1 flex flex-col overflow-y-auto">
    <main class="p-6">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-gray-300 pb-4 mb-6">
        <div>
          <h2 class="text-2xl font-bold text-gray-800">Create New Recognition</h2>
          <p class="text-sm text-gray-600">Recognize an employee for their achievements</p>
        </div>
        <div class="flex items-center space-x-4">
          <a href="recognition.php" class="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
            <i data-lucide="arrow-left" class="w-4 h-4"></i>
            <span>Back to Recognitions</span>
          </a>
          <?php include 'profile_dropdown.php'; ?>
        </div>
      </div>

      <!-- Error Messages -->
      <?php if (!empty($error)): ?>
        <div class="mb-6 p-4 bg-red-50 border border-red-400 text-red-700 rounded-lg">
          <div class="flex items-center">
            <i data-lucide="alert-circle" class="w-5 h-5 mr-2"></i>
            <span class="font-medium">Error: <?php echo htmlspecialchars($error); ?></span>
          </div>
        </div>
      <?php endif; ?>

      <?php if (!empty($errors)): ?>
        <div class="mb-6 p-4 bg-red-50 border border-red-400 text-red-700 rounded-lg">
          <div class="flex items-center">
            <i data-lucide="alert-circle" class="w-5 h-5 mr-2"></i>
            <span class="font-medium">Please fix the following errors:</span>
          </div>
          <ul class="mt-2 list-disc list-inside">
            <?php foreach ($errors as $err): ?>
              <li><?php echo htmlspecialchars($err); ?></li>
            <?php endforeach; ?>
          </ul>
        </div>
      <?php endif; ?>

      <!-- Form -->
      <div class="bg-white rounded-lg shadow p-6">
        <form method="POST" class="space-y-6">
          <div class="grid md:grid-cols-2 gap-6">
            <!-- Employee Selection -->
            <div class="md:col-span-2">
              <label class="block text-sm font-medium text-gray-700 mb-2">
                Employee <span class="text-red-500">*</span>
              </label>
              <select name="employee_id" required
                      class="employee-select w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                <option value="">Select an employee...</option>
                <?php if (!empty($employees)): ?>
                  <?php foreach ($employees as $employee): ?>
                    <option value="<?php echo $employee['id']; ?>"
                      <?php echo isset($_POST['employee_id']) && $_POST['employee_id'] == $employee['id'] ? 'selected' : ''; ?>
                      data-department="<?php echo htmlspecialchars($employee['department_name'] ?? 'N/A'); ?>"
                      data-employee-id="<?php echo htmlspecialchars($employee['employee_id']); ?>"
                      data-email="<?php echo htmlspecialchars($employee['email']); ?>"
                      data-status="<?php echo htmlspecialchars($employee['status']); ?>">
                      <?php echo htmlspecialchars($employee['full_name']); ?> 
                      (<?php echo htmlspecialchars($employee['employee_id']); ?>) - 
                      <?php echo htmlspecialchars($employee['department_name'] ?? 'N/A'); ?>
                      <?php if ($employee['status'] === 'On Leave'): ?>
                        <span class="text-yellow-600">[On Leave]</span>
                      <?php endif; ?>
                    </option>
                  <?php endforeach; ?>
                <?php endif; ?>
              </select>
              <?php if (empty($employees)): ?>
                <p class="mt-2 text-sm text-red-600">No active employees found. Please add employees first.</p>
              <?php endif; ?>
            </div>
            
            <!-- Selected Employee Details -->
            <div class="md:col-span-2 hidden" id="employee-details">
              <div class="bg-gray-50 p-4 rounded-lg">
                <h4 class="font-medium text-gray-700 mb-2">Selected Employee Information</h4>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label class="text-sm text-gray-500">Employee ID:</label>
                    <p id="detail-employee-id" class="font-medium"></p>
                  </div>
                  <div>
                    <label class="text-sm text-gray-500">Department:</label>
                    <p id="detail-department" class="font-medium"></p>
                  </div>
                  <div>
                    <label class="text-sm text-gray-500">Email:</label>
                    <p id="detail-email" class="font-medium"></p>
                  </div>
                  <div>
                    <label class="text-sm text-gray-500">Status:</label>
                    <p id="detail-status" class="font-medium"></p>
                  </div>
                </div>
              </div>
            </div>
            
            <!-- Recognition Type -->
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-2">
                Recognition Type <span class="text-red-500">*</span>
              </label>
              <select name="recognition_type" required
                      class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                <option value="">Select type...</option>
                <?php if (isset($types) && is_array($types)): ?>
                  <?php foreach ($types as $key => $label): ?>
                    <option value="<?php echo htmlspecialchars($key); ?>"
                      <?php echo isset($_POST['recognition_type']) && $_POST['recognition_type'] == $key ? 'selected' : ''; ?>>
                      <?php echo htmlspecialchars($label); ?>
                    </option>
                  <?php endforeach; ?>
                <?php else: ?>
                  <option value="">No types available</option>
                <?php endif; ?>
              </select>
            </div>
            
            <!-- Category -->
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-2">
                Category <span class="text-red-500">*</span>
              </label>
              <select name="category" required
                      class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                <option value="">Select category...</option>
                <?php if (isset($categories) && is_array($categories)): ?>
                  <?php foreach ($categories as $key => $label): ?>
                    <option value="<?php echo htmlspecialchars($key); ?>"
                      <?php echo isset($_POST['category']) && $_POST['category'] == $key ? 'selected' : ''; ?>>
                      <?php echo htmlspecialchars($label); ?>
                    </option>
                  <?php endforeach; ?>
                <?php else: ?>
                  <option value="">No categories available</option>
                <?php endif; ?>
              </select>
            </div>
            
            <!-- Points Awarded -->
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-2">
                Points Awarded
              </label>
              <input type="number" name="points_awarded" 
                     value="<?php echo htmlspecialchars($_POST['points_awarded'] ?? 0); ?>"
                     min="0" max="1000" step="1"
                     class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                     placeholder="0">
            </div>
            
            <!-- Recognition Date -->
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-2">
                Recognition Date <span class="text-red-500">*</span>
              </label>
              <input type="date" name="recognition_date" required
                     value="<?php echo htmlspecialchars($_POST['recognition_date'] ?? date('Y-m-d')); ?>"
                     class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
            </div>
            
            <!-- Description -->
            <div class="md:col-span-2">
              <label class="block text-sm font-medium text-gray-700 mb-2">
                Description <span class="text-red-500">*</span>
              </label>
              <textarea name="description" required rows="4"
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        placeholder="Describe the achievement and why it's being recognized..."><?php echo htmlspecialchars($_POST['description'] ?? ''); ?></textarea>
            </div>
            
            <!-- Status -->
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-2">
                Status
              </label>
              <select name="status" 
                      class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                <option value="draft" <?php echo ($_POST['status'] ?? 'draft') == 'draft' ? 'selected' : ''; ?>>Draft</option>
                <option value="published" <?php echo ($_POST['status'] ?? '') == 'published' ? 'selected' : ''; ?>>Publish Immediately</option>
                <option value="pending" <?php echo ($_POST['status'] ?? '') == 'pending' ? 'selected' : ''; ?>>Pending Review</option>
              </select>
            </div>
          </div>
          
          <!-- Form Actions -->
          <div class="flex justify-end space-x-4 pt-6 border-t">
            <a href="recognition.php" 
               class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
              Cancel
            </a>
            <button type="submit" name="save_draft"
                    class="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700">
              Save as Draft
            </button>
            <button type="submit" name="publish"
                    class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
              <i data-lucide="send" class="w-4 h-4 inline mr-2"></i>
              Publish Recognition
            </button>
          </div>
        </form>
      </div>
    </main>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
<script>
document.addEventListener("DOMContentLoaded", () => {
  lucide.createIcons();
  
  // Initialize Select2 for employee dropdown
  $('.employee-select').select2({
    placeholder: "Select an employee...",
    allowClear: true,
    width: '100%'
  });

  // Set min/max date for recognition date
  const dateInput = document.querySelector('input[name="recognition_date"]');
  if (dateInput) {
    const today = new Date().toISOString().split('T')[0];
    dateInput.max = today;
    dateInput.min = '2000-01-01';
  }

  // Show employee details when selected
  $('.employee-select').on('change', function() {
    const selectedOption = $(this).find('option:selected');
    const detailsDiv = document.getElementById('employee-details');
    
    if (selectedOption.val()) {
      document.getElementById('detail-employee-id').textContent = selectedOption.data('employee-id');
      document.getElementById('detail-department').textContent = selectedOption.data('department');
      document.getElementById('detail-email').textContent = selectedOption.data('email');
      document.getElementById('detail-status').textContent = selectedOption.data('status');
      
      // Add status class
      const statusElement = document.getElementById('detail-status');
      const status = selectedOption.data('status');
      statusElement.className = 'font-medium ' + 
        (status === 'Active' ? 'text-green-600' : 
         status === 'On Leave' ? 'text-yellow-600' : 
         status === 'Inactive' ? 'text-gray-600' : 
         status === 'Terminated' ? 'text-red-600' : 'text-gray-600');
      
      detailsDiv.classList.remove('hidden');
    } else {
      detailsDiv.classList.add('hidden');
    }
  });

  // Trigger change on page load if employee is already selected
  if ($('.employee-select').val()) {
    $('.employee-select').trigger('change');
  }
});
</script>
</body>
</html>