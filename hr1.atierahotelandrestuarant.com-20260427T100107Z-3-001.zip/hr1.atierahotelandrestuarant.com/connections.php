<?php
// connections.php
require_once 'vendor/autoload.php';

// Database connection
$servername = "localhost";
$username = "hratier1";
$password = "F71jvVX7Qnr9JH";
$dbname = "hr1_recruitment_system";

try {
    $connections = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $connections->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $connections->exec("SET NAMES 'utf8'");
    
    // Fix timezone
    date_default_timezone_set('Asia/Manila');
    $connections->exec("SET time_zone = '+08:00'");
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Email Configuration – using the new Gmail account
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 465);                               // SSL port 465
define('SMTP_USERNAME', 'james.sabandal001@gmail.com'); // New Gmail
define('SMTP_PASSWORD', 'cdmljpeymipeupge');            // New app password (no spaces)
define('SMTP_FROM_EMAIL', 'james.sabandal001@gmail.com');
define('SMTP_FROM_NAME', 'HR1 System');

// OTP Configuration
define('OTP_EXPIRY_MINUTES', 10);
define('OTP_LENGTH', 6);

// Google OAuth Configuration (unchanged)
define('GOOGLE_CLIENT_ID', '106417722260-gmtv44sn2brmidg58btborrrhq4vleqh.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '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');
define('GOOGLE_REDIRECT_URI', 'https://hr1.atierahotelandrestaurant.com/google_login_callback.php');
?>