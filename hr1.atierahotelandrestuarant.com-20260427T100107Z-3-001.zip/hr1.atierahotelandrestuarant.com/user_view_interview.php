<?php
// File: view_interview.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

// Get interview ID
if (!isset($_GET['id'])) {
    header('Location: user_interviews.php');
    exit();
}

$interview_id = $_GET['id'];

// Fetch interview details
$query = "SELECT i.*, a.first_name, a.last_name, a.email, a.phone, a.resume_path, 
                 a.job_id, j.job_title, j.department,
                 u.full_name as scheduled_by
          FROM interviews i
          JOIN applicants a ON i.applicant_id = a.id
          LEFT JOIN job_postings j ON a.job_id = j.id
          LEFT JOIN users u ON i.scheduled_by = u.id
          WHERE i.id = :id";

$stmt = $connections->prepare($query);
$stmt->bindParam(':id', $interview_id, PDO::PARAM_INT);
$stmt->execute();
$interview = $stmt->fetch();

if (!$interview) {
    $_SESSION['error'] = "Interview not found";
    header('Location: user_interviews.php');
    exit();
}

// Fetch evaluation if exists - JOIN with users table to get evaluator name
$eval_query = "SELECT ie.*, u.full_name as evaluator_name 
               FROM interview_evaluations ie
               LEFT JOIN users u ON ie.evaluated_by = u.id
               WHERE ie.interview_id = :id";
               
$eval_stmt = $connections->prepare($eval_query);
$eval_stmt->bindParam(':id', $interview_id, PDO::PARAM_INT);
$eval_stmt->execute();
$evaluation = $eval_stmt->fetch();

// Check if applicant is already in onboarding
$onboarding_check = $connections->prepare("
    SELECT id, employee_id FROM onboarding 
    WHERE applicant_id = :applicant_id 
    AND interview_id = :interview_id
");
$onboarding_check->bindParam(':applicant_id', $interview['applicant_id'], PDO::PARAM_INT);
$onboarding_check->bindParam(':interview_id', $interview_id, PDO::PARAM_INT);
$onboarding_check->execute();
$onboarding_info = $onboarding_check->fetch();

// Parse scheduled datetime
$scheduled_date = new DateTime($interview['scheduled_date']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>HR1 - View Interview</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="h-screen bg-gray-100 font-sans">
<div class="flex h-full">
    
    <!-- Sidebar -->
    <?php include 'user_sidebar.php'; ?>
    
    <!-- Main Content -->
    <div class="flex-1 flex flex-col overflow-y-auto">
        <main class="p-6">
            <!-- Header -->
            <div class="flex items-center justify-between border-b border-gray-300 pb-4 mb-6">
                <div>
                    <div class="flex items-center space-x-3">
                        <a href="user_interviews.php" class="text-blue-600 hover:text-blue-800">
                            <i data-lucide="arrow-left" class="w-5 h-5"></i>
                        </a>
                        <h2 class="text-2xl font-bold text-gray-800">Interview Details</h2>
                    </div>
                    <p class="text-sm text-gray-600">View interview information and evaluation</p>
                </div>
                <div class="flex items-center space-x-4">
                    <?php if($interview['status'] == 'scheduled'): ?>
                    <a href="user_conduct_interview.php?id=<?php echo $interview['id']; ?>" 
                       class="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">
                        <i data-lucide="video" class="w-4 h-4"></i>
                        <span>Conduct Interview</span>
                    </a>
                    <a href="user_reschedule_interview.php?id=<?php echo $interview['id']; ?>" 
                       class="flex items-center space-x-2 px-4 py-2 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700">
                        <i data-lucide="calendar" class="w-4 h-4"></i>
                        <span>Reschedule</span>
                    </a>
                    <?php endif; ?>
                    <?php include 'user_profile_dropdown.php'; ?>
                </div>
            </div>

            <!-- Status Alert -->
            <div class="mb-6">
                <div class="flex items-center justify-between p-4 rounded-lg 
                    <?php echo $interview['status'] == 'scheduled' ? 'bg-blue-50 border border-blue-200' : 
                           ($interview['status'] == 'completed' ? 'bg-green-50 border border-green-200' : 
                           ($interview['status'] == 'cancelled' ? 'bg-red-50 border border-red-200' : 'bg-gray-50 border')); ?>">
                    <div class="flex items-center space-x-3">
                        <span class="px-3 py-1 text-sm rounded-full 
                            <?php echo $interview['status'] == 'scheduled' ? 'bg-blue-100 text-blue-800' : 
                                   ($interview['status'] == 'completed' ? 'bg-green-100 text-green-800' : 
                                   ($interview['status'] == 'cancelled' ? 'bg-red-100 text-red-800' : 'bg-gray-100')); ?>">
                            <?php echo ucfirst($interview['status']); ?>
                        </span>
                        <span class="text-gray-700">
                            Scheduled: <?php echo $scheduled_date->format('F j, Y \a\t h:i A'); ?>
                        </span>
                    </div>
                    <?php if($interview['status'] == 'scheduled'): ?>
                    <div class="text-sm text-gray-600">
                        <?php 
                            $now = new DateTime();
                            $interval = $now->diff($scheduled_date);
                            if ($scheduled_date > $now) {
                                echo "In " . $interval->format('%d days, %h hours');
                            } else {
                                echo "Started " . $interval->format('%h hours ago');
                            }
                        ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Onboarding Status Alert -->
            <?php if($onboarding_info): ?>
            <div class="mb-6 p-4 bg-gradient-to-r from-green-50 to-blue-50 border border-green-200 rounded-lg">
                <div class="flex items-center">
                    <i data-lucide="user-check" class="w-5 h-5 text-green-600 mr-3"></i>
                    <div>
                        <p class="text-green-700 font-medium">
                            Candidate has been moved to Onboarding
                        </p>
                        <p class="text-green-600 text-sm mt-1">
                            Employee ID: <strong><?php echo htmlspecialchars($onboarding_info['employee_id']); ?></strong> | 
                            <a href="user_onboarding.php" class="underline hover:text-green-800">View Onboarding Dashboard</a>
                        </p>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Main Content Grid -->
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <!-- Left Column - Applicant Info -->
                <div class="lg:col-span-2 space-y-6">
                    <!-- Applicant Information -->
                    <div class="bg-white rounded-lg shadow border">
                        <div class="p-6 border-b border-gray-200">
                            <h3 class="text-lg font-semibold text-gray-800">Applicant Information</h3>
                        </div>
                        <div class="p-6">
                            <div class="flex items-start space-x-4">
                                <div class="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center">
                                    <i data-lucide="user" class="w-8 h-8 text-gray-600"></i>
                                </div>
                                <div class="flex-1">
                                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div>
                                            <p class="text-sm text-gray-600">Full Name</p>
                                            <p class="font-medium text-gray-900">
                                                <?php echo htmlspecialchars($interview['first_name'] . ' ' . $interview['last_name']); ?>
                                            </p>
                                        </div>
                                        <div>
                                            <p class="text-sm text-gray-600">Email</p>
                                            <p class="font-medium text-gray-900"><?php echo htmlspecialchars($interview['email']); ?></p>
                                        </div>
                                        <div>
                                            <p class="text-sm text-gray-600">Phone</p>
                                            <p class="font-medium text-gray-900"><?php echo htmlspecialchars($interview['phone'] ?? 'N/A'); ?></p>
                                        </div>
                                        <div>
                                            <p class="text-sm text-gray-600">Job Applied</p>
                                            <p class="font-medium text-gray-900"><?php echo htmlspecialchars($interview['job_title'] ?? 'N/A'); ?></p>
                                        </div>
                                    </div>
                                    <?php if(!empty($interview['resume_path'])): ?>
                                    <div class="mt-4">
                                        <a href="<?php echo htmlspecialchars($interview['resume_path']); ?>" 
                                           target="_blank" 
                                           class="inline-flex items-center space-x-2 text-blue-600 hover:text-blue-800">
                                            <i data-lucide="file-text" class="w-4 h-4"></i>
                                            <span>View Resume</span>
                                        </a>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Interview Details -->
                    <div class="bg-white rounded-lg shadow border">
                        <div class="p-6 border-b border-gray-200">
                            <h3 class="text-lg font-semibold text-gray-800">Interview Details</h3>
                        </div>
                        <div class="p-6">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <p class="text-sm text-gray-600">Date & Time</p>
                                    <p class="font-medium text-gray-900">
                                        <?php echo $scheduled_date->format('l, F j, Y'); ?>
                                    </p>
                                    <p class="text-gray-700">
                                        <?php echo $scheduled_date->format('h:i A'); ?>
                                    </p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-600">Interview Type</p>
                                    <p class="font-medium text-gray-900">
                                        <?php echo ucfirst($interview['interview_type'] ?? 'Not specified'); ?>
                                    </p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-600">Interviewers</p>
                                    <p class="font-medium text-gray-900">
                                        <?php echo htmlspecialchars($interview['interviewers']); ?>
                                    </p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-600">Location/Platform</p>
                                    <p class="font-medium text-gray-900">
                                        <?php echo htmlspecialchars($interview['location'] ?? 'Not specified'); ?>
                                    </p>
                                </div>
                                <div class="md:col-span-2">
                                    <p class="text-sm text-gray-600">Notes</p>
                                    <p class="text-gray-900 mt-1">
                                        <?php echo !empty($interview['notes']) ? nl2br(htmlspecialchars($interview['notes'])) : 'No notes provided.'; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Evaluation Section -->
                    <?php if($evaluation): ?>
                    <div class="bg-white rounded-lg shadow border">
                        <div class="p-6 border-b border-gray-200">
                            <h3 class="text-lg font-semibold text-gray-800">Evaluation</h3>
                        </div>
                        <div class="p-6">
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                                <div class="text-center">
                                    <p class="text-sm text-gray-600">Overall Rating</p>
                                    <div class="mt-2">
                                        <?php 
                                        $rating = $evaluation['overall_rating'];
                                        for($i = 1; $i <= 5; $i++): 
                                        ?>
                                            <i data-lucide="star" class="w-6 h-6 inline <?php echo $i <= $rating ? 'text-yellow-500 fill-yellow-500' : 'text-gray-300'; ?>"></i>
                                        <?php endfor; ?>
                                    </div>
                                    <p class="text-2xl font-bold text-gray-800 mt-2"><?php echo $rating; ?>/5</p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-600">Technical Skills</p>
                                    <div class="mt-2">
                                        <?php 
                                        $tech_skills = $evaluation['technical_skills'] ?? 0;
                                        for($i = 1; $i <= 5; $i++): ?>
                                            <i data-lucide="star" class="w-4 h-4 inline <?php echo $i <= $tech_skills ? 'text-yellow-500 fill-yellow-500' : 'text-gray-300'; ?>"></i>
                                        <?php endfor; ?>
                                    </div>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-600">Cultural Fit</p>
                                    <div class="mt-2">
                                        <?php 
                                        $cultural_fit = $evaluation['cultural_fit'] ?? 0;
                                        for($i = 1; $i <= 5; $i++): ?>
                                            <i data-lucide="star" class="w-4 h-4 inline <?php echo $i <= $cultural_fit ? 'text-yellow-500 fill-yellow-500' : 'text-gray-300'; ?>"></i>
                                        <?php endfor; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="space-y-4">
                                <div>
                                    <p class="text-sm text-gray-600">Strengths</p>
                                    <p class="text-gray-900 mt-1"><?php echo nl2br(htmlspecialchars($evaluation['strengths'] ?? '')); ?></p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-600">Weaknesses</p>
                                    <p class="text-gray-900 mt-1"><?php echo nl2br(htmlspecialchars($evaluation['weaknesses'] ?? '')); ?></p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-600">Recommendation</p>
                                    <span class="mt-2 inline-block px-3 py-1 text-sm rounded-full 
                                        <?php echo ($evaluation['recommendation'] ?? '') == 'hire' ? 'bg-green-100 text-green-800' : 
                                               (($evaluation['recommendation'] ?? '') == 'maybe' ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800'); ?>">
                                        <?php echo ucfirst($evaluation['recommendation'] ?? 'Not specified'); ?>
                                    </span>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-600">Evaluation Notes</p>
                                    <p class="text-gray-900 mt-1"><?php echo nl2br(htmlspecialchars($evaluation['notes'] ?? '')); ?></p>
                                </div>
                                <div class="pt-4 border-t border-gray-200">
                                    <p class="text-sm text-gray-600">
                                        Evaluated by <?php echo htmlspecialchars($evaluation['evaluator_name'] ?? 'Unknown'); ?>
                                    </p>
                                    <p class="text-xs text-gray-500">on <?php echo date('M j, Y \a\t h:i A', strtotime($evaluation['evaluated_at'] ?? 'now')); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Right Column - Actions & Timeline -->
                <div class="space-y-6">
                    <!-- Quick Actions -->
                    <div class="bg-white rounded-lg shadow border">
                        <div class="p-6 border-b border-gray-200">
                            <h3 class="text-lg font-semibold text-gray-800">Quick Actions</h3>
                        </div>
                        <div class="p-6 space-y-3">
                            <?php if($interview['status'] == 'scheduled'): ?>
                            <a href="usesr_conduct_interview.php?id=<?php echo $interview['id']; ?>" 
                               class="flex items-center justify-center space-x-2 w-full px-4 py-3 bg-green-50 border border-green-200 text-green-700 rounded-lg hover:bg-green-100">
                                <i data-lucide="video" class="w-5 h-5"></i>
                                <span>Conduct Interview</span>
                            </a>
                            <a href="user_reschedule_interview.php?id=<?php echo $interview['id']; ?>" 
                               class="flex items-center justify-center space-x-2 w-full px-4 py-3 bg-yellow-50 border border-yellow-200 text-yellow-700 rounded-lg hover:bg-yellow-100">
                                <i data-lucide="calendar" class="w-5 h-5"></i>
                                <span>Reschedule</span>
                            </a>
                            <button onclick="confirmCancel()" 
                                    class="flex items-center justify-center space-x-2 w-full px-4 py-3 bg-red-50 border border-red-200 text-red-700 rounded-lg hover:bg-red-100">
                                <i data-lucide="x-circle" class="w-5 h-5"></i>
                                <span>Cancel Interview</span>
                            </button>
                            <?php endif; ?>
                            
                            <a href="#" 
                               class="flex items-center justify-center space-x-2 w-full px-4 py-3 bg-blue-50 border border-blue-200 text-blue-700 rounded-lg hover:bg-blue-100">
                                <i data-lucide="mail" class="w-5 h-5"></i>
                                <span>Send Reminder</span>
                            </a>
                            
                            <?php if($interview['status'] == 'completed' && !$evaluation && !$onboarding_info): ?>
                            <a href="user_conduct_interview.php?id=<?php echo $interview['id']; ?>" 
                               class="flex items-center justify-center space-x-2 w-full px-4 py-3 bg-purple-50 border border-purple-200 text-purple-700 rounded-lg hover:bg-purple-100">
                                <i data-lucide="clipboard-check" class="w-5 h-5"></i>
                                <span>Add Evaluation</span>
                            </a>
                            <?php endif; ?>

                            <?php if($onboarding_info): ?>
                            <a href="user_onboarding.php" 
                               class="flex items-center justify-center space-x-2 w-full px-4 py-3 bg-gradient-to-r from-green-50 to-blue-50 border border-green-200 text-green-700 rounded-lg hover:bg-green-100">
                                <i data-lucide="arrow-right" class="w-5 h-5"></i>
                                <span>Go to Onboarding</span>
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Timeline -->
                    <div class="bg-white rounded-lg shadow border">
                        <div class="p-6 border-b border-gray-200">
                            <h3 class="text-lg font-semibold text-gray-800">Timeline</h3>
                        </div>
                        <div class="p-6">
                            <div class="space-y-4">
                                <div class="flex items-start space-x-3">
                                    <div class="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                                        <i data-lucide="calendar-plus" class="w-4 h-4 text-green-600"></i>
                                    </div>
                                    <div>
                                        <p class="font-medium text-gray-900">Interview Scheduled</p>
                                        <p class="text-sm text-gray-600">by <?php echo htmlspecialchars($interview['scheduled_by'] ?? 'System'); ?></p>
                                        <p class="text-xs text-gray-500"><?php echo date('M j, Y \a\t h:i A', strtotime($interview['created_at'])); ?></p>
                                    </div>
                                </div>
                                
                                <?php if($interview['status'] == 'completed'): ?>
                                <div class="flex items-start space-x-3">
                                    <div class="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                                        <i data-lucide="check-circle" class="w-4 h-4 text-blue-600"></i>
                                    </div>
                                    <div>
                                        <p class="font-medium text-gray-900">Interview Completed</p>
                                        <p class="text-sm text-gray-600">Status updated to completed</p>
                                        <p class="text-xs text-gray-500"><?php echo date('M j, Y', strtotime($interview['scheduled_date'])); ?></p>
                                    </div>
                                </div>
                                <?php endif; ?>
                                
                                <?php if($evaluation): ?>
                                <div class="flex items-start space-x-3">
                                    <div class="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                                        <i data-lucide="clipboard-check" class="w-4 h-4 text-purple-600"></i>
                                    </div>
                                    <div>
                                        <p class="font-medium text-gray-900">Evaluation Submitted</p>
                                        <p class="text-sm text-gray-600">by <?php echo htmlspecialchars($evaluation['evaluator_name'] ?? 'Unknown'); ?></p>
                                        <p class="text-xs text-gray-500"><?php echo date('M j, Y \a\t h:i A', strtotime($evaluation['evaluated_at'] ?? 'now')); ?></p>
                                    </div>
                                </div>
                                <?php endif; ?>

                                <?php if($onboarding_info): ?>
                                <div class="flex items-start space-x-3">
                                    <div class="w-8 h-8 bg-gradient-to-r from-green-100 to-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                                        <i data-lucide="user-check" class="w-4 h-4 text-green-600"></i>
                                    </div>
                                    <div>
                                        <p class="font-medium text-gray-900">Moved to Onboarding</p>
                                        <p class="text-sm text-gray-600">Employee ID: <?php echo htmlspecialchars($onboarding_info['employee_id']); ?></p>
                                        <p class="text-xs text-gray-500">Added to onboarding system</p>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
function confirmCancel() {
    if (confirm('Are you sure you want to cancel this interview? This action cannot be undone.')) {
        window.location.href = 'user_cancel_interview.php?id=<?php echo $interview['id']; ?>';
    }
}

document.addEventListener("DOMContentLoaded", () => {
    lucide.createIcons();
});
</script>
</body>
</html>