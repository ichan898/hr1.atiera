<?php
// File: edit_posting.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

$id = $_GET['id'] ?? null;
if (!$id) {
    header('Location: job_postings.php');
    exit();
}

$posting = getJobPosting($id);
if (!$posting) {
    header('Location: job_postings.php?error=notfound');
    exit();
}

// Fetch departments for dropdown
$departments = [];
$error = '';

// Try multiple methods to get departments
try {
    // First, try to use the getDepartmentsList function which has fallback logic
    $departments = getDepartmentsList($connections);
    
    // If empty, try direct query as fallback
    if (empty($departments)) {
        // Check if departments table exists
        $stmt = $connections->query("SHOW TABLES LIKE 'departments'");
        $tableExists = $stmt->fetch();
        
        if ($tableExists) {
            // Try with is_active column
            try {
                $stmt = $connections->query("SELECT id, name FROM departments WHERE is_active = 1 ORDER BY name");
                $departments = $stmt->fetchAll(PDO::FETCH_ASSOC);
            } catch (PDOException $e) {
                // Try without is_active filter
                $stmt = $connections->query("SELECT id, name FROM departments ORDER BY name");
                $departments = $stmt->fetchAll(PDO::FETCH_ASSOC);
            }
        } else {
            // Get distinct departments from existing job postings
            $stmt = $connections->query("SELECT DISTINCT department as name FROM job_postings WHERE department IS NOT NULL AND department != '' ORDER BY department");
            $deptResults = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Convert to same format
            $departments = [];
            $counter = 1;
            foreach ($deptResults as $dept) {
                $departments[] = [
                    'id' => $counter++,
                    'name' => $dept['name']
                ];
            }
        }
    }
    
    if (empty($departments)) {
        // Create a default department if none exist
        $departments = [
            ['id' => 1, 'name' => 'Human Resources'],
            ['id' => 2, 'name' => 'IT Department'],
            ['id' => 3, 'name' => 'Operations'],
            ['id' => 4, 'name' => 'Sales'],
            ['id' => 5, 'name' => 'Marketing']
        ];
    }
    
} catch (PDOException $e) {
    error_log("Error fetching departments: " . $e->getMessage());
    $error = "Unable to load department list. Using default departments.";
    // Provide default departments
    $departments = [
        ['id' => 1, 'name' => 'Human Resources'],
        ['id' => 2, 'name' => 'IT Department'],
        ['id' => 3, 'name' => 'Operations'],
        ['id' => 4, 'name' => 'Sales'],
        ['id' => 5, 'name' => 'Marketing']
    ];
}

// Parse salary range to min/max if needed
$salary_min = $posting['salary_min'] ?? '';
$salary_max = $posting['salary_max'] ?? '';

if (empty($salary_min) && empty($salary_max) && !empty($posting['salary_range'])) {
    // Try to parse from salary_range string
    $range = $posting['salary_range'];
    if (preg_match('/(\d+(?:\.\d+)?)[^\d]*(\d+(?:\.\d+)?)/', $range, $matches)) {
        $salary_min = $matches[1];
        $salary_max = $matches[2];
    }
}

// Check if department_id exists in posting, if not try to match by department name
if (!isset($posting['department_id']) || empty($posting['department_id'])) {
    $deptName = $posting['department'] ?? '';
    foreach ($departments as $dept) {
        if ($dept['name'] == $deptName) {
            $posting['department_id'] = $dept['id'];
            break;
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        // Calculate salary range from min/max if provided
        $salary_range = null;
        $salary_min = null;
        $salary_max = null;
        
        if (!empty($_POST['salary_min']) && !empty($_POST['salary_max'])) {
            $salary_min = floatval($_POST['salary_min']);
            $salary_max = floatval($_POST['salary_max']);
            $salary_range = "₱" . number_format($salary_min, 2) . " - ₱" . number_format($salary_max, 2);
        } elseif (!empty($_POST['salary_min'])) {
            $salary_min = floatval($_POST['salary_min']);
            $salary_range = "₱" . number_format($salary_min, 2) . " and above";
        } elseif (!empty($_POST['salary_max'])) {
            $salary_max = floatval($_POST['salary_max']);
            $salary_range = "Up to ₱" . number_format($salary_max, 2);
        }
        
        // Get department name from department_id
        $department_name = '';
        $department_id = null;
        
        if (!empty($_POST['department_id'])) {
            $department_id = $_POST['department_id'];
            // Find department name
            foreach ($departments as $dept) {
                if ($dept['id'] == $department_id) {
                    $department_name = $dept['name'];
                    break;
                }
            }
        }
        
        // If no department_id but we have department name in form
        if (empty($department_name) && !empty($_POST['department'])) {
            $department_name = $_POST['department'];
        }
        
        $data = [
            'job_title' => $_POST['job_title'] ?? '',
            'job_code' => $_POST['job_code'] ?? '',
            'department' => $department_name,
            'department_id' => $department_id,
            'location' => $_POST['location'] ?? '',
            'employment_type' => $_POST['employment_type'] ?? 'full_time',
            'salary_range' => $salary_range,
            'salary_min' => $salary_min,
            'salary_max' => $salary_max,
            'experience_level' => $_POST['experience_level'] ?? 'mid',
            'description' => $_POST['description'] ?? '',
            'requirements' => $_POST['requirements'] ?? '',
            'responsibilities' => $_POST['responsibilities'] ?? '',
            'benefits' => $_POST['benefits'] ?? '',
            'status' => $_POST['status'] ?? 'draft',
            'vacancies' => $_POST['vacancies'] ?? 1,
            'published_date' => $_POST['published_date'] ?? null,
            'closing_date' => $_POST['closing_date'] ?? null,
            'posting_date' => $_POST['published_date'] ?? $posting['posting_date'] ?? date('Y-m-d')
        ];
        
        // Remove null values for optional fields
        foreach ($data as $key => $value) {
            if (is_null($value)) {
                unset($data[$key]);
            }
        }
        
        if (updateJobPosting($id, $data)) {
            header('Location: job_postings.php?success=updated');
            exit();
        } else {
            $error = "Failed to update job posting. Please try again.";
        }
    } catch (Exception $e) {
        error_log("Error updating job posting: " . $e->getMessage());
        $error = "An error occurred while updating the job posting.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>HR1 - Edit Job Posting</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
</head>

<body class="h-screen bg-gray-100 font-sans">
<div class="flex h-full">
  <?php include 'sidebar.php'; ?>
  
  <div class="flex-1 flex flex-col overflow-y-auto">
    <main class="p-6">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-gray-300 pb-4 mb-6">
        <div>
          <h2 class="text-2xl font-bold text-gray-800">Edit Job Posting</h2>
          <p class="text-sm text-gray-600">Edit the details for job posting #<?php echo htmlspecialchars($posting['job_code']); ?></p>
        </div>
        <div class="flex items-center space-x-4">
          <?php include 'profile_dropdown.php'; ?>
        </div>
      </div>

      <?php if (!empty($error)): ?>
      <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
        <?php echo htmlspecialchars($error); ?>
      </div>
      <?php endif; ?>

      <form method="POST" class="bg-white rounded-lg shadow p-6">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          <!-- Basic Information -->
          <div class="space-y-4">
            <h3 class="text-lg font-semibold text-gray-800">Basic Information</h3>
            
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">Job Title *</label>
              <input type="text" name="job_title" value="<?php echo htmlspecialchars($posting['job_title']); ?>" required
                     class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
            
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">Job Code *</label>
              <input type="text" name="job_code" value="<?php echo htmlspecialchars($posting['job_code']); ?>" required
                     class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
            
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">Department *</label>
              <select name="department_id" required
                      class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="">Select Department</option>
                <?php foreach ($departments as $dept): 
                  $selected = '';
                  if (isset($posting['department_id']) && $posting['department_id'] == $dept['id']) {
                    $selected = 'selected';
                  } elseif ($posting['department'] == $dept['name']) {
                    $selected = 'selected';
                  }
                ?>
                <option value="<?php echo htmlspecialchars($dept['id']); ?>" <?php echo $selected; ?>>
                  <?php echo htmlspecialchars($dept['name']); ?>
                </option>
                <?php endforeach; ?>
              </select>
              <?php if (empty($posting['department_id']) && !empty($posting['department'])): ?>
              <input type="hidden" name="department" value="<?php echo htmlspecialchars($posting['department']); ?>">
              <?php endif; ?>
            </div>
            
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">Location</label>
              <input type="text" name="location" value="<?php echo htmlspecialchars($posting['location'] ?? ''); ?>"
                     class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
            
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">Number of Vacancies</label>
              <input type="number" name="vacancies" min="1" value="<?php echo htmlspecialchars($posting['vacancies'] ?? 1); ?>"
                     class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
          </div>

          <!-- Job Details -->
          <div class="space-y-4">
            <h3 class="text-lg font-semibold text-gray-800">Job Details</h3>
            
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">Employment Type</label>
              <select name="employment_type"
                      class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="full_time" <?php echo ($posting['employment_type'] ?? 'full_time') == 'full_time' ? 'selected' : ''; ?>>Full Time</option>
                <option value="part_time" <?php echo ($posting['employment_type'] ?? 'full_time') == 'part_time' ? 'selected' : ''; ?>>Part Time</option>
                <option value="contract" <?php echo ($posting['employment_type'] ?? 'full_time') == 'contract' ? 'selected' : ''; ?>>Contract</option>
                <option value="temporary" <?php echo ($posting['employment_type'] ?? 'full_time') == 'temporary' ? 'selected' : ''; ?>>Temporary</option>
                <option value="internship" <?php echo ($posting['employment_type'] ?? 'full_time') == 'internship' ? 'selected' : ''; ?>>Internship</option>
              </select>
            </div>
            
            <div class="grid grid-cols-2 gap-4">
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Salary Min (₱)</label>
                <input type="number" name="salary_min" step="0.01" min="0" 
                       value="<?php echo htmlspecialchars($salary_min); ?>"
                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500" 
                       placeholder="0.00">
              </div>
              
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Salary Max (₱)</label>
                <input type="number" name="salary_max" step="0.01" min="0" 
                       value="<?php echo htmlspecialchars($salary_max); ?>"
                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                       placeholder="0.00">
              </div>
            </div>
            
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">Experience Level</label>
              <select name="experience_level"
                      class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="entry" <?php echo ($posting['experience_level'] ?? 'mid') == 'entry' ? 'selected' : ''; ?>>Entry Level</option>
                <option value="mid" <?php echo ($posting['experience_level'] ?? 'mid') == 'mid' ? 'selected' : ''; ?>>Mid Level</option>
                <option value="senior" <?php echo ($posting['experience_level'] ?? 'mid') == 'senior' ? 'selected' : ''; ?>>Senior Level</option>
                <option value="executive" <?php echo ($posting['experience_level'] ?? 'mid') == 'executive' ? 'selected' : ''; ?>>Executive</option>
              </select>
            </div>
            
            <div class="grid grid-cols-2 gap-4">
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Published Date</label>
                <input type="date" name="published_date" 
                       value="<?php echo $posting['published_date'] ? date('Y-m-d', strtotime($posting['published_date'])) : ''; ?>"
                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
              </div>
              
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Closing Date</label>
                <input type="date" name="closing_date" 
                       value="<?php echo $posting['closing_date'] ? date('Y-m-d', strtotime($posting['closing_date'])) : ''; ?>"
                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
              </div>
            </div>
            
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">Status</label>
              <select name="status"
                      class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="draft" <?php echo $posting['status'] == 'draft' ? 'selected' : ''; ?>>Draft</option>
                <option value="active" <?php echo $posting['status'] == 'active' ? 'selected' : ''; ?>>Active</option>
                <option value="closed" <?php echo $posting['status'] == 'closed' ? 'selected' : ''; ?>>Closed</option>
                <option value="archived" <?php echo $posting['status'] == 'archived' ? 'selected' : ''; ?>>Archived</option>
              </select>
            </div>
          </div>
        </div>

        <!-- Rich Text Editors -->
        <div class="mt-8 space-y-6">
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Job Description</label>
            <div id="description-editor" style="height: 200px;"></div>
            <textarea name="description" id="description" class="hidden"><?php echo htmlspecialchars($posting['description'] ?? ''); ?></textarea>
          </div>
          
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Requirements</label>
            <div id="requirements-editor" style="height: 150px;"></div>
            <textarea name="requirements" id="requirements" class="hidden"><?php echo htmlspecialchars($posting['requirements'] ?? ''); ?></textarea>
          </div>
          
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Responsibilities</label>
            <div id="responsibilities-editor" style="height: 150px;"></div>
            <textarea name="responsibilities" id="responsibilities" class="hidden"><?php echo htmlspecialchars($posting['responsibilities'] ?? ''); ?></textarea>
          </div>
          
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Benefits</label>
            <div id="benefits-editor" style="height: 150px;"></div>
            <textarea name="benefits" id="benefits" class="hidden"><?php echo htmlspecialchars($posting['benefits'] ?? ''); ?></textarea>
          </div>
        </div>

        <!-- Form Actions -->
        <div class="flex justify-end space-x-4 mt-8 pt-6 border-t">
          <a href="job_postings.php"
             class="px-6 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 transition-colors">
            Cancel
          </a>
          <a href="delete_posting.php?id=<?php echo $id; ?>" 
             onclick="return confirm('Are you sure you want to delete this job posting?')"
             class="px-6 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors">
            Delete
          </a>
          <button type="submit"
                  class="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors">
            Update Job Posting
          </button>
        </div>
      </form>
    </main>
  </div>
</div>

<script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>
<script>
document.addEventListener("DOMContentLoaded", () => {
  lucide.createIcons();
  
  // Initialize Quill editors
  const editors = {};
  const fields = ['description', 'requirements', 'responsibilities', 'benefits'];
  
  fields.forEach(field => {
    editors[field] = new Quill(`#${field}-editor`, {
      theme: 'snow',
      modules: {
        toolbar: [
          [{ 'header': [1, 2, 3, false] }],
          ['bold', 'italic', 'underline', 'strike'],
          [{ 'list': 'ordered'}, { 'list': 'bullet' }],
          ['link', 'clean']
        ]
      }
    });
    
    // Set initial content from textarea
    const textarea = document.getElementById(field);
    if (textarea && textarea.value) {
      editors[field].root.innerHTML = textarea.value;
    }
    
    // Update hidden textarea on content change
    editors[field].on('text-change', () => {
      document.getElementById(field).value = editors[field].root.innerHTML;
    });
  });
  
  // Form submission
  document.querySelector('form').addEventListener('submit', (e) => {
    // Update all textareas with Quill content
    fields.forEach(field => {
      document.getElementById(field).value = editors[field].root.innerHTML;
    });
    
    // Validate required fields
    const jobTitle = document.querySelector('input[name="job_title"]').value.trim();
    const jobCode = document.querySelector('input[name="job_code"]').value.trim();
    const department = document.querySelector('select[name="department_id"]').value;
    
    if (!jobTitle || !jobCode || !department) {
      e.preventDefault();
      alert('Please fill in all required fields marked with *');
      return false;
    }
    
    // Validate salary range if provided
    const salaryMin = document.querySelector('input[name="salary_min"]').value;
    const salaryMax = document.querySelector('input[name="salary_max"]').value;
    
    if (salaryMin && salaryMax) {
      if (parseFloat(salaryMin) > parseFloat(salaryMax)) {
        e.preventDefault();
        alert('Salary minimum cannot be greater than salary maximum');
        return false;
      }
    }
    
    return true;
  });
  
  // Set min date for closing date to today
  const closingDateInput = document.querySelector('input[name="closing_date"]');
  if (closingDateInput) {
    const today = new Date().toISOString().split('T')[0];
    closingDateInput.min = today;
  }
  
  // Set max date for published date to today
  const publishedDateInput = document.querySelector('input[name="published_date"]');
  if (publishedDateInput) {
    const today = new Date().toISOString().split('T')[0];
    publishedDateInput.max = today;
  }
});
</script>
</body>
</html>