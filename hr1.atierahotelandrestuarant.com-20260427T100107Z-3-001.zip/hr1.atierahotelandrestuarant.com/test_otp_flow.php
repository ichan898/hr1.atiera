<?php
// test_otp_flow.php - Simulate the OTP verification process
session_start();
require_once 'connections.php';
require_once 'email_functions.php';

echo "<h2>OTP Flow Debugger</h2>";

// Step 1: Check if we have a temp user in session
if (isset($_SESSION['temp_user_id']) && isset($_SESSION['temp_user_type'])) {
    echo "<p style='color:green'>✓ Temp user exists in session: ID={$_SESSION['temp_user_id']}, Type={$_SESSION['temp_user_type']}</p>";
    
    // Step 2: Fetch user from database
    try {
        $stmt = $connections->prepare("
            SELECT id, username, email, full_name, role, otp_secret, otp_created_at 
            FROM hr_users 
            WHERE id = ? AND is_active = TRUE
        ");
        $stmt->execute([$_SESSION['temp_user_id']]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($row) {
            echo "<p style='color:green'>✓ User found in database: {$row['email']}</p>";
            echo "<p>Stored OTP: {$row['otp_secret']}</p>";
            echo "<p>OTP created at: {$row['otp_created_at']}</p>";
            
            $otpCreatedAt = strtotime($row['otp_created_at']);
            $expired = (time() - $otpCreatedAt) > 300;
            echo "<p>OTP expired: " . ($expired ? "YES (more than 5 minutes)" : "NO") . "</p>";
            
            // Step 3: Simulate OTP verification with a form
            if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['test_otp'])) {
                $entered_otp = trim($_POST['test_otp']);
                if ($row['otp_secret'] === $entered_otp && !$expired) {
                    echo "<p style='color:green; font-weight:bold'>✓ OTP VERIFICATION WOULD SUCCEED!</p>";
                    echo "<p>Session would be updated with:</p>";
                    echo "<pre>";
                    echo "user_id = {$row['id']}\n";
                    echo "user_name = {$row['full_name']}\n";
                    echo "user_role = {$row['role']}\n";
                    echo "user_email = {$row['email']}\n";
                    echo "user_username = {$row['username']}\n";
                    echo "otp_verified = true\n";
                    echo "user_type = hr\n";
                    echo "</pre>";
                } else {
                    echo "<p style='color:red'>✗ OTP verification would FAIL. Either wrong OTP or expired.</p>";
                }
            } else {
                echo "<form method='POST'>";
                echo "<label>Enter the OTP you received: </label>";
                echo "<input type='text' name='test_otp' placeholder='6-digit code'>";
                echo "<button type='submit'>Test OTP</button>";
                echo "</form>";
            }
        } else {
            echo "<p style='color:red'>✗ User not found in hr_users table (ID={$_SESSION['temp_user_id']})</p>";
        }
    } catch (PDOException $e) {
        echo "<p style='color:red'>Database error: " . $e->getMessage() . "</p>";
    }
} else {
    echo "<p style='color:orange'>⚠ No temp user in session. Please login first (enter email/password or use Google).</p>";
    echo "<p>After logging in, come back to this page.</p>";
}

// Show current full session
echo "<hr><h3>Current Session Data:</h3>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";
?>