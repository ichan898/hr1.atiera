<?php
// File: goals_dashboard.php
$user_id = $_SESSION['user_id'] ?? 0;
$is_manager = checkUserRole($user_id, ['manager', 'supervisor', 'department_head', 'admin', 'hr_manager'], $connections);

// Fetch goals
if ($is_manager) {
    $goalsStmt = $connections->prepare("
        SELECT g.*, CONCAT(e.first_name, ' ', e.last_name) AS employee_name 
        FROM performance_goals g
        JOIN employees e ON g.employee_id = e.id
        ORDER BY g.due_date DESC
    ");
    $goalsStmt->execute();
    $goals = $goalsStmt;
} else {
    // Find the employee_id for this user
    $empStmt = $connections->prepare("SELECT id FROM employees WHERE user_id = ?");
    $empStmt->execute([$user_id]);
    $emp = $empStmt->fetch(PDO::FETCH_ASSOC);
    $employee_id = $emp ? $emp['id'] : 0;
    
    $goalsStmt = $connections->prepare("
        SELECT g.*, CONCAT(e.first_name, ' ', e.last_name) AS employee_name 
        FROM performance_goals g
        JOIN employees e ON g.employee_id = e.id
        WHERE g.employee_id = ?
        ORDER BY g.due_date DESC
    ");
    $goalsStmt->execute([$employee_id]);
    $goals = $goalsStmt;
}
?>
<div class="bg-white rounded-lg shadow p-6">
    <div class="flex justify-between items-center mb-4">
        <h3 class="text-lg font-semibold">Performance Goals</h3>
        <?php if($is_manager): ?>
        <button onclick="showAddGoalModal()" class="px-3 py-1 bg-blue-600 text-white rounded hover:bg-blue-700 text-sm">
            <i data-lucide="plus" class="w-4 h-4 inline"></i> Add Goal
        </button>
        <?php endif; ?>
    </div>

    <!-- Goals List -->
    <div class="space-y-3">
        <?php while($goal = $goals->fetch(PDO::FETCH_ASSOC)): 
            $status_color = [
                'not_started' => 'gray',
                'in_progress' => 'yellow',
                'completed' => 'green',
                'overdue' => 'red'
            ][$goal['status']] ?? 'gray';
        ?>
        <div class="border rounded-lg p-4">
            <div class="flex justify-between items-start">
                <div>
                    <h4 class="font-medium"><?php echo htmlspecialchars($goal['title']); ?></h4>
                    <p class="text-sm text-gray-600">
                        <?php if($is_manager): ?>
                            <?php echo htmlspecialchars($goal['employee_name']); ?> - 
                        <?php endif; ?>
                        Due: <?php echo $goal['due_date'] ? formatDate($goal['due_date']) : 'No due date'; ?>
                    </p>
                </div>
                <span class="status-badge bg-<?php echo $status_color; ?>-100 text-<?php echo $status_color; ?>-800">
                    <?php echo ucfirst(str_replace('_', ' ', $goal['status'])); ?>
                </span>
            </div>
            <div class="mt-3">
                <div class="flex justify-between text-sm mb-1">
                    <span>Progress</span>
                    <span><?php echo $goal['progress']; ?>%</span>
                </div>
                <div class="w-full bg-gray-200 rounded-full h-2">
                    <div class="bg-<?php echo $goal['progress'] == 100 ? 'green' : 'blue'; ?>-600 h-2 rounded-full progress-bar" style="width: <?php echo $goal['progress']; ?>%"></div>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>

    <canvas id="goalsChart" class="mt-6" style="max-height: 300px;"></canvas>
</div>