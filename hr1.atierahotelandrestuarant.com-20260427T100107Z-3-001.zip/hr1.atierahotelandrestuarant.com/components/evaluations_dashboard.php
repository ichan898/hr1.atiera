<?php
// File: evaluations_dashboard.php
$is_admin = checkUserRole($_SESSION['user_id'] ?? 0, ['admin', 'hr_manager'], $connections);

// Fetch upcoming/completed appraisals – use correct column: appraisal_date
$appraisalsStmt = $connections->prepare("
    SELECT a.*, CONCAT(e.first_name, ' ', e.last_name) AS employee_name, t.template_name 
    FROM appraisals a
    JOIN employees e ON a.employee_id = e.id
    LEFT JOIN appraisal_templates t ON a.template_id = t.template_id
    ORDER BY a.appraisal_date DESC
    LIMIT 10
");
$appraisalsStmt->execute();
$appraisals = $appraisalsStmt;
?>
<div class="bg-white rounded-lg shadow p-4">
    <div class="flex justify-between items-center mb-4">
        <h3 class="text-lg font-semibold">Performance Evaluations</h3>
        <?php if($is_admin): ?>
        <button onclick="showScheduleAppraisalModal()" class="px-3 py-1 bg-blue-600 text-white rounded hover:bg-blue-700 text-sm">
            <i data-lucide="calendar" class="w-4 h-4 inline"></i> Schedule Appraisal
        </button>
        <?php endif; ?>
    </div>

    <div class="space-y-3">
        <?php while($app = $appraisals->fetch(PDO::FETCH_ASSOC)): ?>
        <div class="border rounded-lg p-3 flex justify-between items-center">
            <div>
                <h4 class="font-medium"><?php echo htmlspecialchars($app['employee_name']); ?> - <?php echo htmlspecialchars($app['template_name'] ?: 'Review'); ?></h4>
                <p class="text-sm text-gray-500">
                    <?php echo $app['status'] == 'scheduled' ? 'Scheduled: ' . formatDate($app['appraisal_date']) : 'Completed: ' . formatDate($app['appraisal_date']); ?>
                </p>
            </div>
            <span class="status-badge bg-<?php echo $app['status'] == 'completed' ? 'green' : ($app['status'] == 'scheduled' ? 'blue' : 'gray'); ?>-100 text-<?php echo $app['status'] == 'completed' ? 'green' : ($app['status'] == 'scheduled' ? 'blue' : 'gray'); ?>-800">
                <?php echo ucfirst($app['status']); ?>
            </span>
        </div>
        <?php endwhile; ?>
    </div>

    <canvas id="evaluationChart" class="mt-4" style="max-height: 200px;"></canvas>
</div>