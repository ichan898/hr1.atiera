<?php
// File: performance_overview.php
$totalStmt = $connections->query("SELECT COUNT(*) FROM employees WHERE status = 'Active'");
$total_employees = $totalStmt ? $totalStmt->fetchColumn() : 0;

$avgStmt = $connections->query("SELECT AVG(overall_rating) FROM appraisals WHERE status = 'completed'");
$avg_performance = $avgStmt ? $avgStmt->fetchColumn() : 4.2;

$pendingStmt = $connections->query("SELECT COUNT(*) FROM appraisals WHERE status = 'scheduled'");
$pending_reviews = $pendingStmt ? $pendingStmt->fetchColumn() : 0;

$completedStmt = $connections->query("SELECT COUNT(*) FROM performance_goals WHERE status = 'completed'");
$goals_completed = $completedStmt ? $completedStmt->fetchColumn() : 0;

$recentStmt = $connections->prepare("
    SELECT a.*, CONCAT(e.first_name, ' ', e.last_name) AS full_name
    FROM appraisals a
    JOIN employees e ON a.employee_id = e.id
    WHERE a.status = 'completed'
    ORDER BY a.appraisal_date DESC
    LIMIT 5
");
$recentStmt->execute();
$recent_appraisals = $recentStmt;
?>
<div class="grid grid-cols-1 md:grid-cols-4 gap-4">
    <div class="bg-white rounded-lg shadow p-4">
        <div class="flex items-center">
            <div class="p-3 bg-blue-100 rounded-full">
                <i data-lucide="users" class="w-6 h-6 text-blue-600"></i>
            </div>
            <div class="ml-4">
                <p class="text-sm text-gray-500">Total Employees</p>
                <p class="text-2xl font-semibold"><?php echo $total_employees; ?></p>
            </div>
        </div>
    </div>
    <div class="bg-white rounded-lg shadow p-4">
        <div class="flex items-center">
            <div class="p-3 bg-green-100 rounded-full">
                <i data-lucide="trending-up" class="w-6 h-6 text-green-600"></i>
            </div>
            <div class="ml-4">
                <p class="text-sm text-gray-500">Avg Performance</p>
                <p class="text-2xl font-semibold"><?php echo number_format($avg_performance, 1); ?>/5</p>
            </div>
        </div>
    </div>
    <div class="bg-white rounded-lg shadow p-4">
        <div class="flex items-center">
            <div class="p-3 bg-yellow-100 rounded-full">
                <i data-lucide="clock" class="w-6 h-6 text-yellow-600"></i>
            </div>
            <div class="ml-4">
                <p class="text-sm text-gray-500">Pending Reviews</p>
                <p class="text-2xl font-semibold"><?php echo $pending_reviews; ?></p>
            </div>
        </div>
    </div>
    <div class="bg-white rounded-lg shadow p-4">
        <div class="flex items-center">
            <div class="p-3 bg-purple-100 rounded-full">
                <i data-lucide="target" class="w-6 h-6 text-purple-600"></i>
            </div>
            <div class="ml-4">
                <p class="text-sm text-gray-500">Goals Completed</p>
                <p class="text-2xl font-semibold"><?php echo $goals_completed; ?></p>
            </div>
        </div>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-4 mt-4">
    <div class="bg-white rounded-lg shadow p-4">
        <h3 class="text-md font-semibold mb-3">Performance Distribution</h3>
        <canvas id="performanceDistributionChart" style="max-height: 250px;"></canvas>
    </div>
    <div class="bg-white rounded-lg shadow p-4">
        <h3 class="text-md font-semibold mb-3">Performance Trend</h3>
        <canvas id="performanceTrendChart" style="max-height: 250px;"></canvas>
    </div>
</div>

<div class="bg-white rounded-lg shadow p-4 mt-4">
    <h3 class="text-md font-semibold mb-3">Recent Appraisals</h3>
    <table class="min-w-full divide-y divide-gray-200">
        <thead>
            <tr>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Employee</th>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Rating</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-200">
            <?php while($row = $recent_appraisals->fetch(PDO::FETCH_ASSOC)): ?>
            <tr>
                <td class="px-4 py-2"><?php echo htmlspecialchars($row['full_name']); ?></td>
                <td class="px-4 py-2"><?php echo formatDate($row['appraisal_date']); ?></td>
                <td class="px-4 py-2"><?php echo $row['overall_rating'] ? number_format($row['overall_rating'],1) : 'N/A'; ?></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>