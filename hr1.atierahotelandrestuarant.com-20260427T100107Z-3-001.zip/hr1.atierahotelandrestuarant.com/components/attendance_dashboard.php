<?php
// File: attendance_dashboard.php
$today = date('Y-m-d');

// Summary counts – use attendance_date
$summaryStmt = $connections->prepare("
    SELECT 
        SUM(status = 'present') as present,
        SUM(status = 'absent') as absent,
        SUM(status = 'late') as late,
        SUM(status = 'leave') as on_leave
    FROM attendance 
    WHERE attendance_date = ?
");
$summaryStmt->execute([$today]);
$summary = $summaryStmt->fetch(PDO::FETCH_ASSOC);

// Recent attendance – use attendance_date and id
$recentStmt = $connections->prepare("
    SELECT a.*, CONCAT(e.first_name, ' ', e.last_name) AS full_name
    FROM attendance a
    JOIN employees e ON a.employee_id = e.id
    ORDER BY a.attendance_date DESC, a.id DESC
    LIMIT 10
");
$recentStmt->execute();
$recent = $recentStmt;
?>
<div class="bg-white rounded-lg shadow p-4">
    <div class="flex justify-between items-center mb-4">
        <h3 class="text-lg font-semibold">Attendance Overview</h3>
        <button onclick="showMarkAttendanceModal()" class="px-3 py-1 bg-blue-600 text-white rounded hover:bg-blue-700 text-sm">
            <i data-lucide="calendar-check" class="w-4 h-4 inline"></i> Mark Attendance
        </button>
    </div>

    <div class="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
        <div class="bg-green-50 p-3 rounded">
            <p class="text-sm text-gray-600">Present Today</p>
            <p class="text-xl font-bold"><?php echo intval($summary['present'] ?? 0); ?></p>
        </div>
        <div class="bg-red-50 p-3 rounded">
            <p class="text-sm text-gray-600">Absent</p>
            <p class="text-xl font-bold"><?php echo intval($summary['absent'] ?? 0); ?></p>
        </div>
        <div class="bg-yellow-50 p-3 rounded">
            <p class="text-sm text-gray-600">Late</p>
            <p class="text-xl font-bold"><?php echo intval($summary['late'] ?? 0); ?></p>
        </div>
        <div class="bg-blue-50 p-3 rounded">
            <p class="text-sm text-gray-600">On Leave</p>
            <p class="text-xl font-bold"><?php echo intval($summary['on_leave'] ?? 0); ?></p>
        </div>
    </div>

    <canvas id="attendanceTrendChart" style="max-height: 250px;"></canvas>

    <h4 class="font-medium mt-4 mb-2">Recent Attendance</h4>
    <table class="min-w-full divide-y divide-gray-200">
        <thead>
            <tr>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Employee</th>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
            </tr>
        </thead>
        <tbody>
            <?php while($row = $recent->fetch(PDO::FETCH_ASSOC)): ?>
            <tr>
                <td class="px-4 py-2"><?php echo htmlspecialchars($row['full_name']); ?></td>
                <td class="px-4 py-2"><?php echo formatDate($row['attendance_date']); ?></td>
                <td class="px-4 py-2">
                    <span class="status-badge status-<?php echo $row['status']; ?>">
                        <?php echo ucfirst($row['status']); ?>
                    </span>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>