<?php
// File: performance_modals.php
$employees = getEmployeeList($connections);
$criteria_list = getActiveCriteria($connections);
$templates_list = getActiveTemplates($connections);
?>

<!-- Add Goal Modal -->
<div id="addGoalModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden items-center justify-center z-50">
    <div class="bg-white rounded-lg p-6 w-96">
        <h3 class="text-lg font-medium mb-4">Add Performance Goal</h3>
        <form method="POST" action="performance.php?tab=goals">
            <div class="space-y-3">
                <div>
                    <label class="block text-sm font-medium text-gray-700">Employee</label>
                    <select name="employee_id" class="mt-1 block w-full border rounded p-2" required>
                        <option value="">Select employee...</option>
                        <?php foreach($employees as $emp): ?>
                        <option value="<?php echo $emp['id']; ?>"><?php echo htmlspecialchars($emp['full_name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Goal Title</label>
                    <input type="text" name="goal_title" class="mt-1 block w-full border rounded p-2" required>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Description</label>
                    <textarea name="goal_description" class="mt-1 block w-full border rounded p-2"></textarea>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Due Date</label>
                    <input type="date" name="goal_due" class="mt-1 block w-full border rounded p-2">
                </div>
            </div>
            <div class="mt-4 flex justify-end space-x-2">
                <button type="button" onclick="hideModal('addGoalModal')" class="px-4 py-2 bg-gray-200 rounded">Cancel</button>
                <button type="submit" name="add_goal" class="px-4 py-2 bg-blue-600 text-white rounded">Save</button>
            </div>
        </form>
    </div>
</div>

<!-- Mark Attendance Modal -->
<div id="markAttendanceModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden items-center justify-center z-50">
    <div class="bg-white rounded-lg p-6 w-96">
        <h3 class="text-lg font-medium mb-4">Mark Attendance</h3>
        <form method="POST" action="performance.php?tab=attendance">
            <div class="space-y-3">
                <div>
                    <label class="block text-sm font-medium text-gray-700">Employee</label>
                    <select name="employee_id" class="mt-1 block w-full border rounded p-2" required>
                        <option value="">Select employee...</option>
                        <?php foreach($employees as $emp): ?>
                        <option value="<?php echo $emp['id']; ?>"><?php echo htmlspecialchars($emp['full_name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Date</label>
                    <input type="date" name="attendance_date" class="mt-1 block w-full border rounded p-2" value="<?php echo date('Y-m-d'); ?>">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Status</label>
                    <select name="status" class="mt-1 block w-full border rounded p-2" required>
                        <option value="present">Present</option>
                        <option value="absent">Absent</option>
                        <option value="late">Late</option>
                        <option value="leave">On Leave</option>
                    </select>
                </div>
            </div>
            <div class="mt-4 flex justify-end space-x-2">
                <button type="button" onclick="hideModal('markAttendanceModal')" class="px-4 py-2 bg-gray-200 rounded">Cancel</button>
                <button type="submit" name="update_attendance" class="px-4 py-2 bg-blue-600 text-white rounded">Save</button>
            </div>
        </form>
    </div>
</div>

<!-- Schedule Appraisal Modal -->
<div id="scheduleAppraisalModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden items-center justify-center z-50">
    <div class="bg-white rounded-lg p-6 w-96">
        <h3 class="text-lg font-medium mb-4">Schedule Appraisal</h3>
        <form method="POST" action="performance.php?tab=evaluations">
            <div class="space-y-3">
                <div>
                    <label class="block text-sm font-medium text-gray-700">Employee</label>
                    <select name="employee_id" class="mt-1 block w-full border rounded p-2" required>
                        <option value="">Select...</option>
                        <?php foreach($employees as $emp): ?>
                        <option value="<?php echo $emp['id']; ?>"><?php echo htmlspecialchars($emp['full_name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Appraisal Date</label>
                    <input type="date" name="appraisal_date" class="mt-1 block w-full border rounded p-2" required>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Template</label>
                    <select name="template_id" class="mt-1 block w-full border rounded p-2">
                        <option value="">None</option>
                        <?php foreach($templates_list as $tpl): ?>
                        <option value="<?php echo $tpl['template_id']; ?>"><?php echo htmlspecialchars($tpl['template_name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="mt-4 flex justify-end space-x-2">
                <button type="button" onclick="hideModal('scheduleAppraisalModal')" class="px-4 py-2 bg-gray-200 rounded">Cancel</button>
                <button type="submit" name="schedule_appraisal" class="px-4 py-2 bg-blue-600 text-white rounded">Schedule</button>
            </div>
        </form>
    </div>
</div>

<!-- Add Criteria Modal -->
<div id="addCriteriaModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden items-center justify-center z-50">
    <div class="bg-white rounded-lg p-6 w-96">
        <h3 class="text-lg font-medium mb-4">Add Appraisal Criteria</h3>
        <form method="POST" action="performance.php?tab=configuration">
            <div class="space-y-3">
                <div>
                    <label class="block text-sm font-medium text-gray-700">Criteria Name</label>
                    <input type="text" name="criteria_name" class="mt-1 block w-full border rounded p-2" required>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Description</label>
                    <textarea name="criteria_desc" class="mt-1 block w-full border rounded p-2"></textarea>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Weight (%)</label>
                    <input type="number" name="weight" min="0" max="100" class="mt-1 block w-full border rounded p-2">
                </div>
            </div>
            <div class="mt-4 flex justify-end space-x-2">
                <button type="button" onclick="hideModal('addCriteriaModal')" class="px-4 py-2 bg-gray-200 rounded">Cancel</button>
                <button type="submit" name="add_criteria" class="px-4 py-2 bg-blue-600 text-white rounded">Add</button>
            </div>
        </form>
    </div>
</div>

<!-- Add Template Modal -->
<div id="addTemplateModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden items-center justify-center z-50">
    <div class="bg-white rounded-lg p-6 w-96">
        <h3 class="text-lg font-medium mb-4">Add Evaluation Template</h3>
        <form method="POST" action="performance.php?tab=configuration">
            <div class="space-y-3">
                <div>
                    <label class="block text-sm font-medium text-gray-700">Template Name</label>
                    <input type="text" name="template_name" class="mt-1 block w-full border rounded p-2" required>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Description</label>
                    <textarea name="template_desc" class="mt-1 block w-full border rounded p-2"></textarea>
                </div>
            </div>
            <div class="mt-4 flex justify-end space-x-2">
                <button type="button" onclick="hideModal('addTemplateModal')" class="px-4 py-2 bg-gray-200 rounded">Cancel</button>
                <button type="submit" name="add_template" class="px-4 py-2 bg-blue-600 text-white rounded">Add</button>
            </div>
        </form>
    </div>
</div>

<script>
// Functions to show/hide modals
function showModal(modalId) {
    document.getElementById(modalId).classList.remove('hidden');
    document.getElementById(modalId).classList.add('flex');
}

function hideModal(modalId) {
    document.getElementById(modalId).classList.add('hidden');
    document.getElementById(modalId).classList.remove('flex');
}

function showAddGoalModal() { showModal('addGoalModal'); }
function showMarkAttendanceModal() { showModal('markAttendanceModal'); }
function showScheduleAppraisalModal() { showModal('scheduleAppraisalModal'); }
function showAddCriteriaModal() { showModal('addCriteriaModal'); }
function showAddTemplateModal() { showModal('addTemplateModal'); }
</script>