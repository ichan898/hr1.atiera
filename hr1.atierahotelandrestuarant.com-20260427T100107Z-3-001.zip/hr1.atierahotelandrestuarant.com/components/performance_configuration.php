<?php
// File: performance_configuration.php
if(!checkUserRole($_SESSION['user_id'] ?? 0, ['admin', 'hr_manager'], $connections)) {
    echo '<p class="text-red-500">Access denied.</p>';
    return;
}

// Fetch existing criteria
$criteriaStmt = $connections->query("SELECT * FROM appraisal_criteria WHERE is_active = 1 ORDER BY criteria_name");
$criteria = $criteriaStmt ? $criteriaStmt : null;

// Fetch existing templates
$templatesStmt = $connections->query("SELECT * FROM appraisal_templates WHERE is_active = 1 ORDER BY template_name");
$templates = $templatesStmt ? $templatesStmt : null;
?>
<div class="bg-white rounded-lg shadow p-4">
    <h3 class="text-lg font-semibold mb-4">Performance Configuration</h3>

    <div class="grid md:grid-cols-2 gap-4">
        <!-- Appraisal Criteria -->
        <div class="border rounded p-3">
            <h4 class="font-medium mb-2">Appraisal Criteria</h4>
            <ul class="text-sm space-y-1">
                <?php if($criteria): while($row = $criteria->fetch(PDO::FETCH_ASSOC)): ?>
                <li><?php echo htmlspecialchars($row['criteria_name']); ?> (Weight: <?php echo $row['default_weight']; ?>%)</li>
                <?php endwhile; endif; ?>
            </ul>
            <button onclick="showAddCriteriaModal()" class="mt-2 text-blue-600 text-sm">+ Add Criteria</button>
        </div>

        <!-- Evaluation Templates -->
        <div class="border rounded p-3">
            <h4 class="font-medium mb-2">Evaluation Templates</h4>
            <ul class="text-sm space-y-1">
                <?php if($templates): while($row = $templates->fetch(PDO::FETCH_ASSOC)): ?>
                <li><?php echo htmlspecialchars($row['template_name']); ?></li>
                <?php endwhile; endif; ?>
            </ul>
            <button onclick="showAddTemplateModal()" class="mt-2 text-blue-600 text-sm">+ Add Template</button>
        </div>
    </div>

    <!-- Settings Form (example) -->
    <div class="mt-4 border-t pt-4">
        <h4 class="font-medium mb-2">Settings</h4>
        <form method="POST" action="performance.php?tab=configuration">
            <label class="block text-sm mb-2">
                <span>Review Period (months)</span>
                <input type="number" name="review_period" value="12" class="mt-1 block w-full border rounded p-2">
            </label>
            <button type="submit" name="save_settings" class="px-4 py-2 bg-blue-600 text-white rounded">Save Settings</button>
        </form>
    </div>
</div>