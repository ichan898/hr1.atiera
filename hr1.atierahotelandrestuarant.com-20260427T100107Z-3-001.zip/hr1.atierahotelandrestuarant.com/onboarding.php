<?php
// File: onboarding.php (replaces job_offers.php)
session_start();
require_once 'connections.php';
require_once 'functions.php'; // Include functions instead
require_once 'process_onboarding.php';
requireAuth(); // This will work now

// Get onboarding employees
$status = $_GET['status'] ?? 'onboarding';

$query = "SELECT * FROM onboarding WHERE 1=1";
$params = [];

if ($status && $status != 'all') {
    $query .= " AND status = ?";
    $params[] = $status;
}

$query .= " ORDER BY created_at DESC";

$stmt = $connections->prepare($query);
$stmt->execute($params);
$employees = $stmt->fetchAll();

// Get stats
$stats_stmt = $connections->prepare("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'onboarding' THEN 1 ELSE 0 END) as onboarding,
        SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed
    FROM onboarding
");
$stats_stmt->execute();
$stats = $stats_stmt->fetch();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>HR1 - Onboarding</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<script>
function toggleModal(id) {
    document.getElementById(id).classList.toggle('hidden');
}
</script>
</head>

<body class="h-screen bg-gray-100 font-sans">
<div class="flex h-full">
  
  <!-- Sidebar -->
  <?php include 'sidebar.php'; ?>
  
  <!-- Main Content -->
  <div class="flex-1 flex flex-col overflow-y-auto">
    <main class="p-6 space-y-6">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-gray-300 pb-4">
        <div>
          <h2 class="text-2xl font-bold text-gray-800">Onboarding</h2>
          <p class="text-sm text-gray-600">Manage new employee onboarding process</p>
        </div>
        <div class="flex items-center space-x-4">
          <!--<a href="add_onboarding.php" class="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">-->
          <!--  <i data-lucide="user-plus" class="w-4 h-4"></i>-->
          <!--  <span>Add Employee</span>-->
          <!--</a>-->
          <?php include 'profile_dropdown.php'; ?>
        </div>
      </div>

      <!-- Stats -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div class="bg-white p-6 rounded-lg shadow border">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-600">Total Onboarding</p>
              <p class="text-2xl font-bold text-gray-800"><?php echo $stats['total']; ?></p>
            </div>
            <i data-lucide="users" class="w-8 h-8 text-blue-500"></i>
          </div>
        </div>
        
        <div class="bg-white p-6 rounded-lg shadow border border-l-4 border-l-yellow-500">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-600">Onboarding</p>
              <p class="text-2xl font-bold text-gray-800"><?php echo $stats['onboarding']; ?></p>
            </div>
            <i data-lucide="clock" class="w-8 h-8 text-yellow-500"></i>
          </div>
        </div>
        
        <div class="bg-white p-6 rounded-lg shadow border border-l-4 border-l-green-500">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-600">Active</p>
              <p class="text-2xl font-bold text-gray-800"><?php echo $stats['active']; ?></p>
            </div>
            <i data-lucide="check-circle" class="w-8 h-8 text-green-500"></i>
          </div>
        </div>
        
        <div class="bg-white p-6 rounded-lg shadow border border-l-4 border-l-gray-500">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-600">Completed</p>
              <p class="text-2xl font-bold text-gray-800"><?php echo $stats['completed']; ?></p>
            </div>
            <i data-lucide="flag" class="w-8 h-8 text-gray-500"></i>
          </div>
        </div>
      </div>

      <!-- Tabs -->
      <div class="bg-white rounded-lg shadow">
        <div class="border-b">
          <nav class="flex -mb-px">
            <a href="?status=onboarding" class="py-4 px-6 border-b-2 font-medium text-sm 
              <?php echo $status == 'onboarding' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'; ?>">
              Onboarding (<?php echo $stats['onboarding']; ?>)
            </a>
            <a href="?status=active" class="py-4 px-6 border-b-2 font-medium text-sm 
              <?php echo $status == 'active' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'; ?>">
              Active (<?php echo $stats['active']; ?>)
            </a>
            <a href="?status=completed" class="py-4 px-6 border-b-2 font-medium text-sm 
              <?php echo $status == 'completed' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'; ?>">
              Completed (<?php echo $stats['completed']; ?>)
            </a>
            <a href="?status=all" class="py-4 px-6 border-b-2 font-medium text-sm 
              <?php echo $status == 'all' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'; ?>">
              All
            </a>
          </nav>
        </div>

        <!-- Onboarding Table -->
        <div class="overflow-x-auto">
          <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
              <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Employee</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Position</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Hire Date</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Onboarding Tasks</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
              <?php foreach($employees as $employee): ?>
              <tr class="hover:bg-gray-50">
                <td class="px-6 py-4">
                  <div class="flex items-center">
                    <div class="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center mr-3">
                      <i data-lucide="user" class="w-5 h-5 text-gray-600"></i>
                    </div>
                    <div>
                      <div class="text-sm font-medium text-gray-900">
                        <?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?>
                      </div>
                      <div class="text-sm text-gray-500">ID: <?php echo $employee['employee_id']; ?></div>
                    </div>
                  </div>
                </td>
                <td class="px-6 py-4 text-sm text-gray-900"><?php echo htmlspecialchars($employee['job_position']); ?></td>
                <td class="px-6 py-4 text-sm text-gray-500"><?php echo date('M d, Y', strtotime($employee['hire_date'])); ?></td>
                <td class="px-6 py-4">
                  <div class="flex items-center space-x-2">
                    <span class="text-sm <?php echo $employee['contract_signed'] ? 'text-green-600' : 'text-gray-400'; ?>">
                      <i data-lucide="<?php echo $employee['contract_signed'] ? 'check-circle' : 'circle'; ?>" class="w-4 h-4"></i>
                    </span>
                    <span class="text-sm <?php echo $employee['documents_complete'] ? 'text-green-600' : 'text-gray-400'; ?>">
                      <i data-lucide="<?php echo $employee['documents_complete'] ? 'check-circle' : 'circle'; ?>" class="w-4 h-4"></i>
                    </span>
                    <span class="text-sm <?php echo $employee['orientation_complete'] ? 'text-green-600' : 'text-gray-400'; ?>">
                      <i data-lucide="<?php echo $employee['orientation_complete'] ? 'check-circle' : 'circle'; ?>" class="w-4 h-4"></i>
                    </span>
                  </div>
                </td>
                <td class="px-6 py-4">
                  <span class="px-3 py-1 text-xs rounded-full 
                    <?php echo $employee['status'] == 'onboarding' ? 'bg-yellow-100 text-yellow-800' : 
                           ($employee['status'] == 'active' ? 'bg-green-100 text-green-800' : 
                           'bg-gray-100 text-gray-800'); ?>">
                    <?php echo ucfirst($employee['status']); ?>
                  </span>
                </td>
                <td class="px-6 py-4">
                  <div class="flex space-x-2">
                    <a href="view_onboarding.php?id=<?php echo $employee['id']; ?>" 
                       class="px-3 py-1 text-sm bg-gray-100 rounded hover:bg-gray-200">
                      <i data-lucide="eye" class="w-4 h-4"></i>
                    </a>
                    
                    <?php if($employee['status'] == 'onboarding' && !$employee['contract_signed']): ?>
                    <button onclick="toggleModal('contract<?php echo $employee['id']; ?>')"
                            class="px-3 py-1 text-sm bg-blue-100 text-blue-700 rounded hover:bg-blue-200">
                      <i data-lucide="file-text" class="w-4 h-4"></i>
                    </button>
                    <?php endif; ?>
                    
                    <?php if($employee['status'] == 'onboarding' && $employee['contract_signed']): ?>
                    <a href="complete_onboarding.php?id=<?php echo $employee['id']; ?>" 
                       class="px-3 py-1 text-sm bg-green-100 text-green-700 rounded hover:bg-green-200">
                      <i data-lucide="check" class="w-4 h-4"></i>
                    </a>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
          
          <?php if(empty($employees)): ?>
          <div class="text-center py-12">
            <i data-lucide="users" class="w-12 h-12 text-gray-400 mx-auto mb-4"></i>
            <p class="text-gray-500">No employees in onboarding</p>
            <a href="add_onboarding.php" class="mt-2 inline-block text-blue-600 hover:underline">
              Add your first employee to onboarding
            </a>
          </div>
          <?php endif; ?>
        </div>
      </div>
    </main>
  </div>
</div>

<!-- CONTRACT PDF MODALS -->
<?php foreach ($employees as $employee): ?>
<?php if ($employee['status'] === 'onboarding' && !$employee['contract_signed']): ?>
<div id="contract<?php echo $employee['id']; ?>"
     class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">

  <div class="bg-white rounded-lg shadow-lg flex flex-col w-full max-w-4xl md:max-w-5xl lg:max-w-6xl h-full md:h-auto max-h-[90vh] overflow-hidden">

    <!-- Header -->
    <div class="flex justify-between items-center px-4 md:px-6 py-3 border-b">
      <h2 class="text-lg md:text-xl font-semibold">Employment Contract</h2>
      <button onclick="toggleModal('contract<?php echo $employee['id']; ?>')"
              class="text-gray-500 hover:text-gray-700 text-lg md:text-xl">✕</button>
    </div>

    <!-- PDF Viewer -->
    <div class="flex-1 overflow-auto">
      <iframe
        src="contract/EMPLOYEE-CONTRACT.pdf"
        class="w-full h-full min-h-[400px]"
        frameborder="0">
      </iframe>
    </div>

    <!-- Footer Actions -->
    <form method="POST" action="sign_contract.php"
          class="flex flex-col md:flex-row justify-between items-center gap-3 px-4 md:px-6 py-3 border-t bg-gray-50">

      <input type="hidden" name="employee_id" value="<?php echo $employee['id']; ?>">

      <button type="button"
              onclick="document.querySelector('#contract<?php echo $employee['id']; ?> iframe').contentWindow.print()"
              class="w-full md:w-auto px-4 py-2 bg-gray-200 text-gray-800 rounded hover:bg-gray-300">
        🖨 Print
      </button>

      <div class="flex flex-col md:flex-row gap-3 w-full md:w-auto">
        <button type="button"
                onclick="toggleModal('contract<?php echo $employee['id']; ?>')"
                class="px-4 py-2 border rounded w-full md:w-auto">
          Cancel
        </button>

        <button type="submit"
                name="sign_contract"
                class="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 w-full md:w-auto">
          Confirm & Activate
        </button>
      </div>

    </form>
  </div>
</div>
<?php endif; ?>
<?php endforeach; ?>


<script>
document.addEventListener("DOMContentLoaded", () => {
  lucide.createIcons();
});
</script>
</body>
</html>