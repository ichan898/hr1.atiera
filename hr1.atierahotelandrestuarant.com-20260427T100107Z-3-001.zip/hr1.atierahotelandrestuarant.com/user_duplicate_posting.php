<?php
// File: duplicate_posting.php
session_start();
require_once 'connections.php';
require_once 'functions.php';
requireAuth();

$id = $_GET['id'] ?? null;
if (!$id) {
    header('Location: user_job_postings.php');
    exit();
}

// Get the original posting
$posting = getJobPosting($id);
if (!$posting) {
    header('Location: user_job_postings.php?error=notfound');
    exit();
}

// Create a copy with "(Copy)" appended to title and new job code
$newJobCode = $posting['job_code'] . '-COPY-' . date('Ymd');
$data = [
    'job_title' => $posting['job_title'] . ' (Copy)',
    'job_code' => $newJobCode,
    'department' => $posting['department'],
    'location' => $posting['location'],
    'employment_type' => $posting['employment_type'],
    'salary_range' => $posting['salary_range'],
    'experience_level' => $posting['experience_level'],
    'description' => $posting['description'],
    'requirements' => $posting['requirements'],
    'responsibilities' => $posting['responsibilities'],
    'benefits' => $posting['benefits'],
    'status' => 'draft',
    'published_date' => null,
    'closing_date' => null
];

if (createJobPosting($data, $_SESSION['user_id'])) {
    header('Location: user_edit_posting.php?id=' . $connections->lastInsertId() . '&success=duplicated');
} else {
    header('Location: user_job_postings.php?error=duplicate_failed');
}
exit();
?>